*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBBL_CONUM
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBBL_CONUM          .

  PERFORM TABLEPROC.

ENDFUNCTION.
