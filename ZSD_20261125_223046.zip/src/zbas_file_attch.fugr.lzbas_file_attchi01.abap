*$*$-----------------------------------------------------------------$*$
*$*$ Author       : Collabera                                        $*$
*$*$ Creation Date: 02.08.2011                                       $*$
*$*$ Funtion group: /OBIZ/IMP_FILE_ATTCH                             $*$
*$*$ Description  : To upload and download documents                 $*$
*$*$                                                                 $*$
*$*$                                                                 $*$
*$*$-----------------------------------------------------------------$*$
*----------------------------------------------------------------------*
***INCLUDE /OBIZ/LFG_FILE_ATTCHI01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9000  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9000 INPUT.
  sav_okcode = ok_code.
  CASE sav_okcode.

    WHEN 'OK'.
*>>>>>> Insertion Block Starts Here
*Code Added on : 11.01.2007 Under the request
*          By  : SKE
*Reason        : To Clear  The Object Created for ALV grid & Container

      PERFORM free_alv.
*>>>>>> Insertion Blocks Endds Here
      LEAVE TO SCREEN 0.

    WHEN 'CANCEL'.
*>>>>>> Insertion Block Starts Here
*Code Added on : 11.01.2007 Under the request
*          By  : SKE
*Reason        : To Clear  The Object Created for ALV grid & Container
      PERFORM free_alv.
*>>>>>> Insertion Blocks Endds Here
      LEAVE TO SCREEN 0.

  ENDCASE.

ENDMODULE.                 " USER_COMMAND_9000  INPUT
