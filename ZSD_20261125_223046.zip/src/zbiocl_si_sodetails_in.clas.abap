class ZBIOCL_SI_SODETAILS_IN definition
  public
  create public .

public section.

  interfaces ZBIOII_SI_SODETAILS_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOCL_SI_SODETAILS_IN IMPLEMENTATION.


  METHOD zbioii_si_sodetails_in~si_sodetails_in.
*** **** INSERT IMPLEMENTATION HERE **** ***
    TYPES : BEGIN OF ty_saleorder,
              so_number TYPE vbak-vbeln,
            END OF ty_saleorder.
    DATA : it_sonumber TYPE TABLE OF ty_saleorder,
           wa_sonumber TYPE ty_saleorder.

    DATA: lt_nast TYPE TABLE OF nast,
          ls_nast TYPE nast.
    DATA:   retcode   LIKE sy-subrc.         "Returncode
DATA:   xscreen(1) TYPE c.
DATA : fp_formoutput TYPE fpformoutput.

    DATA zso_number TYPE zbiodt_sodetails_req_records. "FOR INPUT
    DATA zoutput_saleorder_details TYPE zbiodt_sodetails_res_records. "FOR OUTPUT.
    DATA zoutput_tt TYPE zbiodt_sodetails_res.
    DATA lt_final TYPE zbiodt_sodetails_res_recor_tab.

    DATA zmaterial_data TYPE  zbiodt_sodetails_res_material.
    DATA zmaterial_data_tt TYPE zbiodt_sodetails_res_mater_tab.
    DATA zobd_data TYPE zbiodt_sodetails_res_obd_detai.
    DATA zobd_data_tt TYPE zbiodt_sodetails_res_obd_d_tab.

    LOOP AT input-mt_sodetails_req-records INTO zso_number.
      wa_sonumber = zso_number-so_number.
      APPEND wa_sonumber TO it_sonumber.
    ENDLOOP.

    SELECT * FROM vbak INTO TABLE @DATA(it_vbak)
                       FOR ALL ENTRIES IN @it_sonumber
                       WHERE vbeln = @it_sonumber-so_number.
    IF it_vbak IS NOT INITIAL.
      SELECT * FROM VBAKUK INTO TABLE @data(it_VBAKUK) FOR ALL ENTRIES IN
                                                       @it_vbak WHERE vbeln = @it_vbak-vbeln.
      SELECT * FROM vbap INTO TABLE @DATA(it_vbap)
                         FOR ALL ENTRIES IN @it_vbak
                         WHERE vbeln = @it_vbak-vbeln.

      SELECT * FROM vbfa INTO TABLE @DATA(it_vbfa)
                         FOR ALL ENTRIES IN @it_vbap
                         WHERE vbelv = @it_vbap-vbeln AND VBTYP_N = 'J'.
        SELECT * FROM VBFA INTO TABLE @DATA(IT_VBFA_M) FOR ALL ENTRIES IN @IT_VBFA WHERE VBELV = @IT_VBFA-vbeln.
      SELECT * FROM kna1 INTO TABLE @DATA(it_kna1)
                         FOR ALL ENTRIES IN @it_vbak
                         WHERE kunnr = @it_vbak-kunnr.
    ENDIF.
    IF it_vbfa IS NOT INITIAL.
      SELECT * FROM lips INTO TABLE @DATA(it_lips)
                         FOR ALL ENTRIES IN @it_vbfa
                         WHERE vbeln = @it_vbfa-vbeln.
      SELECT * FROM vbrk INTO TABLE @DATA(it_vbrk)
                         FOR ALL ENTRIES IN @it_vbfa
                         WHERE vbeln = @it_vbfa-vbeln.
      SELECT * FROM j_1ig_ewaybill INTO TABLE @DATA(it_ewaybill)
                                   FOR ALL ENTRIES IN @it_vbfa
                                   WHERE docno = @it_vbfa-vbeln.

    ENDIF.

    SORT it_vbap ASCENDING BY vbeln posnr.
     sort IT_VBFA_M DESCENDING by vbeln.
    LOOP AT it_vbak INTO DATA(wa_vbak).
      zoutput_saleorder_details-so_number = wa_vbak-vbeln.
*     zoutput_saleorder_details-plant = wa_vbak-werks.
      zoutput_saleorder_details-so_date = wa_vbak-erdat.
      zoutput_saleorder_details-customer_code = wa_vbak-kunnr.
      zoutput_saleorder_details-net_value = wa_vbak-netwr.
      READ TABLE it_kna1 INTO DATA(wa_kna1) WITH KEY kunnr = wa_vbak-kunnr.
      IF sy-subrc = 0.
        zoutput_saleorder_details-customer_name = wa_kna1-name1.
      ENDIF.
      READ TABLE it_VBAKUK INTO data(wa_VBAKUK) with key vbeln = wa_vbak-vbeln.
      IF sy-subrc = 0.
*       zoutput_saleorder_details-so_staus = wa_vbakuk-GBSTK.
       IF wa_vbakuk-GBSTK = 'A'.
          zoutput_saleorder_details-so_staus = 'Not Yet Processed'.
       ELSEIF wa_vbakuk-GBSTK = 'B'.
         zoutput_saleorder_details-so_staus = 'Partially Processed'.
       ELSEIF wa_vbakuk-gbstk = 'C'.
         zoutput_saleorder_details-so_staus = 'Completely Processed'.
       ENDIF.
      ENDIF.
      LOOP AT it_vbap INTO DATA(wa_vbap) WHERE vbeln = wa_vbak-vbeln.
        zmaterial_data-material_code = wa_vbap-matnr.
        zmaterial_data-material_description = wa_vbap-arktx.
        zmaterial_data-order_quantity = wa_vbap-kwmeng.
        zmaterial_data-uom = wa_vbap-vrkme.
        zoutput_saleorder_details-plant = wa_vbap-werks.
*      APPEND zmaterial_data TO zmaterial_data_tt.
        LOOP AT it_vbfa INTO DATA(wa_vbfa) WHERE vbelv = wa_vbap-vbeln AND posnv = wa_vbap-posnr and vbtyp_n = 'J'.
            READ TABLE IT_VBFA_M INTO DATA(WA_VBFA_M) WITH KEY  vbelv = WA_VBFA-VBELN
                                                              vbtyp_n = 'M'.
            IF SY-SUBRC = 0.
               zobd_data-obd_number = wa_vbfa-vbeln.
                zobd_data-invoice = WA_VBFA_M-vbeln.
            ENDIF.

            READ TABLE it_lips INTO DATA(wa_lips) WITH KEY vbeln = wa_vbfa-vbeln
*                                                       posnr = wa_vbap-posnr
                                                       matnr = wa_vbap-matnr.
            IF sy-subrc = 0.
              zobd_data-batch = wa_lips-charg.
              zobd_data-odb_quantity = wa_lips-lfimg.
              delete it_lips WHERE charg = wa_lips-charg and matnr = wa_lips-matnr.
            ENDIF.
            READ TABLE it_vbrk INTO DATA(wa_vbrk) WITH KEY vbeln = wa_vbfa-vbeln.
            IF sy-subrc = 0.
              READ TABLE it_ewaybill INTO DATA(wa_ewaybill) WITH KEY docno = wa_vbfa-vbeln
                                                                     bukrs = wa_vbrk-bukrs
                                                                     doctyp = wa_vbrk-fkart.
              IF sy-subrc = 0.
                zobd_data-airwaybil_number = wa_ewaybill-ebillno.
              ENDIF.
            ENDIF.
            SELECT SINGLE * FROM nast
             INTO ls_nast
              WHERE kappl = 'V3'
              AND objky = WA_VBFA_M-vbeln
              AND kschl = 'ZEDS'.
data : var1 TYPE string.
DATA : PROXY_FLAG TYPE C.

var1 = WA_VBFA_M-vbeln.
PROXY_FLAG = 'X'.
EXPORT name_a FROM var1
       NAME_B FROM PROXY_FLAG
       TO MEMORY ID 'VBELN_KEY'.
                PERFORM processing IN PROGRAM ZSD_EXPORT_INVOICE_DS USING xscreen
                                        CHANGING
*                                        fp_formoutput
                                        retcode .
 import fp_formoutput to fp_formoutput FROm MEMORY id 'INV_ATT'.
* DATA: lv_base64 TYPE string.

CALL FUNCTION 'SCMS_BASE64_ENCODE_STR'
  EXPORTING
    input  = fp_formoutput-pdf
  IMPORTING
    output = zobd_data-invoice_attachment.
*zobd_data-invoice_attachment = fp_formoutput-pdf.

              APPEND zobd_data TO zmaterial_data-obd_details.
            CLEAR : zobd_data.
        ENDLOOP.
        APPEND zmaterial_data TO zoutput_saleorder_details-material_details.
        CLEAR : zmaterial_data.
      ENDLOOP.
      APPEND zoutput_saleorder_details TO output-mt_sodetails_res-records.
      CLEAR : zoutput_saleorder_details.
    ENDLOOP.

***********************************************



  ENDMETHOD.
ENDCLASS.
