class ZCL_IM_SD_DELIVERY definition
  public
  final
  create public .

public section.

  interfaces IF_EX_DELIVERY_PUBLISH .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_SD_DELIVERY IMPLEMENTATION.


  method IF_EX_DELIVERY_PUBLISH~PUBLISH_AFTER_SAVE.
  endmethod.


  method IF_EX_DELIVERY_PUBLISH~PUBLISH_BEFORE_COMMIT.

  endmethod.
ENDCLASS.
