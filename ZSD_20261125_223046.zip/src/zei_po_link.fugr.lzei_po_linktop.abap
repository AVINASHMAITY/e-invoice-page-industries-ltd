FUNCTION-POOL ZEI_PO_LINK                MESSAGE-ID SV.

* INCLUDE LZEI_PO_LINKD...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZEI_PO_LINKT00                         . "view rel. data dcl.
