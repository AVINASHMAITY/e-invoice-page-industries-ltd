class ZCL_IM_SD_BILL_LICENSE definition
  public
  final
  create public .

public section.

  interfaces IF_EX_SD_CIN_LV60AU02 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_SD_BILL_LICENSE IMPLEMENTATION.


  METHOD if_ex_sd_cin_lv60au02~excise_invoice_create.
*    break pushpa.
*    DATA : LS_XVBRP LIKE LINE OF XVBRP.
*    READ TABLE xvbrp INTO LS_XVBRP INDEX 1.
*    LS_xvbrp-zzct3_no = '1'.
*    LS_xvbrp-zzct1_no = '1'.
*    LS_xvbrp-zzct_anx = '1'.
*    LS_xvbrp-zzct_adv = '1'.
*    MODIFY TABLE xvbrp FROM LS_XVBRP TRANSPORTING zzct3_no zzct1_no zzct_anx zzct_adv.
**    MESSAGE 'OK' TYPE 'E'.
  ENDMETHOD.
ENDCLASS.
