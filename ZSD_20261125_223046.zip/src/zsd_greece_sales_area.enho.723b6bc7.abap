"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_GREECE_SALES_AREA.
*&-------------------------------------------------------------------
*Date       : 17.11.2023
*Programmer : Sameek
*TR No.     : DR1K980526
*Description: BB Greece setup -  AM Platinum  Project
*&-------------------------------------------------------------------
data:lwa_e1edk01_hdr type e1edk01.

LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_idoc_hdr>) where segnam = 'E1EDK01' .
lwa_e1edk01_hdr  = <fs_idoc_hdr>-sdata.
IF lwa_e1edk01_hdr-recipnt_no IS NOT INITIAL.
data(l_customer) = lwa_e1edk01_hdr-recipnt_no.
EXPORT l_customer TO MEMORY id 'LV_CUSTOMER'.
ENDIF.
ENDLOOP.

ENDENHANCEMENT.
