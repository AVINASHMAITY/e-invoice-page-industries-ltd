FUNCTION-POOL ZFGLIFSP_UPDATE.              "MESSAGE-ID ..

* INCLUDE LZFGLIFSP_UPDATED...               " Local class definition
