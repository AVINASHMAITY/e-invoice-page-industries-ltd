"Name: \PR:SAPLV60A\FO:USEREXIT_FILL_VBRK_VBRP\SE:END\EI
ENHANCEMENT 0 ZSD_PGI_BACKDATED.
*&--------------------Modification Log-----------------
* 11.01.2021  Bhagavan     DR1K955427      Added Committed Date mandat Code      *
*&-----------------------------------------------------
*BREAK Sahoo.
*****************Begin of changes by Bhagavan on 11/1/2021 DR1K955427******************
  DATA: GT_VKORG TYPE ZTT_ZTABAP_TVARVC,
        GV_FLAG(1).
  CALL METHOD zcl_abap_utility=>get_options
    EXPORTING
      im_objname = 'ZSD_PGI_BACKDATE'
    IMPORTING
      ex_tab     = GT_VKORG
      .
  CLEAR GV_FLAG.
    LOOP AT GT_VKORG INTO DATA(GS_VKORG).
      IF VBRK-vkorg = GS_VKORG-low.
        GV_FLAG = 'X'.
      ENDIF.
    ENDLOOP.

*If vbrk-vkorg = '1101'.                                             "Commented by Bhagavan on 07/1/21 DR1K955427
IF GV_FLAG = 'X'.
*****************End of changes by Bhagavan on 11/1/2021 DR1K955427******************
FIELD-SYMBOLS : <lx_dat> type any.
*FIELD-SYMBOLS : <lx_VBTYP> type any.


  ASSIGN ('(SAPMV60A)RV60A-FKDAT') TO <lx_dat>.
*  ASSIGN ('(SAPMV60A)RV60A-VBTYP') TO <lx_VBTYP>.
*if <lx_VBTYP> is ASSIGNED.
if vbrk-vbtyp ne  'O'.
if <lx_dat> is ASSIGNED.
if <lx_dat> is not INITIAL.
if <lx_dat> is NOT INITIAL.
If <lx_dat> ne sy-datum .
  MESSAGE 'Invoice is back dated. Posting not allowed' Type 'E'.
endif.
endif.
endif.
endif.
endif.
*endif.
endif.
DATA: V_dat type mkpf-budat.
DATA: i_mkpf type TABLE OF mkpf.
DATA: W_mkpf type mkpf.
*If vbrk-vkorg = '1101'.                                             "Commented by Bhagavan on 11/1/21 DR1K955427
IF GV_FLAG = 'X'.                                                    "Added by Bhagavan on 11/1/21 DR1K955427
if vbrk-vbtyp ne  'O'.
 if likp-vbeln is not INITIAL.
 Select *  from mkpf Into TABLE I_mkpf where xblnr = likp-vbeln.
 sort i_mkpf DESCENDING.
 READ TABLE i_mkpf INTO w_mkpf INDEX 1.
 if sy-subrc = 0.
  V_dat = w_mkpf-budat.
 endif.
 if v_dat is NOT INITIAL.
 if v_dat ne Sy-datum.
   MESSAGE 'PGI Date is back dated. Posting Not Allowed' type 'E'.
 endif.
endif.
endif.
endif.
endif.

*& Added BY Lokesh/Iteanz on feb 1 2017 TR # DR1K931105 ***
************************************************************
* Author/Company Name     : Lokesh/Iteanz                  *
* Functional Consultant   : Saroj Sirla                    *
* Transport Request       : DR1K931105                     *
* Creation Date           : 31.01.2017                     *
************************************************************
* Description: Delivery block(Z1/Z2) check while invoicing *
************************************************************
************************************************************
* Modification History *
************************************************************
* Date Programmer Client Ref No. Description Correction    *
************************************************************

************************************************************
* TYpes Declaration                                        *
************************************************************
TYPES :  BEGIN OF tp_vbep,
         vbeln TYPE vbep-vbeln,
         posnr TYPE vbep-posnr,
         etenr TYPE vbep-etenr,
         lifsp TYPE vbep-lifsp,
        END OF tp_vbep.

************************************************************
* Structures and Internal tables                           *
************************************************************
data : gw_vbep TYPE tp_vbep,
       gt_vbep TYPE TABLE OF tp_vbep.

*************************************************************
* Constants                                                 *
*************************************************************
CONSTANTS : gv_tcode TYPE sy-tcode   VALUE 'VF01',
            gv_z1    TYPE vbak-lifsk VALUE 'Z1',
            gv_z2    TYPE vbep-lifsp VALUE 'Z2'.

if sy-tcode eq gv_tcode.

if vbak-lifsk eq gv_z1.
MESSAGE e000(zsd_blk).
else.

refresh gt_vbep.
SELECT vbeln posnr
       etenr lifsp
       FROM vbep INTO TABLE gt_vbep WHERE vbeln = lips-vgbel.
  if sy-subrc eq 0.
    SORT gt_vbep by lifsp.

    READ TABLE gt_vbep INTO gw_vbep with key lifsp = gv_z2 posnr = lips-posnr.
    if sy-subrc eq 0.
     MESSAGE e000(zsd_blk).
    endif.
  endif.
endif.

endif.
*& End of Code Added BY Lokesh/Iteanz on feb 1 2017 TR # DR1K931105 ***
ENDENHANCEMENT.
