class ZCL_SALES_LEVEL definition
  public
  final
  create public .

public section.

  interfaces BI_OBJECT .
  interfaces BI_PERSISTENT .
  interfaces IF_WORKFLOW .

  class-methods SELECT_DATA
    exporting
      !LI_LEVEL type ZSDT_WF_LEVEL_TT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SALES_LEVEL IMPLEMENTATION.


  method SELECT_DATA.

    select ZLEVEL BNAME from ZSDT_WF_LEVEL into table li_level.

  endmethod.
ENDCLASS.
