*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_SHIP_DETAIL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_SHIP_DETAIL    .

  PERFORM TABLEPROC.

ENDFUNCTION.
