FUNCTION-POOL ZBBL_CONUM                 MESSAGE-ID SV.

* INCLUDE LZBBL_CONUMD...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBBL_CONUMT00                          . "view rel. data dcl.
