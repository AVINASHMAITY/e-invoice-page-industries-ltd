"Name: \PR:SAPMV50A\FO:USEREXIT_DELETE_DOCUMENT\SE:BEGIN\EI
ENHANCEMENT 0 ZZSD_DELETE_DELIVERY_MESSAGE.
*&--------------------Modification Log---------------------------------*
*Date       : 06.06.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K945737                                               *
*Description: Remove Sales Org. 1102 and Add ZCMAIN for BFI            *
*&---------------------------------------------------------------------*
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************
*If LIKP-VKORG =  '1101' or LIKP-VKORG = '1102'.
If LIKP-VKORG =  '1101' or LIKP-VKORG IN ra_vkorg.
DATA: V_WERKS type LIPS-WERKS .
DATA: V_werks1 type J_1IWRKCUS-J_1IWERKS.
DATA: V_vbeln type likp-vbeln.
DATA: v_rdoc1 type J_1IEXCDTL-rdoc1.DATA : V_VBELN3 TYPE VBFA-VBELN,
                                           V_VBELN4 TYPE VBRK-VBELN.
BREAK sahoo.
 select single J_1IWERKS from J_1IWRKCUS INTO V_WERKS1 where J_1IWERKS = lips-werks
                                                   and   J_1IDEPOT  = 'X'.
 if V_WERKS1 is not INITIAL." = 0.
   select single VBELN  from J_1IRG23D INTO v_vbeln where vbeln = likp-vbeln
                                                     and  STATUS = 'P'.
   if v_vbeln is not INITIAL.
     MESSAGE 'Delivery cannot be deleted as Depot excise invoice is created' type 'S' DISPLAY LIKE 'E'.
     LEAVE PROGRAM.
   endif.
* endif.
else.
 select single rdoc1 from J_1IEXCDTL INTO v_rdoc1 where rdoc1 = LIKP-VBELN
                                                  and   STATUS = 'C'.
 if v_rdoc1 is not INITIAL.
   MESSAGE 'Delivery cannot be deleted as Excise invoice is created' type 'S' DISPLAY LIKE 'E'.
   Leave program.
 endif.
endif.
clear v_vbeln3.
Break Sahoo.
SELECT SINGLE vbeln FROM vbfa INTO v_vbeln3 WHERE vbelv = lips-vbeln AND vbtyp_n = 'U'.
  IF sy-subrc EQ 0.
    clear v_vbeln4.
    SELECT SINGLE vbeln FROM vbrk INTO v_vbeln4 WHERE vbeln = v_vbeln3 AND rfbsk EQ 'E'.
      IF Sy-subrc NE 0.
        MESSAGE 'Proforma Invoice is created delivery document cannot be deleted' TYPE 'S'  DISPLAY LIKE 'E'.
        LEAVE PROGRAM.
      ENDIF.
   ENDIF.
endif.

ENDENHANCEMENT.
