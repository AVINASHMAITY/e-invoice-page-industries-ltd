*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSD_BANK_DETAILS................................*
DATA:  BEGIN OF STATUS_ZSD_BANK_DETAILS              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_BANK_DETAILS              .
CONTROLS: TCTRL_ZSD_BANK_DETAILS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSD_BANK_DETAILS              .
TABLES: ZSD_BANK_DETAILS               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
