"Name: \PR:SAPMV45A\FO:USEREXIT_READ_DOCUMENT\SE:BEGIN\EI
ENHANCEMENT 0 ZSDE_AUTHORIZATION_CHECK.
*
**Changes for authorization check against block SO
** Made by Parul Kumar Sharma
*---------------------------------------------------------------------*
*                         Modification Log                            *
*---------------------------------------------------------------------*
* Author/Company Name    Date         TR No.        Description       *
* Chaithanya / Iteanz  22.02.2018   DR1K938789    New Order Type ZBSR *
* Chaithanya / Iteanz  22.02.2018   DR1K942450    New Order Type ZBOR *
*---------------------------------------------------------------------*

DATA   : lW_ZAUTH TYPE ZAUTH,
         IT_ZAUTH type table of ZAUTH,
         it_zsdt009 type TABLE OF zsdt009,
         wa_zsdt009 type zsdt009.
DATA   : lv_vbeln type vbeln,
         lv_rel type zsdt009-releas,
         LV_EXCLUDE TYPE CHAR1,
         LV_YB3R TYPE AUART VALUE 'YB3R',             "Added by Ravi on 14.09.2017 DR1K935283
         LV_ZBOR TYPE AUART VALUE 'ZBOR'.             "Added by Chaithanya on 23.10.2018 DR1K942450

IF SY-TCODE = 'VA02' and ( vbak-bukrs_vf = '1100'  or vbak-bukrs_vf = '1400' ). " '1400'Added by Bhagavan on 18.11.2020  DR1K954982
  CASE vbak-auart.
    WHEN 'ZBCR' OR 'ZBDR' OR 'ZBCZ' OR 'ZBRE' OR 'ZBRZ' OR 'ZBDZ'
       OR 'YBCR' OR 'YBDR' OR 'YBNR' OR 'YBRE' or 'YBSC' OR LV_YB3R      "Added by Ravi on 14.09.2017 DR1K935283
       OR 'YBSR'      "Added by Chaithanya on 22.02.2018 DR1K938789
       OR LV_ZBOR.     "Added by Chaithanya on 23.10.2018 DR1K942450
      LV_EXCLUDE = 'X'.
  ENDCASE.
      SELECT single SNO
             VKORG
             VTWEG
             AUART
             USERID
             UNAME
        FROM ZAUTH
        INTO lW_ZAUTH"IT_ZAUTH
        WHERE USERID = SY-UNAME
        and vkorg = vbak-vkorg
        and vtweg = vbak-vtweg
        and auart = vbak-auart.
        IF sy-subrc <> 0.
           select single vbeln into lv_vbeln
              from ZTSD_BLOCKED_SO
              where VBELN = vbak-vbeln
              and  REJECTED <> 'X'.
            IF sy-subrc = 0 and LV_EXCLUDE IS INITIAL.
              message 'You are not authorized to change a blocked SO.'
              type 'E'.
            ENDIF.
        ENDIF.
CLEAR lw_ZAUTH.
SELECT single SNO
             VKORG
             VTWEG
             AUART
             USERID
             UNAME
        FROM ZAUTH
        INTO lW_ZAUTH"IT_ZAUTH
        WHERE USERID = SY-UNAME
        and vkorg = vbak-vkorg
        and vtweg = vbak-vtweg
        and auart = vbak-auart.
        IF sy-subrc <> 0.
           select single vbeln releas into (lv_vbeln,Lv_rel)
              from ZSDT009
              where VBELN = vbak-vbeln
              and  REJECT <> 'X'.
            IF sy-subrc = 0 and LV_EXCLUDE IS INITIAL.
              if Lv_rel ne 'X'.
              message 'You are not authorized to change a blocked SO.'
              type 'E'.
            endif.
            ENDIF.
        ENDIF.
endif.
** Made by Parul Kumar Sharma
**Changes for authorization check against block SO

ENDENHANCEMENT.
