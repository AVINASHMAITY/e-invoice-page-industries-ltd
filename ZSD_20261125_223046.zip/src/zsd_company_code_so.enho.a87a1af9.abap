"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_COMPANY_CODE_SO.
*----------------------------------------------------------------------*
*Implementetaion   : ZSD_COMPANY_CODE_SO                               *
*Created on        : 27.06.2018                                        *
*Developer         : Chaithanya/Iteanz                                 *
*Functional        : Saroj                                             *
*Transport         : DR1K940843                                        *
*Description       : Validation in VA01 for customer extension in      *
*                    company code                                      *
*----------------------------------------------------------------------*
constants : lc_va01  type syst_tcode value 'VA01'.
if sy-tcode eq lc_va01.
  constants : lc_prg      type sobj_name value 'ZSD_COMPANY_CODE_SO',
              lc_bukrs(5) value 'BUKRS'.
  data : lt_con type ztt_ztabap_tvarvc,
         lw_con type ztabap_tvarvc.
  data: lv_bukrs type bukrs,
        lw_bukrs type knb1-bukrs.
  clear : lw_con.
  select single bukrs
    from tvko
    into lv_bukrs
   where vkorg eq vbak-vkorg.

  call method zcl_abap_utility=>get_options
    exporting
      im_objname = lc_prg
    importing
      ex_tab     = lt_con.

  read table lt_con into lw_con
       with key   obj_name = lc_prg
                  name     = lc_bukrs
                  low      = lv_bukrs.
  if sy-subrc = 0.
    select single bukrs
      from knb1
      into lw_bukrs
     where kunnr eq vbak-kunnr
       and bukrs eq lv_bukrs.
    if sy-subrc <> 0.
      message e062(zsd_messages) with vbak-kunnr lv_bukrs.
    endif.
  endif.
endif.
ENDENHANCEMENT.
