"Name: \PR:SAPFV45K\FO:VBAK_BEARBEITEN_VORBEREITEN\SE:END\EI
ENHANCEMENT 0 ZACTMLS_BILLING_PLAN_UPD.
"$. Region PWC : Activity Validation modification : 29.07.2024
 IF  xfplt[] IS NOT INITIAL AND
  ( sy-tcode = 'VA02' OR sy-tcode = 'VA03' ).
      DATA(gt_fplt) = xfplt[].
      EXPORT gt_fplt FROM gt_fplt TO MEMORY ID 'GT_FPLT'.
 ENDIF.
 DATA : gv_waerk TYPE waerk.
 IF vbak-waerk IS NOT INITIAL AND sy-tcode = 'VA02'.
   gv_waerk = vbak-waerk.
   EXPORT gv_waerk FROM gv_waerk TO MEMORY ID 'GV_WAERK'.
 ENDIF.
"$. Endregion PWC : Activity Validation modification : 29.07.2024
ENDENHANCEMENT.
