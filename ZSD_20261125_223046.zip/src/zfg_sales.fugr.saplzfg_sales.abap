*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_SALESTOP.                     " Global Data
  INCLUDE LZFG_SALESUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_SALESF...                     " Subroutines
* INCLUDE LZFG_SALESO...                     " PBO-Modules
* INCLUDE LZFG_SALESI...                     " PAI-Modules
* INCLUDE LZFG_SALESE...                     " Events
* INCLUDE LZFG_SALESP...                     " Local class implement.
* INCLUDE LZFG_SALEST99.                     " ABAP Unit tests
  INCLUDE LZFG_SALESF00                           . " subprograms
  INCLUDE LZFG_SALESI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
