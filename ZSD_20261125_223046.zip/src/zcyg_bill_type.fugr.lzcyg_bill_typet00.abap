*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_BILL_TYPE..................................*
DATA:  BEGIN OF STATUS_ZCYG_BILL_TYPE                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_BILL_TYPE                .
CONTROLS: TCTRL_ZCYG_BILL_TYPE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_BILL_TYPE                .
TABLES: ZCYG_BILL_TYPE                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
