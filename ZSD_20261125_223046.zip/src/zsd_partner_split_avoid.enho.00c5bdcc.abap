"Name: \PR:SAPLV60A\FO:XVBPAK_IDENTISCH\SE:END\EI
ENHANCEMENT 0 ZSD_PARTNER_SPLIT_AVOID.
************************************************************************
*Implementetaion   : ZSD_PARTNER_SPLIT_AVOID                           *
*Created on        : 10.08.2018                                        *
*Developer         : Chaithanya/Iteanz                                 *
*Functional        : Akki                                              *
*Transport         : DR1K941336                                        *
*Description       : Avoid Invoice Split due to different Partner      *
************************************************************************
*                         Modification Log                             *
************************************************************************
*   Date        Changed By   TR No.          Description               *
* 21.08.2018    Chaithanya  DR1K941602     ZT Partner Deletion         *
* 12.09.2018    Chaithanya  DR1K941917     ZT Partner Deletion Changes *
************************************************************************
CONSTANTS : GC_YBOR LIKE VBAK-AUART VALUE 'YBOR',
            GC_YBZT LIKE VBAK-AUART VALUE 'YBZT',
            GC_1102 LIKE VBAK-VKORG VALUE '1102'.
CONSTANTS : GC_VF01 TYPE SYST_TCODE VALUE 'VF01'.
CONSTANTS : C_PARVW LIKE VBPA-PARVW VALUE 'ZT'.
CONSTANTS : GC_ZT   LIKE VBPA-PARVW VALUE 'ZT'.

DATA : LW_XVBPA TYPE  VBPAVB,
       LW_XVBPAK TYPE VBPAVB.

IF SYST-TCODE = GC_VF01.
  IF VBAK-VKORG = GC_1102.
  IF VBAK-AUART = GC_YBOR ."OR VBAK-AUART = GC_YBZT.
****Code Start by Chaithanya  DR1K941602 ***
*  IF SY-SUBRC = 4.
*  IF XVBPA-PARVW = C_PARVW OR
*     XVBPAK-PARVW = C_PARVW .
*
*      SY-SUBRC = 0.
*
*  ENDIF.
*  ENDIF.
****Code End by Chaithanya  DR1K941602 ***
****Code Start by Chaithanya  DR1K941917 ***
READ TABLE XVBPA INTO LW_XVBPA WITH KEY PARVW = GC_ZT.
IF SY-SUBRC = 0.
DELETE XVBPA WHERE PARVW = GC_ZT.
ELSE.
  SY-SUBRC = 0.
ENDIF.
READ TABLE XVBPAK INTO LW_XVBPAK WITH KEY PARVW = GC_ZT.
IF SY-SUBRC = 0.
DELETE XVBPAK WHERE PARVW = GC_ZT.
ELSE.
  SY-SUBRC = 0.
ENDIF.
****Code End by Chaithanya  DR1K941917 ***
  ENDIF.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
