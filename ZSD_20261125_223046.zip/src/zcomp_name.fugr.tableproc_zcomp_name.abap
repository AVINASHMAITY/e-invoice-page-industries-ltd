*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCOMP_NAME
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCOMP_NAME          .

  PERFORM TABLEPROC.

ENDFUNCTION.
