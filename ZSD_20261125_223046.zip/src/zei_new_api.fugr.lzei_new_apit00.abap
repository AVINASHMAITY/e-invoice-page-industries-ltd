*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZEI_NEW_API.....................................*
DATA:  BEGIN OF STATUS_ZEI_NEW_API                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZEI_NEW_API                   .
CONTROLS: TCTRL_ZEI_NEW_API
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZEI_NEW_API                   .
TABLES: ZEI_NEW_API                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
