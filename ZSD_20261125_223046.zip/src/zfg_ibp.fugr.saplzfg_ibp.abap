*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_IBPTOP.                       " Global Data
  INCLUDE LZFG_IBPUXX.                       " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_IBPF...                       " Subroutines
* INCLUDE LZFG_IBPO...                       " PBO-Modules
* INCLUDE LZFG_IBPI...                       " PAI-Modules
* INCLUDE LZFG_IBPE...                       " Events
* INCLUDE LZFG_IBPP...                       " Local class implement.
* INCLUDE LZFG_IBPT99.                       " ABAP Unit tests
  INCLUDE LZFG_IBPF00                             . " subprograms
  INCLUDE LZFG_IBPI00                             . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
