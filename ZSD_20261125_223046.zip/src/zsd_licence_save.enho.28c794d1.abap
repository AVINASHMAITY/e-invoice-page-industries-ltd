"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_LICENCE_SAVE.
*&------------------------------------------------------------------------*
* Date        Programmer   TR No.          Description                    *
* 28.06.2018  Ravindran    DR1K940629      Add 'YBDT' for skipping error  *
* 11.01.2021  Bhagavan     DR1K955427      Added Committed Date mandat Code
*&------------------------------------------------------------------------*
*****************Begin of changes by Ravi on 27.12.2018 DR1K943532*******************
CONSTANTS : GC_SALES         VALUE 'ZSD_SALES_CHECKS' TYPE SOBJ_NAME,
            GC_1101(15)      VALUE 'SO_VKORG_1101',
            GC_1102(15)      VALUE 'SO_VKORG_1102'.
DATA : GT_CONSTANTS TYPE ZTT_ZTABAP_TVARVC.
RANGES : RA_1101 FOR TVKO-VKORG,
         RA_1102 FOR TVKO-VKORG.

CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
      EXPORTING
        IM_OBJNAME = GC_SALES
      IMPORTING
        EX_TAB     = GT_CONSTANTS.

LOOP AT GT_CONSTANTS INTO DATA(GW_CONSTANTS)
                     WHERE OBJ_NAME = GC_SALES
                       AND NAME     = GC_1101.
  RA_1101-SIGN = 'I'.
  RA_1101-OPTION = 'EQ'.
  RA_1101-LOW = GW_CONSTANTS-LOW.
  APPEND RA_1101." TO RA_1101.
  CLEAR : RA_1101.
ENDLOOP.

LOOP AT GT_CONSTANTS INTO GW_CONSTANTS
                     WHERE OBJ_NAME = GC_SALES
                       AND NAME     = GC_1102.
  RA_1102-SIGN = 'I'.
  RA_1102-OPTION = 'EQ'.
  RA_1102-LOW = GW_CONSTANTS-LOW.
  APPEND RA_1102." TO RA_1101.
  CLEAR : RA_1102.
ENDLOOP.
*****************End of changes by Ravi on 27.12.2018 DR1K943532******************
If sy-tcode = 'VA01' or Sy-tcode = 'VA02' or Sy-tcode = 'ZVA01' or  Sy-tcode = 'ZSD_ZVA01' or  Sy-tcode = 'ZSD_QUOT_SO' . "ZSD_QUOT_SO Added by Bhagavan 16/12/2020 DR1K953998.
*if vbak-vkorg = '1102'.
if vbak-vkorg IN RA_1102.
DATA : wa_vbapp type  VBAP .
DATA:  W_KOMV type  komv.
DATA:  W_KOMV1 type  komv.
DATA:  W_KOMV2 type  komv.
data : v_flag ,
       v_flag1   .     " Added by raju on 27.10.2015
*IF vbak-auart NE 'YBEX' .    "  Commented By raju on 28.10.2015
" addition of code by raju on 28.10.2015
* if vbak-auart eq 'YBEX' or vbak-auart eq 'YBOI' or vbak-auart eq 'YBR2' or vbak-auart eq 'YBS1'    " By raju on 28.10.2015 (for skipping the error for 'yboi')
 if vbak-auart eq 'YBEX' or vbak-auart eq 'YBR2'    "Removed 'YBOI' & 'YBS1' on 10.05.2019 DR1K945305
    OR vbak-auart EQ 'YBDT'.      "Added by Ravi on 28.06.2018 DR1K940882
 exit .
 else .
" End of code by raju

READ TABLE xvbap INTO wa_vbapp WITH KEY PSTYV = 'ZTN1'.
IF SY-SUBRC EQ 0.
 DATA(LV_CHECK) = 'X'.
ENDIF.
IF LV_CHECK IS INITIAL.

loop at xvbap INTO wa_vbapp.
READ TABLE xkomv INTO W_KOMV with key kschl  = 'ZMRT'
                                      kposn  = wa_vbapp-posnr .
if sy-subrc = 0.

endif.
READ TABLE xkomv INTO W_KOMV1 with key kschl  = 'ZPTR'
                                      kposn  = wa_vbapp-posnr .
if sy-subrc = 0.
if w_komv-kwert is not INITIAL and sy-tcode ne 'ZSD_QUOT_SO'.   "Code Added by Bhagavan on 3/12/2020 DR1K953998
If W_KOMV1-kwert is not INITIAL and W_KOMV1-kbetr is  INITIAL.
*W_KOMV1-kbetr = W_KOMV1-kwert / wa_vbapp-kwmeng.
*if W_KOMV1-kbetr is INITIAL.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
*else.
*MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'ZPTR'
*                                    and kposn  = vbap-posnr .
*endif.
endif.
If W_KOMV1-kbetr is not INITIAL and W_KOMV1-kwert is  INITIAL.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
If W_KOMV1-kbetr is INITIAL or W_KOMV1-kwert is  INITIAL.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
if W_KOMV1-kwert gt w_komv-kwert.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
endif.
endif.
READ TABLE xkomv INTO W_KOMV2 with key kschl  = 'ZPTS'
                                      kposn  = wa_vbapp-posnr .
if sy-subrc = 0.
if w_komv-kwert is not INITIAL  and sy-tcode ne 'ZSD_QUOT_SO'.   "Code Added by Bhagavan on 3/12/2020 DR1K953998
If W_KOMV2-kwert is not INITIAL and W_KOMV2-kbetr is  INITIAL.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
If W_KOMV2-kbetr is not INITIAL and W_KOMV2-kwert is  INITIAL.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
If W_KOMV2-kbetr is INITIAL or W_KOMV2-kwert is  INITIAL.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
if W_KOMV2-kwert gt w_komv-kwert.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
if W_KOMV2-kwert gt w_komv1-kwert.
MESSAGE 'Error in Pricing.Recreate the document' type 'E'.
endif.
endif.
endif.
CLEAR : W_KOMV,W_KOMV1,W_KOMV2,wa_vbapp.
endloop.
ENDIF.
endif.
endif.
endif.
If sy-tcode = 'VA01' or Sy-tcode = 'VA02' or Sy-tcode = 'ZSD_QUOT_SO'.
*if vbak-vkorg = '1101' or vbak-vkorg = '1102'.
if vbak-vkorg IN RA_1101 or vbak-vkorg IN RA_1102.
DATA:i_temp type TABLE OF zsdt009,
     w_temp type zsdt009.
SELECT * from ZSDt009 INTO TABLE i_temp WHERE vbeln = ''.
loop at i_temp INTO w_temp.
delete zsdt009 from w_temp." WHERE vbeln = w_temp-vbeln.
w_temp-vbeln = vbak-vbeln.
MODIFY i_temp from w_temp TRANSPORTING vbeln.
endloop.

if i_temp IS NOT INITIAL.
MODIFY zsdt009 from TABLE i_temp.
COMMIT WORK AND WAIT.
endif.
refresh i_temp.
endif.
endif.
**** >>>> Code added on 30 July 2014 for sales oder block based on condition modify
IF sy-ucomm = 'SICH' or  sy-ucomm = 'YES' or sy-ucomm = 'TEIL' or sy-ucomm = 'WEIT'.
BREAK sahoo.
*IF ( sy-tcode = 'VA02' ) and ( vbak-vkorg = '1101'  or vbak-vkorg = '1102' ).
IF ( sy-tcode = 'VA02' ) and ( vbak-vkorg IN RA_1101  or vbak-vkorg IN RA_1102 ).
DATA : i_tab TYPE TABLE OF ztab_va01block,
       w_tab TYPE          ztab_va01block,
       i_vbap TYPE TABLE OF vbap,
       w_vbap TYPE  vbap,
       v_line_vbap TYPE i,
       v_count     TYPE i.

** Select the date from the custom table based on the year and the month
SELECT SINGLE * FROM ztab_va01block INTO w_tab WHERE ZSALES_ORG = vbak-vkorg
                                               and   ZFISCAL_YEAR = Sy-datum+0(4)"xvbap-erdat+0(4)
                                                       AND ZMONTH = Sy-datum+4(2) "xvbap-erdat+4(2)
                                               and   ZDIVISION = xVBAK-SPART.
if sy-subrc <> 0.
SELECT SINGLE * FROM ztab_va01block INTO w_tab WHERE ZSALES_ORG = vbak-vkorg
                                               and   ZFISCAL_YEAR = Sy-datum+0(4)"xvbap-erdat+0(4)
                                                       AND ZMONTH = Sy-datum+4(2)."xvbap-erdat+4(2).
IF sy-subrc <> 0.
  CLEAR : w_tab.
  ELSE.
    IF xVBAK-SPART = w_tab-ZDIVISION.  " if the division is same as the maintained one then allow creation
      " allow saving
      ELSE.
    "IF ( xvbak-audat GE w_tab-ZDATE or xvbak-erdat GE w_tab-zdate ).
    IF  Sy-datum GT w_tab-ZDATE." or xvbak-erdat GE w_tab-zdate ).
      IF sy-tcode = 'VA02'.
      SELECT * FROM vbap INTO TABLE i_vbap WHERE vbeln = vbak-vbeln.  " get the actual line item , need to check whether any thing is added or deleted
        IF sy-subrc <> 0.
          CLEAR : i_vbap.
        ELSE.
          DESCRIBE TABLE i_vbap lines  v_line_vbap.
        ENDIF.
*        BREAK sahoo.
             LOOP AT xvbap[] INTO xvbap." WHERE kwmeng > '0' and lsmeng > '0'.
               loop at i_vbap INTO w_vbap where vbeln = xvbap-vbeln and posnr = xvbap-posnr.
                if   xvbap-kwmeng gt w_vbap-kwmeng.
                  MESSAGE 'Sales order modification closed for the current period' TYPE 'E'.
                endif.
               endloop.
               clear :w_vbap.
               v_count = v_count + 1.
             ENDLOOP.
           IF v_count = v_line_vbap.  " the no line item and the current no of items are same means nothing is added or changed
*             " same no of item allow changes
             ELSE.
      MESSAGE 'Sales order modification closed for the current period' TYPE 'E'.
           ENDIF.

      ENDIF.
*      endif.
    ENDIF.
break sahoo.
    IF  Sy-datum eq w_tab-ZDATE and SY-uzeit GE w_tab-ZTIME." or xvbak-erdat GE w_tab-zdate ).
      IF sy-tcode = 'VA02'.
      SELECT * FROM vbap INTO TABLE i_vbap WHERE vbeln = vbak-vbeln.  " get the actual line item , need to check whether any thing is added or deleted
        IF sy-subrc <> 0.
          CLEAR : i_vbap.
        ELSE.
          DESCRIBE TABLE i_vbap lines  v_line_vbap.
        ENDIF.
        BREAK sahoo.
             LOOP AT xvbap[] INTO xvbap." WHERE kwmeng > '0' and lsmeng > '0'.
               loop at i_vbap INTO w_vbap where vbeln = xvbap-vbeln and posnr = xvbap-posnr.
                if   xvbap-kwmeng gt w_vbap-kwmeng.
                  MESSAGE 'Sales order modification closed for the current period' TYPE 'E'.
                endif.
               endloop.
               clear :w_vbap.
               v_count = v_count + 1.
             ENDLOOP.
           IF v_count = v_line_vbap.  " the no line item and the current no of items are same means nothing is added or changed
*             " same no of item allow changes
             ELSE.
      MESSAGE 'Sales order modification closed for the current period' TYPE 'E'.
           ENDIF.

      ENDIF.
*      endif.
    ENDIF.
    ENDIF.
ENDIF.
ENDIF.
ENDIF.
endif.
break sahoo.

**** <<<< ----- Code ends here
DATA: it_licmt TYPE TABLE OF ztca_licmast,
      it_licad TYPE TABLE OF ztca_licmast,
      wa_licad TYPE ztca_licmast,
      wa_vbap  TYPE vbapvb,
      lv_qaty  TYPE zca_util.

FIELD-SYMBOLS: <fs_licm> TYPE ztca_licmast,
              <fs_vbap> TYPE vbapvb.

*IF ( sy-uname = 'ILAVARASAN' OR sy-uname = 'VENKAT' ).
*  IF ( sy-tcode = 'VA01' OR sy-tcode = 'VA02' ) AND vbak-vkorg = '1101'.
  IF ( sy-tcode = 'VA01' OR sy-tcode = 'VA02') AND vbak-vkorg IN RA_1101 .
    IF xvbap[] IS NOT INITIAL.
      REFRESH it_licmt.
      SELECT * FROM ztca_licmast INTO TABLE it_licmt FOR ALL ENTRIES IN xvbap
        WHERE aplno = xvbap-aplno.
      IF sy-subrc = 0.
        SELECT * FROM ztca_licmast APPENDING TABLE it_licmt FOR ALL ENTRIES IN yvbap
      WHERE aplno = yvbap-aplno.
      ENDIF.
      SORT it_licmt BY aplno.
      DELETE ADJACENT DUPLICATES FROM it_licmt COMPARING aplno.
      IF sy-tcode = 'VA01'.
        LOOP AT xvbap ASSIGNING <fs_vbap>.
          CLEAR wa_licad.
          READ TABLE it_licmt INTO wa_licad WITH KEY aplno = <fs_vbap>-aplno.
          IF sy-subrc = 0.
            wa_licad-util_qty_sp = wa_licad-util_qty_sp + <fs_vbap>-quantity.
            wa_licad-util_qty = wa_licad-util_qty - <fs_vbap>-quantity.
            MODIFY ztca_licmast FROM wa_licad.
          ENDIF.
        ENDLOOP.
      ELSEIF sy-tcode = 'VA02'.
        LOOP AT xvbap ASSIGNING <fs_vbap>.
          CLEAR wa_vbap.
          READ TABLE yvbap INTO wa_vbap WITH KEY vbeln = <fs_vbap>-vbeln posnr = <fs_vbap>-posnr.
          IF sy-subrc = 0.
            CLEAR lv_qaty.
            lv_qaty = <fs_vbap>-quantity - wa_vbap-quantity.
            IF wa_vbap-aplno = <fs_vbap>-aplno.
              CLEAR wa_licad.
              READ TABLE it_licmt INTO wa_licad WITH KEY aplno = <fs_vbap>-aplno.
              IF sy-subrc = 0.
                wa_licad-util_qty_sp = wa_licad-util_qty_sp + lv_qaty.
                wa_licad-util_qty = wa_licad-util_qty - lv_qaty.
                MODIFY ztca_licmast FROM wa_licad.
              ENDIF.
            ELSE.

            CLEAR wa_licad.
            READ TABLE it_licmt INTO wa_licad WITH KEY aplno = <fs_vbap>-aplno.
            IF sy-subrc = 0.
              wa_licad-util_qty_sp = wa_licad-util_qty_sp + lv_qaty.
              wa_licad-util_qty = wa_licad-util_qty - lv_qaty.
              MODIFY ztca_licmast FROM wa_licad.
            ENDIF.
            CLEAR wa_licad.
            READ TABLE it_licmt INTO wa_licad WITH KEY aplno = wa_vbap-aplno.
            IF sy-subrc = 0.
              wa_licad-util_qty_sp = wa_licad-util_qty_sp - lv_qaty.
              wa_licad-util_qty = wa_licad-util_qty + lv_qaty.
              MODIFY ztca_licmast FROM wa_licad.
            ENDIF.
          ENDIF.
           ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.
  ENDIF.
*****************BEGIN OF CHANGES BY BHAGAVAN ON 05/1/2021 DR1K955427******************
    IF SY-TCODE = 'VA02' AND ( SY-UCOMM = 'SICH' OR SY-UCOMM = 'OPT2' ). .
    CONSTANTS : GC_SALES1  VALUE 'ZSD_SALES_KPI' TYPE SOBJ_NAME.
    DATA : GT_CONSTANTS1 TYPE ZTT_ZTABAP_TVARVC,
           LV_FLAGC TYPE CHAR1,
           LV_FLAGC1 TYPE CHAR1.
    CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
    EXPORTING
      IM_OBJNAME = GC_SALES1
    IMPORTING
      EX_TAB     = GT_CONSTANTS1.

    LOOP AT GT_CONSTANTS1 INTO DATA(GS_CONSTANTS1).
      IF  VBAK-VKORG = GS_CONSTANTS1-LOW .
        LV_FLAGC = 'X'.
      ENDIF.

        IF  VBAK-AUART = GS_CONSTANTS1-LOW .
          LV_FLAGC1 = 'X'.
        ENDIF.

    ENDLOOP.

    IF   LV_FLAGC1 = 'X'  AND LV_FLAGC = 'X'.
      DATA : LV_MESSAGE TYPE CHAR30.
      LOOP AT  XVBAP INTO DATA(WA_XVBAP).
        READ TABLE YVBAP INTO DATA(WA_YVBAP) WITH KEY VBELN = WA_XVBAP-VBELN POSNR = WA_XVBAP-POSNR UPDKZ = 'D'.
        IF SY-SUBRC NE 0.
        IF WA_XVBAP-COMMIT_DATE IS INITIAL.
          MESSAGE E005(ZSD_MESSAGES) WITH 'Please Enter Committed Date' && ` ` && 'in Additional Data B'.
        ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.
    ENDIF.

*****************END OF CHANGES BY BHAGAVAN ON 05/1/2021 DR1K955427******************

ENDENHANCEMENT.
