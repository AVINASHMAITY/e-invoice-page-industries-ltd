*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_UNIT_MASTER................................*
DATA:  BEGIN OF STATUS_ZCYG_UNIT_MASTER              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_UNIT_MASTER              .
CONTROLS: TCTRL_ZCYG_UNIT_MASTER
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_UNIT_MASTER              .
TABLES: ZCYG_UNIT_MASTER               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
