*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCOMP_NAMETOP.                    " Global Data
  INCLUDE LZCOMP_NAMEUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCOMP_NAMEF...                    " Subroutines
* INCLUDE LZCOMP_NAMEO...                    " PBO-Modules
* INCLUDE LZCOMP_NAMEI...                    " PAI-Modules
* INCLUDE LZCOMP_NAMEE...                    " Events
* INCLUDE LZCOMP_NAMEP...                    " Local class implement.
* INCLUDE LZCOMP_NAMET99.                    " ABAP Unit tests
  INCLUDE LZCOMP_NAMEF00                          . " subprograms
  INCLUDE LZCOMP_NAMEI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
