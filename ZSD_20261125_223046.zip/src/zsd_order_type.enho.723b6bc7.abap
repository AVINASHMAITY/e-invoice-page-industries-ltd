"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ORDER_TYPE.
*&-------------------------------------------------------------------
*Date       : 01.04.2024
*Programmer : Suganya
*TR No.     : DR1K984169
*Description: Enhancment for SAP Order type mapping while sales order creation
*&-------------------------------------------------------------------
DATA: lwa_e1edk14_ord TYPE e1edk14.
LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_idoc_so>) WHERE segnam = 'E1EDK14' .
  lwa_e1edk14_ord = <fs_idoc_so>-sdata.
  "Order Code - Sales Document Type AUART
  IF lwa_e1edk14_ord-qualf = '013'.
   DATA(lv_ord_code) = lwa_e1edk14_ord-orgid.
   EXPORT lv_ord_code TO MEMORY id 'LV_ORD_CODE'.
  ENDIF.
  "Sales Org VKORG
  IF lwa_e1edk14_ord-qualf = '008'.
   DATA(lv_ord_org) = lwa_e1edk14_ord-orgid.
   EXPORT lv_ord_org TO MEMORY id 'LV_ORD_ORG'.
  ENDIF.
  "Distribution Channel VTWEG
  IF lwa_e1edk14_ord-qualf = '007'.
   DATA(lv_ord_dc) = lwa_e1edk14_ord-orgid.
   EXPORT lv_ord_dc TO MEMORY id 'LV_ORD_DC'.
  ENDIF.
  "Division SPART
  IF lwa_e1edk14_ord-qualf = '006'.
   DATA(lv_ord_dv) = lwa_e1edk14_ord-orgid.
   EXPORT lv_ord_dv TO MEMORY id 'LV_ORD_DV'.
  ENDIF.
ENDLOOP.
ENDENHANCEMENT.
