*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_EINV_PLANT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_EINV_PLANT     .

  PERFORM TABLEPROC.

ENDFUNCTION.
