"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SOPOVAL_L.
  CONSTANTS: lc_tcode_va01          TYPE syst-tcode         VALUE 'VA01',
             lc_tcode_va02          TYPE syst-tcode         VALUE 'VA02',
             lc_ucomm_sich          TYPE syst-ucomm         VALUE 'SICH',
             lc_param_zsopoval      TYPE zparam-parameter1  VALUE 'ZSOPOVAL%',
             lc_param_zsopoval_mat  TYPE zparam-parameter1  VALUE 'ZSOPOVAL_MAT',
             lc_param_zsopoval_ser  TYPE zparam-parameter1  VALUE 'ZSOPOVAL_SER',
             lc_param_auart         TYPE zparam-parameter1  VALUE 'AUART',
             lc_param_kunnr         TYPE zparam-parameter1  VALUE 'KUNNR',
             lc_param_tolerance     TYPE zparam-parameter1  VALUE 'TOLERANCE',
             lc_kschl_pb00          TYPE konv-kschl         VALUE 'PB00',
             lc_kschl_pbxx          TYPE konv-kschl         VALUE 'PBXX'.

*&====================================================================&*
*&  DR1K927685
*&  Added by PwC|SN on 14-07-2016
*&  To handle the case where SOPO Validations are being skipped when
*&  clicks back and yes on the do you want to save popup instead of
*&  pressing save button.
*&====================================================================&*
  CONSTANTS lc_ucomm_yes TYPE syst-ucomm VALUE 'YES'.
*&====================================================================&*
*&  End of DR1K927685
*&====================================================================&*

  DATA: lw_zparam TYPE zparam.
  DATA: lw_zparam_kunnr TYPE zparam.
  DATA: lw_vbak   TYPE vbak.
  DATA: lw_ekko   TYPE ekko.

  DATA: lt_ekpo TYPE TABLE OF ekpo,
        lw_ekpo TYPE          ekpo.

  DATA: lt_zsd_cc_matnr TYPE TABLE OF zsd_cc_matnr,
        lw_zsd_cc_matnr TYPE          zsd_cc_matnr.

  DATA: lt_zsd_cc_asnum TYPE TABLE OF zsd_cc_asnum,
        lw_zsd_cc_asnum TYPE          zsd_cc_asnum.

  DATA: l_menge    TYPE menge_d,
        l_menge_t  TYPE menge_d,
        l_menge_so TYPE menge_d,
        l_meins    TYPE ekpo-meins.

  DATA: l_amnt  TYPE wertv8.
  DATA: l_tot_qty TYPE menge_d.

  DATA: lt_konv TYPE TABLE OF konv,
        lw_konv TYPE          konv.

  DATA: l_message(255).

  DATA: l_fwste TYPE bset-fwste.

  DATA: lt_esll_h   TYPE TABLE OF esll,
        lt_esll_l   TYPE TABLE OF esll,
        lw_esll_h   TYPE          esll,
        lw_esll_l   TYPE          esll,
        lw_esll_l_t TYPE          esll.

  DATA: lt_marm   TYPE TABLE OF marm,
        lw_marm_s TYPE marm,
        lw_marm_p TYPE marm.

  DATA: l_wrbtr TYPE bseg-wrbtr.

  DATA: l_bsart TYPE ekko-bsart.

  DATA: l_kunnr TYPE zparameter.

  DATA: l_amt_po(15) TYPE p DECIMALS 2,
        l_amt_so(15) TYPE p DECIMALS 2.

  DATA: lt_mwdat LIKE rtax1u15 OCCURS 0 WITH HEADER LINE.

  DATA: lw_zparam_tol   TYPE zparam,
        lv_tolerance(5) TYPE p DECIMALS 2,
        lv_variance(5)  TYPE p DECIMALS 2.

  DATA: l_fkrel TYPE tvap-fkrel.

*&====================================================================&*
*&  DR1K927685
*&  Changed by PwC|SN on 14-07-2016
*&  To handle the case where SOPO Validations are being skipped when
*&  clicks back and yes on the do you want to save popup instead of
*&  pressing save button.
*&====================================================================&*
*  IF ( sy-tcode EQ lc_tcode_va01 OR sy-tcode EQ lc_tcode_va02 ) AND sy-ucomm EQ lc_ucomm_sich.
  IF ( sy-tcode EQ lc_tcode_va01 OR sy-tcode EQ lc_tcode_va02 ) AND
     ( sy-ucomm EQ lc_ucomm_sich OR sy-ucomm EQ lc_ucomm_yes ).
*&====================================================================&*
*&  End of DR1K927685
*&====================================================================&*

    CLEAR: lw_zparam.
    SELECT SINGLE * FROM zparam
                    INTO lw_zparam
                    WHERE parameter1 LIKE lc_param_zsopoval
                    AND   parameter2 EQ   lc_param_auart
                    AND   parameter3 EQ vbak-auart.
    IF sy-subrc = 0.
      CLEAR: l_kunnr.
      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = vbak-kunnr
        IMPORTING
          output = l_kunnr.
      SELECT SINGLE * FROM zparam
                      INTO lw_zparam_kunnr
                      WHERE parameter1 EQ lw_zparam-parameter1
                      AND   parameter2 EQ lc_param_kunnr
                      AND   parameter3 EQ l_kunnr.
      IF sy-subrc = 0.
        IF vbak-zzebeln IS NOT INITIAL.
          CLEAR: lw_vbak.

          CLEAR: lw_ekko.
          SELECT SINGLE * FROM ekko
                          INTO lw_ekko
                          WHERE ebeln EQ vbak-zzebeln.
          IF sy-subrc NE 0.
          ELSE.

            CASE lw_zparam-parameter1.
              WHEN lc_param_zsopoval_mat.
                CLEAR: lw_zparam_tol, lv_tolerance.
                SELECT SINGLE * FROM zparam
                                INTO lw_zparam_tol
                                WHERE parameter1 EQ lc_param_zsopoval_mat
                                AND   parameter2 EQ lc_param_tolerance.
                IF sy-subrc = 0.
                  lv_tolerance = lw_zparam_tol-parameter3.
                ELSE.
                  lv_tolerance = '0.00'.
                ENDIF.

                "Compare Materials
                IF xvbap[] IS NOT INITIAL.

                  REFRESH: lt_zsd_cc_matnr.
                  SELECT * FROM zsd_cc_matnr
                           INTO TABLE lt_zsd_cc_matnr
                           FOR ALL ENTRIES IN xvbap
                           WHERE bukrs_s EQ vbak-bukrs_vf
                           AND   matnr_s EQ xvbap-matnr
                           AND   bukrs_r EQ lw_ekko-bukrs.
                  IF sy-subrc = 0.
                    SORT lt_zsd_cc_matnr.
                  ENDIF.

                  REFRESH: lt_ekpo.
                  SELECT * FROM ekpo
                           INTO TABLE lt_ekpo
                           WHERE ebeln EQ lw_ekko-ebeln.
                  IF sy-subrc = 0.
                    SORT lt_ekpo.
                    DELETE lt_ekpo WHERE loekz EQ 'L'.
                  ENDIF.

                  REFRESH: lt_konv.
                  SELECT * FROM konv
                           INTO TABLE lt_konv
                           WHERE knumv EQ lw_ekko-knumv.
                  IF sy-subrc = 0.
                    SORT lt_konv.
                    DELETE lt_konv WHERE kstat EQ 'X' AND mwsk1 IS INITIAL AND kvsl2 IS INITIAL.
                  ENDIF.

                  REFRESH: lt_marm.
                  SELECT * FROM marm
                           INTO TABLE lt_marm
                           FOR ALL ENTRIES IN xvbap
                           WHERE matnr EQ xvbap-matnr.
                  IF sy-subrc = 0.
                    SORT lt_marm.
                  ENDIF.


                  LOOP AT lt_ekpo INTO lw_ekpo.
                    READ TABLE xvbap INTO lw_xvbap
                                     INDEX sy-tabix.
                    IF sy-subrc = 0.
                      READ TABLE lt_zsd_cc_matnr INTO     lw_zsd_cc_matnr
                                                 WITH KEY bukrs_s = vbak-bukrs_vf
                                                          matnr_s = lw_xvbap-matnr
                                                          bukrs_r = lw_ekko-bukrs.
                      IF sy-subrc = 0.
                        IF lw_zsd_cc_matnr-matnr_r NE lw_ekpo-matnr.
                          MESSAGE: w011(zmsg_comn) WITH lw_xvbap-posnr lw_ekpo-ebelp DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                        ENDIF.
                      ELSE.
                        MESSAGE: w012(zmsg_comn) WITH lw_xvbap-matnr DISPLAY LIKE 'E'.
                        LEAVE TO SCREEN sy-dynnr.
                      ENDIF.
                    ELSE.
                      MESSAGE: w025(zmsg_comn) DISPLAY LIKE 'E'.
                      LEAVE TO SCREEN sy-dynnr.
                    ENDIF.
                    CLEAR: lw_ekpo, lw_xvbap.
                  ENDLOOP.

                  LOOP AT xvbap INTO lw_xvbap.
                    IF lw_xvbap-matnr IS NOT INITIAL.
                      READ TABLE lt_ekpo INTO lw_ekpo
                                         INDEX sy-tabix.
                      IF sy-subrc = 0.
                        READ TABLE lt_zsd_cc_matnr INTO     lw_zsd_cc_matnr
                                                   WITH KEY bukrs_s = vbak-bukrs_vf
                                                            matnr_s = lw_xvbap-matnr
                                                            bukrs_r = lw_ekko-bukrs.
                        IF sy-subrc EQ 0.
                          IF lw_zsd_cc_matnr-matnr_r NE lw_ekpo-matnr.
                            MESSAGE: w011(zmsg_comn) WITH lw_xvbap-posnr lw_ekpo-ebelp DISPLAY LIKE 'E'.
                            LEAVE TO SCREEN sy-dynnr.
                          ENDIF.
                        ELSE.
                          MESSAGE: w012(zmsg_comn) WITH lw_xvbap-matnr DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                        ENDIF.
                      ELSE.
                        MESSAGE: w013(zmsg_comn) DISPLAY LIKE 'E'.
                        LEAVE TO SCREEN sy-dynnr.
                      ENDIF.
                      CLEAR: lw_xvbap.
                    ENDIF.
                  ENDLOOP.

                  LOOP AT xvbap INTO lw_xvbap.
                    CLEAR: l_menge, l_amnt, l_meins.

                    READ TABLE lt_ekpo INTO lw_ekpo
                                       INDEX sy-tabix.
                    IF sy-subrc = 0.
                      l_menge  = lw_ekpo-menge.
                      l_meins  = lw_ekpo-meins.
                      LOOP AT lt_konv INTO lw_konv
                                      WHERE kposn EQ lw_ekpo-ebelp.
                        l_amnt = l_amnt +  lw_konv-kwert.
                      ENDLOOP.

                      CLEAR: lw_ekpo.
                    ENDIF.

                    CLEAR: l_menge_so.
                    IF l_meins EQ lw_xvbap-vrkme.
                      l_menge_so = lw_xvbap-kwmeng.
                    ELSE.
                      CLEAR: lw_marm_p, lw_marm_s.
                      READ TABLE lt_marm INTO lw_marm_p
                                         WITH KEY matnr = lw_xvbap-matnr
                                                  meinh = l_meins.
                      IF sy-subrc NE 0.
                        READ TABLE lt_zsd_cc_matnr INTO     lw_zsd_cc_matnr
                                                   WITH KEY bukrs_s = vbak-bukrs_vf
                                                            matnr_s = lw_xvbap-matnr
                                                            bukrs_r = lw_ekko-bukrs.
                        MESSAGE: w022(zmsg_comn) WITH lw_xvbap-matnr lw_xvbap-vrkme lw_zsd_cc_matnr-matnr_r l_meins DISPLAY LIKE 'E'.
                        LEAVE TO SCREEN sy-dynnr.
                      ENDIF.
                      READ TABLE lt_marm INTO lw_marm_s
                                         WITH KEY matnr = lw_xvbap-matnr
                                                  meinh = lw_xvbap-vrkme.
                      IF sy-subrc NE 0.
                        READ TABLE lt_zsd_cc_matnr INTO     lw_zsd_cc_matnr
                                                   WITH KEY bukrs_s = vbak-bukrs_vf
                                                            matnr_s = lw_xvbap-matnr
                                                            bukrs_r = lw_ekko-bukrs.
                        MESSAGE: w022(zmsg_comn) WITH lw_xvbap-matnr lw_xvbap-vrkme lw_zsd_cc_matnr-matnr_r l_meins DISPLAY LIKE 'E'.
                        LEAVE TO SCREEN sy-dynnr.
                      ENDIF.
                      l_menge_so = ( lw_xvbap-kwmeng * lw_marm_p-umren * lw_marm_s-umrez ) / ( lw_marm_p-umrez * lw_marm_s-umren ).
                    ENDIF.

                    IF l_menge NE l_menge_so.
                      MESSAGE: w014(zmsg_comn) WITH lw_xvbap-posnr lw_xvbap-matnr DISPLAY LIKE 'E'.
                      LEAVE TO SCREEN sy-dynnr.
                    ENDIF.

                    CLEAR: l_amt_po, l_amt_so.
                    l_amt_po = l_amnt * 1000 / l_menge.
                    l_amt_so = ( lw_xvbap-netwr + lw_xvbap-mwsbp ) * 1000 / l_menge.

                    CLEAR: lv_variance.
                    IF l_amt_po NE 0.
                      lv_variance = ( l_amt_po - l_amt_so ) * '100.00' / l_amt_po.
                    ENDIF.

                    IF lv_variance LT 0.
                      lv_variance = lv_variance * ( -1 ).
                    ENDIF.

                    IF lv_variance GT lv_tolerance.
                      MESSAGE: w015(zmsg_comn) WITH lw_xvbap-posnr lw_xvbap-matnr DISPLAY LIKE 'E'.
                      LEAVE TO SCREEN sy-dynnr.
                      EXIT.
                    ENDIF.
                    CLEAR: lw_xvbap.
                  ENDLOOP.

                ENDIF.
              WHEN lc_param_zsopoval_ser.
                CLEAR: lw_zparam_tol, lv_tolerance.
                SELECT SINGLE * FROM zparam
                                INTO lw_zparam_tol
                                WHERE parameter1 EQ lc_param_zsopoval_ser
                                AND   parameter2 EQ lc_param_tolerance.
                IF sy-subrc = 0.
                  lv_tolerance = lw_zparam_tol-parameter3.
                ELSE.
                  lv_tolerance = '0.00'.
                ENDIF.

                "Compare Services
                IF xvbap[] IS NOT INITIAL.
                  REFRESH: lt_zsd_cc_asnum.
                  SELECT * FROM zsd_cc_asnum
                           INTO TABLE lt_zsd_cc_asnum
                           FOR ALL ENTRIES IN xvbap
                           WHERE bukrs_s EQ vbak-bukrs_vf
                           AND   asnum_s EQ xvbap-matnr
                           AND   bukrs_r EQ lw_ekko-bukrs.
                  IF sy-subrc = 0.
                    SORT lt_zsd_cc_asnum.
                  ENDIF.

                  REFRESH: lt_ekpo.
                  SELECT * FROM ekpo
                           INTO TABLE lt_ekpo
                           WHERE ebeln EQ lw_ekko-ebeln.
                  IF sy-subrc = 0.
                    SORT lt_ekpo.
                    DELETE lt_ekpo WHERE loekz EQ 'L'.

                    SELECT * FROM esll
                             INTO TABLE lt_esll_h
                             FOR ALL ENTRIES IN lt_ekpo
                             WHERE packno EQ lt_ekpo-packno.
                    IF sy-subrc = 0.
                      SORT lt_esll_h.
                      SELECT * FROM esll
                               INTO TABLE lt_esll_l
                               FOR ALL ENTRIES IN lt_esll_h
                               WHERE packno EQ lt_esll_h-sub_packno.
                      IF sy-subrc = 0.
                        SORT lt_esll_l.
                        DELETE lt_esll_l WHERE del IS NOT INITIAL.
                      ENDIF.
                    ENDIF.
                  ENDIF.

                  REFRESH: lt_konv.
                  SELECT * FROM konv
                           INTO TABLE lt_konv
                           WHERE knumv EQ lw_ekko-knumv.
                  IF sy-subrc = 0.
                    SORT lt_konv.
                    DELETE lt_konv WHERE kstat EQ 'X' AND mwsk1 IS INITIAL.
                  ENDIF.

                  REFRESH: lt_marm.
                  SELECT * FROM marm
                           INTO TABLE lt_marm
                           FOR ALL ENTRIES IN xvbap
                           WHERE matnr EQ xvbap-matnr.
                  IF sy-subrc = 0.
                    SORT lt_marm.
                  ENDIF.


                  READ TABLE xvbap INTO lw_xvbap
                                   INDEX 1.
                  IF sy-subrc = 0.
                    SELECT SINGLE fkrel FROM tvap
                                        INTO l_fkrel
                                        WHERE pstyv = lw_xvbap-pstyv.
                    IF sy-subrc = 0 AND l_fkrel EQ 'I'.

                      "Line Item Checks
                      LOOP AT lt_ekpo INTO lw_ekpo.
                        READ TABLE xvbap INTO lw_xvbap
                                         INDEX sy-tabix.
                        IF sy-subrc = 0.
                        ELSE.
                          MESSAGE: w025(zmsg_comn) DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                        ENDIF.
                      ENDLOOP.

                      LOOP AT xvbap INTO lw_xvbap.
                        READ  TABLE lt_ekpo INTO lw_ekpo
                                            INDEX sy-tabix.
                        IF sy-subrc = 0.
                        ELSE.
                          MESSAGE: w013(zmsg_comn) DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                        ENDIF.
                      ENDLOOP.

                      "Amount Check
                      LOOP AT xvbap INTO lw_xvbap.
                        CLEAR: l_amnt.

                        l_menge = lw_xvbap-kwmeng.

                        READ TABLE lt_ekpo INTO lw_ekpo
                                           INDEX sy-tabix.
                        IF sy-subrc = 0.
                          LOOP AT lt_konv INTO lw_konv
                                              WHERE kposn EQ lw_ekpo-ebelp
                                              AND ( kschl NE lc_kschl_pb00 AND kschl NE lc_kschl_pbxx ).
                            l_amnt = l_amnt + lw_konv-kwert.
                          ENDLOOP.
                          READ TABLE lt_esll_h INTO lw_esll_h
                                               WITH KEY packno = lw_ekpo-packno.
                          IF sy-subrc = 0.
                            LOOP AT lt_esll_l INTO lw_esll_l
                                              WHERE packno EQ lw_esll_h-sub_packno.
                              l_amnt = l_amnt + ( lw_esll_l-tbtwr * lw_esll_l-menge / 1000 ).
                              CLEAR: lw_esll_l.
                            ENDLOOP.
                          ENDIF.
                        ENDIF.

                        CLEAR: l_amt_po, l_amt_so.
                        l_amt_po = l_amnt * 1000 / l_menge.
                        l_amt_so = ( lw_xvbap-netwr + lw_xvbap-mwsbp ) * 1000 / l_menge.

                        CLEAR: lv_variance.
                        IF l_amt_po NE 0.
                          lv_variance = ( l_amt_po - l_amt_so ) * '100.00' / l_amt_po.
                        ENDIF.

                        IF lv_variance LT 0.
                          lv_variance = lv_variance * ( -1 ).
                        ENDIF.

                        IF lv_variance GT lv_tolerance.
                          MESSAGE: w019(zmsg_comn) WITH lw_xvbap-posnr lw_xvbap-matnr DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                          EXIT.
                        ENDIF.

                        CLEAR: lw_xvbap.
                      ENDLOOP.

                    ELSE.

                      LOOP AT lt_esll_l INTO lw_esll_l.
                        READ TABLE xvbap INTO lw_xvbap
                                         INDEX sy-tabix.
                        IF sy-subrc = 0.
                          READ TABLE lt_esll_h INTO lw_esll_h
                                               WITH KEY sub_packno = lw_esll_l-packno.
                          IF sy-subrc = 0.
                            READ TABLE lt_ekpo INTO lw_ekpo
                                               WITH KEY packno = lw_esll_h-packno.
                            IF sy-subrc = 0.
                              READ TABLE lt_zsd_cc_asnum INTO     lw_zsd_cc_asnum
                                                         WITH KEY bukrs_s = vbak-bukrs_vf
                                                                  asnum_s = lw_xvbap-matnr
                                                                  bukrs_r = lw_ekko-bukrs.
                              IF sy-subrc EQ 0.
                                IF lw_zsd_cc_asnum-asnum_r NE lw_esll_l-srvpos.
                                  MESSAGE: w016(zmsg_comn) WITH lw_xvbap-posnr lw_ekpo-ebelp lw_esll_l-extrow DISPLAY LIKE 'E'.
                                  LEAVE TO SCREEN sy-dynnr.
                                ENDIF.
                              ELSE.
                                MESSAGE: w017(zmsg_comn) WITH lw_xvbap-matnr DISPLAY LIKE 'E'.
                                LEAVE TO SCREEN sy-dynnr.
                              ENDIF.
                            ENDIF.
                          ENDIF.
                        ELSE.
                          MESSAGE: w025(zmsg_comn) DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                        ENDIF.

                        CLEAR: lw_esll_l, lw_xvbap.
                      ENDLOOP.

                      LOOP AT xvbap INTO lw_xvbap.
                        READ TABLE lt_esll_l INTO lw_esll_l
                                             INDEX sy-tabix.
                        IF sy-subrc = 0.
                          READ TABLE lt_esll_h INTO lw_esll_h
                                               WITH KEY sub_packno = lw_esll_l-packno.
                          IF sy-subrc = 0.
                            READ TABLE lt_ekpo INTO lw_ekpo
                                               WITH KEY packno = lw_esll_h-packno.
                            IF sy-subrc = 0.
                              READ TABLE lt_zsd_cc_asnum INTO     lw_zsd_cc_asnum
                                                         WITH KEY bukrs_s = vbak-bukrs_vf
                                                                  asnum_s = lw_xvbap-matnr
                                                                  bukrs_r = lw_ekko-bukrs.
                              IF sy-subrc EQ 0.
                                IF lw_zsd_cc_asnum-asnum_r NE lw_esll_l-srvpos.
                                  MESSAGE: w016(zmsg_comn) WITH lw_xvbap-posnr lw_ekpo-ebelp lw_esll_l-extrow DISPLAY LIKE 'E'.
                                  LEAVE TO SCREEN sy-dynnr.
                                ENDIF.
                              ELSE.
                                MESSAGE: w017(zmsg_comn) WITH lw_xvbap-matnr DISPLAY LIKE 'E'.
                                LEAVE TO SCREEN sy-dynnr.
                              ENDIF.
                            ENDIF.
                          ENDIF.

                        ELSE.
                          MESSAGE: w013(zmsg_comn) DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                        ENDIF.
                        CLEAR: lw_xvbap.
                      ENDLOOP.

                      LOOP AT xvbap INTO lw_xvbap.
                        CLEAR: l_menge, l_amnt, l_meins.

                        READ TABLE lt_esll_l INTO lw_esll_l
                                             INDEX sy-tabix.
                        IF sy-subrc = 0.
                          l_menge = lw_esll_l-menge.
                          l_meins = lw_esll_l-meins.
                          READ TABLE lt_esll_h INTO lw_esll_h
                                               WITH KEY sub_packno = lw_esll_l-packno.
                          IF sy-subrc = 0.
                            READ TABLE lt_ekpo INTO lw_ekpo
                                               WITH KEY packno = lw_esll_h-packno.
                            IF sy-subrc = 0.
                              LOOP AT lt_konv INTO lw_konv
                                              WHERE kposn EQ lw_ekpo-ebelp
                                              AND ( kschl NE lc_kschl_pb00 AND kschl NE lc_kschl_pbxx ).
                                l_amnt = l_amnt + lw_konv-kwert.
                              ENDLOOP.

                              CLEAR: l_tot_qty.
                              LOOP AT lt_esll_l INTO lw_esll_l_t
                                                WHERE packno EQ lw_esll_h-sub_packno.
                                l_tot_qty = l_tot_qty + ( lw_esll_l_t-menge * lw_esll_l_t-tbtwr ).
                                CLEAR: lw_esll_l_t.
                              ENDLOOP.

                              IF l_tot_qty NE 0.
                                l_amnt = l_amnt * l_menge * lw_esll_l-tbtwr / l_tot_qty.
                              ENDIF.
                              l_amnt = l_amnt + ( lw_esll_l-tbtwr * l_menge / 1000 ).
                            ENDIF.
                          ENDIF.
                          CLEAR: lw_esll_l, lw_esll_h, lw_ekpo.
                        ENDIF.

                        CLEAR: l_menge_so.
                        IF l_meins EQ lw_xvbap-vrkme.
                          l_menge_so = lw_xvbap-kwmeng.
                        ELSE.
                          CLEAR: lw_marm_p, lw_marm_s.
                          READ TABLE lt_marm INTO lw_marm_p
                                             WITH KEY matnr = lw_xvbap-matnr
                                                      meinh = l_meins.
                          IF sy-subrc NE 0.
                            READ TABLE lt_zsd_cc_asnum INTO     lw_zsd_cc_asnum
                                                       WITH KEY bukrs_s = vbak-bukrs_vf
                                                                asnum_s = lw_xvbap-matnr
                                                                bukrs_r = lw_ekko-bukrs.
                            MESSAGE: w022(zmsg_comn) WITH lw_xvbap-matnr lw_xvbap-vrkme lw_zsd_cc_asnum-asnum_r l_meins DISPLAY LIKE 'E'.
                            LEAVE TO SCREEN sy-dynnr.
                          ENDIF.
                          READ TABLE lt_marm INTO lw_marm_s
                                             WITH KEY matnr = lw_xvbap-matnr
                                                      meinh = lw_xvbap-vrkme.
                          IF sy-subrc NE 0.
                            READ TABLE lt_zsd_cc_asnum INTO     lw_zsd_cc_asnum
                                                       WITH KEY bukrs_s = vbak-bukrs_vf
                                                                asnum_s = lw_xvbap-matnr
                                                                bukrs_r = lw_ekko-bukrs.
                            MESSAGE: w022(zmsg_comn) WITH lw_xvbap-matnr lw_xvbap-vrkme lw_zsd_cc_asnum-asnum_r l_meins DISPLAY LIKE 'E'.
                            LEAVE TO SCREEN sy-dynnr.
                          ENDIF.
                          l_menge_so = ( lw_xvbap-kwmeng * lw_marm_p-umren * lw_marm_s-umrez ) / ( lw_marm_p-umrez * lw_marm_s-umren ).

                        ENDIF.

                        IF l_menge NE l_menge_so.
                          MESSAGE: w018(zmsg_comn) WITH lw_xvbap-posnr lw_xvbap-matnr DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                          EXIT.
                        ENDIF.

                        CLEAR: l_amt_po, l_amt_so.
                        l_amt_po = l_amnt * 1000 / l_menge.
                        l_amt_so = ( lw_xvbap-netwr + lw_xvbap-mwsbp ) * 1000 / l_menge.

                        CLEAR: lv_variance.
                        IF l_amt_po NE 0.
                          lv_variance = ( l_amt_po - l_amt_so ) * '100.00' / l_amt_po.
                        ENDIF.

                        IF lv_variance LT 0.
                          lv_variance = lv_variance * ( -1 ).
                        ENDIF.

                        IF lv_variance GT lv_tolerance.
                          MESSAGE: w019(zmsg_comn) WITH lw_xvbap-posnr lw_xvbap-matnr DISPLAY LIKE 'E'.
                          LEAVE TO SCREEN sy-dynnr.
                          EXIT.
                        ENDIF.
                        CLEAR: lw_xvbap.
                      ENDLOOP.

                    ENDIF.
                  ENDIF.

                ENDIF.
            ENDCASE.
          ENDIF.

        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDENHANCEMENT.
