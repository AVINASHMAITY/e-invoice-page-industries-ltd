*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBPI_FORECASTTOP.                 " Global Data
  INCLUDE LZBPI_FORECASTUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBPI_FORECASTF...                 " Subroutines
* INCLUDE LZBPI_FORECASTO...                 " PBO-Modules
* INCLUDE LZBPI_FORECASTI...                 " PAI-Modules
* INCLUDE LZBPI_FORECASTE...                 " Events
* INCLUDE LZBPI_FORECASTP...                 " Local class implement.
* INCLUDE LZBPI_FORECASTT99.                 " ABAP Unit tests
  INCLUDE LZBPI_FORECASTF00                       . " subprograms
  INCLUDE LZBPI_FORECASTI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
