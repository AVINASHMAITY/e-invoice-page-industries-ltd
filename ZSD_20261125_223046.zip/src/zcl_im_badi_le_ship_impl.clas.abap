class ZCL_IM_BADI_LE_SHIP_IMPL definition
  public
  final
  create public .

public section.

  interfaces IF_EX_BADI_LE_SHIPMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_BADI_LE_SHIP_IMPL IMPLEMENTATION.


  METHOD if_ex_badi_le_shipment~at_save.



*   LOOP AT cha_shipments_at_save-new_vtts ASSIGNING FIELD-SYMBOL(<lw_vtts>).
*      IF <lw_vtts>-route IS NOT INITIAL.
*        SELECT SINGLE vendor FROM zlogistics_delv INTO @DATA(lv_vendor)
*          WHERE route = @<lw_vtts>-route
*          AND   leg =  @<lw_vtts>-laufk.
*        IF sy-subrc = 0.
*          <lw_vtts>-tdlnr = lv_vendor.
**          IF sy-tabix = 2.
**            READ TABLE cha_shipments_at_save-new_vttk ASSIGNING FIELD-SYMBOL(<lw_vttk>) WITH KEY route = <lw_vtts>-route .
**            <lw_vttk>-tdlnr = lv_vendor.
**          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDLOOP.





  ENDMETHOD.


  METHOD if_ex_badi_le_shipment~before_update.

*    LOOP AT cha_shipments_at_save-new_vtts ASSIGNING FIELD-SYMBOL(<lw_vtts>).
*      IF <lw_vtts>-route IS NOT INITIAL.
*        SELECT SINGLE vendor FROM zlogistics_delv INTO @DATA(lv_vendor)
*          WHERE route = @<lw_vtts>-route
*          AND   leg =  @<lw_vtts>-laufk.
*        IF sy-subrc = 0.
*          <lw_vtts>-tdlnr = lv_vendor.
**          IF sy-tabix = 2.
**            READ TABLE cha_shipments_at_save-new_vttk ASSIGNING FIELD-SYMBOL(<lw_vttk>) WITH KEY route = <lw_vtts>-route .
**            <lw_vttk>-tdlnr = lv_vendor.
**          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDLOOP.

  ENDMETHOD.


  method IF_EX_BADI_LE_SHIPMENT~IN_UPDATE.
  endmethod.
ENDCLASS.
