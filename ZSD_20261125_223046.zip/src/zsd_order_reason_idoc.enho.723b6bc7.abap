"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ORDER_REASON_IDOC.
*&----------------------------------------------------------------
*Date       : 25.05.2023
*Programmer : Sumit
*TR No.     : DR1K975730
*Description: Enhancment for Order Reason
*&----------------------------------------------------------------
data:lwa_E1EDK01_temp type E1EDK01.
data:lv_idoc1 type char1.

LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_idoc>) where segnam = 'E1EDK01' .
lwa_E1EDK01_temp  = <fs_idoc>-sdata.
*IF lwa_E1EDK01_temp-augru is not INITIAL.      "Commented by Suganya DR1K990784 to avoid clearnce issue while reason code blank
DATA(lv_augru) = lwa_E1EDK01_temp-augru.
lv_idoc1 = 'X'.
EXPORT lv_idoc1 TO MEMORY id 'LV_IDOC1'.
EXPORT lv_augru TO MEMORY id 'LV_AUGRU'.
*ENDIF.                                         "Commented by Suganya DR1K990784 to avoid clearnce issue while reason code blank
ENDLOOP.

ENDENHANCEMENT.
