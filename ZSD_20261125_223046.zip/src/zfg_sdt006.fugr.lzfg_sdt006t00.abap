*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSDT006.........................................*
DATA:  BEGIN OF STATUS_ZSDT006                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSDT006                       .
CONTROLS: TCTRL_ZSDT006
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZSDT006                       .
TABLES: ZSDT006                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
