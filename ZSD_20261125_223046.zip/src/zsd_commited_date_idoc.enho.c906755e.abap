"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAP\SE:END\EI
ENHANCEMENT 0 ZSD_COMMITED_DATE_IDOC.
*&----------------------------------------------------------------
*Date       : 06.06.2023
*Programmer : Sumit
*TR No.     : DR1K975848
*TR No.     : DR1K976367
*Description: Enhancment for Committed Date and Payment term
*&----------------------------------------------------------------
DATA:lv_idoc TYPE CHAR1.
data:lv_ZTERM type vbkd-zterm.

import lv_idoc from MEMORY id 'LV_IDOC'.

If Sy-tcode = 'VA01' and lv_idoc = 'X'.

VBAP-commit_date = sy-datum.
**********Changes for Payment term DR1K976367
import lv_ZTERM from MEMORY ID 'ZTERM'.

VBKD-ZTERM = lv_ZTERM.
**********Changes for Payment term DR1K976367
Endif.

ENDENHANCEMENT.
