"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAP\SE:END\EI
ENHANCEMENT 0 ZSD_MATERIAL_CHAPTER_ID.
*&--------------------Modification Log---------------------------------*
*Date       : 06.06.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K945737                                               *
*Description: Remove Sales Org. 1102 and Add ZCMAIN for BFI            *
*&---------------------------------------------------------------------*
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************
*****************************************************************
* Developer         : Bhagavan/Iteanz
* Changes           : Restricting Z1 Block for Order Type
*                     which maintained in ZSD_RESTRICT_BLK table
*                     for the ZSD_QUOT_SO
* Transaport        : DR1K953998
*****************************************************************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************

DATA: I_plant1 type TABLE OF ZSDT004,
      W_plant1 type  ZSDT004.
If Sy-tcode = 'VA01'  or Sy-tcode = 'VA02' or Sy-tcode = 'VA21'  OR  sy-tcode = 'ZSD_QUOT_SO' and Sy-tcode = 'VA22'.  " 'Zsd_quot_so'Added by Bhagavan on 18.11.2020  DR1K953998
data: v_MTART type mara-mtart.
data : v_steuc TYPE MARC-STEUC .
FIELD-SYMBOLS : <lx_MATNR> type any.
FIELD-SYMBOLS : <lx_vkorg> type any.
FIELD-SYMBOLS : <lx_werks1> type any.

  ASSIGN ('(SAPMV45A)VBAP-MATNR') TO <lx_MATNR>.
  ASSIGN ('(SAPMV45A)VBAK-VKORG') TO <lx_VKORG>.
  ASSIGN ('(SAPMV45A)VBAP-WERKS') TO <lx_WERKS1>.
if <lx_VKORG> is ASSIGNED.
if <lx_VKORG>  = '1101'.
if  <lx_matnr> IS ASSIGNED.
  select * from ZSDT004 INTO TABLE i_plant1.
SELECT SINGLE MTART from mara INTO v_MTART where matnr = <lx_matnr>.
 if v_MTART ne 'DIEN'.
  if  <lx_WERKS1> is ASSIGNED.
    READ TABLE i_plant1 INTO w_plant1 with key  auart = vbak-auart
                                              werks = <lx_WERKS1>."xvbap-werks.
    if sy-subrc eq 0.
    if w_plant1-CHP_ID is INITIAL.
   SELECT SINGLE steuc from marc INTO v_steuc where matnr = <lx_matnr>
                                                and    werks = <lx_WERKS1>.
   if v_steuc is INITIAL.
    MESSAGE e000(8i) with 'Chapter ID not updated for the Material' <lx_matnr>.
   endif.
 endif.
endif.
endif.
endif.
endif.
endif.
 endif.
 endif.
If Sy-tcode = 'VA01' or Sy-tcode = 'VA02' .
*  if vbak-vkorg = '1102' .
  if vbak-vkorg IN ra_vkorg .            "Added by Ravi on 06.06.2019 DR1K945737
* if ( vbak-auart = 'YBOR' or vbak-auart = 'YBOI' ).
if <lx_WERKS1> is not INITIAL.
*  AUTHORITY-CHECK OBJECT 'ZOBJ_WERKS'
*             ID 'WERKS' FIELD <lx_WERKS1>
*             ID 'ACTVT' FIELD '01'.
*    IF SY-SUBRC <> 0.
*      MESSAGE 'You do not have authorisation for this plant' type 'E'.
*    ENDIF.
 data: W_ZSDT_PLANT_USER  type ZSDT_PLANT_USER.
 CLEAR w_ZSDT_PLANT_USER.
 select single * From ZSDT_PLANT_USER INTO w_ZSDT_PLANT_USER where vkorg = vbak-vkorg
                                and   vwerk = <lx_WERKS1>
                                and   UNAME = sy-uname.
* if sy-subrc eq 0.
 if sy-subrc NE 0.
*  if w_ZSDT_PLANT_USER-uname ne sy-uname.
   MESSAGE 'You do not have authorisation for this plant' type 'E'.
*  endif.
 endif.
types: BEGIN OF t_knvv,
        kunnr type knvv-kunnr,
        vwerk type knvv-vwerk,
       end of t_knvv.
data: i_knvv TYPE TABLE OF t_knvv,
      w_knvv type t_knvv.
CLEAR w_knvv.
REFRESH i_knvv.
 Select kunnr vwerk from knvv INTO TABLE i_knvv where kunnr = vbak-kunnr.
 if i_knvv is NOT INITIAL.
 read TABLE i_knvv INTO w_knvv with key kunnr = vbak-kunnr
                                     vwerk = <lx_WERKS1>.
 if sy-subrc ne 0.

  read TABLE i_knvv INTO w_knvv with key kunnr = vbak-kunnr.
  if w_knvv-vwerk is not INITIAL.
  if w_knvv-vwerk ne <lx_WERKS1>.
   MESSAGE 'Customer does not belongs to your plant' type 'E'.
  endif.
   endif.
 endif.
 endif.

endif.
*endif.
endif.
endif.
XVBAP-BLOCK_ORDER = 'Blocked'.
DATA: I_plant type TABLE OF ZSDT004,
      W_plant type  ZSDT004.
*BREAK-POINT.

IF sy-ucomm = 'SICH' or  sy-ucomm = 'YES' or sy-ucomm = 'TEIL' or sy-ucomm = 'WEIT' or sy-ucomm = 'OPT1' or sy-ucomm = 'NO' or sy-ucomm = 'CANC' or sy-ucomm = ''.
IF ( sy-tcode = 'VA02' or sy-tcode = 'VA01' OR  sy-tcode = 'ZSD_QUOT_SO' ) and ( vbak-vkorg = '1101'  )."or vbak-vkorg = '1102' ). " 'Zsd_quot_so'Added by Bhagavan on 18.11.2020  DR1K953998
  select * from ZSDT004 INTO TABLE i_plant.
FIELD-SYMBOLS: <LX_werks> type any,
      <LX_auart> type any.
ASSIGN ('(SAPMV45A)VBAP-WERKS') TO <lx_WERKS>.
*ASSIGN ('(SAPMV45A)VBAK-') TO <lx_WERKS>.
*  LOOP AT xvbap[] INTO xvbap.
    READ TABLE i_plant INTO w_plant with key  auart = vbak-auart
                                              werks = <lx_WERKS>."xvbap-werks.
    if sy-subrc ne 0.
*    if sy-subrc eq 0.
*    if w_plant-CHP_ID is INITIAL.
      MESSAGE e000(8I) with 'Selected Doc type' VBAK-AUART  'not pertaining to' vbap-werks.
*    endif.Biocon-ABAP Devlpmnt
    endif.
*  ENDLOOP.
endif.
endif.
If sy-tcode = 'VA01' or sy-tcode = 'VA02' OR  sy-tcode = 'ZSD_QUOT_SO' .  " 'Zsd_quot_so'Added by Bhagavan on 18.11.2020  DR1K953998
*IF VBAK-VKORG = '1102'.
IF VBAK-VKORG IN ra_vkorg.               "Added by Ravi on 06.06.2019 DR1K945737
data: v_lgort type zsdt011-lgort.
FIELD-SYMBOLS : <lx_lgort> type any.


select SINGLE lgort from zsdt011 INTO v_lgort where auart = VBAK-auart.
if sy-subrc = 0.
*   (SAPMV45A)VBAP-WERKS = v_lgort.
  vbap-lgort = v_lgort.
*  ASSIGN <lx_lgort> to ('(SAPMV45A)VBAP-LGORT') ."TO <lx_MATNR>.
endif.
endif.
endif.

if ( sy-tcode = 'VA01' )  or ( sy-tcode = 'VA02' ) OR  ( sy-tcode = 'ZSD_QUOT_SO' ).   " 'Zsd_quot_so'Added by Bhagavan on 18.11.2020  DR1K953998
*BREAK sahoo.
if VBAK-VBTYP = 'C'.
*if vbak-vkorg = '1102'.
if vbak-vkorg IN ra_vkorg.         "Added by Ravi on 06.06.2019 DR1K945737
FIELD-SYMBOLS : <lx_charg> type any.
FIELD-SYMBOLS : <lx_matnr1> type any.
FIELD-SYMBOLS : <lx_auart1> type any. " Added on 06.05.2015
data: v_vfdat type mch1-vfdat.
    ASSIGN ('(SAPMV45A)VBAP-MATNR') TO <lx_MATNR1>.
  ASSIGN ('(SAPMV45A)VBAP-CHARG') TO <lx_CHARG>.
if <lx_charg> is ASSIGNED.
 if <lx_matnr1> is ASSIGNED.
   IF vbak-auart NE 'YBEX'.
   select SINGLE vfdat from mch1 INTO v_vfdat where matnr = <lx_MATNR1>
                                                and   charg =  <lx_CHARG>.
      if v_vfdat is not INITIAL.
        if  v_vfdat(6) le sy-datum(6).
          MESSAGE e000(8i) with <lx_CHARG> 'Batch is expired'.
        endif.
      endif.
   ENDIF.
 endif.
endif.
endif.
endif.
endif.
*DATA: L_yvbap type vbap,
*      l_xvbap type vbap.
*data: v_vfdat type mch1-vfdat.
*loop at yvbap INTO l_yvbap.
* read TABLE xvbap INTO l_xvbap with key posnr = l_yvbap-posnr.
* if sy-subrc = 0.
*   if l_xvbap-charg ne l_yvbap-charg.
*     select SINGLE vfdat from mch1 INTO v_vfdat where matnr = l_xvbap-matnr
*                                                and   charg = l_xvbap-charg.
*      if v_vfdat is not INITIAL.
*        if  v_vfdat(6) le sy-datum(6).
*          MESSAGE e000(8i) with l_xvbap-charg 'Batch is expired'.
*        endif.
*      endif.
*   endif.
* endif.
* CLEAR : L_yvbap,L_yvbap,v_vfdat.
*endloop.
*endif.
*endif.
ENDENHANCEMENT.
