*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_SEZBILLTYPE................................*
DATA:  BEGIN OF STATUS_ZCYG_SEZBILLTYPE              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_SEZBILLTYPE              .
CONTROLS: TCTRL_ZCYG_SEZBILLTYPE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_SEZBILLTYPE              .
TABLES: ZCYG_SEZBILLTYPE               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
