"Name: \PR:SAPLV60A\EX:RV_INVOICE_DOCUMENT_ADD_32\EI
ENHANCEMENT 0 ZSD_NUMBERRANGE_RV_INVOICE_DOC.
**Begin of change made by parul kumar sharma
**Type declaration for Constant
TYPES : BEGIN OF t_constant,
          regionfrom TYPE char2,
        END OF t_constant.
**Local Data Declaration
DATA : lw_ztsd_inv_range TYPE ztsd_inv_range,
       lw_vbrp TYPE vbrp,
       lv_regionto TYPE regio,
       lv_regionfrom TYPE regio,
       lv_kunnr TYPE kunnr,
       lw_constants TYPE t_constant,
       lv_nr TYPE char2,
       lv_vbeln type vbeln,
       lv_gjahr type gjahr.

"Get Constants from Utility Class
DATA: li_constants_ztab TYPE ztt_ztabap_tvarvc,
      lw_constants_ztab TYPE ztabap_tvarvc.

FIELD-SYMBOLS <lx_constants> TYPE any.

CASE xvbrk-fkdat+4(2).
  WHEN 01 or 02 or 03.
    lv_gjahr = xvbrk-fkdat+0(4).
    lv_gjahr = lv_gjahr - 1.
  WHEN OTHERS.
    lv_gjahr = xvbrk-fkdat+0(4).
ENDCASE.

CLEAR li_constants_ztab.
 CALL METHOD zcl_abap_utility=>get_parameters
  EXPORTING
    im_objname = 'RV_INVOICE_DOCUMENT_ADD'
  IMPORTING
    ex_tab     = li_constants_ztab.
 SORT li_constants_ztab BY id. "Sort by Index/ID
"Assigning Constants from Internal Table to local Structure
 LOOP AT li_constants_ztab INTO lw_constants_ztab.
   UNASSIGN <lx_constants>.
   ASSIGN COMPONENT sy-tabix
      OF STRUCTURE lw_constants
                TO <lx_constants>.
    IF <lx_constants> IS ASSIGNED.
     <lx_constants> = lw_constants_ztab-low.
    ENDIF.
    CLEAR lw_constants_ztab.
 ENDLOOP.

   READ TABLE xvbrp INTO lw_vbrp INDEX 1.
   IF sy-subrc = 0.
    lv_kunnr = lw_vbrp-werks.
     CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
        EXPORTING
          input  = lv_kunnr
        IMPORTING
          output = lv_kunnr.
     SELECT SINGLE regio INTO lv_regionfrom
                             FROM kna1
                             WHERE kunnr = lv_kunnr.
           IF lv_regionfrom = lw_constants-regionfrom.
             CLEAR lv_kunnr.
             lv_kunnr = likp-kunnr.
               IF sy-subrc = 0.
                  SELECT SINGLE regio INTO lv_regionto
                             FROM kna1
                             WHERE kunnr = lv_kunnr.
                    IF lv_regionfrom = lv_regionto.
                       SELECT SINGLE * FROM ztsd_inv_range
                          INTO lw_ztsd_inv_range
                          where werks = lw_vbrp-werks
                         and gjahr = lv_gjahr
                          AND fkart = xvbrk-fkart
                          AND region_from = lv_regionfrom
                          AND region_to = lv_regionto.
                        IF sy-subrc = 0.
                             IF lw_ztsd_inv_range-nrlevel is initial.
                              lw_ztsd_inv_range-nrlevel = lw_ztsd_inv_range-FROMNUMBER.
                             ENDIF.
*                             lv_gjahr = lv_gjahr + 1.
                             xvbrk-vbeln+0(2) = lv_gjahr+2(2).
                                    lw_ztsd_inv_range-nrlevel =
                                    lw_ztsd_inv_range-nrlevel + 1.
                           CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                            EXPORTING
                              input  = lw_ztsd_inv_range-nrlevel
                            IMPORTING
                              output = lw_ztsd_inv_range-nrlevel.
                            xvbrk-vbeln+2(8) = lw_ztsd_inv_range-nrlevel.
                          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                            EXPORTING
                              input  = xvbrk-vbeln
                            IMPORTING
                              output = xvbrk-vbeln.
                          select single vbeln
                                 into lv_vbeln
                                 from vbrk
                                 where vbeln = xvbrk-vbeln.
                    IF sy-subrc = 0.
             MESSAGE e030(zsd_messages).
                    ENDIF.
                 ELSE.
             MESSAGE e023(zsd_messages) WITH lw_vbrp-werks xvbrk-fkart lv_regionfrom.
                 ENDIF.
                    ELSE.
                     SELECT SINGLE * FROM ztsd_inv_range
                          INTO lw_ztsd_inv_range
                          where werks = lw_vbrp-werks
                          and  gjahr = lv_gjahr
                          AND fkart = xvbrk-fkart
                          AND region_from = lv_regionfrom
                          AND region_to = space.
                       IF sy-subrc = 0.
                            IF lw_ztsd_inv_range-nrlevel is initial.
                              lw_ztsd_inv_range-nrlevel = lw_ztsd_inv_range-FROMNUMBER.
                             ENDIF.
*                            lv_gjahr = lv_gjahr + 1.
                            xvbrk-vbeln+0(2) = lv_gjahr+2(2).
                           lw_ztsd_inv_range-nrlevel =
                               lw_ztsd_inv_range-nrlevel + 1.
                          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                            EXPORTING
                              input  = lw_ztsd_inv_range-nrlevel
                            IMPORTING
                              output = lw_ztsd_inv_range-nrlevel.
                          xvbrk-vbeln+2(8) = lw_ztsd_inv_range-nrlevel.
                         CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                            EXPORTING
                              input  = xvbrk-vbeln
                            IMPORTING
                              output = xvbrk-vbeln.
                     select single vbeln
                                 into lv_vbeln
                                 from vbrk
                                 where vbeln = xvbrk-vbeln.
                    IF sy-subrc = 0.
             MESSAGE e030(zsd_messages).
                    ENDIF.
                       ELSE.
              MESSAGE e023(zsd_messages) WITH lw_vbrp-werks xvbrk-fkart lv_regionfrom.
                       ENDIF.
                   ENDIF.
               ENDIF.
           ELSE.
               SELECT SINGLE * FROM ztsd_inv_range
                        INTO lw_ztsd_inv_range
                        WHERE werks = lw_vbrp-werks
                        and  gjahr = lv_gjahr
                        AND fkart = xvbrk-fkart.
               IF sy-subrc = 0.
                 IF lw_ztsd_inv_range-nrlevel is initial.
                   lw_ztsd_inv_range-nrlevel = lw_ztsd_inv_range-FROMNUMBER.
                 ENDIF.
*                 lv_gjahr = lv_gjahr + 1.
                 xvbrk-vbeln+0(2) = lv_gjahr+2(2).
              lw_ztsd_inv_range-nrlevel = lw_ztsd_inv_range-nrlevel + 1.
              CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                            EXPORTING
                              input  = lw_ztsd_inv_range-nrlevel
                            IMPORTING
                              output = lw_ztsd_inv_range-nrlevel.
                 xvbrk-vbeln+2(8) = lw_ztsd_inv_range-nrlevel.
                 CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
                            EXPORTING
                              input  = xvbrk-vbeln
                            IMPORTING
                              output = xvbrk-vbeln.
                   select single vbeln
                                 into lv_vbeln
                                 from vbrk
                                 where vbeln = xvbrk-vbeln.
                    IF sy-subrc = 0.
             MESSAGE e030(zsd_messages).
                    ENDIF.
               ELSE.
       MESSAGE e006(zsd_messages) WITH lw_vbrp-werks xvbrk-fkart.
               ENDIF.
         ENDIF.



**Begin of changes for ZMRP condition type
**   start of change by Shony on 14 July 2014 ------------------------>>
**   start of change by Shony on 14 July 2014 ------------------------>>

data : lv_xkomv type  komv,
       lv_xvbrp type vbrpvb,
       lw_xkomv type komv.

  if xvbrk-vkorg = '1102'.
     if xvbrk-KALSM = 'ZINCFA'.
  loop at xvbrp into lv_xvbrp.
    if lv_xvbrp-fkimg is not INITIAL.
    read table xkomv into lw_xkomv with key kposn = lv_xvbrp-posnr
                                            kschl = 'ZMRP' .
    IF SY-SUBRC NE 0.
     MESSAGE 'Please maintain condition record for ZMRP' type 'E'.
    ENDIF.
    endif.
endloop.


  loop at xkomv into lv_xkomv .
   if lv_xkomv-kschl eq 'ZMRP'.
       IF  lV_xkomv-KWERT IS INITIAL.
      MESSAGE 'Please maintain condition record for ZMRP' type 'E'.
      endif.
*   elseif lv_xkomv-kschl eq space.
*     MESSAGE 'Please maintain condition record for ZMRP' type 'E'.
   endif.
      clear : lv_xkomv.
  endloop.
    endif.
    endif.
****    -----------------------End of change by Shony on 14 July 2014 ---------------
****    -----------------------End of change by Shony on 14 July 2014 ---------------


  UPDATE ztsd_inv_range set NRLEVEL = lw_ztsd_inv_range-NRLEVEL
          where FROMNUMBER = lw_ztsd_inv_range-FROMNUMBER
            AND gjahr = lv_gjahr.        "Added by Ravi on 08.08.2018 DR1K941467
*  COMMIT WORK AND WAIT.     "Added by Ravi on 24.04.2018 DR1K939905 "Commented by chandru "DR1K937851 on 02.05.2018
  ENDIF.
**End of change made by parul kumar sharma

***Begin of changes for ZMRP condition type
*
*
*
*data : lv_xkomv type  komv,
*       lv_xvbrp type vbrpvb,
*       lw_xkomv type komv.
*
*
*
*
*
*
*  if xvbrk-vkorg = '1102'.
*
*     if xvbrk-KALSM = 'ZINCFA'.
*
*
*  loop at xvbrp into lv_xvbrp.
*
*    if lv_xvbrp-fkimg is not INITIAL.
*
*    read table xkomv into lw_xkomv with key kposn = lv_xvbrp-posnr
*                                            kschl = 'ZMRP' .
*    IF SY-SUBRC NE 0.
*     MESSAGE 'Please maintain condition record for ZMRP' type 'E'.
*
*    ENDIF.
*    endif.
*
*
*
*endloop.
*
*
*  loop at xkomv into lv_xkomv .
*
*   if lv_xkomv-kschl eq 'ZMRP'.
*       IF  lV_xkomv-KWERT IS INITIAL.
*      MESSAGE 'Please maintain condition record for ZMRP' type 'E'.
*      endif.
**   elseif lv_xkomv-kschl eq space.
**     MESSAGE 'Please maintain condition record for ZMRP' type 'E'.
*   endif.
*
*      clear : lv_xkomv.
*  endloop.
*    endif.
*    endif.











**end of changes.

*-->Begin of PDC Chnages
        IF l_flag = 'X'.

*-->Cheques
        CLEAR:t_cheq_v,l_diff.
        LOOP AT li_cheques3 INTO lw_cheques.
          t_cheq_v = t_cheq_v + lw_cheques-bal_amt.

*-->Local Cheques
          IF lw_cheques-cheque_type = 'L'.
*            T_CHEQ_V " Total Cheque Value.
*            T_BILL " Total Bill valu
            l_diff = t_bill - t_cheq_v.
            IF lw_cheques-vbeln1 IS INITIAL.
              lw_cheques-vbeln1 = xvbrk-vbeln.
              lw_cheques-fkdat1 = xvbrk-fkdat.
              lw_cheques-netwr1 = l_diff.
            ELSEIF lw_cheques-vbeln2 IS INITIAL.
              lw_cheques-cheque_amt = l_diff.
              lw_cheques-vbeln2 = xvbrk-vbeln.
              lw_cheques-fkdat2 = xvbrk-fkdat.
              lw_cheques-netwr2 = l_diff.
            ELSEIF lw_cheques-vbeln3 IS INITIAL.
              lw_cheques-vbeln3 = xvbrk-vbeln.
              lw_cheques-fkdat3 = xvbrk-fkdat.
              lw_cheques-netwr3 = l_diff.
            ELSEIF lw_cheques-vbeln4 IS INITIAL.
              lw_cheques-vbeln4 = xvbrk-vbeln.
              lw_cheques-fkdat4 = xvbrk-fkdat.
              lw_cheques-netwr4 = l_diff.
            ENDIF.

            lw_cheques-cheque_amt = lw_cheques-netwr1 + lw_cheques-netwr2 + lw_cheques-netwr3 + lw_cheques-netwr4.
            lw_cheques-adj_amt = lw_cheques-cheque_amt.
            APPEND lw_cheques TO li_cheques4.
            EXIT.
          ENDIF.

          IF t_cheq_v GE t_bill.
            l_diff = t_cheq_v - t_bill.
            l_adj_amt = lw_cheques-bal_amt - l_diff.
            lw_cheques-adj_amt = lw_cheques-adj_amt + l_adj_amt.
            lw_cheques-bal_amt = l_diff.
            IF lw_cheques-vbeln1 IS INITIAL.
              lw_cheques-vbeln1 = xvbrk-vbeln.
              lw_cheques-fkdat1 = xvbrk-fkdat.
              lw_cheques-netwr1 = l_adj_amt.
            ELSEIF lw_cheques-vbeln2 IS INITIAL.
              lw_cheques-vbeln2 = xvbrk-vbeln.
              lw_cheques-fkdat2 = xvbrk-fkdat.
              lw_cheques-netwr2 = l_adj_amt.
            ELSEIF lw_cheques-vbeln3 IS INITIAL.
              lw_cheques-vbeln3 = xvbrk-vbeln.
              lw_cheques-fkdat3 = xvbrk-fkdat.
              lw_cheques-netwr3 = l_adj_amt.
            ELSEIF lw_cheques-vbeln4 IS INITIAL.
              lw_cheques-vbeln4 = xvbrk-vbeln.
              lw_cheques-fkdat4 = xvbrk-fkdat.
              lw_cheques-netwr4 = l_adj_amt.
            ENDIF.
            APPEND lw_cheques TO li_cheques4.
            EXIT.
          ELSE.
            IF lw_cheques-vbeln1 IS INITIAL.
              lw_cheques-vbeln1 = xvbrk-vbeln.
              lw_cheques-fkdat1 = xvbrk-fkdat.
              lw_cheques-netwr1 = lw_cheques-bal_amt.
            ELSEIF lw_cheques-vbeln2 IS INITIAL.
              lw_cheques-vbeln2 = xvbrk-vbeln.
              lw_cheques-fkdat2 = xvbrk-fkdat.
              lw_cheques-netwr2 = lw_cheques-bal_amt.
            ELSEIF lw_cheques-vbeln3 IS INITIAL.
              lw_cheques-vbeln3 = xvbrk-vbeln.
              lw_cheques-fkdat3 = xvbrk-fkdat.
              lw_cheques-netwr3 = lw_cheques-bal_amt.
            ELSEIF lw_cheques-vbeln4 IS INITIAL.
              lw_cheques-vbeln4 = xvbrk-vbeln.
              lw_cheques-fkdat4 = xvbrk-fkdat.
              lw_cheques-netwr4 = lw_cheques-bal_amt.
            ENDIF.
            lw_cheques-adj_amt = lw_cheques-adj_amt + lw_cheques-bal_amt.
            lw_cheques-bal_amt = 0.
            APPEND lw_cheques TO li_cheques4.
          ENDIF.
        ENDLOOP.
        MODIFY zsd_pd_cheques FROM TABLE  li_cheques4.
        ENDIF.
*-->End of PDC Chnages

"Begin of Addition by chandru "DR1K937851 "Common ODN
constants : lc_tcode(10) value 'J1IGSUBCON',
            lc_6(1) value '6',
            lc_1(1) value '1',
            lc_7(1) value '7',
            lc_sym(2) value '||'.
  IF sy-tcode EQ lc_tcode.
    select *
      from zmm_challan_bill
      where bukrs EQ @XVBRK-BUKRS
      and FKART EQ @XVBRK-FKART
      into table @data(lt_ichk).
      IF sy-subrc EQ 0.
        data(lw_chk) = value #( XVBRP[ 1 ] optional ).
        if lw_chk-werks+0(1) eq lc_1.
          data(cl_odn) = new zcl_common_odn( ).
          cl_odn->werks = lw_chk-werks.
          cl_odn->update( importing result = data(result) odn = data(odn) data = data(val) ).
          if result eq lc_6.
            split val at lc_sym into data(a) data(b).
            message e003(zodn) with a b cl_odn->tab.
          elseif result eq abap_true.
            message e002(zodn).
          elseif result eq abap_undefined.
            message e001(zodn).
          elseif result eq lc_7.
            xvbrk-xblnr = odn.
          endif.
        endif.
      endif.
  endif.
"End of Addition by chandru "DR1K937851 "Common ODN
***** Start of change by Sristi " Missing Accumulation
 data : ls_knvi type knvi.
 DATA:  ls_thld      TYPE j_1ig_thld,
        ls_accum     TYPE zsd_accumhdr,
        ls_accum_n   TYPE zsd_accumhdr,
        ls_accumkey  TYPE j_1ig_accumkey,
        ls_accumhdr_badi TYPE j_1ig_accumhdr.
 DATA : lt_accumdtl type TABLE OF ZSD_ACCUMDTL.
 DATA : lt_accumdtl_n type TABLE OF ZSD_ACCUMDTL.
 data : ls_Accumdtl type ZSD_ACCUMDTL.
 data : ls_Accumdtl_n type ZSD_ACCUMDTL.
 data : ls_Accumitm type ZSD_ACCUMDTL.
 DATA lv_count TYPE i.

 data : lv_Seq type J_1IG_ACCUM_SEQ,
        lv_accum type J_1IG_ACCUM_PREV.
 data : ls_vbrp type vbrp.
 data : lv_Accum_amt type J_1IG_ACCUM_AMT.

  ls_thld = j_1ig_cl_tcs_utility=>threshold_amount( vbrk-fkdat ).
               CALL METHOD j_1ig_cl_tcs_utility=>buyer_id
                EXPORTING
                  kunnr           = xvbrk-kunag
                IMPORTING
                  ev_buyer_id     = ls_accumkey-buyer_id
                  ev_buyer_idtype = ls_accumkey-buyer_idtype.


              ls_accumkey-seller_pan = j_1ig_cl_tcs_utility=>seller_id( xvbrk-bukrs ).
              ls_accumkey-kunnr      = xvbrk-kunag.
              ls_accumkey-thld_cat   = ls_thld-thld_cat.
              ls_accumkey-valid_from = ls_thld-valid_from.
              CLEAR ls_accum_n.
      if ls_accumkey-buyer_id is NOT initial.
            select  *  from zsd_accumdtl into table lt_accumdtl where thld_cat = ls_thld-thld_cat
                                                                    and SELLER_PAN = ls_accumkey-seller_pan
                                                                    and BUYER_IDTYPE = ls_accumkey-buyer_idtype
                                                                    and BUYER_ID = ls_accumkey-buyer_id
                                                                    and VALID_FROM = ls_thld-valid_from.

*            clear lv_accum_amt.
*            select single accum_Amt into lv_Accum_Amt from zsd_accumhdr where THLD_CAT = ls_thld-thld_cat
            SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum where THLD_CAT = ls_thld-thld_cat
                                                                          and SELLER_PAN = ls_accumkey-seller_pan
                                                                          and BUYER_IDTYPE = ls_accumkey-buyer_idtype
                                                                          and BUYER_ID = ls_accumkey-buyer_id
                                                                          and VALID_FROM = ls_thld-valid_from.
              "SOC by madhur on 140823
              IF sy-subrc NE 0.
           select  *  from zsd_accumdtl into table lt_accumdtl where thld_cat = ls_thld-thld_cat
                                                                    and SELLER_PAN = ls_accumkey-seller_pan
                                                                    and KUNNR = xvbrk-kunag
                                                                    and VALID_FROM = ls_thld-valid_from.

*           clear lv_accum_amt.
*           select single accum_Amt into lv_Accum_Amt from zsd_accumhdr where THLD_CAT = ls_thld-thld_cat
           SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum where THLD_CAT = ls_thld-thld_cat
                                                                          and SELLER_PAN = ls_accumkey-seller_pan
                                                                          and KUNNR = xvbrk-kunag
                                                                          and VALID_FROM = ls_thld-valid_from.

*             DELETE Zsd_ACCUMHDR WHERE kunnr =  ls_accum-kunnr  VALID_FROM = ls_accum-valid_from.
              IF sy-subrc = 0.
              DELETE  Zsd_ACCUMHDR FROM ls_accum.
**              IF sy-subrc = 0.
**                  COMMIT WORK.
**              ENDIF.
             ls_accum-kunnr = ''.
             ls_accum-buyer_id = ls_accumkey-buyer_id.
             ls_accum-buyer_idtype = ls_accumkey-buyer_idtype.
             ENDIF.

             ELSE.
               SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum_n where THLD_CAT = ls_thld-thld_cat
                                                                          and SELLER_PAN = ls_accumkey-seller_pan
                                                                          and buyer_id = ''
                                                                          and KUNNR = xvbrk-kunag
                                                                          and VALID_FROM = ls_thld-valid_from.

*             DELETE Zsd_ACCUMHDR WHERE kunnr =  ls_accum-kunnr  VALID_FROM = ls_accum-valid_from.
              IF sy-subrc = 0.
              DELETE  Zsd_ACCUMHDR FROM ls_accum_n.
**              IF sy-subrc = 0.
**                  COMMIT WORK.
**              ENDIF.
             ls_accum-kunnr = ''.
             ls_accum-buyer_id = ls_accumkey-buyer_id.
             ls_accum-buyer_idtype = ls_accumkey-buyer_idtype.
             ls_accum-accum_amt = ls_accum-accum_amt + ls_accum_n-accum_amt.
              ENDIF.
              ENDIF.
              "EOC by madhur on 140823
             ELSE.
           select  *  from zsd_accumdtl into table lt_accumdtl where thld_cat = ls_thld-thld_cat
                                                                    and SELLER_PAN = ls_accumkey-seller_pan
                                                                    and KUNNR = xvbrk-kunag
                                                                    and VALID_FROM = ls_thld-valid_from.

*           clear lv_accum_amt.
*           select single accum_Amt into lv_Accum_Amt from zsd_accumhdr where THLD_CAT = ls_thld-thld_cat
            SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum where THLD_CAT = ls_thld-thld_cat
                                                                          and SELLER_PAN = ls_accumkey-seller_pan
                                                                          and KUNNR = xvbrk-kunag
                                                                          and VALID_FROM = ls_thld-valid_from.
      endif.
**     if  ls_accumkey-buyer_id IS NOT initial .
**           SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum WHERE  thld_cat      = ls_thld-thld_cat AND
**                                                                  seller_pan    = ls_accumkey-seller_pan AND
**                                                                  buyer_idtype  = ls_accumkey-buyer_idtype AND
**                                                                  buyer_id      = ls_accumkey-buyer_id AND
**                                                                  valid_from    = ls_thld-valid_from.
**             IF sy-subrc ne 0.
**      SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum WHERE  thld_cat   =  ls_thld-thld_cat AND
**                                                                  seller_pan =  ls_accumkey-seller_pan AND
**                                                                  kunnr      =   xvbrk-kunag AND
**                                                                  valid_from =  ls_thld-valid_from.
**
**             ENDIF.
**        ELSE.
**      SELECT SINGLE * FROM ZSD_ACCUMHDR INTO ls_accum WHERE  thld_cat   =  ls_thld-thld_cat AND
**                                                                  seller_pan =  ls_accumkey-seller_pan AND
**                                                                  kunnr      =   xvbrk-kunag AND
**                                                                  valid_from =  ls_thld-valid_from.
**
**    ENDIF.
              if lt_accumdtl[] is not initial.
                sort lt_accumdtl by accum_seq DESCENDING.
              endif.
data : ls_t683s type t683s.
    select single * from knvi into ls_knvi where kunnr eq xvbrk-kunag
                                            and tatyp eq 'JTC1'.
     if sy-subrc eq 0.
       if ls_knvi-taxkd = '2'.
         select single * from t683s into ls_t683s where kvewe = 'A'
                                                        and kappl = 'V'
                                                        and kalsm = xvbrk-kalsm
                                                        and kschl eq 'ZTDS'.
         if sy-subrc eq 0.
         if xvbrk-vbtyp = 'M' or xvbrk-vbtyp = 'P' or xvbrk-vbtyp = '5'.

*              ls_accum = j_1ig_cl_tcs_utility=>read_accumhdr( ls_accumkey ).
              IF ls_accum IS INITIAL.                       " Added by UP 24.08.2021
                MOVE-CORRESPONDING ls_accumkey TO ls_accum ." Added by UP 24.08.2021
                IF ls_accum-accum_date IS INITIAL.          " Added by UP 24.08.2021
                  ls_accum-accum_date = xvbrk-fkdat.        " Added by UP 24.08.2021
                ENDIF.                                      " Added by UP 24.08.2021
              ENDIF.                                        " Added by UP 24.08.2021
              ls_accum-ACCUM_AMT = ls_accum-ACCUM_AMT + xvbrk-netwr .
              IF ls_accum-buyer_id IS NOT INITIAL.
                ls_accum-kunnr = ''.
              ENDIF.
              MODIFY  Zsd_ACCUMHDR from ls_accum  .
              CLEAR ls_accum.

           loop at xvbrp[] into ls_vbrp. " where vbeln eq vbrk-vbeln.

            ls_accumdtl-THLD_CAT = ls_thld-thld_cat .
            ls_accumdtl-SELLER_PAN = ls_accumkey-seller_pan.
*            ls_accumdtl-BUYER_IDTYPE = ls_accumkey-buyer_idtype.

            if ls_accumkey-buyer_id is not initial.
            ls_accumdtl-BUYER_ID = ls_accumkey-buyer_id.
            ls_accumdtl-BUYER_IDTYPE = ls_accumkey-buyer_idtype.
            else.
            ls_accumdtl-KUNNR = xvbrk-kunag.
            endif.
            ls_accumdtl-VALID_FROM = ls_thld-valid_from.

*            select  *  from zsd_accumdtl into table lt_accumdtl where thld_cat = ls_thld-thld_cat
*                                                                    and SELLER_PAN = ls_accumkey-seller_pan
*                                                                    and BUYER_IDTYPE = ls_accumkey-buyer_idtype
*                                                                    and BUYER_ID = ls_accumkey-buyer_id
*                                                                    and KUNNR = vbrk-kunag
*                                                                    and VALID_FROM = ls_thld-valid_from.
*
*              if sy-subrc eq 0.
*                sort lt_accumdtl by accum_seq DESCENDING.
             if ls_accumkey-buyer_id is not initial.
                clear ls_Accumitm.
                read table lt_accumdtl into ls_accumitm with key thld_cat = ls_thld-thld_cat
                                                              SELLER_PAN = ls_accumkey-seller_pan
                                                              BUYER_IDTYPE = ls_accumkey-buyer_idtype
                                                              BUYER_ID = ls_accumkey-buyer_id
*                                                              KUNNR = xvbrk-kunag
                                                              VALID_FROM = ls_thld-valid_from.
              if sy-subrc eq 0.
                ls_accumdtl-ACCUM_SEQ = ls_accumitm-accum_seq + 1.
                ls_accumdtl-ACCUM_PREV = ls_accumitm-accum_curr.
*                endif.
              else.
                ls_accumdtl-ACCUM_SEQ = '00000001'.
              endif.
             else.
                clear ls_Accumitm.
                read table lt_accumdtl into ls_accumitm with key thld_cat = ls_thld-thld_cat
                                                              SELLER_PAN = ls_accumkey-seller_pan
                                                              KUNNR = xvbrk-kunag
                                                              VALID_FROM = ls_thld-valid_from.
              if sy-subrc eq 0.

                ls_accumdtl-ACCUM_SEQ = ls_accumitm-accum_seq + 1.
                ls_accumdtl-ACCUM_PREV = ls_accumitm-accum_curr.
*                endif.
              else.
                ls_accumdtl-ACCUM_SEQ = '00000001'.
              endif.
             endif.


            ls_accumdtl-BUKRS = xvbrk-bukrs.
            ls_accumdtl-BELNR = xvbrk-vbeln. "ls_bkpf-belnr.
            ls_accumdtl-GJAHR = lv_gjahr.
            ls_accumdtl-BUZEI = ls_vbrp-posnr.
            ls_accumdtl-BLART = 'RV'.
            ls_accumdtl-BUDAT = xvbrk-fkdat.
*            ls_accumdtl-ACCUM_PREV
            ls_accumdtl-ITEM_AMT = ls_vbrp-netwr.
            ls_accumdtl-ACCUM_CURR = ls_vbrp-netwr + ls_accumdtl-ACCUM_PREV .
            ls_accumdtl-THLD_AMT = ls_thld-thld_amt.

            insert into zsd_accumdtl VALUES ls_accumdtl.
            INSERT ls_accumdtl INTO lt_accumdtl INDEX 1.  " Added by UP 24.08.2021
            clear ls_accumdtl.
            clear ls_vbrp.
            endloop.


         ELSEIF xvbrk-vbtyp = 'O' or xvbrk-vbtyp = '6' or xvbrk-vbtyp = 'N'.
              data : gt_xvbrp type STANDARD TABLE OF VBRPVB.

*              ls_accumkey-seller_pan = j_1ig_cl_tcs_utility=>seller_id( xvbrk-bukrs ).
*              ls_accumkey-kunnr      = xvbrk-kunag.
*              ls_accumkey-thld_cat   = ls_thld-thld_cat.
*              ls_accumkey-valid_from = ls_thld-valid_from.

*              ls_accum = j_1ig_cl_tcs_utility=>read_accumhdr( ls_accumkey ).
**              ls_accum-ACCUM_AMT = lv_Accum_Amt - xvbrk-netwr .
              ls_accum-ACCUM_AMT = ls_accum-ACCUM_AMT - xvbrk-netwr .
                           IF ls_accum-buyer_id IS NOT INITIAL.
                ls_accum-kunnr = ''.
              ENDIF.
               MODIFY  Zsd_ACCUMHDR from ls_accum  .
              CLEAR ls_accum.
               gt_xvbrp[] = xvbrp[].
              IF xvbrk-vbtyp = 'N'.                   " Added by UP 24.08.2021
                DELETE gt_xvbrp WHERE vbeln(1) EQ '$'.   " Added by UP 24.08.2021
              ENDIF.                                  " Added by UP 24.08.2021
           loop at gt_xvbrp[] into ls_vbrp . "where vbeln eq vbrk-vbeln.

            ls_accumdtl-THLD_CAT = ls_thld-thld_cat .
            ls_accumdtl-SELLER_PAN = ls_accumkey-seller_pan.
            if ls_accumkey-buyer_id is not initial.
            ls_accumdtl-BUYER_IDTYPE = ls_accumkey-buyer_idtype.
            ls_accumdtl-BUYER_ID = ls_accumkey-buyer_id.
            else.
            ls_accumdtl-KUNNR = xvbrk-kunag.
            endif.
            ls_accumdtl-VALID_FROM = ls_thld-valid_from.

*            select  *  from zsd_accumdtl into table lt_accumdtl where thld_cat = ls_thld-thld_cat
*                                                                    and SELLER_PAN = ls_accumkey-seller_pan
*                                                                    and BUYER_IDTYPE = ls_accumkey-buyer_idtype
*                                                                    and BUYER_ID = ls_accumkey-buyer_id
*                                                                    and KUNNR = vbrk-kunag
*                                                                    and VALID_FROM = ls_thld-valid_from.

*              if sy-subrc eq 0.
*                sort lt_accumdtl by accum_seq DESCENDING.
             if ls_accumkey-buyer_id is not initial.
                clear ls_Accumitm.
                read table lt_accumdtl into ls_accumitm with key thld_cat = ls_thld-thld_cat
                                                              SELLER_PAN = ls_accumkey-seller_pan
                                                              BUYER_IDTYPE = ls_accumkey-buyer_idtype
                                                              BUYER_ID = ls_accumkey-buyer_id
*                                                              KUNNR = xvbrk-kunag
                                                              VALID_FROM = ls_thld-valid_from.
              if sy-subrc eq 0.
                ls_accumdtl-ACCUM_SEQ = ls_accumitm-accum_seq + 1.
                ls_accumdtl-ACCUM_PREV = ls_accumitm-accum_curr.
*                endif.
              else.
                ls_accumdtl-ACCUM_SEQ = '00000001'.
              endif.
             else.
                clear ls_Accumitm.
                read table lt_accumdtl into ls_accumitm with key thld_cat = ls_thld-thld_cat
                                                              SELLER_PAN = ls_accumkey-seller_pan
                                                              KUNNR = xvbrk-kunag
                                                              VALID_FROM = ls_thld-valid_from.
              if sy-subrc eq 0.
                ls_accumdtl-ACCUM_SEQ = ls_accumitm-accum_seq + 1.
                ls_accumdtl-ACCUM_PREV = ls_accumitm-accum_curr.
*                endif.
              else.
                ls_accumdtl-ACCUM_SEQ = '00000001'.
              endif.
             endif.

            ls_accumdtl-BUKRS = xvbrk-bukrs.
            ls_accumdtl-BELNR = xvbrk-vbeln.
            ls_accumdtl-GJAHR = lv_gjahr.
            ls_accumdtl-BUZEI = ls_vbrp-posnr.
            ls_accumdtl-BLART = 'RV'.
            ls_accumdtl-BUDAT = xvbrk-fkdat.
*            ls_accumdtl-ACCUM_PREV
            ls_accumdtl-ITEM_AMT = 0 - ls_vbrp-netwr.
            ls_accumdtl-ACCUM_CURR = ls_accumdtl-ACCUM_PREV - ls_vbrp-netwr .
            ls_accumdtl-THLD_AMT = ls_thld-thld_amt.

            insert into zsd_accumdtl VALUES ls_accumdtl.
            INSERT ls_accumdtl INTO lt_accumdtl INDEX 1. " Added by UP 24.08.2021
            clear ls_accumdtl.
            clear ls_vbrp.

            endloop.
         endif.
         endif.
       endif.
     endif.
***** End   of change by Sristi


ENDENHANCEMENT.
