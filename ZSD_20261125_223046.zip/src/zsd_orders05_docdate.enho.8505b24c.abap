"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAK\SE:END\EI
ENHANCEMENT 0 ZSD_ORDERS05_DOCDATE.
*&------------------------------------------------------------------------------
*Date       : 10.09.2024
*Programmer : Suganya
*TR No.     : DR1K988281
*Description: Enhancment for sales order mass upload idoc additonal fields update
*&------------------------------------------------------------------------------
DATA lv_vdatu1    TYPE edatu_vbak.  "Req Delivery date
DATA lv_idoc_ords TYPE char1.   "IDOC
IMPORT lv_idoc_ords FROM MEMORY ID 'LV_IDOC_ORDS'.

IF sy-tcode = 'VA01' AND lv_idoc_ords = 'X'.
"Req Delivery date
 IMPORT lv_vdatu1 FROM MEMORY ID 'VDATU1'.
 vbak-vdatu = lv_vdatu1.
ENDIF.
ENDENHANCEMENT.
