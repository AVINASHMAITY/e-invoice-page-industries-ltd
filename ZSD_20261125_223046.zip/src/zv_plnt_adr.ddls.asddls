/*
----------------------------------------------------------
Object Name           : ZV_PLNT_ADR
Author/Comapny Name   : Chandra Mohan/ITEANZ
Transport Request     : DR1K938213
Creation Date         : 02.02.2018
----------------------------------------------------------
Description : Plant address
----------------------------------------------------------*/
@AbapCatalog.sqlViewName: 'ZSV_PLNT_ADR'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Plant Address'
define view ZV_PLNT_ADR 
with parameters language : abap.lang
as select from t001w as _t001w
left outer join adrc as _adrc
    on _t001w.adrnr = _adrc.addrnumber 
//association[1..1]to t005u as _t005u
left outer join t005u as _t005u
    on _t005u.spras = $parameters.language
    and _adrc.country = _t005u.land1 
    and _adrc.region = _t005u.bland 
left outer join t005t as _t005t    
//association[1..1] to t005t as _t005t
    on _t005t.spras = $parameters.language 
    and _adrc.country = _t005t.land1     
{
    _t001w.werks as werks,
    _t001w.name1 as name,
    _adrc.str_suppl1 as str_suppl1,
    _adrc.str_suppl2 as str_suppl2,
    _adrc.city1 as city1,
    _adrc.post_code1 as post_code,
    _t005u.bezei as bezei,
    _t005t.landx as landx,
     replace(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(concat(
        _t001w.name1,',')
        ,coalesce(_adrc.str_suppl1,','))
        ,',')
        ,coalesce(_adrc.str_suppl2,','))
        ,',')
        ,coalesce(_adrc.city1,','))
        ,'-')
        ,coalesce(_adrc.post_code1,','))
        ,',') 
        ,coalesce(_t005u.bezei,','))
        ,',')
        ,coalesce(_t005t.landx,',')),',,',',')
        as padr
    }
