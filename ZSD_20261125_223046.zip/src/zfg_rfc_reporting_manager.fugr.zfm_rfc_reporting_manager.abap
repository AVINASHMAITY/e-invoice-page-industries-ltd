FUNCTION zfm_rfc_reporting_manager.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IM_USRID) TYPE  SYSID
*"  EXPORTING
*"     VALUE(EX_USRID) TYPE  SYSID
*"  EXCEPTIONS
*"      POSITION_NOT_FOUND
*"      STRUC_GET_METHOD_ERROR
*"      NO_ENTRY_FOUND
*"      USERID_NOT_MAINTAINED
*"----------------------------------------------------------------------

  DATA: lv_pernr TYPE persno.

  IF im_usrid IS NOT INITIAL.
    SELECT SINGLE pernr
      FROM pa0105
      INTO lv_pernr
      WHERE usrid = im_usrid.
    IF sy-subrc IS INITIAL.

      CALL FUNCTION 'ZFM_HCM_REPORTING_MANAGER'
        EXPORTING
          im_pernr               = lv_pernr
        IMPORTING
          ex_usrid               = ex_usrid
        EXCEPTIONS
          position_not_found     = 1
          struc_get_method_error = 2
          no_entry_found         = 3
          userid_not_maintained  = 4.

    ENDIF.
  ENDIF.


ENDFUNCTION.
