FUNCTION ZBAS_DOWNLOAD_FILE.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(MOD_DESC) TYPE  ZMOD_IMP
*"     REFERENCE(DOCCATEGORY) TYPE  ZIMP_DOCTYP
*"     REFERENCE(DOCNO) TYPE  ZBAS_ATTACHMENT-DOCNO
*"     REFERENCE(DISPLAY) TYPE  C OPTIONAL
*"----------------------------------------------------------------------

  EXPORT mod_desc TO MEMORY ID 'MD'.
  EXPORT doccategory TO  MEMORY ID 'CG'.
  EXPORT docno TO MEMORY ID 'DN'.
  CLEAR wrk_disp.
  wrk_disp = display.
  PERFORM fetch_file USING mod_desc
                           doccategory
                           docno.
  CALL SCREEN 9000 STARTING AT  20 18 ENDING AT 80 40 .


ENDFUNCTION.
