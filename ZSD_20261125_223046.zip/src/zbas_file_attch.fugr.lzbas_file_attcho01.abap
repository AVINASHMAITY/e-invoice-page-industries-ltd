*$*$-----------------------------------------------------------------$*$
*$*$ Author       : Collabera                                        $*$
*$*$ Creation Date: 02.08.2011                                       $*$
*$*$ Funtion group: /OBIZ/IMP_FILE_ATTCH                             $*$
*$*$ Description  : To upload and download documents                 $*$
*$*$                                                                 $*$
*$*$                                                                 $*$
*$*$-----------------------------------------------------------------$*$
*----------------------------------------------------------------------*
***INCLUDE /OBIZ/LFG_FILE_ATTCHO01 .
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9000 OUTPUT.
  SET PF-STATUS 'PF900'.
  SET TITLEBAR 'T100'.

ENDMODULE.                 " STATUS_9000  OUTPUT
*&---------------------------------------------------------------------*
*&      Module  init  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE init OUTPUT.
  IF g_c_container IS INITIAL.

    CREATE OBJECT g_c_container
      EXPORTING
        container_name              = 'CONTAINER'
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5
        OTHERS                      = 6.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.


  ENDIF.
  IF grid1 IS INITIAL.
    CREATE OBJECT grid1
      EXPORTING
        i_parent          = g_c_container
      EXCEPTIONS
        error_cntl_create = 1
        error_cntl_init   = 2
        error_cntl_link   = 3
        error_dp_create   = 4
        OTHERS            = 5.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.


    PERFORM sel_fieldcat.
    it_lay-sel_mode = 'A'.

    CALL METHOD grid1->set_table_for_first_display
      CHANGING
        it_outtab                     = it_pic_download
        it_fieldcatalog               = it_fieldcat
      EXCEPTIONS
        invalid_parameter_combination = 1
        program_error                 = 2
        too_many_lines                = 3
        OTHERS                        = 4.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.
*>>>>>>>>>Insertion Block Starts Here

*Code Added on : 12.01.2007
*           By :SKE
*Reason        :Creating the the object , if it is initial
    IF event_receiver IS INITIAL.
*>>>>>>>>>Insertion Block Ends Here

      CREATE OBJECT event_receiver.

*>>>>>>>>>Insertion Block Starts Here
    ENDIF.
*>>>>>>>>>Inserion Block Ends Here

    SET HANDLER event_receiver->handle_double_click FOR grid1.
    SET HANDLER event_receiver->handle_menu_button
                event_receiver->handle_toolbar FOR ALL INSTANCES.
    SET HANDLER event_receiver->handle_user_command FOR ALL INSTANCES.

    CALL METHOD grid1->set_toolbar_interactive.


  ELSE.
    CALL METHOD grid1->refresh_table_display
      EXCEPTIONS
        finished = 1
        OTHERS   = 2.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.


  ENDIF.

ENDMODULE.                 " init  OUTPUT
