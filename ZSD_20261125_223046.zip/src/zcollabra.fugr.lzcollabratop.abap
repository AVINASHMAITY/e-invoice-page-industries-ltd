FUNCTION-POOL ZCOLLABRA.                    "MESSAGE-ID ..

* INCLUDE LZCOLLABRAD...                     " Local class definition
