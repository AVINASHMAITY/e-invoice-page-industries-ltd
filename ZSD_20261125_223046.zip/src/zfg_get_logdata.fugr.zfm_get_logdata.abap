FUNCTION zfm_get_logdata.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(FI_LOGDATE) TYPE  CHAR10
*"     REFERENCE(FI_LOGTIME) TYPE  CHAR8
*"     REFERENCE(FI_LOGKEY) TYPE  LOGKEY
*"  EXPORTING
*"     VALUE(FE_GETLOG) TYPE  ZTT_GETLOG
*"----------------------------------------------------------------------
  " Modified By :Khurshida shaik
  " Date        :6/16/2016
  " TR          :DR1K926561
  " Description : For converting date and time format from yyyymmdd to
  "dd.mm.yyyy,HHMMSS to HH.MM.SS by changing type of
  " date and time.
************************************************************************

***********************************************************************
  " Begin of changes by khurshida on 6/16/2016 DR1K926561
***********************************************************************
  " Local data declarartion

  DATA: lv_date TYPE sydats,
        lv_time TYPE sytime,
        lv_logid TYPE logid.

  CONCATENATE fi_logdate+6(4) fi_logdate+3(2) fi_logdate+0(2)
              INTO lv_date.
  CONCATENATE fi_logtime+0(2) fi_logtime+3(2) fi_logtime+6(2)
              INTO lv_time.
  lv_logid = fi_logkey.
***********************************************************************
  " End of changes by khurshida on 6/16/2016 DR1K926561
***********************************************************************
  SELECT *
          INTO TABLE gt_dbtablog
          FROM       dbtablog
          WHERE      logdate = lv_date " added by khurshida on 6/16/2016 DR1K926561
          AND        logtime = lv_time " added by khurshida on 6/16/2016 DR1K926561
          AND        logkey  = fi_logkey.

*"----------------------------------------------------------------------
*"         Process the data
*"----------------------------------------------------------------------

  LOOP AT gt_dbtablog WHERE optype <> ''.
    UNASSIGN <in_content>.
*... point field symbol (in correct cast) at LOGDATA field
    ASSIGN gt_dbtablog-logdata TO <in_content>
     CASTING TYPE (gt_dbtablog-tabname).
    CHECK <in_content> IS ASSIGNED.
    SKIP 1.
    DO.
*... work through all structure's components...
      ASSIGN COMPONENT sy-index  OF STRUCTURE <in_content> TO <field>.
      IF sy-subrc <> 0.
*... exit when reaching the end of components
        EXIT.
      ENDIF.
*.. only interested in non-initial components
      CHECK NOT <field> IS INITIAL.
*.. get attributes of component field
      DESCRIBE FIELD <field> INTO fs_td.
*get field name.........
      CLEAR w_long_name.
      LOOP AT fs_td-names INTO w_names WHERE name NS '=='.
        IF NOT w_word_found IS INITIAL.
          CLEAR: w_word_found, w_long_name.
        ENDIF.
        CONCATENATE w_long_name w_names-name INTO w_long_name.
        IF w_names-continue NE '*'.
          w_word_found = 'x'.
        ENDIF.
      ENDLOOP.
*if found write out the name and value
      IF w_word_found IS NOT INITIAL.
*      WRITE:/ w_long_name,'=',<field>.
        gs_getdata-w_long_name = w_long_name.
        gs_getdata-field = <field>.
        APPEND gs_getdata TO gt_getdata.
        CLEAR gs_getdata.
      ENDIF.
    ENDDO.
  ENDLOOP.

  fe_getlog = gt_getdata.

ENDFUNCTION.
