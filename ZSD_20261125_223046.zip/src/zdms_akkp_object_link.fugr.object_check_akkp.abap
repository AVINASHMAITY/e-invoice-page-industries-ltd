FUNCTION OBJECT_CHECK_AKKP.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(CALLED_FROM) DEFAULT 1
*"     VALUE(LANGUAGE) LIKE  SY-LANGU DEFAULT SY-LANGU
*"     VALUE(LOCK) DEFAULT SPACE
*"     VALUE(SINGLE) DEFAULT SPACE
*"     VALUE(I_AUTH_CHK) LIKE  RMCLF-KREUZ DEFAULT SPACE
*"  EXPORTING
*"     VALUE(FAULT_TEXT)
*"     VALUE(MESSAGE_TYPE)
*"     VALUE(NO_AUTH)
*"  TABLES
*"      OTAB STRUCTURE  RMCLOBTX
*"  EXCEPTIONS
*"      FOREIGN_LOCK
*"      OBJECT_NOT_FOUND
*"      SYSTEM_FAILURE
*"----------------------------------------------------------------------

CONSTANTS:
  Y_ERROR          TYPE C VALUE 'E',                        " P9CK429322
  Y_WARNING        TYPE C VALUE 'W',
  Y_CALLED_FROM_2  TYPE C VALUE '2'.



ENDFUNCTION.
