/*
----------------------------------------------------------
Object Name           : ZV_MIS_IBD
Author/Comapny Name   : Chandra Mohan/ITEANZ
Transport Request     : DR1K938213
Creation Date         : 18.01.2018
----------------------------------------------------------
Description : Inbound delivery
----------------------------------------------------------
*/
@AbapCatalog.sqlViewName: 'ZSV_MIS_IBD'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@ClientDependent: true
@EndUserText.label: 'MIS View for IBD'
define view ZV_MIS_IBD
with parameters langauage : abap.lang, client : abap.clnt
//as select from likp[ lfart = 'EL' and lfart = 'NL' ] as _likp         *Commented by Bhagwan on 02.05.2022
as select from likp as _likp           //Added by Bhagwan on 02.05.2022
left outer join lips as _lips
    on _likp.vbeln = _lips.vbeln 
    
left outer join zsdt_mis as _zsdtmis   //added by kiruba
 on _likp.vbeln = _zsdtmis.vbeln
    
//MARA
left outer join mara as _mara
    on _lips.matnr = _mara.matnr
left outer join t134t as _T134T
    on _T134T.spras = $parameters.langauage
//    on _T134T.spras = 'E'
    and _mara.mtart = _T134T.mtart
//Mat Desc
//left outer join makt[ spras = $parameters.langauage ] as _makt   //Commented by Bhagavan on 23.05.2022  DR1k965918
 left outer join makt as _makt
    on _mara.matnr = _makt.matnr 
     and _makt.spras = 'E'                //Added by Bhagavan on 23.05.2022  DR1k965918
//Delivery date
left outer join ekes as _ekes
    on _lips.vgbel = _ekes.ebeln
    and _lips.vbeln = _ekes.vbeln
left outer join zsdt_mis as _ex
    on _likp.vbeln = _ex.vbeln
 //HSN CODE    
left outer join marc as _marc           //Added by Bhagavan on 11.09.2020    DR1K952693
    on  _mara.matnr = _marc.matnr 
    and _lips.werks = _marc.werks    
    
//    left outer join ekko as _ekko 
//    on _lips.vgbel = _ekko.ebeln
    {
    _likp.vbeln as vbeln,
    _likp.ernam as ERNAM,//Created BY                                  // Added by Bhagavan on 31/05/2022 "DR1k965918
    _likp.erdat as erdat,
    _likp.lfart as lfart,
    _likp.igm_date as igm_date,
    _likp.igm_no as igm_no,
    _likp.netrpr4 as NETRPR4, //Customs duty paid
    _likp.bill_entry_no as bill_entry_no,
    _likp.bill_entry_date as bill_entry_date,
    _likp.date_cargo_clear as DATE_CARGO_CLEAR, //Shipment clearance date
    _likp.date_cargo_bond as DATE_CARGO_BOND, //Bonding date
    _likp.cust_broker_name as cust_broker_name, //Customs house agent
    _likp.cha_bill_no as CHA_BILL_NO,
    _likp.cha_date as cha_date,
    _likp.netrpr2 as netrpr2, // Demurrage charges
    _likp.meins2 as meins2, // Demurrage currency
    _likp.reason_delay as reason_delay, //Dem.. reason
    _likp.netrpr3 as netrpr3, //Total CHA Bill amt
    _likp.meins6 as meins6, //Tot Cha amt curr
    _likp.trans_bill_no as trans_bill_no, //
    _likp.date_trans_bill as date_trans_bill,
    _likp.netrpr5 as netrpr5, // Trans charges
    _likp.freight_bill_no as freight_bill_no, //freight_bill_no
    _likp.date_of_freight as date_of_freight, // ?date 
    _lips.werks as werks,
    _lips.vgbel as vgbel,
    _lips.matnr as Matnr,
    _lips.posnr as posnr,
    _lips.meins as meins,
    _lips.lfimg as lfimg,
    _T134T.mtbez as mtbez,
    _makt.maktx as maktx,
    _ekes.eindt as eindt,
    
    _zsdtmis.zlics_date1 as zlics_date1,    // added by kiruba DR1K982014 
    _zsdtmis.zlics_expdt1 as ZLICS_EXPDT1,  // added by kiruba DR1K982014
    _zsdtmis.zlics_qty1 as ZLICS_QTY1,      // added by kiruba DR1K982014
    _zsdtmis.zlics_date2 as ZLICS_DATE2,    // added by kiruba DR1K982014
    _zsdtmis.zlics_expdt2 as ZLICS_EXPDT2,  // added by kiruba DR1K982014  
    _zsdtmis.zlics_qty2 as ZLICS_QTY2,      // added by kiruba DR1K982014
    _zsdtmis.zlics_date3 as ZLICS_DATE3,    // added by kiruba DR1K982014
    _zsdtmis.zlics_expdt3 as ZLICS_EXPDT3,  // added by kiruba DR1K982014
    _zsdtmis.zlics_qty3 as ZLICS_QTY3,      // added by kiruba DR1K982014
    _zsdtmis.zlics_date4 as ZLICS_DATE4,    // added by kiruba DR1K982014
    _zsdtmis.zlics_expdt4 as ZLICS_EXPDT4,  // added by kiruba DR1K982014
    _zsdtmis.z1schn as z1schn,              // added by kiruba DR1K982014
       
    case 
        when _lips.vgpos is not null then substring( _lips.vgpos, 2, 5 )
        else ' '
    end as EBELP1,
    case 
        when _ex.zstatus = '1' then 'Pending'
        when _ex.zstatus = '2' then 'Cleared'
        else ''
    end as status,
    case 
        when _ex.zctyp = 'G' then 'General'
        when _ex.zctyp = 'H' then 'Hazardous'
        when _ex.zctyp = 'P' then 'Perishable'
        else ''
    end as noc,
    case 
        when _ex.zpers = '1' then 'Controlled Ambient'    
        when _ex.zpers = '2' then '2 to 8 Degree'    
        when _ex.zpers = '3' then '-25 to -15 Degree'    
        when _ex.zpers = '4' then '-80 Degree'    
        else ''
    end as per,
    _ex.zbroad as bro_ad,
    _ex.zbrord as bro_rd,
    _ex.zbnkad as bnk_ad,
    _ex.zbnkrd as bnk_rd,
    _ex.zhclpa as lpci,
    _ex.zhcioc as iocd,
    _ex.zhcopa as op,
    _ex.zcbwbn as cbw_bno,
    _ex.zcbwbd as cbw_dat,
    _ex.zxbwbn as xcbw_xbno,
    _ex.zxbwnd as xcbw_xbn,
    _ex.zxwscd as xcbw_scd,
    _ex.zxbcda as xcbw_cd,
    _ex.zxblpa as xcbw_lpci,
    _ex.zxbicd as xcbw_iocd,
    _ex.zxbopa as xcbw_op,
    case
        when _ex.z1schn = '1' then 'DSIR' 
        when _ex.z1schn = '2' then 'MEIS'
        when _ex.z1schn = '3' then 'FMS'
        when _ex.z1schn = '4' then 'EPCG'
        when _ex.z1schn = '5' then 'Advance License'
        when _ex.z1schn = '6' then 'FMS'
        when _ex.z1schn = '7' then 'FPS'
        when _ex.z1schn = '8' then 'Others'
        when _ex.z1schn = '9' then 'DSIR + SCRIP'
        
        when _ex.z1schn = 'A' then 'RODTEP'  // ADDED BY KIRUBA
        when _ex.z1schn = 'B' then 'SIMS'
        when _ex.z1schn = 'C' then 'PIMS'
        
        else ''
     end as sc_nam, //Scheme name
    _ex.z1lscn as LS_No, //License/Scheme no
    _ex.z1vdls as val_d2l, //val debited to license/scheme
    case
        when _ex.z2cdcs = '1' then 'Form 10'
        when _ex.z2cdcs = '2' then 'Form 11'
        when _ex.z2cdcs = '3' then 'NOC'
        else ''
    end as CDCSO,
    _ex.z2cdfn as cfno, //Clearance Form No
    _ex.z2cdcq as cqty, //Clearance Quantity
    _ex.z2fsln as fssaino, //FSSAI  NOC/License No
    _ex.z2fscq as fssaiqty, //FSSAI  quantity
    _ex.z2anln as aniqno, //Animal Quarantine  NOC/License No
    _ex.z2anqy as aniqty, //Animal Quarantine Quantity
    _ex.z2pqln as PQ_NO, //Plant Quarantine  NOC/License  No
    _ex.z2pqqy as PQ_qty, //Plant Quarantine Quantity
    _ex.z2ndln as nar_no, //Narcotics Dept  NOC/ License No.
    _ex.z2ndqy as nar_qty, //Narcotics Qty
    _ex.z2adfl as adf_no, //ADF NOC/License No.
    _ex.z2adfq as adf_qty, //ADF Qty
    _ex.z2pcbl as pcb_no, //PCB NOC/ License No.
    _ex.z2pcbq as pcb_qty, //PCB Qty
    _ex.z2pesl as peso_no, // PESO  NOC/License No.
    _ex.z2pesq as peso_qty, //PESO Qty 
    _ex.z3chcr as cha_rec,
    _ex.z3chnr as cha_nrec,
    _ex.z4tnam as trans_nam,
    _ex.z4hlca as hlc,
    _ex.z4hltc as hatc,
    _ex.z4rhat as rhat,
    _ex.z5ffnm as ff_nam,
    _ex.z5frga as fr_amt,
    _ex.zfnsum as final,
    _ex.zintdt as intdt,
    _ex.zsaldt as saldt,
    _ex.zbondt as bondt,
    _ex.zaugdt as augdt,
    _ex.zremrk as remrk,
   
   
    case 
        when _ex.zdocm = '1' then 'Direct'
        when  _ex.zdocm = '2' then 'Bank'
        else ''
    end as zdocm,
    case 
        when _ex.ztoc = '1' then 'Home Consumption'
        when _ex.ztoc = '2' then 'Bonding at CBW'
        when _ex.ztoc = '3' then 'SEZ'
        else ''
    end as ztoc,
    case 
        when _ex.zcuvrl = '1' then 'CDCSO'
        when _ex.zcuvrl = '2' then 'FSSAI'
        when _ex.zcuvrl = '3' then 'Animal Quarantine'
        when _ex.zcuvrl = '4' then 'Plant Quarantine'
        when _ex.zcuvrl = '5' then 'Department of Narcotics'
        when _ex.zcuvrl = '6' then 'Dept. of Animal Husbandry, Dairying, Fisheries'
        when _ex.zcuvrl = '7' then 'Pollution control board'
        when _ex.zcuvrl = '8' then 'Petroleum and Explosives safety organisation'
        
        when _ex.zcuvrl = '9' then 'FORM CT-17'  // ADDED BY KIRUBA
        when _ex.zcuvrl = 'A' then 'IBC'
        when _ex.zcuvrl = 'B' then 'FORM MD-15'
        else ''
    end as zcuvrl,
    _ex.zcuscr,
    _ex.zdelof,
    case
    when _ex.zrsdem = '0' then 'Storage constraint / variation in planning schedule'
    when _ex.zrsdem = '1' then 'Original document delay / BRO delay'
    when _ex.zrsdem = '2' then 'ADC/FSSAI/AQ/PQ process delay'
    when _ex.zrsdem = '3' then 'Assessment / Amendment / Customs systems delay'
    when _ex.zrsdem = '4' then 'Holiday / Weekend arrival of shipment'
    when _ex.zrsdem = '5' then 'Discrepancy in shipping documents'
    when _ex.zrsdem = '6' then 'Duty payment / service charge payment delay'
    when _ex.zrsdem = '7' then 'Shipment short delivered'
    when _ex.zrsdem = '8' then 'PO NA in advance/Unauthorised Cargo Delivery by supplier'
    when _ex.zrsdem = '9' then 'Others / Miscellaneous'
    when _ex.zrsdem = 'A' then 'SEZ BOE delay from IDT dept.'
    when _ex.zrsdem = 'B' then 'Delay due to discrepancy in documents from Projects/E&M'
    when _ex.zrsdem = 'C' then 'Delay due to XML Error'
    when _ex.zrsdem = 'D' then 'Delay due to Natural disaster/ Pandemic'
    when _ex.zrsdem = 'E' then 'Delay due to late de-stuffing/Port congestion'
    when _ex.zrsdem = 'F' then 'Delay due to late permission from Drug Inspector office'
   
    else ''
    end as zrsdem,
    
    _ex.z2lscn as lsc_no,     //Added by Bhagavan on 11.09.2020    DR1K952693
    _ex.z2vdls as vade_sch,   //Added by Bhagavan on 11.09.2020    DR1K952693
    _ex.z3lscn as lsc_no1,    //Added by Bhagavan on 11.09.2020    DR1K952693
    _ex.z3vdls as vade_sch1,  //Added by Bhagavan on 11.09.2020    DR1K952693
    _marc.steuc as hsn_code   //Added by Bhagavan on 11.09.2020    DR1K952693
    
    
   
//    _lips. 
}
group by _likp.vbeln, _likp.erdat, _likp.lfart, _likp.igm_date, _likp.igm_no, _likp.netrpr4, _likp.bill_entry_no,
    _likp.bill_entry_date, _likp.date_cargo_clear, _likp.date_cargo_bond, _likp.cust_broker_name, _likp.cha_bill_no, _likp.cha_date,
    _likp.netrpr2, _likp.meins2, _likp.reason_delay, _likp.netrpr3, _likp.meins6, _likp.trans_bill_no, _likp.date_trans_bill, _likp.netrpr5, 
    _likp.freight_bill_no, _likp.date_of_freight, _lips.werks, _lips.vgbel,
    _lips.matnr, _lips.posnr, _lips.meins, _lips.lfimg, _T134T.mtbez, _makt.maktx, _ekes.eindt, _lips.vgpos,
    _ex.zstatus, _ex.zctyp, _ex.zpers,_ex.zbroad,_ex.zbrord,_ex.zbnkad,_ex.zbnkrd,_ex.zhclpa,_ex.zhcioc,_ex.zhcopa,_ex.zcbwbn,_ex.zcbwbd,
    _ex.zxbwbn,_ex.zxbwnd,_ex.zxwscd,_ex.zxbcda,_ex.zxblpa,_ex.zxbicd,_ex.zxbopa,_ex.z1schn,_ex.z1lscn,_ex.z1vdls,_ex.z2cdcs,_ex.z2cdfn,_ex.z2cdcq,
    _ex.z2fsln,_ex.z2fscq,_ex.z2anln,_ex.z2anqy,_ex.z2pqln,_ex.z2pqqy,_ex.z2ndln,_ex.z2ndqy,_ex.z2adfl,_ex.z2adfq,_ex.z2pcbl,_ex.z2pcbq,_ex.z2pesl,
    _ex.z2pesq,_ex.z3chcr,_ex.z3chnr,_ex.z4tnam,_ex.z4hlca,_ex.z4hltc,_ex.z4rhat,_ex.z5ffnm,_ex.z5frga,_ex.zfnsum,_ex.zintdt, _ex.zsaldt, _ex.zbondt ,_ex.zaugdt ,
    _ex.zremrk,_ex.zdocm,
    _ex.ztoc,_ex.zcuvrl,_ex.zcuscr, _ex.zdelof, _ex.zrsdem,_ex.z2lscn,_ex.z2vdls,_ex.z3lscn,_ex.z3vdls,_marc.steuc,
    _likp.ernam,        // Added by Bhagavan on 31/05/2022 "DR1k965918
    _zsdtmis.zlics_date1, _zsdtmis.zlics_expdt1, _zsdtmis.zlics_qty1, 
    _zsdtmis.zlics_date2, _zsdtmis.zlics_expdt2,   // added by kiruba  DR1K982014
    _zsdtmis.zlics_qty2, _zsdtmis.zlics_date3, _zsdtmis.zlics_expdt3, // added by kiruba DR1K982014
    _zsdtmis.zlics_qty3, _zsdtmis.zlics_date4, // added by kiruba DR1K982014
    _zsdtmis.zlics_expdt4, _zsdtmis.z1schn  // added by kiruba DR1K982014
    
