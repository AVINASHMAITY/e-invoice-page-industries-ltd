*$*$-----------------------------------------------------------------$*$
*$*$ Author       : Collabera                                        $*$
*$*$ Creation Date: 02.08.2011                                       $*$
*$*$ Funtion group: /OBIZ/IMP_FILE_ATTCH                             $*$
*$*$ Description  : To upload and download documents                 $*$
*$*$                                                                 $*$
*$*$                                                                 $*$
*$*$-----------------------------------------------------------------$*$
*&---------------------------------------------------------------------*
*&      Form  sav_files
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM sav_files .
*  MODIFY /obiz/zfl_attach FROM TABLE it_pic_upload.
  MODIFY zbas_attachment FROM TABLE it_pic_upload.
  EXPORT it_pic_upload TO MEMORY ID 'ATT'.
  IF it_pic_tab_up IS NOT INITIAL.
    EXPORT it_pict_tab = it_pic_tab_up
           TO DATABASE abtree(iv)
           ID wrk_pic_no.
    IF sy-subrc = 0.
*      MESSAGE  s003(/obiz/file) WITH file_length.
      MESSAGE  s003(zbfn_file_imp) WITH file_length.
    ENDIF.
  ENDIF.
  COMMIT WORK.
ENDFORM.                    " sav_files
*&---------------------------------------------------------------------*
*&      Form  fetch_file
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_MOD_DESC  text
*      -->P_DOCCATEGORY  text
*      -->P_DOCNO  text
*----------------------------------------------------------------------*
FORM fetch_file  USING    p_mod_desc
                          p_doccategory
                          p_docno.
  SELECT *
*    FROM /obiz/zfl_attach
    FROM zbas_attachment
    INTO TABLE it_pic_download
   WHERE mod_desc = p_mod_desc
     AND doccategory = p_doccategory
     AND docno = p_docno
     AND fid  IN r_fid.

*>>>>>>>>Deletion Block Starts Here

*Commented on :11.01.2007
*By           :SKE
*Reason : keeping only one button for upload/download


*  IF it_pic_download IS INITIAL.
*    MESSAGE e001(/obiz/file).
*  ENDIF.


*>>>>>>>>Deletion Blocks Ends Here

ENDFORM.                    " fetch_file
*&---------------------------------------------------------------------*
*&      Form  upload_file
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*      -->P_MOD_DESC  text
*      -->P_DOCCATEGORY  text
*      -->P_DOCNO  text
*----------------------------------------------------------------------*
FORM upload_file  USING    p_mod_desc
                           p_doccategory
                           p_docno.

  CLEAR :    it_pic_tab,
                rc,
                action,
                wa_pic_tab,
                it_nam2,
                name,
                it_nam3,
                it_nam2,
*                it_nam,
                count,count2,count3,fnam,
                wrk_pic_no,
                it_pic_upload,
                wa_pic_upload.


  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    CHANGING
      file_table              = it_pic_tab
      rc                      = rc
      user_action             = action
    EXCEPTIONS
      file_open_dialog_failed = 1
      cntl_error              = 2
      error_no_gui            = 3
      not_supported_by_gui    = 4
      OTHERS                  = 5.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
               WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

  ELSEIF action = 9.
*    MESSAGE s002(/obiz/file).
    MESSAGE  s002(zbfn_file_imp).
  ELSE.

    LOOP AT it_pic_tab INTO wa_pic_tab.
      name = wa_pic_tab-filename.
    ENDLOOP.

*    SPLIT name  AT '.' INTO TABLE it_nam.
    SPLIT name AT  '\' INTO TABLE it_nam2.
*
*
*    DESCRIBE TABLE it_nam LINES count .
    DESCRIBE TABLE it_nam2 LINES count2.
*
*    READ TABLE it_nam INDEX count INTO wa_nam.
    READ TABLE it_nam2 INDEX count2 INTO wa_nam2.
*
    SPLIT wa_nam2 AT '.' INTO TABLE it_nam3.

    DESCRIBE TABLE it_nam3 LINES count3.
*    count3 = count3 - 1.
    READ TABLE it_nam3 INDEX count3 INTO wa_nam3.
    TRANSLATE wa_nam3 TO UPPER CASE.
    fnam = wa_nam2.

    CALL METHOD cl_gui_frontend_services=>gui_upload
      EXPORTING
        filename                = name
        filetype                = 'BIN'
      IMPORTING
        filelength              = file_length
*       header                  = header
      CHANGING
        data_tab                = it_pic_tab_up
      EXCEPTIONS
        file_open_error         = 1
        file_read_error         = 2
        no_batch                = 3
        gui_refuse_filetransfer = 4
        invalid_type            = 5
        no_authority            = 6
        unknown_error           = 7
        bad_data_format         = 8
        header_not_allowed      = 9
        separator_not_allowed   = 10
        header_too_long         = 11
        unknown_dp_error        = 12
        access_denied           = 13
        dp_out_of_memory        = 14
        disk_full               = 15
        dp_timeout              = 16
        not_supported_by_gui    = 17
        error_no_gui            = 18
        OTHERS                  = 19.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

    IF file_length GT 400000.     "File size restriction below 400KB
      MESSAGE 'File Size should not exceed 400KB' TYPE 'I' DISPLAY LIKE 'I'.
      LEAVE SCREEN.
    ENDIF.

    CALL FUNCTION 'NUMBER_GET_NEXT'
      EXPORTING
        nr_range_nr             = '01'
        object                  = 'ZBAS'
      IMPORTING
        number                  = wrk_pic_no
      EXCEPTIONS
        interval_not_found      = 1
        number_range_not_intern = 2
        object_not_found        = 3
        quantity_is_0           = 4
        quantity_is_not_1       = 5
        interval_overflow       = 6
        buffer_overflow         = 7
        OTHERS                  = 8.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
              WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

    wa_pic_upload-fid = wrk_pic_no.
    wa_pic_upload-doccategory = p_doccategory.
    wa_pic_upload-mod_desc = p_mod_desc.
    wa_pic_upload-docno = p_docno.
    wa_pic_upload-fpath = name.
    wa_pic_upload-fname = wa_nam2.
    wa_pic_upload-ftype = wa_nam3.
    wa_pic_upload-fsize = file_length.
    wa_pic_upload-fdate = sy-datum.
    wa_pic_upload-fcname = sy-uname.

    DATA icon_type TYPE icon-name.
    DATA icon_name TYPE icon-name VALUE 'ICON_'.


    CONCATENATE icon_name  wa_nam3 INTO icon_type.

    SELECT
    SINGLE id
      FROM icon
      INTO wa_pic_upload-ficon
     WHERE name = icon_type.

    IF wa_pic_upload-ficon IS INITIAL.

      SELECT
      SINGLE id
        FROM icon
        INTO wa_pic_upload-ficon
       WHERE name = 'ICON_DOCUMENT'.


    ENDIF.

    DESCRIBE TABLE it_pic_upload LINES count  .
    count = count + 1.
    APPEND  wa_pic_upload TO it_pic_upload .
    PERFORM sav_files.
  ENDIF.

ENDFORM.                    " upload_file
*&---------------------------------------------------------------------*
*&      Form  free_alv
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM free_alv .
  CALL METHOD grid1->free
*    EXCEPTIONS
*      CNTL_ERROR        = 1
*      CNTL_SYSTEM_ERROR = 2
*      others            = 3
    .
  IF sy-subrc <> 0.
*   MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*              WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.
  CLEAR grid1.



  CALL METHOD g_c_container->free
*  EXCEPTIONS
*    CNTL_ERROR        = 1
*    CNTL_SYSTEM_ERROR = 2
*    others            = 3
    .
  IF sy-subrc <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*            WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
  ENDIF.



  CLEAR g_c_container.


ENDFORM.                    " free_alv
