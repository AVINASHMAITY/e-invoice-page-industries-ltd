class ZCL_IM_ZMD_CHANGE_MRP_DATA definition
  public
  final
  create public .

public section.
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_ZMD_CHANGE_MRP_DATA IMPLEMENTATION.
ENDCLASS.
