*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_SHIP_DETAIL................................*
DATA:  BEGIN OF STATUS_ZCYG_SHIP_DETAIL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_SHIP_DETAIL              .
CONTROLS: TCTRL_ZCYG_SHIP_DETAIL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_SHIP_DETAIL              .
TABLES: ZCYG_SHIP_DETAIL               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
