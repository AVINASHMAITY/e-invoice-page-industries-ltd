"Name: \PR:SAPMV60A\FO:VBRK_UNTERLEGEN\SE:END\EI
ENHANCEMENT 0 ZENH_FREIGHT_POST_CANCEL.
data:wa_reversal like BAPIACREV,
      wa_obj-obj_type LIKE  BAPIACREV-OBJ_TYPE,
      wa_obj-obj_key  LIKE  BAPIACREV-OBJ_KEY,
      wa_obj-obj_SYS  LIKE  BAPIACREV-OBJ_SYS,
      gw_RETURN LIKE  BAPIRET2 ,
      gt_return like TABLE OF bapiret2.
data : lw_bkpf1 TYPE bkpf.
TYPES : BEGIN OF ty_msg,
          status TYPE c,           "Status
          vbeln  TYPE char30,      "Reference
          belnr_CAN  TYPE belnr_d,     "Doc. no
          desc   TYPE string,      "Description
        END OF ty_msg.
data : lt_frt type TABLE OF zsdt_frt_automat,
       lw_frt type zsdt_frt_automat.
DATA : lt_msg TYPE TABLE OF ty_msg,
       ls_msg TYPE ty_msg.
IF sy-tcode = 'VF11' and sy-ucomm = 'SICH'.
 CLEAR : LW_FRT,lw_bkpf1.
 SELECT * FROM zsdt_frt_automat INTO TABLE lT_frT WHERE VBELN = XVBRK-VBELN.
  READ TABLE LT_FRT INTO LW_FRT WITH KEY VBELN = XVBRK-VBELN.

 IF SY-SUBRC = 0 AND lW_frt-BELNR IS NOT INITIAL.
      select SINGLE * from bkpf into lw_bkpf1 where bukrs = lw_frt-bukrs and belnr = lw_frt-belnr.
      IF sy-subrc = 0.
       wa_reversal-obj_type = lw_bkpf1-AWTYP.
       wa_reversal-obj_key = lw_bkpf1-AWKEY.
       wa_reversal-obj_key_r = lw_bkpf1-AWKEY.
       wa_reversal-reason_rev = '04'. " The reason code is required:
       wa_reversal-pstng_date = sy-datum. " The posting date is optional:

       call function 'BAPI_ACC_DOCUMENT_REV_POST'
        exporting
          reversal = wa_reversal
          bus_act = 'RFBU'
        importing
          obj_type = wa_obj-obj_type
          obj_key = wa_obj-obj_key
          obj_sys = wa_obj-obj_sys
        tables
          return = gt_return.

            CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
              EXPORTING
                wait = abap_true.

            READ TABLE gt_return WITH KEY type = 'S' INTO gw_return .
            IF sy-subrc NE 0.
              LOOP AT gt_return INTO gw_return WHERE type = 'E'.
                ls_msg-status = 'E'.
                ls_msg-vbeln = lW_frt-vbeln.
                ls_msg-desc = gw_return-message.
                APPEND ls_msg TO lt_msg.
                CLEAR: ls_msg.
              ENDLOOP.

              CLEAR: lW_frt.
              lW_frt-status = 'Error'.
              lW_frt-CANCEL_by = sy-uname.
              lW_frt-CANCEL_on = sy-datum.
              lW_frt-CANCEL_at = sy-uzeit.
*              MOVE lW_frt TO ls_frt.
              MODIFY lt_frt FROM lW_frt TRANSPORTING status CANCEL_by CANCEL_on CANCEL_at
                                        WHERE vbeln EQ lW_frt-vbeln.
            ELSE.
              ls_msg-status = 'S'.
              ls_msg-vbeln = lW_frt-vbeln.
              ls_msg-belnr_CAN = gw_return-message_v2.
              ls_msg-desc = 'Cancelled Doc. successfully created'.
              APPEND ls_msg TO lt_msg.
              CLEAR: ls_msg.

*              CLEAR: lw_frt.
              lW_frt-belnr_can = gw_return-message_v2.
              lW_frt-status = 'Success'.
              lW_frt-CANCEL_by = sy-uname.
              lW_frt-CANCEL_on = sy-datum.
              lW_frt-CANCEL_at = sy-uzeit.
*              MOVE <fs_frt> TO ls_frt.
              MODIFY lt_frt FROM lw_frt TRANSPORTING belnr_can status CANCEL_by CANCEL_on CANCEL_at
                                        WHERE vbeln EQ lW_frt-vbeln.
            ENDIF.
      ENDIF.

    IF lt_frt IS NOT INITIAL.
          MODIFY zsdt_frt_automat FROM TABLE lt_frt.
          COMMIT WORK AND WAIT.
        ENDIF.
 endif.
 endif.

ENDENHANCEMENT.
