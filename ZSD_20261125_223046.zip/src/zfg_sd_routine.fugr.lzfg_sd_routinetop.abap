FUNCTION-POOL ZFG_SD_ROUTINE.               "MESSAGE-ID ..

DATA v_komv TYPE wdy_boolean.
* INCLUDE LZFG_SD_ROUTINED...                " Local class definition
