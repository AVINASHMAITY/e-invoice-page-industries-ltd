"Name: \PR:SAPLV60A\FO:USEREXIT_PRICING_PREPARE_TKOMK\SE:BEGIN\EN:ZPARVW1\SE:END\EI
ENHANCEMENT 0 ZESD_INVOICE_CR_VAL.
************************************************************************
* Object Name             : ZESD_INVOICE_CR_VAL
* Author/Company Name     : Magam Sai Sudarshan - SAISMA
* Functional Consultant   : Magam Sai Sudarshan
* Transport Request       : DR1K967084
* Creation Date           : 07 JUNL 2022
************************************************************************
* Description: System should not allow to Create invoice if the Billing date
*              is less than SO Creation Date
************************************************************************
CONSTANTS: lc_vf01    TYPE syst-tcode VALUE 'VF01',
           lc_vf02    TYPE syst-tcode VALUE 'VF02',
           lc_objname TYPE sy-repid   VALUE 'ZCL_INV_VAL'.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = lc_objname
  IMPORTING
    ex_tab     = DATA(lt_inv_sel).

SORT lt_inv_sel BY low.
READ TABLE lt_inv_sel INTO DATA(lw_inv_sel) WITH KEY low = vbak-vkorg BINARY SEARCH.

IF sy-subrc EQ 0.
  IF sy-tcode EQ lc_vf01 OR sy-tcode EQ lc_vf02.
    IF vbak-erdat GT vbrk-fkdat AND NOT vbrk-fkdat IS INITIAL.
      MESSAGE 'Billing date is less than Sales order date' TYPE 'E'." DISPLAY LIKE 'I'.
    ENDIF.
  ENDIF.
ENDIF.
"SOC By Madhur for Z9 Billing Block Validation
  IF sy-tcode EQ lc_vf01 AND VBAK-FAKSK = 'Z9'.
    MESSAGE ' Sales Order EXPO_NOC Block' TYPE 'E'.
  ENDIF.
"EOC By Madhur for Z9 Billing Block Validation
ENDENHANCEMENT.
