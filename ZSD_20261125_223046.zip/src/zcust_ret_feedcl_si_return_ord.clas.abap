class ZCUST_RET_FEEDCL_SI_RETURN_ORD definition
  public
  create public .

public section.

  interfaces ZCUST_RET_FEEDII_SI_RETURN_ORD .
protected section.
private section.
ENDCLASS.



CLASS ZCUST_RET_FEEDCL_SI_RETURN_ORD IMPLEMENTATION.


METHOD ZCUST_RET_FEEDII_SI_RETURN_ORD~SI_RETURN_ORDERS_IN.
*** **** INSERT IMPLEMENTATION HERE **** ***
  DATA:
        lwa_Output TYPE  ZCUST_RET_FEEDMT_RETURN_ORDERS,
        lwa_return TYPE  ZCUST_RET_FEEDDT_RETURN_ORDER1,
        lt_rorders TYPE  ZCUST_RET_FEEDDT_RETURN_OR_TAB.
  DATA: lw_ZSDT_RETFEED TYPE ZSDT_RETFEED.

  FIELD-SYMBOLS: <fs_str> TYPE ANY.
  FIELD-SYMBOLS: <fs_data> TYPE ANY.
  DATA: lw_mara TYPE mara.

   lwa_Output = !INPUT.
  lwa_return = lwa_Output-MT_RETURN_ORDERS.
  lt_rorders[] = lwa_return-ROW[].

  LOOP AT lt_rorders INTO DATA(lwa_rorders).

    lw_ZSDT_RETFEED-HANDLE = lwa_rorders-UNIQUE.
    lw_ZSDT_RETFEED-SOLD_KUNNR = lwa_rorders-CUSTOMER_NUMBER.
    lw_ZSDT_RETFEED-SOLD_NAME1 = lwa_rorders-CUSTOMER_NAME.
    lw_ZSDT_RETFEED-SHIP_KUNNR = lwa_rorders-SHIP_TO_NUMBER.
    lw_ZSDT_RETFEED-SHIP_NAME1 = lwa_rorders-SHIP_TO_NAME.
    lw_ZSDT_RETFEED-KUNN2 = lwa_rorders-INDIRECT_CUSTOMER_NAME.
    lw_ZSDT_RETFEED-ORT01 = lwa_rorders-CITY.
    lw_ZSDT_RETFEED-REGIO = lwa_rorders-STATE.
    lw_ZSDT_RETFEED-BSTNK = lwa_rorders-PO_NUMBER.
    lw_ZSDT_RETFEED-IHREZ = lwa_rorders-DEBIT_MEMO_NUMBER.
    lw_ZSDT_RETFEED-RAN_NUMBER = lwa_rorders-RETURNS_AUTHORIZATION_NUMBER.
    lw_ZSDT_RETFEED-CMNGV = lwa_rorders-RETURN_AUTHORIZATION_DATE.
    lw_ZSDT_RETFEED-KDMAT = lwa_rorders-PID.
    lw_ZSDT_RETFEED-VBELN = lwa_rorders-RETURN_NUMBER.
    lw_ZSDT_RETFEED-AUART = lwa_rorders-RETURN_ORDER_TYPE.
    lw_ZSDT_RETFEED-AEDAT = lwa_rorders-RECEIVED_DATE.
    lw_ZSDT_RETFEED-ERDAT = lwa_rorders-PROCESSED_DATE.
    lw_ZSDT_RETFEED-VDATU = lwa_rorders-APPROVAL_DATE.
    lw_ZSDT_RETFEED-EDATU = lwa_rorders-CREDIT_CREATE_DATE.
    lw_ZSDT_RETFEED-ITEN_NUMBER = lwa_rorders-ITEM_NUMBER.
    lw_ZSDT_RETFEED-ARKTX = lwa_rorders-ITEM_DESCRIPTION.
    lw_ZSDT_RETFEED-EAN11 = lwa_rorders-PRODUCT_BARCODE.
    lw_ZSDT_RETFEED-STADAT = lwa_rorders-EXPIRATION_DATE.
    lw_ZSDT_RETFEED-CHARG = lwa_rorders-LOT_NUMBER.

****    IF lwa_rorders-RECEIVED_QUANTITY IS NOT INITIAL.
****      ASSIGN lwa_rorders TO <fs_str>.
****      IF <fs_str> IS ASSIGNED.
****        ASSIGN COMPONENT 'RECEIVED_QUANTITY' OF STRUCTURE <fs_str> TO <fs_data>.
****        IF <fs_data> IS ASSIGNED.
****          <fs_data> =  lw_ZSDT_RETFEED-ZMENG .
****          IF lw_ZSDT_RETFEED-ZMENG IS INITIAL.
****            lw_ZSDT_RETFEED-STATUS_MSG = 'Entry not updated successfully'.
****            MODIFY ZSDT_RETFEED FROM lw_ZSDT_RETFEED.
****            IF sy-subrc IS INITIAL.
****              COMMIT WORK  AND WAIT.
****            ENDIF.
****            CLEAR:lw_ZSDT_RETFEED.
****            CONTINUE.
****          ENDIF.
****          UNASSIGN <fs_data>.
****        ENDIF.
****        UNASSIGN <fs_str>.
****      ENDIF.
****    ENDIF.

    lw_ZSDT_RETFEED-ZMENG  = lwa_rorders-RECEIVED_QUANTITY .
    lw_ZSDT_RETFEED-ZIEME = lwa_rorders-UOM.
    lw_ZSDT_RETFEED-AUGRU = lwa_rorders-RETURN_REASON_CODE.
    lw_ZSDT_RETFEED-MASCHINE = lwa_rorders-PRODUCT_CONDITION.
    lw_ZSDT_RETFEED-ORIGINAL_INPUT = lwa_rorders-RETURNABLE_FOR_CREDIT.
    lw_ZSDT_RETFEED-ABLFZ = lwa_rorders-CREDIT_QUANTITY.
    lw_ZSDT_RETFEED-NETPR = lwa_rorders-CREDIT_PRICE.
    lw_ZSDT_RETFEED-MWSBP = lwa_rorders-CREDIT_AMOUNT.
    lw_ZSDT_RETFEED-ZUONR = lwa_rorders-TRANSACTION_NUMBER.
    lw_ZSDT_RETFEED-ABHOD = lwa_rorders-THIRD_PARTY_RECEIVEDATE.
*    lw_ZSDT_RETFEED-STATUS_MSG = 'Entry updated successfully'.
    lw_ZSDT_RETFEED-CREATE_DATE = sy-datum .
    lw_ZSDT_RETFEED-ENTRY_TIME =  sy-uzeit .

    MODIFY ZSDT_RETFEED FROM lw_ZSDT_RETFEED.
    IF sy-subrc IS INITIAL.
      COMMIT WORK  AND WAIT.
    ENDIF.
    CLEAR:lw_ZSDT_RETFEED.
  ENDLOOP.
  CLEAR lt_rorders[].
ENDMETHOD.
ENDCLASS.
