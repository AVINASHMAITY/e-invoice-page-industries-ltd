"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:END\EI
ENHANCEMENT 0 ZSD_HIDE_ORDER_REASON.
************************************************************************
* Date       Programmer  Client Ref No.     Correction               *
*  31.01.2017  Kavin                       DR1K931091                *
*  04.04.2017  Chaithanya                  DR1K932131                *
* Description   Hide Screen Field Order Reason
************************************************************************
*
*IF  sy-tcode = 'VA02'.
*
*  IF  VBAK-VKORG = '1102'.
*
*  IF   SCREEN-NAME EQ 'VBAP-ZZAUGRU'.
*
*DATA  :  LC_BSART(11) VALUE 'SO_BSART_SO'.
*
*CONSTANTS :   GC_ORD_REASON       TYPE SOBJ_NAME   VALUE 'ZSD_EXPIRED_ORDER_REASON'.
*
*DATA : GT_CONSTANT TYPE ZTT_ZTABAP_TVARVC,
*       GW_CONSTANT TYPE ZTABAP_TVARVC.
**----------------------------------------------------------------------*
**ZCMAIN PARAMTER  FOR Order Reason
**----------------------------------------------------------------------*
*CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
*  EXPORTING
*    IM_OBJNAME = GC_ORD_REASON
*  IMPORTING
*    EX_TAB     = GT_CONSTANT.
*
*READ TABLE GT_CONSTANT TRANSPORTING NO FIELDS
*     WITH KEY   OBJ_NAME = GC_ORD_REASON
*                NAME     = LC_BSART
*                LOW      = VBAK-AUART.
*IF SY-SUBRC EQ 0.
*    SCREEN-INPUT    = 0.
*  MODIFY SCREEN.
*  ENDIF.
* ENDIF.
* endif.
* endif.

ENDENHANCEMENT.
