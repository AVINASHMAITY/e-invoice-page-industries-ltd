*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDMS_AKKP_OBJECT_LINKTOP.         " Global Data
  INCLUDE LZDMS_AKKP_OBJECT_LINKUXX.         " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDMS_AKKP_OBJECT_LINKF...         " Subroutines
* INCLUDE LZDMS_AKKP_OBJECT_LINKO...         " PBO-Modules
* INCLUDE LZDMS_AKKP_OBJECT_LINKI...         " PAI-Modules
* INCLUDE LZDMS_AKKP_OBJECT_LINKE...         " Events
* INCLUDE LZDMS_AKKP_OBJECT_LINKP...         " Local class implement.
* INCLUDE LZDMS_AKKP_OBJECT_LINKT99.         " ABAP Unit tests
