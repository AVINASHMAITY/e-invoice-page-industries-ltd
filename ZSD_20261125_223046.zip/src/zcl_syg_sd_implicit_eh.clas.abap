class ZCL_SYG_SD_IMPLICIT_EH definition
  public
  final
  create public .

public section.

  class-methods CHECK_CREDIT_MANAGEMENT
    importing
      !IV_VBAK type VBAK .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SYG_SD_IMPLICIT_EH IMPLEMENTATION.


  METHOD check_credit_management.
*&--------------------------------------------------------------------*
* Modification History *
*&--------------------------------------------------------------------*
* Date        Programmer   Correction *
* 28 SEP 2018 SAISMA       DR1K942149
* Description: Bug fix in Credit limit Enhancement
*&--------------------------------------------------------------------*
*& Begin of code 12-Dec-2017
*& Fucntional Ramesh
*& Technical SAP_KARTHM / JKT
*& TR --> DR1K937576, DR1K937987
*&  Credit Management check for specific document types
    CHECK sy-tcode EQ 'VA01' OR sy-tcode EQ 'VA02'. " DR1K937987

*& Check Document type has been maintained for custom validtions
*    SELECT SINGLE @abap_true FROM ztsd_doc_types INTO @DATA(lv_exist)
    SELECT SINGLE @abap_true FROM ztsd_doc_type_cm INTO @DATA(lv_exist)
      WHERE auart = @iv_vbak-auart.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
*&*  Check Credit management amount.
    SELECT SINGLE klimk FROM knkk INTO @DATA(lv_klimk)
      WHERE kunnr = @iv_vbak-kunnr
      AND   kkber = @iv_vbak-kkber. "'5001'. " DR1K942149
    IF sy-subrc <> 0. " Cutomer not available
      MESSAGE e078(zsd_messages)." DISPLAY LIKE 'I'.
    ELSEIF lv_klimk = 0.
      MESSAGE e078(zsd_messages)." DISPLAY LIKE 'I'. " Display the same message for both Condition
    ENDIF.
  ENDMETHOD.
ENDCLASS.
