"Name: \PR:SAPMV45A\FO:USEREXIT_PRICING_PREPARE_TKOMK\SE:BEGIN\EI
ENHANCEMENT 0 ZPARVW.
*&--------------------------------------------------------------------*
*    Date      Programmer         TR No.         Description          *
* 04.07.2018   Chaithanya      DR1K940738  Item level Partner Function*
* 31.04.2019   Chaithanya      DR1K945151  Partner Function ZI        *
* 16.12.2020   Bhagavan        DR1K953998  Added YBOT Doc Type        *
* 21.10.2021   Bhagavan        DR1K961619  partner function issue in z004*
*---------------------------------------------------------------------*
*  BREAK SARSIR.


*if ( ( sy-tcode = 'VA01' or sy-tcode = 'VA02' ) and vbak-vkorg eq '2600' ).
*READ TABLE xkomv INTO DATA(lw_komv) with KEY kschl = 'ZBM1'.
*IF  sy-subrc eq 0.
* READ TABLE xkomv INTO DATA(lw_komv1) with KEY kschl = 'ZBMP'.
* if sy-subrc ne 0.
*  lw_komv-kschl = 'ZBMP'.
*  APPEND lw_komv to xkomv.
*  CLEAR lw_komv.
*  endif.
**READ TABLE xkomv ASSIGNING FIELD-SYMBOL(<lw_komv>) with KEY kschl = 'ZBMP'.
**if sy-subrc eq 0.
**  <lw_komv>-kbetr = lw_komv-kbetr.
**endif.
*ENDIF.
*  endif.

  IF VBAK-AUART = 'YBOI' OR VBAK-AUART = 'YBOR'  OR VBAK-AUART = 'YBOT' .  "YBOT Added by bhagavan on 16/12/2020
    DATA : LS_XVBPA LIKE LINE OF XVBPA[].
    CLEAR : LS_XVBPA.
*************Code Starts by Bhagavan on 21.10.2021 "DR1K961619*****************************************************************
      READ TABLE XVBPA INTO LS_XVBPA WITH KEY PARVW = 'ZT'.
      IF SY-SUBRC = 0.
        MOVE LS_XVBPA-PARVW TO KOMK-ZZPARVW.
        MOVE LS_XVBPA-PARVW TO TKOMK-ZZPARVW.
        MOVE LS_XVBPA-KUNNR TO KOMK-ZZKUNNR.
        MOVE LS_XVBPA-KUNNR TO TKOMK-ZZKUNNR.
        MOVE LS_XVBPA-KUNNR TO TKOMK-KUNNR.
        MOVE LS_XVBPA-KUNNR TO KOMK-KUNNR..
        MOVE LS_XVBPA-PARVW TO KOMP-ZZPARVW.
        MOVE LS_XVBPA-PARVW TO TKOMP-ZZPARVW.
        MOVE LS_XVBPA-KUNNR TO KOMP-ZZKUNNR.
        MOVE LS_XVBPA-KUNNR TO TKOMP-ZZKUNNR.
      ENDIF.
      READ TABLE XVBPA INTO LS_XVBPA WITH KEY PARVW = 'ZI'.
      IF SY-SUBRC = 0.
        MOVE LS_XVBPA-PARVW TO KOMK-ZZPARVW.
        MOVE LS_XVBPA-PARVW TO TKOMK-ZZPARVW.
        MOVE LS_XVBPA-KUNNR TO KOMK-ZZKUNNR.
        MOVE LS_XVBPA-KUNNR TO TKOMK-ZZKUNNR.
        MOVE LS_XVBPA-KUNNR TO TKOMK-KUNNR.
        MOVE LS_XVBPA-KUNNR TO KOMK-KUNNR..
        MOVE LS_XVBPA-PARVW TO KOMP-ZZPARVW.
        MOVE LS_XVBPA-PARVW TO TKOMP-ZZPARVW.
        MOVE LS_XVBPA-KUNNR TO KOMP-ZZKUNNR.
        MOVE LS_XVBPA-KUNNR TO TKOMP-ZZKUNNR.
      ENDIF.
*************Code Ends by Bhagavan on 21.10.2021 "DR1K961619*****************************************************************
    READ TABLE XVBPA INTO LS_XVBPA WITH KEY PARVW = 'ZT'
                                            posnr = xvbap-posnr. " Code Added By chaithanya DR1K940738
    IF SY-SUBRC = 0.
      MOVE LS_XVBPA-PARVW TO KOMK-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMK-ZZPARVW.
      MOVE LS_XVBPA-KUNNR TO KOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMK-KUNNR.
      MOVE LS_XVBPA-KUNNR TO KOMK-KUNNR..
      MOVE LS_XVBPA-PARVW TO KOMP-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMP-ZZPARVW.
      MOVE LS_XVBPA-KUNNR TO KOMP-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMP-ZZKUNNR.
    ENDIF.
    READ TABLE XVBPA INTO LS_XVBPA WITH KEY PARVW = 'ZI'
                                            posnr = xvbap-posnr. " Code Added By chaithanya DR1K945151
    IF SY-SUBRC = 0.
      MOVE LS_XVBPA-PARVW TO KOMK-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMK-ZZPARVW.
      MOVE LS_XVBPA-KUNNR TO KOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMK-KUNNR.
      MOVE LS_XVBPA-KUNNR TO KOMK-KUNNR..
      MOVE LS_XVBPA-PARVW TO KOMP-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMP-ZZPARVW.
      MOVE LS_XVBPA-KUNNR TO KOMP-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMP-ZZKUNNR.
    ENDIF.
  ENDIF.
ENDENHANCEMENT.
