FUNCTION-POOL ZFG_SD_CVD.                   "MESSAGE-ID ..

* INCLUDE LZFG_SD_CVDD...                    " Local class definition
