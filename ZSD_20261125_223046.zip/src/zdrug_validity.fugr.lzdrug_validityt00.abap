*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDRUG_VALIDITY..................................*
DATA:  BEGIN OF STATUS_ZDRUG_VALIDITY                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDRUG_VALIDITY                .
CONTROLS: TCTRL_ZDRUG_VALIDITY
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDRUG_VALIDITY                .
TABLES: ZDRUG_VALIDITY                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
