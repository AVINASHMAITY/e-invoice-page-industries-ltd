class ZCL_IM_LE_SHP_DELIVERY_PRO definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_LE_SHP_DELIVERY_PROC .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_LE_SHP_DELIVERY_PRO IMPLEMENTATION.


  METHOD if_ex_le_shp_delivery_proc~change_delivery_header.

  ENDMETHOD.


  METHOD if_ex_le_shp_delivery_proc~change_delivery_item.

    break pushpa.

    DATA lv_flag TYPE char1.
    DATA lv_flag_q TYPE char1.
    CLEAR : lv_flag,lv_flag_q.

    DATA : lv_ga TYPE ztmm_gate_entry-zzgate_enrty_no.

    IMPORT flag = lv_flag FROM MEMORY ID 'ZGRCL_S'.

    IF lv_flag = 'X'.
      CLEAR : cs_lips-insmk.

*      IMPORT lv_gate = lv_ga FROM MEMORY ID 'ZGRCL_GA'.
*
*      IF lv_ga IS NOT INITIAL.
*
*        SELECT * FROM zwm_grcl_tab INTO TABLE @DATA(it_ib) WHERE zzgate_enrty_no = @lv_ga.
*
*        IF cs_lips-vgpos+1(5) IS NOT INITIAL.
*
*          READ TABLE it_ib INTO DATA(ls_ib) WITH KEY ebeln = cs_lips-vgbel ebelp = cs_lips-vgpos+1(5).
*          IF sy-subrc NE 0.
*
*            READ TABLE it_xlips INTO DATA(ls_li) WITH KEY vgbel = cs_lips-vgbel vgpos = cs_lips-vgpos.
*            IF sy-subrc EQ 0.
*              CLEAR : cs_lips-lfimg,
*              CS_LIPSD-G_LFIMG.
*
*            ENDIF.
*
*
*
*
*          ENDIF.
*
*        ENDIF.
*
*
*
*
*      ENDIF.






    ENDIF.

    IMPORT flag_q = lv_flag_q
  FROM MEMORY ID 'ZGRCL_Q'.

    IF lv_flag_q = 'X'.
      cs_lips-bestq = 'Q'.
    ENDIF.



  ENDMETHOD.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FCODE_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FIELD_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHECK_ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_FINAL_CHECK.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DOCUMENT_NUMBER_PUBLISH.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_HEADER.
  endmethod.


  METHOD if_ex_le_shp_delivery_proc~fill_delivery_item.
    DATA : lv_order_block TYPE zorder_block,
           lv_lifsk       TYPE lifsk.

**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

    CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
                gc_vkorg(15) VALUE 'BFI_VKORG'.

    DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
    TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

    CALL METHOD zcl_abap_utility=>get_options
      EXPORTING
        im_objname = gc_bfi
      IMPORTING
        ex_tab     = gt_vkorg.

    DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                      ( sign = 'I'
                        option = 'EQ'
                        low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************

    IF sy-tcode EQ 'VL01N' OR sy-tcode EQ 'VL10C'.
      IF cs_lips-vgbel IS NOT INITIAL  .
        SELECT SINGLE lifsk FROM vbak INTO lv_lifsk WHERE vbeln = cs_lips-vgbel .
        IF lv_lifsk EQ 'Z1' .
          MESSAGE : 'You can not Create the Delivery For this Order Due to Z1 Block' TYPE 'E'.
        ENDIF.

        SELECT SINGLE lifsk,vtweg,auart FROM vbak INTO @DATA(lv_lifsk_1) WHERE vbeln = @cs_lips-vgbel .

        IF lv_lifsk_1-lifsk EQ 'ZP' AND lv_lifsk_1-vtweg = '50' AND lv_lifsk_1-auart = 'YBOI'.   "ADDED BY KIRUBA  " LOGIC GIVEN BY AKKI
          MESSAGE : 'You can not Create the Delivery For this Order Due to ZP Block' TYPE 'E'.
        ENDIF.

      ENDIF.
    ENDIF.
    break sahoo.
    IF sy-tcode EQ 'VA02' OR sy-tcode EQ 'VL01N'.
      IF cs_lips-vgbel IS NOT INITIAL  .
        SELECT SINGLE block_order FROM vbap INTO lv_order_block WHERE vbeln = cs_lips-vgbel AND
                                                                      posnr = cs_lips-vgpos .
        IF lv_order_block NE '0' AND lv_order_block IS NOT INITIAL.
*          message : 'You can not Create the Delivery of this Order' type 'E'." Code Comment by Chaithanya  DR1K935297
          MESSAGE :  'You can not Create the Delivery For this Order Due to Z2 Block' TYPE 'E'.  " Code Comment by Chaithanya  DR1K935297
        ENDIF.
      ENDIF.
    ENDIF.
    IF sy-tcode EQ 'VA02' OR sy-tcode EQ 'VL01N' OR sy-tcode EQ 'VL10B' OR sy-tcode EQ 'VL10X'.
*      IF is_likp-vkorg = '1102'.
      IF is_likp-vkorg IN ra_vkorg.  "Added by Ravi on 06.06.2019 DR1K945737
        DATA: v_lgort  TYPE zsdt011-lgort,
****************Begin of changes by Ravi on 17.09.2018 DR1K941932*******************
              lv_numc  TYPE vgpos,
              lv_ebelp TYPE ebelp.
        FIELD-SYMBOLS : <lx_lgort> TYPE any.
        lv_numc = cs_lips-vgpos.
*        SHIFT lv_numc by 1 PLACES.          "Commented by Ravi on 21.09.2018 DR1K942018
        lv_ebelp = lv_numc.
        IF cs_lips-vgbel IS NOT INITIAL AND
           lv_ebelp IS NOT INITIAL.
          SELECT SINGLE lgort INTO v_lgort FROM ekpo WHERE ebeln = cs_lips-vgbel
                                                       AND ebelp = lv_ebelp.
          IF v_lgort IS NOT INITIAL.
            cs_lips-lgort = v_lgort.
          ENDIF.
        ENDIF.
        IF cs_lips-lgort IS INITIAL.
          SELECT SINGLE lgort FROM zsdt011 INTO v_lgort WHERE auart = is_likp-lfart.
          IF sy-subrc = 0.
            cs_lips-lgort = v_lgort.
          ENDIF.
        ENDIF.
      ENDIF.
****************End of changes by Ravi on 17.09.2018 DR1K941932*******************
    ENDIF.


  ENDMETHOD.


  method IF_EX_LE_SHP_DELIVERY_PROC~INITIALIZE_DELIVERY.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~ITEM_DELETION.

  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~PUBLISH_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~READ_DELIVERY.
  endmethod.


  method if_ex_le_shp_delivery_proc~save_and_publish_before_output.
************************ Modification Log***************************************
********************************************************************************
* Date         Programmer  Client   Ref No.   Description   Correction         *
* 23.04.2018   Chandru/ITZ        DR1K938213 Update Extra Input
* 07.09.2020   Lakshmi/Iteanz     DR1K952594 Allow the T-code "VL02N & VL01N
*
********************************************************************************

    if ( sy-tcode = 'VL31N' or sy-tcode = 'VL32N'
       or sy-tcode = 'VL01N' or sy-tcode = 'VL02N' ) "Added By Lakshmi/Iteanz " DR1K952594
       and sy-ucomm = 'SICH_T' .
      data : ls_zsdt_mis type zsdt_mis.
      import gw_zsdt_mis to ls_zsdt_mis from memory id 'ZMIS_IBD'.
      data(lv_ibd) = value #( it_xlikp[ 1 ]-vbeln optional ).
      if lv_ibd is not initial.
        ls_zsdt_mis-vbeln = lv_ibd.
        modify zsdt_mis from ls_zsdt_mis.
        if sy-subrc = 0.
          commit work and wait.
        else.
          rollback work.
        endif.
      endif.
    endif.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_DOCUMENT.
  endmethod.


method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_DOCUMENT_PREPARE.
*  if sy-tcode = 'VL01N' or SY-tcode = 'VL02N'.
*    types: BEGIN OF T_VBAK,
*        VBELN TYPE VBAK-VBELN,
*        AUART TYPE VBAK-AUART,
*        VKORG TYPE VBAK-VKORG,
*        VTWEG TYPE VBAK-VTWEG,
*        Kunnr type vbak-kunnr,
*      END OF T_VBAK.
*DATA: w_VBUPVB type VBUKVB.
*DATA: w_vbak type t_vbak.
*DATA: v_werks type vbrp-werks.
*DATA: v_adrnr type t001w-adrnr.
*DATA: v_sort type adrc-sort2.
*DATA: v_vbeln type vbak-vbeln.
*DATA: w_lips type LIPSVB.
*DATA: v_ct3 type /obiz/zuxg_cts-ct3_num.
* types: BEGIN OF t_excise,
*      KUNNR type /OBIZ/ZUXG_CTSI-KUNNR,
*      FORM_TYPE type /OBIZ/ZUXG_CTSI-form_TYPE,
*      SERIAL_NUM type /OBIZ/ZUXG_CTSI-serial_num,
*      ZEILE  type /OBIZ/ZUXG_CTSI-ZEILE,
*      CT3_NUM type /OBIZ/ZUXG_CTSI-ct3_num,
*      MATNR type /OBIZ/ZUXG_CTSI-matnr,
*      BAL_QTY type /OBIZ/ZUXG_CTSI-BAL_QTY,
*     END OF t_excise.
*DATA: W_excise type t_excise,
*      i_excise type TABLE OF t_excise.
*types: begin of t_vbap,
*       vbeln type vbap-vbeln,
*       posnr type vbap-vbeln,
*       lsmeng type vbap-lsmeng,
*      END OF t_vbap.
*data: w_vbap type t_vbap,
*      i_vbap type TABLE OF t_vbap.
*data: v_lsmng type vbap-lsmeng.
*read TABLE iT_YVBUK  INTO w_VBUPVB INDEX 1.
*Select SINGLE vbeln auart vkorg vtweg kunnr from vbak INTO w_vbak where vbeln = w_VBUPVB-vbeln
*  and ( AUART = 'ZBDE' or AUART = 'ZBEX' or AUART = 'ZBA1' or AUART = 'ZBAL' )
*  and vkorg = '1101'
*  and vtweg = '10'.
*if sy-subrc = 0.
* If W_vbak-auart = 'ZBDE'.
* loop at ct_xlips INTO w_lips.
*   if w_lips-zzct3_no is INITIAL.
*    MESSAGE 'Mantain the ct3 no ' type 'E'.
*  else.
*    select SINGLE
*      KUNNR
*      FORM_TYPE
*      SERIAL_NUM
*      ZEILE
*      CT3_NUM
*      MATNR
*      BAL_QTY
*   from /OBIZ/ZUXG_CTSI
*   INTO w_excise
*   where kunnr = w_vbak-kunnr
*   and   matnr = w_lips-matnr
*   and   form_type = 'CT3'
*   and   CT3_num  = w_lips-zzct3_no.
*   if sy-subrc = 0.
*     if w_excise-bal_qty NE w_lips-LFIMG.
*       MESSAGE 'Qty Mismatch' type 'E'.
*     endif.
*   else.
*     MESSAGE 'Enter The correct Ct3 No' type 'E'.
*   endif.
*  endif.
*  clear: w_lips,w_excise.
* ENDLOOP.
*  elseif w_vbak-auart = 'ZBEX'.
*    loop at ct_xlips INTO w_lips.
*   if w_lips-zzct1_no is INITIAL.
*    MESSAGE 'Mantain the ct1 no ' type 'E'.
*  else.
*    select SINGLE
*      KUNNR
*      FORM_TYPE
*      SERIAL_NUM
*      ZEILE
*      CT3_NUM
*      MATNR
*      BAL_QTY
*   from /OBIZ/ZUXG_CTSI
*   INTO w_excise
*   where kunnr = w_vbak-kunnr
*   and   matnr = w_lips-matnr
*   and   form_type = 'CT1'
*   and   CT3_num  = w_lips-ZZCT1_NO.
*   if sy-subrc = 0.
*     if w_excise-bal_qty NE w_lips-LFIMG.
*       MESSAGE 'Qty Mismatch' type 'E'.
*     endif.
*   else.
*     MESSAGE 'Enter The correct Ct1 No' type 'E'.
*   endif.
*  endif.
*  clear: w_lips,w_excise.
* ENDLOOP.
*  elseif w_vbak-auart = 'ZBA1'.
*        loop at ct_xlips INTO w_lips.
*   if w_lips-ZZCT_ANX is INITIAL.
*    MESSAGE 'Mantain the Annexure no ' type 'E'.
*  else.
*    select SINGLE
*      KUNNR
*      FORM_TYPE
*      SERIAL_NUM
*      ZEILE
*      CT3_NUM
*      MATNR
*      BAL_QTY
*   from /OBIZ/ZUXG_CTSI
*   INTO w_excise
*   where kunnr = w_vbak-kunnr
*   and   matnr = w_lips-matnr
*   and   form_type = 'ANX'
*   and   CT3_num  = w_lips-ZZCT_ANX.
*   if sy-subrc = 0.
*     if w_excise-bal_qty NE w_lips-LFIMG.
*       MESSAGE 'Qty Mismatch' type 'E'.
*     endif.
*   else.
*     MESSAGE 'Enter The correct Anexure No' type 'E'.
*   endif.
*  endif.
*  clear: w_lips,w_excise.
* ENDLOOP.
*  elseif w_vbak-auart = 'ZBAL'.
*            loop at ct_xlips INTO w_lips.
*   if w_lips-ZZCT_ADV is INITIAL.
*    MESSAGE 'Mantain the Adv Licence no ' type 'E'.
*  else.
*    select SINGLE
*      KUNNR
*      FORM_TYPE
*      SERIAL_NUM
*      ZEILE
*      CT3_NUM
*      MATNR
*      BAL_QTY
*   from /OBIZ/ZUXG_CTSI
*   INTO w_excise
*   where kunnr = w_vbak-kunnr
*   and   matnr = w_lips-matnr
*   and   form_type = 'ADV'
*   and   CT3_num  = w_lips-ZZCT_ADV.
*   if sy-subrc = 0.
*     if w_excise-bal_qty NE w_lips-LFIMG.
*       MESSAGE 'Qty Mismatch' type 'E'.
*     endif.
*   else.
*     MESSAGE 'Enter The correct Adv Licence  No' type 'E'.
*   endif.
*  endif.
*  clear: w_lips,w_excise.
* ENDLOOP.
*  else.
* endif.
*  endif.
**select vbeln posnr lsmeng from vbap INTO table i_vbap where vbeln = w_vbak-vbeln.
**  if sy-subrc = 0.
**    loop at i_vbap INTO w_vbap.
**       v_lsmng = w_vbap-lsmeng + v_lsmng.
**       CLEAR w_vbap.
**    endloop.
**  endif.
**read TABLE CT_XLIKP INTO w_likp index 1.
**if sy-subrc = 0.
**  if w_likp-zzct3_num is INITIAL.
**    MESSAGE 'Mantain the ct3 no ' type 'E'.
**  else.
**    select SINGLE werks from vbap INTO v_werks
**      where vbeln = w_VBUPVB-vbeln.
**    if sy-subrc = 0.
**      select  single
**                   CT3_NUM
**              from /OBIZ/ZUXG_CTSI
**              INTO  v_ct3
**              where WERKS = v_werks
**               and  KUNNR = w_likp-kunnr
**               and  FORM_TYPE = 'CT3'
**               and  ct3_num   = w_likp-zzct3_num.
**       if sy-subrc ne 0.
**         MESSAGE 'Mantain correct ct3 no' type 'E'.
**       endif.
**    endif.
**  endif.
**endif.
**endif.
*  endif.
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************
If sy-tcode = 'VL02N' or sy-tcode = 'VL09'.
DATA: W_likp type likp.
DATA: W_lipss type lips.
READ TABLE CT_YLIKP INTO w_likp INDEX 1.
READ TABLE CT_YLIPS INTO w_lipss INDEX 1.
 If w_likp-vkorg =  '1101' OR w_likp-vkorg IN ra_vkorg. "w_LIKP-VKORG = '1102'. "Added by Ravi on 06.06.2019 DR1K945737
DATA: V_WERK type LIPS-WERKS .
DATA: V_werks1 type J_1IWRKCUS-J_1IWERKS.
DATA: V_vbel type likp-vbeln.
DATA: v_rdoc1 type J_1IEXCDTL-rdoc1.DATA : V_VBELN3 TYPE VBFA-VBELN,
                                           V_VBELN4 TYPE VBRK-VBELN.
BREAK sahoo.
 select single J_1IWERKS from J_1IWRKCUS INTO V_WERKS1 where J_1IWERKS = w_lipss-werks
                                                   and   J_1IDEPOT  = 'X'.
 if V_WERKS1 is not INITIAL." = 0.
   select single VBELN  from J_1IRG23D INTO v_vbel where vbeln = w_likp-vbeln
                                                     and  STATUS = 'P'.
   if v_vbel is not INITIAL.
     MESSAGE 'Delivery cannot be deleted as Depot excise invoice is created' type 'E' ."DISPLAY LIKE 'E'.
     LEAVE PROGRAM.
   endif.
* endif.
else.
 select single rdoc1 from J_1IEXCDTL INTO v_rdoc1 where rdoc1 = w_LIKP-VBELN
                                                  and   STATUS = 'C'.
 if v_rdoc1 is not INITIAL.
   MESSAGE 'Delivery cannot be deleted as Excise invoice is created' type 'E' ."DISPLAY LIKE 'E'.
   Leave program.
 endif.
endif.
clear v_vbeln3.
Break Sahoo.
SELECT SINGLE vbeln FROM vbfa INTO v_vbeln3 WHERE vbelv = w_likp-vbeln AND vbtyp_n = 'U'.
  IF sy-subrc EQ 0.
    clear v_vbeln4.
    SELECT SINGLE vbeln FROM vbrk INTO v_vbeln4 WHERE vbeln = v_vbeln3 AND rfbsk EQ 'E'.
      IF Sy-subrc NE 0.
        MESSAGE 'Proforma Invoice is created delivery document cannot be deleted' TYPE 'E'."  DISPLAY LIKE 'E'.
      ENDIF.
   ENDIF.
endif.
endif.
*******************Begin of changes by Ravi on 23.01.2020 DR1K949163*************
IF if_tcode EQ 'VL31N' OR if_tcode EQ 'VL32N'.
  READ TABLE ct_xlips INTO DATA(ls_lips) INDEX 1.
  READ TABLE ct_xlikp INTO DATA(ls_likp) INDEX 1.
  IF ls_likp-bill_entry_no is INITIAL or
     ls_likp-bill_entry_date is INITIAL.
  IF ls_lips-vgbel IS NOT INITIAL.
    SELECT SINGLE bsart FROM ekko
           INTO @DATA(lv_bsart)
           WHERE ebeln EQ @ls_lips-vgbel.

    SELECT SINGLE werks FROM ekpo
           INTO @DATA(lv_werks)
           WHERE ebeln EQ @ls_lips-vgbel
             AND loekz EQ @space.

    SELECT SINGLE * FROM zmm_ibd_boe_mand
           INTO @DATA(ls_ibd)
           WHERE bsart EQ @lv_bsart
             AND werks EQ @lv_werks
             AND active EQ @abap_true.
    IF sy-subrc EQ 0.
     MESSAGE e083(zsd_messages).
    ENDIF.
   ENDIF.
  ENDIF.
ENDIF.
DATA : lv_sup TYPE lifnr.
IF if_tcode EQ 'VL02N'.
  READ TABLE ct_xlips INTO ls_lips INDEX 1.
  READ TABLE ct_xlikp INTO ls_likp INDEX 1.
  IF ls_likp-bill_entry_no is INITIAL or
     ls_likp-bill_entry_date is INITIAL.
   IF ls_lips-vgbel IS NOT INITIAL.
    SELECT SINGLE bsart, bsakz, lifnr, reswk FROM ekko
           INTO @DATA(ls_ekko)
           WHERE ebeln EQ @ls_lips-vgbel.

    SELECT SINGLE werks FROM ekpo
           INTO @lv_werks
           WHERE ebeln EQ @ls_lips-vgbel
             AND loekz EQ @space.
    CLEAR : lv_sup.
    IF ls_ekko-bsakz EQ 'T'.
     lv_sup = ls_ekko-reswk.
    ELSE.
     lv_sup = ls_ekko-lifnr.
    ENDIF.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input         = lv_sup
     IMPORTING
       OUTPUT        = lv_sup.

    SELECT SINGLE * FROM zmm_obd_boe_mand
           INTO @DATA(ls_obd)
           WHERE bsart EQ @ls_ekko-bsart
             AND sup_ven EQ @lv_sup
             AND werks EQ @lv_werks
             AND active EQ @abap_true.
    IF sy-subrc EQ 0.
     MESSAGE e083(zsd_messages).
    ENDIF.
   ENDIF.
  ENDIF.
ENDIF.
*******************End of changes by Ravi on 23.01.2020 DR1K949163*************
endmethod.
ENDCLASS.
