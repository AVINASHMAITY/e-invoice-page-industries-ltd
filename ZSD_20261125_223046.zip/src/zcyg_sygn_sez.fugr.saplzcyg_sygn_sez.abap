*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_SYGN_SEZTOP.                 " Global Data
  INCLUDE LZCYG_SYGN_SEZUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_SYGN_SEZF...                 " Subroutines
* INCLUDE LZCYG_SYGN_SEZO...                 " PBO-Modules
* INCLUDE LZCYG_SYGN_SEZI...                 " PAI-Modules
* INCLUDE LZCYG_SYGN_SEZE...                 " Events
* INCLUDE LZCYG_SYGN_SEZP...                 " Local class implement.
* INCLUDE LZCYG_SYGN_SEZT99.                 " ABAP Unit tests
  INCLUDE LZCYG_SYGN_SEZF00                       . " subprograms
  INCLUDE LZCYG_SYGN_SEZI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
