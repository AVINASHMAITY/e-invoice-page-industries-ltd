"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZPARVW.
*  BREAK sarsir.
**************Modification Log *****************************
*  Date         Programmer    TR No.     Description       *
* 11.01.2018     Pushpa     DR1K938076  YBOR Included      *
* 31.04.2019   Chaithanya   DR1K945151  Partner Function ZI*
************************************************************
  IF ( VBAK-AUART = 'YBOI' or VBAK-AUART = 'YBOR') and ( xvbpa-parvw = 'ZT' OR xvbpa-parvw = 'ZI' ). "modified by Pushpa 08.01.2018
    DATA : LS_XVBPA LIKE LINE OF XVBPA[].
    CLEAR : LS_XVBPA.
    READ TABLE XVBPA INTO LS_XVBPA WITH KEY PARVW = 'ZT'.
    IF SY-SUBRC = 0.
      MOVE LS_XVBPA-PARVW TO KOMK-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO KOMp-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMK-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMp-ZZPARVW.
      MOVE LS_XVBPA-KUNNR TO KOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO KOMK-KUNNR.
      MOVE LS_XVBPA-KUNNR TO tKOMK-KUNNR.
      MOVE LS_XVBPA-KUNNR TO KOMp-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMp-ZZKUNNR.
    ENDIF.
    READ TABLE XVBPA INTO LS_XVBPA WITH KEY PARVW = 'ZI'.  " Code Added By Chaithanya DR1K945151
    IF SY-SUBRC = 0.
      MOVE LS_XVBPA-PARVW TO KOMK-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO KOMp-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMK-ZZPARVW.
      MOVE LS_XVBPA-PARVW TO TKOMp-ZZPARVW.
      MOVE LS_XVBPA-KUNNR TO KOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO KOMK-KUNNR.
      MOVE LS_XVBPA-KUNNR TO tKOMK-KUNNR.
      MOVE LS_XVBPA-KUNNR TO KOMp-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMK-ZZKUNNR.
      MOVE LS_XVBPA-KUNNR TO TKOMp-ZZKUNNR.
    ENDIF.

  ENDIF.



****** Begin of Changes Pranesh  DR1K947499 *******

DATA:
      ls_kna1 TYPE kna1,
      LV_BSTNK TYPE KUNNR,
      v_date(10) TYPE c,
      LS_ZDLVKORG TYPE ZDLVKORG,
      lv_validto TYPE ZDRUG_VALIDIty-valid_to,
      lt_drugvalid TYPE TABLE OF ZDRUG_VALIDITY,
      lt_validto TYPE TABLE OF ZDRUG_VALIDITY,
      ls_drugvalid TYPE ZDRUG_VALIDITY.

v_date = sy-datum.
SELECT SINGLE * FROM ZDLVKORG INTO LS_ZDLVKORG WHERE VKORG = VBAK-vkorg AND AUART = VBAK-auart.
  IF SY-SUBRC EQ 0.
 IF ( sy-tcode = 'VA01' OR sy-tcode = 'VA02' ).

   LV_BSTNK = VBAK-kunnr.
   CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
     EXPORTING
       input         = LV_BSTNK
    IMPORTING
      OUTPUT        = LV_BSTNK.



    IF LS_ZDLVKORG-effect_date LE sy-datum.
       SELECT * FROM ZDRUG_VALIDITY INTO TABLE lt_drugvalid WHERE kunnr = vbak-kunnr.
         DESCRIBE TABLE LT_DRUGVALID LINES DATA(lv_lines).
         IF sy-subrc eq 0.
           lt_validto[] = lt_drugvalid[].
            delete lt_drugvalid WHERE valid_to lt sy-datum.
           IF LT_DRUGVALID IS NOT INITIAL.
           READ TABLE lt_drugvalid INTO ls_drugvalid INDEX 1.
         IF ( sy-datum > ls_drugvalid-valid_to  ).
         DATA(lv_msg) =  | Drug license expired for the Customer | && vbak-kunnr .
         CONCATENATE ls_drugvalid-valid_to+6(2) ls_drugvalid-valid_to+4(2) ls_drugvalid-valid_to+0(4)
         INTO DATA(LV_MSG1) SEPARATED BY '.'.
         LV_MSG1 = | On | && LV_MSG1.
         CONCATENATE LV_MSG lv_msg1 INTO LV_MSG.
         MESSAGE lv_msg TYPE 'E'.
         ENDIF.
         ELSE.
                SORT lt_validto ASCENDING by valid_to.
                READ TABLE lt_validto INTO DATA(ls_validto) INDEX lv_lines.
                 lv_validto = ls_validto-valid_to.
            lv_msg =  | Drug license expired for the Customer | && vbak-kunnr .
            CONCATENATE lv_validto+6(2) lv_validto+4(2) lv_validto+0(4)
         INTO LV_MSG1 SEPARATED BY '.'.
         LV_MSG1 = | On | && LV_MSG1.
         CONCATENATE LV_MSG lv_msg1 INTO LV_MSG.
            MESSAGE lv_msg TYPE 'E'.
              ENDIF.
         ENDIF.
         ENDIF.
    ENDIF.
  ENDIF.
****** End of Changes Pranesh  DR1K947499 *******
ENDENHANCEMENT.
