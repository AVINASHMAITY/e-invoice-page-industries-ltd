*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZEI_PAYEE.......................................*
DATA:  BEGIN OF STATUS_ZEI_PAYEE                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZEI_PAYEE                     .
CONTROLS: TCTRL_ZEI_PAYEE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZEI_PAYEE                     .
TABLES: ZEI_PAYEE                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
