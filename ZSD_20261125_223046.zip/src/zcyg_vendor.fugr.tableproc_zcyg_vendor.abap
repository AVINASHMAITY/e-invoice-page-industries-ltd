*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_VENDOR
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_VENDOR         .

  PERFORM TABLEPROC.

ENDFUNCTION.
