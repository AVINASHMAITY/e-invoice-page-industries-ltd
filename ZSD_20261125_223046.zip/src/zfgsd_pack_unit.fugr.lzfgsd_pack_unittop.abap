FUNCTION-POOL ZFGSD_PACK_UNIT            MESSAGE-ID SV.

* INCLUDE LZFGSD_PACK_UNITD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFGSD_PACK_UNITT00                     . "view rel. data dcl.
