"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_CUST_VALIDATE.
*
if sy-tcode eq 'VA01'.
*
*
data: v_bukrs_s type bukrs,
      w_bukrs_s type knb1-bukrs.
*
select single BUKRS
  from tvko
  into v_bukrs_s
 where vkorg eq vbak-vkorg.
*
if ( v_bukrs_s eq '5100' ) or
   ( v_bukrs_s eq '5200' ).
*
   select single bukrs
     from knb1
     into w_bukrs_s
    where kunnr eq vbak-kunnr
      and bukrs eq v_bukrs_s.
*
   if sy-subrc <> 0.
    MESSAGE e062(ZSD_MESSAGES) WITH vbak-kunnr v_bukrs_s.
   endif.
*


endif.
*
**********Added by Megha on 02.24.2025
*DATA : LS_DATA TYPE ZTABAP_TVARVC .
*   IF sy-ucomm EQ 'SICH'.
*SELECT SINGLE low FROM ZTABAP_TVARVC INTO ls_data WHERE OBJ_NAME = 'ZSD_COMMIT_DATE' and low = VBAK-VKORG.
* IF SY-SUBRC EQ 0.
*LOOP AT  XVBAP INTO DATA(WA_WVBAP).
*
*          IF WA_WVBAP-COMMIT_DATE IS INITIAL.
*            MESSAGE 'Please Enter Committed Date' TYPE 'E'.
*            ELSEIF WA_WVBAP-COMMIT_DATE LT VBAK-ERDAT.
*       MESSAGE 'Committed date is less than SO creation date' TYPE 'E'.
*          ENDIF.
*        ENDLOOP.
*ENDIF.
*ENDIF.
**********Added by Megha on 02.24.2025
endif.
*
ENDENHANCEMENT.
