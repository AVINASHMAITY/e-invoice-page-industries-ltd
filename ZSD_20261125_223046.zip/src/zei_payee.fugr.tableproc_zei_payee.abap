*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZEI_PAYEE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZEI_PAYEE           .

  PERFORM TABLEPROC.

ENDFUNCTION.
