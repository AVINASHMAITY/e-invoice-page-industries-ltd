/*
----------------------------------------------------------
Object Name           : ZV_MIS_CLIN
Author/Comapny Name   : Chandra Mohan/ITEANZ
Transport Request     : DR1K938213
Creation Date         : 18.01.2018
----------------------------------------------------------
Description : Clearance
----------------------------------------------------------
*/
@AbapCatalog.sqlViewName: 'ZSV_MIS_CLIN'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@ClientDependent: true
@EndUserText.label: 'MIS View for CLIN'
define view ZV_MIS_CLIN 
as select from /obiz/zbn_clnhdr[ doccat = 'CLIN' and refdoccat = 'NNDO' ] as _clin
left outer join lfa1 as _lfa1
    on _clin.transcode = _lfa1.lifnr
{
    _clin.docnr as docnr,
    _clin.docdate as docdate,
    _clin.refdocnr as refdocnr,
    _clin.refdocdt as refdocdt,
    _clin.chacode as chacode,
    _clin.transcode as transcode,
    _clin.insucode as insucode,
    _clin.ebeln as ebeln,
    _lfa1.name1 as tname
}   
