class ZCL_EI_AUTHENTICATION_PIPO_SYN definition
  public
  create public .

public section.

  interfaces ZII_EI_AUTHENTICATION_PIPO_SYN .
protected section.
private section.
ENDCLASS.



CLASS ZCL_EI_AUTHENTICATION_PIPO_SYN IMPLEMENTATION.


  method ZII_EI_AUTHENTICATION_PIPO_SYN~EI_AUTHENTICATION_PIPO_SYN_IN.
*** **** INSERT IMPLEMENTATION HERE **** ***
  endmethod.
ENDCLASS.
