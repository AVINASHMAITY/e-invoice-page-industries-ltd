FUNCTION-POOL ZEI_NEW_API                MESSAGE-ID SV.

* INCLUDE LZEI_NEW_APID...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZEI_NEW_APIT00                         . "view rel. data dcl.
