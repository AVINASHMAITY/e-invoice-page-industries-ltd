"Name: \PR:SAPMQEVA\FO:BESTANDSBUCHUNGEN_QALS\SE:BEGIN\EI
ENHANCEMENT 0 ZQM_SKP_PASS_QTY.

DATA : lt_qty_tabl TYPE TABLE OF zsd_skp_ud_qty,
       ls_qty      TYPE zsd_skp_ud_qty.

 IMPORT zsd_skp_ud_qty = lt_qty_tabl FROM MEMORY ID 'ZSKP_UD_QTY'.

IF lt_qty_tabl[] IS NOT INITIAL.
  LOOP AT lt_qty_tabl INTO ls_qty WHERE INSPLOT = QALS-PRUEFLOS.
    rqeva-vmenge01 = ls_qty-zappr_qty.
  ENDLOOP.
ENDIF.

 IMPORT zsd_skp_ud_smpl = lt_qty_tabl FROM MEMORY ID 'ZSKP_UD_SMPL'.
 IF lt_qty_tabl[] IS NOT INITIAL.
  LOOP AT lt_qty_tabl INTO ls_qty WHERE INSPLOT = QALS-PRUEFLOS.
    rqeva-vmenge03 = ls_qty-zsam_qty.
  ENDLOOP.
ENDIF.


ENDENHANCEMENT.
