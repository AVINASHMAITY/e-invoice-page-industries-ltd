FUNCTION-POOL ZCYG_SHIP_DETAIL           MESSAGE-ID SV.

* INCLUDE LZCYG_SHIP_DETAILD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_SHIP_DETAILT00                    . "view rel. data dcl.
