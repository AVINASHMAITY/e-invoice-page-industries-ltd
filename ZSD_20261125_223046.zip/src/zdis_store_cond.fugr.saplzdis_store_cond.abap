*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDIS_STORE_CONDTOP.               " Global Data
  INCLUDE LZDIS_STORE_CONDUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDIS_STORE_CONDF...               " Subroutines
* INCLUDE LZDIS_STORE_CONDO...               " PBO-Modules
* INCLUDE LZDIS_STORE_CONDI...               " PAI-Modules
* INCLUDE LZDIS_STORE_CONDE...               " Events
* INCLUDE LZDIS_STORE_CONDP...               " Local class implement.
* INCLUDE LZDIS_STORE_CONDT99.               " ABAP Unit tests
  INCLUDE LZDIS_STORE_CONDF00                     . " subprograms
  INCLUDE LZDIS_STORE_CONDI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
