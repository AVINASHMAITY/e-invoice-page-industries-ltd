*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCOMP_ADD.......................................*
DATA:  BEGIN OF STATUS_ZCOMP_ADD                     .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCOMP_ADD                     .
CONTROLS: TCTRL_ZCOMP_ADD
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCOMP_ADD                     .
TABLES: ZCOMP_ADD                      .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
