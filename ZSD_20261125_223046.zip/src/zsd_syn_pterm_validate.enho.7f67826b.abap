"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SYN_PTERM_VALIDATE.
****Developer: Purushotham (PricewaterhouseCoopers)
***Functional Consultant: Debashish (PricewaterhouseCoopers)
***Purpose: To validate payment terms for company code 5100 tcode MIRO
***Date: 28-July-2022
*&-------------------------------------------------------------------*
* Author/Company Name : PwC                         *
* Transport Request   :
* Creation Date       : 10.08.2022                                   *
*&--------------------------------------------------------------------*
data: lv_bukrs                type bukrs,
      lv_vbtyp                type vbtyp,
      ls_tvarvc               type tvarvc,
      ls_tcode_validate       type ZFI_SY_PTERM_TCO,
      ls_pterm_validate       type ZFI_SYN_PTERMS,
      ls_xvbkd                type vbkd.

move xvbak-bukrs_vf to lv_bukrs.
move xvbak-vbtyp to lv_vbtyp.
IF sy-tcode eq 'VA01' OR sy-tcode eq 'VA02'.
    select single * from tvarvc
                  into ls_tvarvc
                  where name = 'Z_SYN_COCD' and
                        sign = 'I' and
                        opti = 'EQ'.

IF lv_bukrs eq ls_tvarvc-low and lv_vbtyp eq 'C'.

  select single  * from ZFI_SY_PTERM_TCO
                   into ls_tcode_validate
                   where tcode = sy-tcode and
                         bukrs = ls_tvarvc-low.
    IF ls_tcode_validate is not INITIAL.
      loop at xvbkd into ls_xvbkd where vbeln = xvbak-vbeln .
        select single * from ZFI_SYN_PTERMS
                 into  ls_pterm_validate
                 where bukrs = ls_tcode_validate-bukrs and
                       zterm = ls_xvbkd-zterm.
        IF ls_pterm_validate is INITIAL.
          message 'Incorrect payment terms used' type 'E'.
*          leave LIST-PROCESSING.
        ENDIF.
      ENDLOOP.
    ENDIF.
ENDIF.
ENDIF.

ENDENHANCEMENT.
