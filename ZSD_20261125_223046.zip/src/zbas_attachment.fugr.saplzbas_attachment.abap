*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBAS_ATTACHMENTTOP.               " Global Data
  INCLUDE LZBAS_ATTACHMENTUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBAS_ATTACHMENTF...               " Subroutines
* INCLUDE LZBAS_ATTACHMENTO...               " PBO-Modules
* INCLUDE LZBAS_ATTACHMENTI...               " PAI-Modules
* INCLUDE LZBAS_ATTACHMENTE...               " Events
* INCLUDE LZBAS_ATTACHMENTP...               " Local class implement.
* INCLUDE LZBAS_ATTACHMENTT99.               " ABAP Unit tests
  INCLUDE LZBAS_ATTACHMENTF00                     . " subprograms
  INCLUDE LZBAS_ATTACHMENTI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
