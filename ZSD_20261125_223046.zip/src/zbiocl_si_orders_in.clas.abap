class ZBIOCL_SI_ORDERS_IN definition
  public
  create public .

public section.

  interfaces ZBIOII_SI_ORDERS_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOCL_SI_ORDERS_IN IMPLEMENTATION.


  METHOD zbioii_si_orders_in~si_orders_in.

************************ Types Declaration ************************
    TYPES : BEGIN OF ty_batch,
              split          TYPE char1,
              pos_no         TYPE posnr_va,
              matnr          TYPE matnr,
              batch_name     TYPE lichn,
              bl_batch       TYPE charg_d,
              batch_quantity TYPE kwmeng,
              expiry_date    TYPE dats,
            END OF ty_batch.
************************ Data Declaration *************************
    DATA : ls_header         TYPE bapisdhead1,
           ls_headerx        TYPE bapisdhead1x,
           ls_crheader       TYPE bapisdh1,
           ls_crheaderx      TYPE bapisdh1x,
           lt_return         TYPE TABLE OF bapiret2,
           ls_return         TYPE bapiret2,
           lt_schedules_inx  TYPE TABLE OF bapischedulex,
           ls_schedules_inx  TYPE bapischedulex,
           lt_schedules_in   TYPE TABLE OF bapischedule,
           ls_schedules_in   TYPE bapischedule,
           lt_conditions_in  TYPE TABLE OF bapicondition,
           ls_conditions_in  TYPE bapicondition,
           lt_item           TYPE TABLE OF bapisditem,
           ls_item           TYPE bapisditem,
           lt_itemx          TYPE TABLE OF bapisditemx,
           ls_itemx          TYPE bapisditemx,
           lt_partner        TYPE TABLE OF bapipartnr,
           ls_partner        TYPE bapipartnr,
           lt_return1        TYPE TABLE OF bapiret1,
           lt_success        TYPE TABLE OF bapivbrksuccess,
           lt_qty_tabl       TYPE TABLE OF zsd_skp_ud_qty,
           ls_qty            TYPE zsd_skp_ud_qty,
           lt_system         TYPE TABLE OF bapi2045ss,
           lt_user           TYPE TABLE OF bapi2045us,
           ls_ud_data        TYPE bapi2045ud,
           ls_ud_return_data TYPE bapi2045ud_return,
           ls_stock_data     TYPE bapi2045d_il2,
           ls_return1        TYPE bapireturn1.

    DATA : lt_orders         TYPE TABLE OF bapidlvreftosalesorder,
           ls_orders         TYPE bapidlvreftosalesorder,
           ls_header_data    TYPE bapiobdlvhdrchg,
           ls_header_control TYPE bapiobdlvhdrctrlchg,
           ls_header_tech    TYPE bapidlvcontrol,
           lt_item_data      TYPE TABLE OF bapiobdlvitemchg,
           lt_item_control   TYPE TABLE OF bapiobdlvitemctrlchg,
           lt_item_data_spl  TYPE TABLE OF /spe/bapiobdlvitemchg,
           ls_item_data_spl  TYPE /spe/bapiobdlvitemchg,
           ls_item_data      TYPE bapiobdlvitemchg,
           ls_item_control   TYPE bapiobdlvitemctrlchg,
           lt_request        TYPE STANDARD TABLE OF bapideliciousrequest,
           ls_request        TYPE bapideliciousrequest.

    DATA: lt_order      TYPE TABLE OF zbiosi_orders_in_order_confirm,
          lt_sheader    TYPE zbiosi_orders_in_order_hea_tab,
          lt_sitem      TYPE zbiosi_orders_in_order_lin_tab,
          wa_sheader    TYPE zbiosi_orders_in_order_header,
          lt_sitem1     TYPE TABLE OF zbiosi_orders_in_order_line,
          wa_sitem      TYPE zbiosi_orders_in_order_lines,
          lt_sequence   TYPE TABLE OF zbiosi_orders_in_batches,
          wa_sequence   TYPE zbiosi_orders_in_batches,
          lt_seq1       TYPE TABLE OF zbiosi_orders_in_sequence,
          wa_seq1       TYPE zbiosi_orders_in_sequence,
          lt_batch1     TYPE TABLE OF zbiosi_orders_in_batch,
          wa_batch1     TYPE zbiosi_orders_in_batch,
          lt_batch      TYPE TABLE OF ty_batch,
          lt_batch_splt TYPE TABLE OF ty_batch,
          wa_batch      TYPE ty_batch,
          wa_batch_splt TYPE ty_batch,
          lt_line_dis   TYPE TABLE OF zbiosi_orders_in_line_discount,
          wa_line_dis   TYPE zbiosi_orders_in_line_discount,
          lt_discount   TYPE TABLE OF zbiosi_orders_in_line1,
          ls_flow       TYPE zskp_sales_flow,
          ls_vbkok      TYPE vbkok,
          lt_vbpok      TYPE TABLE OF vbpok,
          wa_vbpok      TYPE vbpok,
          ls_prot       TYPE prott,
          lt_prot       TYPE TABLE OF prott,
          lt_billing    TYPE TABLE OF bapivbrk,
          ls_billing    TYPE bapivbrk.

    DATA : lv_posnr     TYPE posnr,
           lv_posnr1    TYPE posnr,
           lv_shline    TYPE etenr,
           lv_vbeln     TYPE vbak-vbeln,
           lv_del       TYPE vbeln_vl,
           lv_bismt     TYPE bismt,
           lv_altkn     TYPE altkn,
           lv_percntg   TYPE string,
           lv_decimal   TYPE char1,
           lv_text      TYPE char50,
           lv_text1     TYPE char4,
           lv_crdt_memo TYPE bapivbeln-vbeln,
           lv_check     TYPE c,
           lv_invoice   TYPE vbeln_vf,
           lv_status    TYPE char2,
           lv_line      TYPE bsvx-sttxt,
           lv_insp_lot  TYPE qplos,
           lv_insp      TYPE bapi2045ud-insplot,
           lv_quant     TYPE qvmenge01,
           lv_splt_item TYPE posnr_vl VALUE '900000',
           lv_ref       TYPE xblnr_v1.

    CONSTANTS : c_e       TYPE char1  VALUE 'E',
                c_a       TYPE char1  VALUE 'A',
                c_s       TYPE char1  VALUE 'S',
                c_w       TYPE char1  VALUE 'W',
                c_j       TYPE char1  VALUE 'J',
                c_k       TYPE char1  VALUE 'K',
                c_x       TYPE c VALUE 'X',
                c_u       TYPE c VALUE 'U',
                c_space   TYPE c VALUE ' ',
                c_10      TYPE char2 VALUE '10',
                c_0       TYPE c VALUE '0',
                c_hipos   TYPE hipos VALUE '000000',
                c_success TYPE zskp_doc_typ VALUE 'Success',
                c_error   TYPE zskp_doc_typ VALUE 'Error'.

*************************** End of Decleration ***********************

    CLEAR: lv_posnr,lv_shline,lv_vbeln,lv_del,lv_invoice,wa_batch,lv_status,lt_qty_tabl[],ls_qty,
           lt_order[],lt_sheader[],lt_sitem[],wa_sheader,lt_sitem1[],wa_batch_splt,
           wa_sitem,lt_sequence[],lt_batch[],lt_batch_splt[],ls_flow,lv_check,lv_posnr1.

    lt_order  = input-order_confirmation.

    IF lt_order[] IS NOT INITIAL.
*$$ Pass SO Header info & SO Item info to "lt_sheader" to "lt_sitem"
      LOOP AT lt_order ASSIGNING FIELD-SYMBOL(<fs_order>).
        IF <fs_order> IS ASSIGNED.
          lt_sheader = <fs_order>-order_header.
          lt_sitem = <fs_order>-order_lines.
          EXIT.
        ENDIF.
      ENDLOOP.

*$$ --> Update Header info for SO BAPI
      IF lt_sheader[] IS NOT INITIAL.
        CLEAR : ls_header, ls_headerx.

        wa_sheader = lt_sheader[ 1 ].
        SHIFT wa_sheader-order_number LEFT DELETING LEADING '0'.
* Search BL Sales document type based on SKP Order type
        SELECT SINGLE * FROM zskp_sales_type INTO @DATA(ls_sales_typ) WHERE zskp_ord_typ = @wa_sheader-order_type.
        IF sy-subrc = 0.
          SELECT SINGLE vbeln FROM vbak INTO @DATA(lv_so) WHERE bukrs_vf = @ls_sales_typ-bukrs AND
                                                                auart = @ls_sales_typ-zbl_odr_typ AND
                                                                bstnk = @wa_sheader-order_number.
          IF sy-subrc = 0.
            ls_flow-zdate = sy-datum.
            ls_flow-ztime = sy-uzeit.
            ls_flow-zdoc_type = c_error.
            ls_flow-msg = | Duplicate SO - | && c_space && wa_sheader-order_number.
            ls_flow-zfile_name = wa_sheader-file_name.
            INSERT zskp_sales_flow FROM ls_flow.
            COMMIT WORK.
            CLEAR : ls_flow.
            lv_check = c_x.
          ENDIF.
        ENDIF.
      ENDIF.

* Order Type
      ls_header-doc_type = ls_sales_typ-zbl_odr_typ.
      CONDENSE ls_header-doc_type.
      ls_headerx-doc_type = c_x.

* Sales organization
      ls_header-sales_org = ls_sales_typ-vkorg.
      ls_headerx-sales_org = c_x.

* Distribution channel
      ls_header-distr_chan  = ls_sales_typ-vtweg.
      ls_headerx-distr_chan = c_x.

* Division
      ls_header-division = ls_sales_typ-spart.
      ls_headerx-division = c_x.

* Pass SKP Order Number as reference
      ls_header-purch_no_c = wa_sheader-order_number.
      ls_headerx-purch_no_c = c_x.

* Payment Terms
      SELECT SINGLE zterm_bl FROM zskp_paymnt_term INTO @DATA(lv_payterm)
        WHERE spras = @sy-langu AND zterm_skp = @wa_sheader-payment_term_code.
      IF sy-subrc = 0.
        ls_header-pmnttrms = lv_payterm.
        ls_headerx-pmnttrms = c_x.
      ELSE.
        ls_flow-zdate = sy-datum.
        ls_flow-ztime = sy-uzeit.
        ls_flow-zdoc_type = c_error.
        ls_flow-msg = | No BL Payment Term found for SKP Payment Term - | && c_space && wa_sheader-payment_term_code .
        ls_flow-zfile_name = wa_sheader-file_name.
        INSERT zskp_sales_flow FROM ls_flow.
        COMMIT WORK.
        CLEAR : ls_flow.
        lv_check = c_x.
      ENDIF.

      ls_header-purch_date = wa_sheader-booking_date.
      ls_headerx-purch_date = c_x.

      ls_header-doc_date = wa_sheader-shipping_date.
      ls_headerx-doc_date = c_x.

      ls_header-req_date_h = wa_sheader-shipping_date.
      ls_headerx-req_date_h = c_x.

      ls_header-price_date = wa_sheader-shipping_date.
      ls_headerx-price_date = c_x.

      ls_header-po_dat_s = wa_sheader-shipping_date.
      ls_headerx-po_dat_s = c_x.

      ls_header-bill_date = wa_sheader-shipping_date.
      ls_headerx-bill_date = c_x.

      ls_header-ref_doc_l = wa_sheader-order_number.
      ls_headerx-ref_doc_l = c_x.

      ls_headerx-updateflag = 'I'.

**- Fetch corresponding BL Customer
      SHIFT wa_sheader-customer_number LEFT DELETING LEADING '0'.
      lv_altkn = wa_sheader-customer_number.
      CONDENSE lv_altkn.
* Fetch Ship to
      SELECT SINGLE kunnr FROM knb1 INTO @DATA(lv_shipto) WHERE bukrs = @ls_sales_typ-bukrs AND altkn = @lv_altkn.
      IF sy-subrc = 0.
        lv_shipto = |{ lv_shipto ALPHA = IN }|.
* Sold to
        SELECT SINGLE kunn2 FROM knvp INTO @DATA(lv_soldto) WHERE kunnr = @lv_shipto AND
                                                                  parvw = 'AG' AND
                                                                  vkorg = @ls_sales_typ-vkorg AND
                                                                  vtweg = @ls_sales_typ-vtweg AND
                                                                  spart = @ls_sales_typ-spart.
        IF sy-subrc = 0.
          lv_soldto = |{ lv_soldto ALPHA = IN }|.
          ls_partner-partn_role = 'AG'.
          ls_partner-partn_numb = lv_soldto.
          APPEND ls_partner TO lt_partner.
          COMMIT WORK.
          CLEAR ls_partner.
* Validation in Incoterms
          SELECT SINGLE inco1 FROM knvv INTO @DATA(lv_incotrms) WHERE kunnr = @lv_soldto AND
                                                                      vkorg = @ls_sales_typ-vkorg AND
                                                                      vtweg = @ls_sales_typ-vtweg AND
                                                                      spart = @ls_sales_typ-spart.
          IF lv_incotrms = c_space.
            ls_flow-zdate = sy-datum.
            ls_flow-ztime = sy-uzeit.
            ls_flow-zdoc_type = c_error.
            ls_flow-msg = | No Incoterms maintained for customer - | && c_space && lv_soldto .
            ls_flow-zfile_name = wa_sheader-file_name.
            INSERT zskp_sales_flow FROM ls_flow.
            COMMIT WORK.
            CLEAR : ls_flow.
          ENDIF.
        ELSE.
          ls_flow-zdate = sy-datum.
          ls_flow-ztime = sy-uzeit.
          ls_flow-zdoc_type = c_error.
          ls_flow-msg = | No Sold to Party for corresponding Ship to - | && c_space && lv_shipto .
          ls_flow-zfile_name = wa_sheader-file_name.
          INSERT zskp_sales_flow FROM ls_flow.
          COMMIT WORK.
          CLEAR : ls_flow.
        ENDIF.

* Ship to
        ls_partner-partn_role = 'WE'.
        ls_partner-partn_numb = lv_shipto.
        APPEND ls_partner TO lt_partner.
        CLEAR ls_partner.
      ELSE.
        ls_flow-zdate = sy-datum.
        ls_flow-ztime = sy-uzeit.
        ls_flow-zdoc_type = c_error.
        ls_flow-msg = | No BL Customer found for SKP Customer - | && c_space && lv_altkn .
        ls_flow-zfile_name = wa_sheader-file_name.
        INSERT zskp_sales_flow FROM ls_flow.
        COMMIT WORK.
        CLEAR : ls_flow.
        lv_check = c_x.
      ENDIF.
*$$ <-- End of Update Header info

*$$ --> Update Item info for SO BAPI
      IF lt_sitem[] IS NOT INITIAL.

        wa_sitem = lt_sitem[ 1 ].
        lt_sitem1[] = wa_sitem-order_line.

        SORT lt_sitem1 BY pos_no ASCENDING .

        LOOP AT lt_sitem1 INTO DATA(ls_sitem).
          lv_posnr = lv_posnr + 10.
          lv_shline = lv_shline + 1.

          ls_itemx-updateflag = 'I'.

* Line item number.
          ls_item-itm_number = lv_posnr.
          ls_itemx-itm_number = c_x.

* Status
          lv_status = ls_sitem-status.
* Material
          lv_bismt = ls_sitem-material.
          TRANSLATE lv_bismt TO UPPER CASE.
          SELECT SINGLE matnr FROM mara INTO @DATA(lv_matnr) WHERE bismt = @lv_bismt.
          IF sy-subrc = 0.
            lv_matnr = |{ lv_matnr ALPHA = IN }|.
            ls_item-material = lv_matnr.
            ls_itemx-material = c_x.
          ELSE.
            ls_flow-zdate = sy-datum.
            ls_flow-ztime = sy-uzeit.
            ls_flow-zdoc_type = c_error.
            ls_flow-msg =  | No BL Material found for SKP material - | && c_space && lv_bismt.
            ls_flow-zfile_name = wa_sheader-file_name.
            INSERT zskp_sales_flow FROM ls_flow.
            COMMIT WORK.
            CLEAR : ls_flow.
            lv_check = c_x.
          ENDIF.
* Plant
          ls_item-plant    = ls_sales_typ-werks.
          ls_itemx-plant   = c_x.

* Quantity
          ls_item-target_qty = ls_sitem-quantity.
          ls_itemx-target_qty = c_x.

*UOM
          SELECT SINGLE meins FROM mara INTO @DATA(lv_uom) WHERE matnr = @lv_matnr.
          ls_item-target_qu = lv_uom.
          ls_itemx-target_qu = c_x.

*Billing date for billing index and printout
          ls_item-bill_date = wa_sheader-booking_date.
          ls_itemx-bill_date = c_x.

*Customer purchase order date
          ls_item-purch_date = wa_sheader-booking_date.
          ls_itemx-purch_date = c_x.

*Ship-to party's PO date
          ls_item-po_dat_s = wa_sheader-booking_date.
          ls_itemx-po_dat_s = c_x.

*Date for pricing and exchange rate
          ls_item-price_date = wa_sheader-booking_date.
          ls_itemx-price_date = c_x.

          APPEND ls_item TO lt_item.
          APPEND ls_itemx TO lt_itemx.
          CLEAR : ls_item, ls_itemx.

*   Fill schedule lines
          ls_schedules_in-itm_number = lv_posnr.
          ls_schedules_in-sched_line = lv_shline.
          ls_schedules_in-req_qty    = ls_sitem-quantity.
          ls_schedules_in-req_date   = wa_sheader-booking_date.
          APPEND ls_schedules_in TO lt_schedules_in.
          CLEAR ls_schedules_in.

*   Fill schedule line flags
          ls_schedules_inx-itm_number  = lv_posnr.
          ls_schedules_inx-sched_line  = lv_shline.
          ls_schedules_inx-updateflag  = c_x.
          ls_schedules_inx-req_qty     = c_x.
          ls_schedules_inx-req_date    = c_x.
          APPEND ls_schedules_inx TO lt_schedules_inx.
          CLEAR ls_schedules_inx.

** Fill Conditions
          ls_conditions_in-itm_number = lv_posnr.
          ls_conditions_in-cond_st_no = '010'.
          ls_conditions_in-cond_type = 'ZPRI'.
          ls_conditions_in-cond_value = ls_sitem-item_price / 10 .
          ls_conditions_in-conpricdat = wa_sheader-booking_date.
          APPEND ls_conditions_in TO lt_conditions_in.
          CLEAR : ls_conditions_in.

** Fill Discount
          lt_line_dis = ls_sitem-line_discounts.
          wa_line_dis = lt_line_dis[ 1 ].

          lt_discount = wa_line_dis-line.

          LOOP AT lt_discount INTO DATA(ls_discount).
            IF ls_discount-discount_number = '1' .
              ls_conditions_in-itm_number = lv_posnr.
              ls_conditions_in-cond_st_no = '033'.
              ls_conditions_in-cond_type = 'ZBDD'.
              ls_conditions_in-cond_value = ls_discount-net_value / 10 .
              ls_conditions_in-conpricdat = wa_sheader-booking_date.
              APPEND ls_conditions_in TO lt_conditions_in.
              CLEAR : ls_conditions_in.
            ELSEIF ls_discount-discount_number = '2' .
              SPLIT ls_discount-name AT '%' INTO lv_text1 lv_text.
              SPLIT lv_text1 AT ',' INTO lv_percntg lv_decimal.
              CONDENSE lv_percntg.

              ls_conditions_in-itm_number = lv_posnr.
              ls_conditions_in-cond_st_no = '037'.
              ls_conditions_in-cond_type = 'ZBD1'.
              ls_conditions_in-cond_value = lv_percntg.
              ls_conditions_in-conpricdat = wa_sheader-booking_date.
              APPEND ls_conditions_in TO lt_conditions_in.
              CLEAR : ls_conditions_in, lv_percntg.
            ELSEIF ls_discount-discount_number = '3' .
              ls_conditions_in-itm_number = lv_posnr.
              ls_conditions_in-cond_st_no = '039'.
              ls_conditions_in-cond_type = 'ZKFS'.
              ls_conditions_in-cond_value = ls_discount-net_value / 10 .
              ls_conditions_in-conpricdat = wa_sheader-booking_date.
              APPEND ls_conditions_in TO lt_conditions_in.
              CLEAR : ls_conditions_in.
            ENDIF.
          ENDLOOP.

** Fill Batch.
          lt_sequence = ls_sitem-batches.
          wa_sequence = lt_sequence[ 1 ].

          lt_seq1 = wa_sequence-sequence.

          LOOP AT lt_seq1 INTO wa_seq1.
            wa_batch1 = wa_seq1-batch.
            wa_batch-split = space.
            wa_batch-pos_no = lv_posnr.
            wa_batch-matnr = lv_matnr.
            wa_batch-batch_name = wa_batch1-batch_name.
            wa_batch-batch_quantity = wa_batch1-batch_quantity.
            wa_batch-expiry_date = wa_batch1-expiry_date.
            APPEND wa_batch TO lt_batch.

* Pass Batch split for same item into 'LT_BATCH_SPLT'.
            IF lv_posnr1 = lv_posnr.
              wa_batch_splt = wa_batch.
              wa_batch_splt-split = c_x.
              APPEND wa_batch_splt TO lt_batch_splt.
            ENDIF.

            lv_posnr1 = wa_batch-pos_no.

          ENDLOOP.
        ENDLOOP.
      ENDIF.

** SO/Delivery/Invoice will only be created for SKP order Type 1 & 2.
      IF ( wa_sheader-order_type = '1' OR
           wa_sheader-order_type = '2' ).
        IF lv_status = c_0 .
**- BAPI to create the sales order.
          IF lv_so IS INITIAL.

            CALL FUNCTION 'BAPI_SALESDOCU_CREATEFROMDATA1'
              EXPORTING
                sales_header_in     = ls_header
                sales_header_inx    = ls_headerx
              IMPORTING
                salesdocument_ex    = lv_vbeln
              TABLES
                return              = lt_return
                sales_items_in      = lt_item
                sales_items_inx     = lt_itemx
                sales_schedules_in  = lt_schedules_in
                sales_schedules_inx = lt_schedules_inx
                sales_conditions_in = lt_conditions_in
                sales_partners      = lt_partner.

            READ TABLE lt_return INTO ls_return WITH KEY type = c_e.
            IF sy-subrc = 0.
              LOOP AT lt_return INTO ls_return WHERE type = c_e.
                ls_flow-zdate = sy-datum.
                ls_flow-ztime = sy-uzeit.
                ls_flow-zdoc_type = c_error.
                ls_flow-msg = ls_return-message.
                ls_flow-zfile_name = wa_sheader-file_name.
                INSERT zskp_sales_flow FROM ls_flow.
                COMMIT WORK.
                CLEAR : ls_flow.
                lv_check = c_x.
              ENDLOOP.

            ELSE.
              CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                EXPORTING
                  wait = c_x.

              ls_flow-zdate = sy-datum.
              ls_flow-ztime = sy-uzeit.
              ls_flow-zdoc_type = c_success.
              ls_flow-zdocument = lv_vbeln.
              ls_flow-msg = | Sale Order created successfully for corr. SKP Order - | && c_space && wa_sheader-order_number.
              ls_flow-zfile_name = wa_sheader-file_name.
              INSERT zskp_sales_flow FROM ls_flow.
              COMMIT WORK.
              CLEAR : ls_flow.
            ENDIF.
          ELSE.
            lv_vbeln = lv_so.
            lv_vbeln = |{ lv_vbeln ALPHA = IN }|.
          ENDIF.

**- BAPI to Create Delivery
          IF lv_vbeln IS NOT INITIAL.

            SELECT SINGLE vbeln FROM vbfa INTO @DATA(lv_delivery) WHERE vbelv = @lv_vbeln AND vbtyp_n = 'J'.
            IF sy-subrc = 0.
              lv_del = lv_delivery.
              lv_del = |{ lv_del ALPHA = IN } |.
            ELSE.
              SELECT vbeln,posnr,matnr,vrkme,meins,kwmeng FROM vbap INTO TABLE @DATA(lt_vbap) WHERE vbeln = @lv_vbeln.
              REFRESH : lt_orders.
              ls_orders-ref_doc = lv_vbeln.
              APPEND ls_orders TO lt_orders.

              REFRESH : lt_return.

              CALL FUNCTION 'BAPI_OUTB_DELIVERY_CREATE_SLS'
                TABLES
                  sales_order_items = lt_orders
                  return            = lt_return.

              READ TABLE lt_return INTO ls_return WITH KEY type   = c_s
                                                           id     = 'VL'
                                                           number = '311'.
              lv_del = ls_return-message_v1.
              lv_del = |{ lv_del ALPHA = IN } |.

              CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                EXPORTING
                  wait = c_x.
            ENDIF.

            IF lv_del IS NOT INITIAL.
              SELECT SINGLE vbeln FROM vbfa INTO @DATA(lv_pgi) WHERE vbelv = @lv_del AND
                                                                    ( vbtyp_n = 'Q' OR
                                                                      vbtyp_n = 'R' ).
              IF sy-subrc = 0.
                ""PGI will not be done for existing Delivery
              ELSE.
**- Create PGI with Batch Split
** Add Batch split for corresponding Item
                SELECT vbeln,posnr,matnr,charg,lfimg,meins FROM lips INTO TABLE @DATA(lt_lips) WHERE vbeln = @lv_del.
                ls_header_data-deliv_numb    = lv_del.
                ls_header_control-deliv_numb = lv_del.
                ls_header_control-route_flg = abap_true.

                IF lt_batch_splt[] IS NOT INITIAL.
                  ls_header_tech-upd_ind = c_u.
                ELSE.
                  ls_header_tech-upd_ind = c_x.
                ENDIF.

**- Fetch Correspoding BL Batch

                SELECT matnr,charg,licha FROM mch1
                  INTO TABLE @DATA(lt_mch1)
                  FOR ALL ENTRIES IN @lt_batch
                  WHERE matnr = @lt_batch-matnr AND
                        licha = @lt_batch-batch_name.
                IF sy-subrc = 0.
                  SELECT matnr,werks,lgort,charg,clabs FROM mchb
                    INTO TABLE @DATA(lt_mchb)
                    FOR ALL ENTRIES IN @lt_mch1
                    WHERE matnr = @lt_mch1-matnr AND
                          werks = @ls_sales_typ-werks AND
                          lgort = @ls_sales_typ-lgort AND
                          charg = @lt_mch1-charg.
                  IF sy-subrc = 0.
                    SORT lt_mchb BY clabs ASCENDING.
                    DELETE lt_mchb WHERE clabs = '0.000'.
                    SORT lt_mchb BY matnr ASCENDING.

* Update Corresponding BL batch into 'LT_BATCH'
                    LOOP AT lt_batch ASSIGNING FIELD-SYMBOL(<fs_batch>).
                      IF <fs_batch> IS ASSIGNED.
**                        <fs_batch>-bl_batch = VALUE #( lt_mch1[ matnr = <fs_batch>-matnr
**                                                                licha = <fs_batch>-batch_name ]-charg OPTIONAL ).
                        LOOP AT lt_mch1 INTO DATA(ls_mch1) WHERE matnr = <fs_batch>-matnr AND
                                                                 licha = <fs_batch>-batch_name.
                          IF ls_mch1 IS NOT INITIAL.
**                            <fs_batch>-bl_batch = VALUE #( lt_mchb[ charg = ls_mch1-charg ]-charg OPTIONAL ).

                            "">>> Begin of TR - DR1K991486 - SKP Batch Sorting issue
                            DATA(lv_bl_batch) = VALUE #( lt_mchb[ charg = ls_mch1-charg ]-charg OPTIONAL ).
                            IF lv_bl_batch IS NOT INITIAL.
                              <fs_batch>-bl_batch = lv_bl_batch.
                              CLEAR : lv_bl_batch.
                            ENDIF.
                            "" <<< Begin of TR - DR1K991486 - SKP Batch Sorting issue
                          ENDIF.
                        ENDLOOP.

                        <fs_batch>-split = VALUE #( lt_batch_splt[ pos_no = <fs_batch>-pos_no ]-split OPTIONAL ).
*                      MODIFY lt_batch FROM ls_batch TRANSPORTING bl_batch split.
                      ENDIF.
                    ENDLOOP.
                    UNASSIGN <fs_batch>.

*~ Batch Split for same item
                    SORT lt_batch_splt BY pos_no ASCENDING.
                    LOOP AT lt_batch INTO wa_batch.
                      DATA(l_posnr1) = wa_batch-pos_no.
                      l_posnr1 = |{ l_posnr1 ALPHA = IN }|.
                      ls_item_data-deliv_numb = lv_del.
                      ls_item_data-deliv_item = l_posnr1.

**                    ls_item_data-material = VALUE #( lt_vbap[ posnr = l_posnr1 ]-matnr OPTIONAL ).
                      ls_item_data-material = wa_batch-matnr.

                      SELECT SINGLE meins FROM mara INTO @DATA(l_meins) WHERE matnr = @ls_item_data-material.
                      IF sy-subrc = 0.
                        SELECT SINGLE isocode FROM t006 INTO @DATA(l_isocode) WHERE msehi = @l_meins.
                        IF sy-subrc = 0.
                          ls_item_data-sales_unit_iso = l_isocode.
                        ENDIF.
                      ENDIF.

*~ Normal Item ~ No Batch Split
                      IF wa_batch-split = space.
                        ls_item_data-hieraritem = l_posnr1.

                        ls_item_data-fact_unit_nom   = 1. "obligatory
                        ls_item_data-fact_unit_denom = 1. "obligatory
                        ls_item_data-dlv_qty        = wa_batch-batch_quantity.
                        ls_item_data-dlv_qty_imunit = wa_batch-batch_quantity.
                        ls_item_data-usehieritm = c_space.

*                        ls_item_data-batch = VALUE #( lt_mchb[ matnr = ls_item_data-material ]-charg OPTIONAL ).
** Change logic to pass same batch number from MCH1
                        ls_item_data-batch = wa_batch-bl_batch.

                        ls_item_control-deliv_numb = lv_del.
                        ls_item_control-deliv_item = l_posnr1.
                        ls_item_control-chg_delqty = abap_true.

                        ls_item_data_spl-deliv_numb = lv_del.
                        ls_item_data_spl-deliv_item = l_posnr1.
                        ls_item_data_spl-pick_denial = c_x.
                        ls_item_data_spl-stge_loc = ls_sales_typ-lgort.

                        APPEND : ls_item_data TO lt_item_data,
                                 ls_item_control TO lt_item_control,
                                 ls_item_data_spl TO lt_item_data_spl.
                      ELSE.
*~ Item with Batch Split
                        DATA(lv_main_item) = VALUE #( lt_batch_splt[ pos_no = wa_batch-pos_no ]-pos_no OPTIONAL ).
                        IF  lv_main_item EQ wa_batch-pos_no.

                          ls_item_data-hieraritem = c_hipos.
                          ls_item_data-dlv_qty = c_space.
                          ls_item_data-dlv_qty_imunit = c_space.
                          ls_item_data-batch = c_space.

                          ls_item_control-deliv_numb = lv_del.
                          ls_item_control-deliv_item = l_posnr1.
                          ls_item_control-chg_delqty = abap_true.

                          ls_item_data_spl-deliv_numb = lv_del.
                          ls_item_data_spl-deliv_item = l_posnr1.
                          ls_item_data_spl-pick_denial = c_x.
                          ls_item_data_spl-stge_loc = ls_sales_typ-lgort.

                          APPEND : ls_item_data TO lt_item_data,
                                   ls_item_control TO lt_item_control,
                                   ls_item_data_spl TO lt_item_data_spl.

                          DELETE lt_batch_splt WHERE pos_no = lv_main_item.
                        ENDIF.

                        lv_splt_item = lv_splt_item + 1.
                        lv_splt_item = |{ lv_splt_item ALPHA = IN }|.

                        ls_item_data-deliv_item = lv_splt_item.
                        ls_item_data-hieraritem = wa_batch-pos_no.
                        ls_item_data-batch = wa_batch-bl_batch.
                        ls_item_data-usehieritm = 1. "Obligatory for Btach Split
                        ls_item_data-fact_unit_nom   = 1. "obligatory
                        ls_item_data-fact_unit_denom = 1. "obligatory
                        ls_item_data-dlv_qty        = wa_batch-batch_quantity.
                        ls_item_data-dlv_qty_imunit = wa_batch-batch_quantity.

                        ls_item_control-deliv_numb = lv_del.
                        ls_item_control-deliv_item = lv_splt_item.
                        ls_item_control-chg_delqty = abap_true.

                        ls_item_data_spl-deliv_numb = lv_del.
                        ls_item_data_spl-deliv_item = lv_splt_item.
                        ls_item_data_spl-pick_denial = c_x.
                        ls_item_data_spl-stge_loc = ls_sales_typ-lgort.

                        APPEND : ls_item_data TO lt_item_data,
                                 ls_item_control TO lt_item_control,
                                 ls_item_data_spl TO lt_item_data_spl.
                      ENDIF.
                    ENDLOOP.
                    CLEAR: lv_splt_item.
                  ENDIF.
                ENDIF.

**- Update Pick & Pack
**- Below Bapi is used to update Batch & Storage Loaction in Picking Tab
                CLEAR : lt_return[].
                CALL FUNCTION 'BAPI_OUTB_DELIVERY_CHANGE'
                  EXPORTING
                    header_data    = ls_header_data
                    header_control = ls_header_control
                    delivery       = lv_del
                    techn_control  = ls_header_tech
                  TABLES
                    item_data      = lt_item_data[]
                    item_control   = lt_item_control[]
                    return         = lt_return[]
                    item_data_spl  = lt_item_data_spl[].
                IF line_exists( lt_return[ type = c_e ] ).
                  ROLLBACK WORK.
                  ls_flow-zdate = sy-datum.
                  ls_flow-ztime = sy-uzeit.
                  ls_flow-zdoc_type = c_error.
                  ls_flow-msg = | Error in update Batch in Delivery - | && c_space && lv_del && |.| .
                  ls_flow-zfile_name = wa_sheader-file_name.
                  INSERT zskp_sales_flow FROM ls_flow.
                  COMMIT WORK.
                  CLEAR : ls_flow.
                  lv_check = c_x.
                ELSE.
                  COMMIT WORK AND WAIT.
                  ls_flow-zdate = sy-datum.
                  ls_flow-ztime = sy-uzeit.
                  ls_flow-zdoc_type = c_success.
                  ls_flow-zdocument = lv_del.
                  ls_flow-msg = | Delivery has been created. |.
                  ls_flow-zfile_name = wa_sheader-file_name.
                  INSERT zskp_sales_flow FROM ls_flow.
                  COMMIT WORK.
                  CLEAR : ls_flow.
                  lv_check = c_x.

**- post goods issue
                  ls_vbkok-wabuc = c_x. "Automatically PGI selection
                  ls_vbkok-vbeln_vl = lv_del."Delivery Number
                  ls_vbkok-wadat_ist = sy-datum."PGI date

                  SELECT vbeln,posnr,matnr,charg,lfimg,meins,vgbel,vgpos
                    FROM lips INTO TABLE @DATA(lt_lips1) WHERE vbeln = @lv_del AND
                                                               charg NE @space AND
                                                               lgmng NE '0.000'.
                  IF sy-subrc = 0.
                    LOOP AT lt_lips1 INTO DATA(ls_lips1).
                      lv_matnr = |{ ls_lips1-matnr ALPHA = IN }|.
                      lv_posnr = |{ ls_lips1-posnr ALPHA = IN }|.
                      wa_vbpok-vbeln = ls_lips1-vgbel."Subsequent sales and distribution document
                      wa_vbpok-posnn = ls_lips1-vgpos.
                      wa_vbpok-vbeln_vl = lv_del.
                      wa_vbpok-posnr_vl = ls_lips1-posnr.

                      wa_vbpok-charg = ls_lips1-charg.
                      wa_vbpok-matnr = lv_matnr.
                      wa_vbpok-werks = ls_sales_typ-werks.
                      wa_vbpok-lgort = ls_sales_typ-lgort.
                      wa_vbpok-vbtyp_n = 'Q'.
*                  wa_vbpok-taqui = ''.
                      wa_vbpok-pikmg = ls_lips1-lfimg.
                      wa_vbpok-lfimg = ls_lips1-lfimg.
                      wa_vbpok-lgmng = ls_lips1-lfimg.
                      wa_vbpok-meins = ls_lips1-meins.
                      APPEND wa_vbpok TO lt_vbpok.
                      CLEAR wa_vbpok.
                    ENDLOOP.
                  ENDIF.

                  CALL FUNCTION 'WS_DELIVERY_UPDATE'
                    EXPORTING
                      vbkok_wa                 = ls_vbkok
                      synchron                 = c_x
                      no_messages_update       = ' '
                      commit                   = c_x
                      delivery                 = lv_del
                      update_picking           = c_x
                      nicht_sperren            = c_x
                      if_error_messages_send_0 = c_x
                      if_late_delivery_upd     = c_x
                    TABLES
                      vbpok_tab                = lt_vbpok
                      prot                     = lt_prot.

                  IF line_exists( lt_prot[ msgty = c_e ] ) OR
                     line_exists( lt_prot[ msgty = c_a ] ).
                    ROLLBACK WORK.

                    ls_flow-zdate = sy-datum.
                    ls_flow-ztime = sy-uzeit.
                    ls_flow-zdoc_type = c_error.
                    ls_flow-msg = | PGI Failed!! for Delivery - | && c_space && lv_del.
                    ls_flow-zfile_name = wa_sheader-file_name.
                    INSERT zskp_sales_flow FROM ls_flow.
                    COMMIT WORK.
                    CLEAR : ls_flow.
                    lv_check = c_x.
                  ELSE.
                    COMMIT WORK.
                    ls_flow-zdate = sy-datum.
                    ls_flow-ztime = sy-uzeit.
                    ls_flow-zdoc_type = c_success.
                    ls_flow-zdocument = lv_del.
                    ls_flow-msg = | PGI successful for Delivery - | && c_space && lv_del.
                    ls_flow-zfile_name = wa_sheader-file_name.
                    INSERT zskp_sales_flow FROM ls_flow.
                    COMMIT WORK.
                    CLEAR : ls_flow.
                    lv_check = c_x.
                  ENDIF.
                ENDIF.

**- BAPI to Create Invoice Document
                ls_billing-ref_doc = lv_del. ""Delivery Number
                ls_billing-ref_doc_ca = c_j.
                ls_billing-zuonr = lv_vbeln. ""Sale order Number.
                APPEND ls_billing TO lt_billing.

                CALL FUNCTION 'BAPI_BILLINGDOC_CREATEMULTIPLE'
                  TABLES
                    billingdatain = lt_billing[]
                    return        = lt_return1[]
                    success       = lt_success[].

                IF line_exists( lt_return1[ type = c_w ] ) OR
                   line_exists( lt_return1[ type = c_s ] ).
                  ls_flow-zdate = sy-datum.
                  ls_flow-ztime = sy-uzeit.
                  ls_flow-zdoc_type = c_success.
                  ls_flow-zdocument = VALUE #( lt_return1[ type = c_s ]-message_v1 OPTIONAL ).
                  ls_flow-msg = | Invoice - | && c_space && ls_flow-zdocument && | Document has been created. |.
                  ls_flow-zfile_name = wa_sheader-file_name.
                  INSERT zskp_sales_flow FROM ls_flow.
                  COMMIT WORK.
                  CLEAR : ls_flow.
                  lv_check = c_x.
                ELSE.
                  ls_flow-zdate = sy-datum.
                  ls_flow-ztime = sy-uzeit.
                  ls_flow-zdoc_type = c_error.
                  ls_flow-msg = VALUE #( lt_return1[ type = c_e ]-message OPTIONAL ).
                  ls_flow-zfile_name = wa_sheader-file_name.
                  INSERT zskp_sales_flow FROM ls_flow.
                  COMMIT WORK.
                  CLEAR : ls_flow.
                  lv_check = c_x.
                ENDIF.
              ENDIF.
            ENDIF.
          ENDIF.
        ELSE.
** Post Sample quantity
* Batch
          SELECT matnr,charg,licha FROM mch1 INTO TABLE @lt_mch1
          FOR ALL ENTRIES IN @lt_batch
            WHERE licha = @lt_batch-batch_name AND
                  matnr = @lt_batch-matnr.
          IF sy-subrc = 0.
            LOOP AT lt_batch INTO DATA(ls_batch).
              READ TABLE lt_mch1 INTO ls_mch1 WITH KEY matnr = ls_batch-matnr.
              IF sy-subrc = 0.
                SELECT prueflos, herkunft, objnr, losmenge FROM qals INTO TABLE @DATA(lt_qals)
                     WHERE matnr = @ls_batch-matnr AND
                           werk = @ls_sales_typ-werks AND
                           charg = @ls_mch1-charg.
                IF sy-subrc = 0.
* Fetch correct BL Sample movement type from table ZSD_SKP_MOVEMENT
                  SELECT SINGLE bwart FROM zsd_skp_movement INTO @DATA(lv_bl_mvmt) WHERE zskp_mvmt = @c_space AND
                                                                                         zstatus = @c_10.
                  IF sy-subrc = 0.
                    LOOP AT lt_qals INTO DATA(ls_qals).
                      CALL FUNCTION 'STATUS_TEXT_EDIT'
                        EXPORTING
                          client      = sy-mandt
                          objnr       = ls_qals-objnr
                          only_active = 'X'
                          spras       = sy-langu
                        IMPORTING
                          line        = lv_line.

                      IF sy-subrc EQ 0.
                        IF lv_line(3) EQ 'REL'.
                          lv_insp_lot = ls_qals-prueflos.
                          DATA(flag) = 'X'.
                          EXIT.
                        ENDIF.
                      ENDIF.
                    ENDLOOP.

                    IF flag = 'X'.
                      CLEAR : ls_qty, lt_qty_tabl[].

                      ls_qty-zdate = sy-datum.
                      ls_qty-ztime = sy-uzeit.
                      ls_qty-insplot = lv_insp_lot.
                      ls_qty-bwart = lv_bl_mvmt.
                      ls_qty-zsam_qty = ls_batch-batch_quantity.
                      ls_qty-zfile_name = wa_sheader-file_name.
                      APPEND ls_qty TO lt_qty_tabl.
                      INSERT zsd_skp_ud_qty FROM ls_qty.
                      COMMIT WORK.

                      EXPORT zsd_skp_ud_smpl = lt_qty_tabl TO MEMORY ID 'ZSKP_UD_SMPL'.

                      CLEAR: lt_system[],lt_user[],ls_ud_return_data,ls_stock_data,ls_return,lv_insp.

                      lv_insp = ls_qals-prueflos.

                      CALL FUNCTION 'BAPI_INSPLOT_SETUSAGEDECISION'   " enhancement ZQM_ENCH_AUTOUD
                        EXPORTING
                          number         = lv_insp
                          ud_data        = ls_ud_data
                        IMPORTING
                          ud_return_data = ls_ud_return_data
                          stock_data     = ls_stock_data
                          return         = ls_return1
                        TABLES
                          system_status  = lt_system
                          user_status    = lt_user.
                      IF sy-subrc = 0 AND ls_return1-id EQ 'QV' AND ls_return1-number EQ '050'.
                        CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                          EXPORTING
                            wait = c_x.

                        ls_flow-zdate = sy-datum.
                        ls_flow-ztime = sy-uzeit.
                        ls_flow-zdoc_type = c_success.
                        ls_flow-msg =  | Sample usage completed with QTY | && c_space && ls_batch-batch_quantity && c_space && | for material - | && c_space && ls_batch-matnr && c_space && | and batch - |
                                       && c_space && ls_mch1-charg && c_space && | combination |.
                        ls_flow-zfile_name = wa_sheader-file_name.
                        INSERT zskp_sales_flow FROM ls_flow.
                        COMMIT WORK.
                        CLEAR : ls_flow.
                      ELSE.
                        ls_flow-zdate = sy-datum.
                        ls_flow-ztime = sy-uzeit.
                        ls_flow-zdoc_type = c_error.
                        ls_flow-msg =  | Error while posting sample UD for material - | && c_space && ls_batch-matnr && c_space && | and Batch - |
                                       && c_space && ls_mch1-charg && c_space && | combination |.
                        ls_flow-zfile_name = wa_sheader-file_name.
                        INSERT zskp_sales_flow FROM ls_flow.
                        COMMIT WORK.
                        CLEAR : ls_flow.
                      ENDIF.
                    ENDIF.
                  ELSE.
                    ls_flow-zdate = sy-datum.
                    ls_flow-ztime = sy-uzeit.
                    ls_flow-zdoc_type = c_error.
                    ls_flow-msg =  | No BL Movement type has found |.
                    ls_flow-zfile_name = wa_sheader-file_name.
                    INSERT zskp_sales_flow FROM ls_flow.
                    COMMIT WORK.
                    CLEAR : ls_flow.
                  ENDIF.
                ENDIF.
              ELSE.
                ls_flow-zdate = sy-datum.
                ls_flow-ztime = sy-uzeit.
                ls_flow-zdoc_type = c_error.
                ls_flow-msg =  | No BL Batch found for SKP batch - | && c_space && ls_mch1-licha.
                ls_flow-zfile_name = wa_sheader-file_name.
                INSERT zskp_sales_flow FROM ls_flow.
                COMMIT WORK.
                CLEAR : ls_flow.
              ENDIF.
            ENDLOOP.
          ENDIF.
        ENDIF.

      ELSEIF ( wa_sheader-order_type = '20' OR
               wa_sheader-order_type = '24' ). "Credit Note

* Create Credit Memo request
        CLEAR: lt_return[],lv_ref.
        SPLIT wa_sheader-customer_order_ref AT c_space INTO DATA(lv_credit) DATA(lv_org_order).
        SHIFT lv_org_order LEFT DELETING LEADING '0'.
        lv_ref = lv_org_order.
        SELECT SINGLE vbeln FROM vbrk INTO @DATA(lv_org_inv) WHERE xblnr = @lv_ref
                                                               AND vkorg = @ls_sales_typ-vkorg.
        IF sy-subrc = 0.
* Create Credit Memo request from invoice reference
          SELECT SINGLE vbeln FROM vbfa INTO @DATA(lv_cr_exist) WHERE vbelv = @lv_org_inv AND vbtyp_n = 'K'.
          IF sy-subrc = 0.
            ls_flow-zdate = sy-datum.
            ls_flow-ztime = sy-uzeit.
            ls_flow-zdoc_type = c_error.
            ls_flow-msg = | Purchase order number already exists | && c_space && | in document number: | && c_space && lv_cr_exist.
            ls_flow-zfile_name = wa_sheader-file_name.
            INSERT zskp_sales_flow FROM ls_flow.
            COMMIT WORK.
            CLEAR : ls_flow.
            lv_check = c_x.
          ELSE.
            CALL FUNCTION 'BAPI_SALESDOCUMENT_COPY'
              EXPORTING
                salesdocument    = lv_org_inv
                documenttype     = ls_sales_typ-zbl_odr_typ
              IMPORTING
                salesdocument_ex = lv_crdt_memo
              TABLES
                return           = lt_return[].

            IF lv_crdt_memo IS NOT INITIAL.
              CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                EXPORTING
                  wait = c_x.

              CLEAR : lt_return[].
            ELSE.
              ls_flow-zdate = sy-datum.
              ls_flow-zdoc_type = c_error.
              ls_flow-ztime = sy-uzeit.
              ls_flow-msg = | Credit memo request not created for Invoice -  | && c_space && lv_org_inv && c_space && | !!! |.
              ls_flow-zfile_name = wa_sheader-file_name.
              INSERT zskp_sales_flow FROM ls_flow.
              COMMIT WORK.
              CLEAR : ls_flow.
              lv_check = c_x.
            ENDIF.
          ENDIF.
        ELSE.
**- Create Credit Memo request without invoice reference
* Clear PO number and PO date as space
          CLEAR: lt_return[], ls_header-doc_type.

**- If No material then skip Credit Memo creation.
          IF wa_sheader-order_type = '20'.
            READ TABLE lt_item INTO DATA(wa_item) WITH KEY material = space.
            IF sy-subrc = 0.
              ls_flow-zdate = sy-datum.
              ls_flow-ztime = sy-uzeit.
              ls_flow-zdoc_type = c_error.
              ls_flow-zdocument = wa_sheader-order_number.
              ls_flow-msg = | Material Not Found for Credit Note - | && c_space && wa_sheader-order_number && | !!! |.
              ls_flow-zfile_name = wa_sheader-file_name.
              INSERT zskp_sales_flow FROM ls_flow.
              COMMIT WORK.
              DATA(lv_mat_chk) = abap_true.
              CLEAR : ls_flow.
            ENDIF.
          ENDIF.

          IF lv_mat_chk = space.
            ls_header-doc_type = ls_sales_typ-zbl_no_ref.
            CONDENSE ls_header-doc_type.

            ls_header-purch_no_c = c_space.
            ls_headerx-purch_no_c = c_space.

            ls_header-purch_date = c_space.
            ls_headerx-purch_date = c_space.

            ls_header-po_dat_s = c_space.
            ls_headerx-po_dat_s = c_space.

            CALL FUNCTION 'BAPI_SALESDOCU_CREATEFROMDATA1'
              EXPORTING
                sales_header_in     = ls_header
                sales_header_inx    = ls_headerx
              IMPORTING
                salesdocument_ex    = lv_crdt_memo
              TABLES
                return              = lt_return
                sales_items_in      = lt_item
                sales_items_inx     = lt_itemx
                sales_schedules_in  = lt_schedules_in
                sales_schedules_inx = lt_schedules_inx
                sales_conditions_in = lt_conditions_in
                sales_partners      = lt_partner.

            READ TABLE lt_return INTO ls_return WITH KEY type = c_e.
            IF sy-subrc = 0.
              LOOP AT lt_return INTO ls_return WHERE type = c_e.
                ls_flow-zdate = sy-datum.
                ls_flow-ztime = sy-uzeit.
                ls_flow-zdoc_type = c_error.
                ls_flow-msg = ls_return-message.
                ls_flow-zfile_name = wa_sheader-file_name.
                INSERT zskp_sales_flow FROM ls_flow.
                COMMIT WORK.
                CLEAR : ls_flow.
                lv_check = c_x.
              ENDLOOP.
            ELSE.
              CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                EXPORTING
                  wait = c_x.
            ENDIF.
          ENDIF.

          IF lv_crdt_memo IS NOT INITIAL.
            ls_crheader-bill_block = c_space.
            ls_crheaderx-bill_block = c_x.

            ls_crheader-purch_no_c = lv_org_order.
            ls_crheaderx-purch_no_c = c_x.

            ls_crheaderx-updateflag = 'U'.

            ls_crheader-ord_reason = '100'.
            ls_crheaderx-ord_reason = c_x.


            CALL FUNCTION 'BAPI_SALESORDER_CHANGE'
              EXPORTING
                salesdocument    = lv_crdt_memo
                order_header_in  = ls_crheader
                order_header_inx = ls_crheaderx
              TABLES
                return           = lt_return[].
            IF line_exists( lt_return[ type = c_s ] ).
              CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                EXPORTING
                  wait = c_x.

              ls_flow-zdate = sy-datum.
              ls_flow-ztime = sy-uzeit.
              ls_flow-zdoc_type = c_success.
              ls_flow-zdocument = lv_crdt_memo.
              ls_flow-msg = | Credit memo request - | && c_space && lv_crdt_memo && c_space && | has been created. |.
              ls_flow-zfile_name = wa_sheader-file_name.
              INSERT zskp_sales_flow FROM ls_flow.
              COMMIT WORK.
              CLEAR : ls_flow.
              lv_check = c_x.
            ELSE.
              ls_flow-zdate = sy-datum.
              ls_flow-ztime = sy-uzeit.
              ls_flow-zdoc_type = c_error.
              ls_flow-msg = VALUE #( lt_return1[ type = c_e ]-message OPTIONAL ).
              ls_flow-zfile_name = wa_sheader-file_name.
              INSERT zskp_sales_flow FROM ls_flow.
              COMMIT WORK.
              CLEAR : ls_flow.
              lv_check = c_x.
            ENDIF.

* Create Credit memo based on credit memo request
            CLEAR: ls_billing,lt_return1[],lt_success[],lt_billing[].
            ls_billing-ref_doc = lv_crdt_memo. "Credit Memo request
            ls_billing-ref_doc_ca = c_k.
            APPEND ls_billing TO lt_billing.

            CALL FUNCTION 'BAPI_BILLINGDOC_CREATEMULTIPLE'
              TABLES
                billingdatain = lt_billing[]
                return        = lt_return1[]
                success       = lt_success[].
            IF line_exists( lt_return1[ type = c_s ] ).
              ls_flow-zdate = sy-datum.
              ls_flow-ztime = sy-uzeit.
              ls_flow-zdoc_type = c_success.
              ls_flow-zdocument = VALUE #( lt_return1[ type = c_s ]-message_v1 OPTIONAL ).
              ls_flow-msg = VALUE #( lt_return1[ type = c_s ]-message OPTIONAL ).
              ls_flow-zfile_name = wa_sheader-file_name.
              INSERT zskp_sales_flow FROM ls_flow.
              COMMIT WORK.
              CLEAR : ls_flow.
              lv_check = c_x.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.
ENDCLASS.
