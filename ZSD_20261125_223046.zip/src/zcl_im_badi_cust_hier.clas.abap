class ZCL_IM_BADI_CUST_HIER definition
  public
  final
  create public .

public section.

  interfaces IF_EX_BADI_CUST_HIER .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_BADI_CUST_HIER IMPLEMENTATION.


  method IF_EX_BADI_CUST_HIER~SET_CUST_HITYP.

    BREAK umadevi.

  endmethod.
ENDCLASS.
