"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAP\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_WBS_VALID_SO.
  data:  lv_pspnr type /RPM/ITEM_D-external_id,
         ls_item type dpr_task,
         lt_acckey type TABLE OF zsd_acckey,
         lt_acckey_gl type TABLE OF zsd_acckey_gl,
         lt_c001 type TABLE OF c001,
         lt_c001_gl type TABLE OF c001,
         lt_c001_gl_tmp type TABLE OF c001,
         ls_c001_gl_tmp type c001,
         lt_vbap type TABLE OF vbap,
         lt_vbak type TABLE OF vbak,
         lv_netwr type vbap-netwr,
         lv_objnr type vbap-objnr,
         ls_vbap_tmp TYPE vbap,
         lv_flag TYPE c,
         lt_auart TYPE TABLE OF ztabap_tvarvc ,
         ls_auart TYPE  ztabap_tvarvc .

IF vbap-PS_PSP_PNR is not INITIAL and vbak-bukrs_VF(1) = '5' and ( vbak-vbtyp = 'C' or vbak-vbtyp = 'L' ) .

  SELECT * FROM ztabap_tvarvc INTO TABLE lt_AUART
               WHERE obj_name = 'ZSD_SO_ERL_CHECK'
                 AND name = 'AUART_ERL'.

  READ TABLE lt_auart INTO ls_auart WITH KEY low = vbak-auart.
    IF sy-subrc NE  0.
               IF sy-tcode = 'VA02'.
                  CLEAR: lv_flag,ls_vbap_tmp.
                  SELECT SINGLE * FROM vbap INTO ls_vbap_tmp WHERE vbeln = vbap-vbeln
                                                               AND posnr = vbap-posnr.
                    IF ls_vbap_tmp-netwr = vbap-netwr.
                      lv_flag = 'X'.
                    ENDIF.
               ENDIF.
IF sy-tcode = 'VA01' or ( sy-tcode = 'VA02' AND lv_flag IS INITIAL ).


*IF vbap-PS_PSP_PNR is not INITIAL and vbak-bukrs_VF(1) = '5' and ( vbak-vbtyp = 'C' or vbak-vbtyp = 'L' ) .


            CALL FUNCTION 'CONVERSION_EXIT_ABPSP_OUTPUT'
              EXPORTING
                input         = vbap-PS_PSP_PNR
             IMPORTING
               OUTPUT        = lv_pspnr
                      .

          data(len) = strlen( lv_pspnr ).
          IF len > 3.
              len = len - 3.
              lv_pspnr = lv_pspnr(len).
          ENDIF.
            select SINGLE * from dpr_task into ls_item
                      where task_id = lv_pspnr.
              IF sy-subrc = 0 and ls_item-zzopportunityvalue is not INITIAL.
                IF vbap-waerk <> ls_item-zzopportunitycurr.
                    Message 'Discrepancy Between WBS and Sales Order Currency' TYpe 'E'.
                ENDIF.
  REFRESH: lt_Acckey_gl,lt_c001_gl.
  select * from zsd_acckey_gl into TABLE lt_Acckey_gl.
    IF lt_Acckey_gl IS NOT INITIAL.
select * from c001 into TABLE lt_c001_gl
        FOR ALL ENTRIES IN lt_acckey_gl
        where KVSL1 = lt_acckey_gl-KVSL1 AND
              KTGRD = VBKD-KTGRD and
              KTGRM = VBAP-KTGRM and
              VKORG = VBAk-VKORG and
              sakn1 = lt_acckey_gl-saknr and
              KAPPL = 'V'.
    ENDIF.
  IF lt_c001_gl IS NOT INITIAL.

    ELSE.

  select * from zsd_acckey into TABLE lt_Acckey.
    IF sy-subrc = 0.
      select * from c001 into TABLE lt_c001
        FOR ALL ENTRIES IN lt_acckey
        where KVSL1 = lt_acckey-KVSL1 AND
              KTGRD = VBKD-KTGRD and
              KTGRM = VBAP-KTGRM and
              VKORG = VBAk-VKORG and
              KAPPL = 'V'.

        select * from vbap into table lt_vbap
                      where PS_PSP_PNR = vbap-PS_PSP_PNR and ABGRU = ''.
          IF sy-subrc = 0.

            select * from VBAK into TABLE lt_vbak
                  FOR ALL ENTRIES IN lt_vbap
                  where vbeln = lt_vbap-vbeln and ( vbtyp = 'C' or vbtyp = 'L'
                                              or vbtyp = 'K' or vbtyp = 'H' ).


            "if already have that entry
            delete lt_vbap where vbeln = vbap-vbeln.
            lv_netwr = REDUCE netwr( init amt type netwr for ls_vbap in lt_vbap
                                                         for ls_vbak in lt_vbak where ( vbeln = ls_vbap-vbeln )
                                  next amt = amt +  ls_vbap-netwr * COND #( when ls_vbak-vbtyp = 'K' or ls_vbak-vbtyp = 'H' then -1 else 1 ) ).
          ENDIF.
          lv_netwr = lv_netwr +
                        REDUCE netwr( init amt type netwr for ls_vbap2 in xvbap
                        where ( ps_psp_pnr = vbap-ps_psp_pnr and
                                                         abgru = '' )
                                  next amt = amt + ls_vbap2-netwr ).



              IF lv_netwr > ls_item-zzopportunityvalue
                and ls_item-zzopportunityvalue is not INITIAL.
                DATA(xvbap_tmp) = xvbap[].
                DELETE xvbap_tmp WHERE PS_PSP_PNR NE vbap-PS_PSP_PNR.
                IF xvbap_tmp IS NOT INITIAL AND lt_acckey_gl IS NOT INITIAL.
                LOOP AT xvbap_tmp INTO DATA(ls_xvbap_tmp).
                  select * from c001 into TABLE lt_c001_gl_tmp
                        FOR ALL ENTRIES IN lt_acckey_gl
                        where KVSL1 = lt_acckey_gl-KVSL1 AND
                              KTGRD = VBKD-KTGRD and
                              KTGRM = ls_xvbap_tmp-KTGRM and
                              VKORG = VBAk-VKORG and
                              sakn1 = lt_acckey_gl-saknr and
                              KVSL1 = 'ERL' AND
                              KAPPL = 'V'.
                    IF sy-subrc = 0.
                      READ TABLE lt_c001_gl_tmp INTO ls_c001_gl_tmp INDEX 1.
                      lv_netwr = lv_netwr - ls_xvbap_tmp-netwr.
                      CLEAR: ls_xvbap_tmp,ls_c001_gl_tmp.
                    ENDIF.
                ENDLOOP.
                ENDIF.
                IF lv_netwr > ls_item-zzopportunityvalue.
                message 'Sale Order amount more than BC Value' type 'E'.
                ENDIF.
              ENDIF.
       ENDIF.
     ENDIF.
*    ENDIF.
  ENDIF.
 ENDIF.
ENDIF.
ENDIF.
ENDENHANCEMENT.
