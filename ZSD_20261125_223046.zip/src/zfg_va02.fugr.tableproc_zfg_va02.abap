*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_VA02
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_VA02            .

  PERFORM TABLEPROC.

ENDFUNCTION.
