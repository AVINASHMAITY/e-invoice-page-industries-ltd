class ZCL_IM_BADI_SCD_ACCTG definition
  public
  final
  create public .

public section.

  interfaces IF_EX_BADI_SCD_ACCTG .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_BADI_SCD_ACCTG IMPLEMENTATION.


  METHOD if_ex_badi_scd_acctg~before_check.

    DATA: lv_sakto TYPE sakto,
          lv_kostl TYPE kostl.

    LOOP AT i_refobj-vtsp INTO DATA(lw_vtsp).
      IF lw_vtsp-tknum IS NOT INITIAL.
        DATA(lv_tknum) = lw_vtsp-tknum.
      ENDIF.
    ENDLOOP.

    SELECT SINGLE vbelv FROM vbfa INTO @DATA(lv_vbeln)
           WHERE vbeln = @lv_tknum
           AND vbtyp_n = '8'.

    SELECT SINGLE vbelv FROM vbfa INTO @DATA(lv_vbeln1)
           WHERE vbeln = @lv_vbeln
            AND vbtyp_n = 'J'.

    SELECT vbeln,kvgr5 FROM vbak INTO TABLE @DATA(lt_vbak)
           WHERE vbeln = @lv_vbeln1.

    IF lt_vbak IS NOT INITIAL.
      SELECT werks,vbeln FROM vbap INTO TABLE @DATA(lt_vbap)
        FOR ALL ENTRIES IN @lt_vbak
        WHERE vbeln = @lt_vbak-vbeln.
    ENDIF.

    LOOP AT lt_vbak INTO DATA(lw_vbak).
      READ TABLE lt_vbap INTO DATA(lw_vbap) WITH KEY vbeln = lw_vbak-vbeln.
      IF lw_vbak-kvgr5 IS NOT INITIAL.
        SELECT SINGLE  sakto kostl FROM zlogistics_gl INTO ( lv_sakto,  lv_kostl )
                       WHERE kvgr5 = lw_vbak-kvgr5
                       AND werks = lw_vbap-werks.

        IF lv_sakto IS NOT INITIAL.
          CLEAR: c_vfkn-sakto .
          c_vfkn-sakto = lv_sakto.
*          c_vfkn-kostl = lv_kostl.
        ENDIF.
      ELSEIF lw_vbak-kvgr5 IS INITIAL.
         SELECT SINGLE  sakto kostl FROM zlogistics_gl INTO ( lv_sakto,  lv_kostl )
                        where werks = lw_vbap-werks.

        IF lv_sakto IS NOT INITIAL.
          CLEAR: c_vfkn-sakto .
          c_vfkn-sakto = lv_sakto.
          c_vfkn-kostl = lv_kostl.
        ENDIF.
      ELSE.
        IF i_vtrlk-werks(2) = '27'.                     "Added by Akshay on 18/03/2026 in DR1K999993
          MESSAGE 'No Customer Group Maintained in sales order' TYPE 'E' DISPLAY LIKE 'E'.
        ENDIF.
      ENDIF.
    ENDLOOP.




  ENDMETHOD.
ENDCLASS.
