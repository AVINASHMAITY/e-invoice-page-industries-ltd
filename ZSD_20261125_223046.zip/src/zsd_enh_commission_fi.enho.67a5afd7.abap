"Name: \PR:SAPLV60A\FO:USEREXIT_PRICING_PREPARE_TKOMK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_COMMISSION_FI.
data : v_lifnr type lifnr,
       V_KUNNR TYPE KUNNR.
    if vbak is not INITIAL.
     select single KUNN2 LIFNR from knvp
                    into (v_KUNNR, V_LIFNR)
                    where kunnr = vbrk-kunrg
                     AND  VKORG = VBRK-VKORG
                     AND  VTWEG = VBRK-VTWEG
                     AND  SPART = VBRK-SPART
                     AND  PARVW in ('LF', 'VN' ,'CR' ,'SP' ,'ZC').
         IF SY-SUBRC = 0 .

             TKOMK-lifnr = v_lifnr.
             TKOMK-SPDNR  = V_LIFNR.
         ENDIF.

    TKOMK-ZZCOMMAG = V_KUNNR.
    endif.

ENDENHANCEMENT.
