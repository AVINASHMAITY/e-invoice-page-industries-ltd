*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBPI_FORECAST
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBPI_FORECAST       .

  PERFORM TABLEPROC.

ENDFUNCTION.
