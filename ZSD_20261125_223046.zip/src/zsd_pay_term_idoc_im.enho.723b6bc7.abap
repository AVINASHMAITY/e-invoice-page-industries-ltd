"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_PAY_TERM_IDOC_IM.
**&---------------------------------------------------------------------*
**&  Include           ZXVEDU13
**&---------------------------------------------------------------------*
*&----------------------------------------------------------------
*Date       : 25.05.2023
*Programmer : Sumit
*TR No.     : DR1K975241
*TR No.     : DR1K975848
*TR No.     : DR1K976367
*Description: Enhancment for payment Term
*&----------------------------------------------------------------
DATA:lv_idoc TYPE CHAR1.

lv_idoc = 'X'.
EXPORT lv_idoc TO MEMORY id 'LV_IDOC'.

******************Logic for SO Header text / Customer Ref no                "DR1K975848
data:lwa_temp type E1EDK01.
LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_idoc_temp>) where segnam = 'E1EDK01' .
lwa_temp  = <fs_idoc_temp>-sdata.
IF lwa_temp-belnr is not INITIAL.
data(lv_belnr) = lwa_temp-belnr.
*EXPORT lv_belnr TO MEMORY id 'LV_AUGRU'.
EXPORT lv_belnr TO MEMORY id 'LV_BELNR'.
ENDIF.
ENDLOOP.
******************Logic for SO Header text / Customer Ref no                 "DR1K975848
ENDENHANCEMENT.
