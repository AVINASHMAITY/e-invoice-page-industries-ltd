"Name: \PR:SAPMV50A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_VALIDATE_BATCH.
*
TYPES : BEGIN OF st_aufm,
        MBLNR	    TYPE MBLNR,     "Number of Material Document
        MJAHR     TYPE MJAHR,     " NUMC  4 0 Material Document Year
        ZEILE     TYPE MBLPO,     " NUMC  4 0 Item in Material Document
        BWART     TYPE BWART,     " CHAR  3 0 Movement Type (Inventory Management)
        MATNR     TYPE MATNR,     " CHAR  18  0 Material Number
        WERKS     TYPE WERKS_D,   " CHAR  4 0 Plant
        CHARG     TYPE CHARG_D,   " CHAR  10  0 Batch Number
        AUFNR     TYPE AUFNR,     " CHAR  12  0 Order Number
       END OF st_aufm,

       BEGIN OF st_aufk,
         AUFNR    TYPE AUFNR,     " CHAR  12  0 Order Number
         OBJNR    TYPE J_OBJNR,   " CHAR  22  0 Object number
       END OF st_aufk,

       BEGIN OF st_jest,
         OBJNR    TYPE J_OBJNR,   " CHAR  22  0 Object number
         STAT     TYPE J_STATUS,  " CHAR  5 0 Object status
         INACT    TYPE J_INACT,   " CHAR  1 0 Indicator: Status Is Inactive
       end of st_jest,

       BEGIN OF st_vbak,
         VBELN    TYPE VBELN_VA,  " CHAR  10  0 Sales Document
         BUKRS_VF TYPE BUKRS_VF,  " CHAR  4 0 Company code to be billed
       end of st_vbak,

       BEGIN OF st_ztab,
         OBJ_NAME       TYPE SOBJ_NAME,   " CHAR  40  0 Object Name in Object Directory
         NAME           TYPE RVARI_VNAM,  " CHAR  30  0 ABAP: Name of Variant Variable
         TYPE           TYPE RSSCR_KIND,  " CHAR  1 0 ABAP: Type of selection
         LOW            TYPE TVARV_LOW,   " CHAR  255 0 Low Field TVARV
       end of st_ztab.


 data : lt_aufm   TYPE STANDARD TABLE OF st_aufm,
        lt_aufk   TYPE STANDARD TABLE OF st_aufk,
        lt_jest   TYPE STANDARD TABLE OF st_jest,
        lt_ztab   TYPE STANDARD TABLE OF st_ztab,
        lt_lips   TYPE STANDARD TABLE OF LIPSVB.
*        lt_vbak   TYPE STANDARD TABLE OF st_vbak.

 DATA : lw_aufm   TYPE st_aufm,
        lw_aufk   TYPE st_aufk,
        lw_jest   TYPE st_jest,
        lw_ztab   TYPE st_ztab,
        lw_lips   TYPE LIPSVB,
        lw_vbak   TYPE st_vbak.


data : lt_ZTABAP_TVARVC TYPE STANDARD TABLE OF ZTABAP_TVARVC,
       lw_ZTABAP_TVARVC TYPE ZTABAP_TVARVC,
       lv_error   TYPE string.

Types : BEGIN OF st_msg,
          line(256) TYPE c,
          END OF st_msg.
Data :  lv_choise TYPE char1,
        lv_txt(50) VALUE 'Error',
        lw_msg type st_msg,
        lt_msg TYPE STANDARD TABLE OF st_msg.


if sy-tcode eq 'VL01N' OR SY-TCODE EQ 'VL02N' OR SY-TCODE EQ 'VL10B'.

********** validation for company code and material type
****** fetch the company code
  SELECT SINGLE VBELN
                BUKRS_VF
                  FROM vbak
                  INTO lw_vbak
                  WHERE vbeln  eq xlips-vgbel.

      lw_ztab-OBJ_NAME  = 'ZPP_BATCHTECO_VAL_OBD'.      "'MV50AFZ1'.
      lw_ztab-NAME      = 'BUKRS_OBD'.
      lw_ztab-TYPE      = 'S'.
      lw_ztab-LOW       = lw_vbak-bukrs_vf.
      append lw_ztab to lt_ztab.
      CLEAR lw_ztab.


  refresh lt_lips.
  lt_lips[] = xlips[].
****** for material  type
  loop at lt_lips INTO lw_lips.
      lw_ztab-OBJ_NAME  = 'ZPP_BATCHTECO_VAL_OBD'.      "'MV50AFZ1'.
      lw_ztab-NAME      = 'MTART_OBD'.
      lw_ztab-TYPE      = 'S'.
      lw_ztab-LOW       = lw_lips-mtart.
      append lw_ztab to lt_ztab.
      CLEAR lw_ztab.
  ENDLOOP.

**fetch the  record for validation

  SELECT * FROM ZTABAP_TVARVC
            INTO TABLE lt_ZTABAP_TVARVC
            FOR ALL ENTRIES IN lt_ztab
            WHERE OBJ_NAME eq lt_ztab-OBJ_NAME
              and NAME     eq lt_ztab-NAME
              and TYPE     eq lt_ztab-TYPE
              and LOW      eq lt_ztab-LOW.



    READ TABLE lt_ZTABAP_TVARVC INTO lw_ZTABAP_TVARVC
                            with key OBJ_NAME  = 'ZPP_BATCHTECO_VAL_OBD'   "'MV50AFZ1'
                                     NAME      = 'BUKRS_OBD'
                                     TYPE      = 'S'
                                     LOW       = lw_vbak-bukrs_vf.
    if sy-subrc eq 0.                                     "validation for bukrs

  SELECT MBLNR
         MJAHR
         ZEILE
         BWART
         MATNR
         WERKS
         CHARG
         AUFNR
            FROM aufm
            INTO CORRESPONDING FIELDS OF TABLE lt_aufm
            for all ENTRIES IN XLIPS
            WHERE matnr eq XLIPS-MATNR
              AND WERKS EQ XLIPS-WERKS
              AND CHARG EQ XLIPS-CHARG
              AND BWART EQ '101'.


   IF LT_AUFM IS NOT INITIAL.
     SELECT AUFNR
            OBJNR
              FROM AUFK
              INTO TABLE LT_AUFK
              FOR ALL ENTRIES IN LT_AUFM
              WHERE AUFNR EQ LT_AUFM-AUFNR.

*   ELSE .
    if lt_aufk is INITIAL.
*     CONCATENATE 'Item No' lw_lips-posnr 'Batch #' lw_lips-charg '- TECO not done'
*                                   into lv_error SEPARATED BY space.
*            MESSAGE lv_error TYPE 'E'.

     CONCATENATE '@0A@' 'Item No' lw_lips-posnr 'Batch #' lw_lips-charg '- TECO not done'
                                   into lw_msg SEPARATED BY space.
        append lw_msg to lt_msg.
        CLEAR lw_msg.

    endif.

   endif.

*BREAK-POINT.
       if lt_aufk is NOT INITIAL.
         SELECT OBJNR
                STAT
                INACT
                  FROM jest
                  INTO TABLE lt_jest
                  FOR ALL ENTRIES IN lt_aufk
                  WHERE objnr eq lt_aufk-objnr
                    and stat eq 'I0045'.

       endif.


loop at lt_lips INTO lw_lips.

if lw_lips-charg is not initial.
*** validation for material type

      READ TABLE lt_ZTABAP_TVARVC INTO lw_ZTABAP_TVARVC
                            with key OBJ_NAME  = 'ZPP_BATCHTECO_VAL_OBD'   "'MV50AFZ1'
                                     NAME      = 'MTART_OBD'
                                     TYPE      = 'S'
                                     LOW       = lw_LIPS-MTART.




    if sy-subrc eq 0.
      READ TABLE lt_aufm INTO lw_aufm with key matnr = lw_lips-matnr
                                           werks = lw_lips-werks
                                           charg = lw_lips-charg.
      if sy-subrc eq 0.

        READ TABLE LT_AUFK INTO LW_AUFK WITH KEY AUFNR = LW_AUFM-AUFNR.

        IF SY-SUBRC EQ 0.
           READ TABLE LT_JEST INTO LW_JEST WITH KEY OBJNR = LW_AUFK-OBJNR.


          IF LW_JEST-INACT IS not INITIAL or SY-SUBRC NE 0.

*     CONCATENATE 'Item No' lw_lips-posnr 'Batch #' lw_lips-charg '- TECO not done'
*                                   into lv_error SEPARATED BY space.
*
*            MESSAGE lv_error TYPE 'E'.

          CONCATENATE '@0A@' 'Item No' lw_lips-posnr 'Batch #' lw_lips-charg '- TECO not done'
                                   into lw_msg SEPARATED BY space.
            append lw_msg to lt_msg.
            CLEAR lw_msg.

          ENDIF.
        ENDIF.
      endif.
  endif.
endif.

endloop.

endif.                              "validation on bukrs



   if lt_msg is not INITIAL.

    CALL FUNCTION 'POPUP_WITH_TABLE'
    EXPORTING
      endpos_col         = 90
      endpos_row         = 15
      startpos_col       = 20
      startpos_row       = 10
      titletext          = 'Error'
    IMPORTING
      CHOICE             = lv_choise
    TABLES
      valuetab           = lt_msg
    EXCEPTIONS
      BREAK_OFF          = 1
    OTHERS             = 2
          .
    IF sy-subrc <> 0.
* Implement suitable error handling here
     ENDIF.

*      LEAVE PROGRAM.
     MESSAGE 'Please Correct the Errors' TYPE 'E'.

   endif.

ENDIF.


ENDENHANCEMENT.
