FUNCTION-POOL ZFG_IBP                    MESSAGE-ID SV.

* INCLUDE LZFG_IBPD...                       " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_IBPT00                             . "view rel. data dcl.
