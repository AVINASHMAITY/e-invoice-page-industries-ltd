*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGSD_PACK_UNITTOP.               " Global Data
  INCLUDE LZFGSD_PACK_UNITUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGSD_PACK_UNITF...               " Subroutines
* INCLUDE LZFGSD_PACK_UNITO...               " PBO-Modules
* INCLUDE LZFGSD_PACK_UNITI...               " PAI-Modules
* INCLUDE LZFGSD_PACK_UNITE...               " Events
* INCLUDE LZFGSD_PACK_UNITP...               " Local class implement.
* INCLUDE LZFGSD_PACK_UNITT99.               " ABAP Unit tests
  INCLUDE LZFGSD_PACK_UNITF00                     . " subprograms
  INCLUDE LZFGSD_PACK_UNITI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
