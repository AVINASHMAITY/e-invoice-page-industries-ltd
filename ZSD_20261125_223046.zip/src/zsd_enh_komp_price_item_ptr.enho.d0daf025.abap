"Name: \PR:SAPLV61A\FO:USEREXIT_XKOMV_BEWERTEN_END\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_KOMP_PRICE_ITEM_PTR.
DATA: lv1 type kwert,
      lv2 type KWMENG,
      lv3 type kbetr.

CONSTANTS : LW_VBRP TYPE STRING VALUE '(SAPLV60A)VBRP',
            LW_VBRK TYPE STRING VALUE '(SAPLV60A)VBRK',
*************code Added on 03.09.2014 ..
            LW_VBAP TYPE STRING VALUE '(SAPMV45A)VBAP'.

*            LW_konv TYPE STRING VALUE '(SAPLV60A)KONV'.
FIELD-SYMBOLS: <LX_VBRP> TYPE vbRP,
               <LX_VBRK> TYPE vbRK,
               <LX_VBAP> TYPE VBAP.

CLEAR: lv1 , LV2 , lv3.

ASSIGN (LW_VBRP) TO  <LX_VBRP>.
ASSIGN (LW_VBRK) TO  <LX_VBRK>.
ASSIGN (LW_VBAP) TO  <LX_VBAP>.

*BREAK SAHOO.
IF <LX_VBRP> IS ASSIGNED.
IF <LX_VBRK> IS ASSIGNED.
IF <LX_VBRK>-KALSM = 'ZINCFA' or <LX_VBRK>-KALSM = 'ZINCFI'.    " Added <LX_VBRK>-KALSM = 'ZINCFI'by raju on 28.10.2015
* LOOP AT XKOMV where kposn = vbRP-posnr.
READ TABLE XKOMV with key KSCHL = 'ZPTR'
kposn = <LX_VBRP>-posnr.
if sy-subrc = 0.
lv1 = XKOMV-kwert.
*LV2 = <LX_VBRP>-FKIMG.
iF SY-TCODE = 'VF01' or Sy-Tcode = 'VF02'.
lv2 = <LX_VBRP>-FKIMG.
endif.
iF SY-TCODE = 'VA01' or Sy-Tcode = 'VA02' or  Sy-Tcode = 'ZSD_BLOCKED_SO' or  Sy-Tcode = 'ZSD_ZVA01' or  Sy-Tcode = 'ZVA01'.
If KOMP-kposn = <LX_VBRP>-posnr.
if <LX_VBAP>-KWMENG ne komp-MGAME.
 lv2 = komp-MGAME.
else.
  lv2 = <LX_VBAP>-KWMENG.
endif.
else.
  lv2 = <LX_VBAP>-KWMENG.
endif.
*lv2 = <LX_VBAP>-KWMENG.
endif.
if lv2 is not INITIAL.

CALL FUNCTION 'ZFM_SD_ROUTINE_QTY'
EXPORTING
LV_KWERT = lv1
LV_KWMENG = lv2
IMPORTING
LV_RESULT = lv3.
.
endif.
XKOMV-kbetr = lv3.
MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'ZPTR'
and kposn = <LX_VBRP>-posnr.
endif.

CLEAR: lv1 , LV2 , lv3.

READ TABLE XKOMV with key KSCHL = 'ZPTS'
kposn = <LX_VBRP>-posnr.
if sy-subrc = 0.
lv1 = XKOMV-kwert.
iF SY-TCODE = 'VF01' or Sy-Tcode = 'VF02'.
lv2 = <LX_VBRP>-FKIMG.
endif.
iF SY-TCODE = 'VA01' or Sy-Tcode = 'VA02' or Sy-Tcode = 'ZSD_BLOCKED_SO' or  Sy-Tcode = 'ZSD_ZVA01' or  Sy-Tcode = 'ZVA01'.
If KOMP-kposn = <LX_VBRP>-posnr.
if <LX_VBAP>-KWMENG ne komp-MGAME.
 lv2 = komp-MGAME.
else.
  lv2 = <LX_VBAP>-KWMENG.
endif.
else.
  lv2 = <LX_VBAP>-KWMENG.
endif.
*lv2 = <LX_VBAP>-KWMENG.
endif.
if lv2 is not INITIAL.

CALL FUNCTION 'ZFM_SD_ROUTINE_QTY'
  EXPORTING
    LV_KWERT = lv1
    LV_KWMENG = lv2
  IMPORTING
    LV_RESULT = lv3.

endif.
XKOMV-kbetr = lv3.
*MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'ZPTS'
*and kposn =  <LX_VBRP>-posnr.
MODIFY  XKOMV[] from xkomv TRANSPORTING KBETR WHERE KSCHL EQ 'ZPTS'
                                and kposn  = xkomv-kposn.
ENDIF.
ENDIF.
*ENDIF.
*ENDIF.
If Sy-tcode = 'VF01' or Sy-tcode = 'VF02'.
if <LX_VBRK>-vkorg = '1101' or <LX_VBRK>-vkorg = '1102'.
 DATA : I_KOMV type TABLE OF komv,
        i_T685A type TABLE OF T685A,
        w_T685A type  T685A.
REFRESH: i_komv,i_t685a.
  if <LX_VBRK>-vbtyp = 'M'.
      i_komv[] = XKOMV[].
   sort i_komv by kschl.
   delete ADJACENT DUPLICATES from i_komv COMPARING kschl.
   delete i_komv where kschl is INITIAL.
   SELECT * from t685a into TABLE i_t685a FOR ALL ENTRIES IN i_komv where kschl = i_komv-kschl
                                                                    and   kmanu = 'C'.
   if i_t685a is not INITIAL.
     loop at i_t685a INTO  w_t685a .
       xkomv-kmanu = 'D'.
       MODIFY  XKOMV[] from xkomv TRANSPORTING KMANU WHERE KSCHL EQ w_t685a-kschl.
     CLEAR: w_t685a.
     endloop.
   endif.
   endif.
REFRESH: i_komv,i_t685a.
  if <LX_VBRK>-vbtyp = 'U' and  <LX_VBRK>-RFBSK = 'D'.
      i_komv[] = XKOMV[].
   sort i_komv by kschl.
   delete ADJACENT DUPLICATES from i_komv COMPARING kschl.
   delete i_komv where kschl is INITIAL.
   SELECT * from t685a into TABLE i_t685a FOR ALL ENTRIES IN i_komv where kschl = i_komv-kschl
                                                                    and   kmanu = 'C'.
   if i_t685a is not INITIAL.
     loop at i_t685a INTO  w_t685a .
       xkomv-kmanu = 'D'.
       MODIFY  XKOMV[] from xkomv TRANSPORTING KMANU WHERE KSCHL EQ w_t685a-kschl.
     CLEAR: w_t685a.
     endloop.
   endif.
   endif.
endif.
endif.
endif.
endif.
ENDENHANCEMENT.
