*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_UNIT_MASTER
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_UNIT_MASTER    .

  PERFORM TABLEPROC.

ENDFUNCTION.
