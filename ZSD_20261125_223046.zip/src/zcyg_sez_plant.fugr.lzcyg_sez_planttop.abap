FUNCTION-POOL ZCYG_SEZ_PLANT             MESSAGE-ID SV.

* INCLUDE LZCYG_SEZ_PLANTD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_SEZ_PLANTT00                      . "view rel. data dcl.
