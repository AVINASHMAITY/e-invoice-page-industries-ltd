"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBKD\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_VA02_STAT.
**IF sy-tcode = 'VA02' and vbak-vkorg = '5100'.
**  Data : gc_status TYPE JEST-STAT VALUE 'E0001', " In Progress
**         lv_objnr(22) TYPE c.
*BREAK JAYAMOT.
**  IF VBKD-ZTERM NE *VBKD-ZTERM OR VBAK-WAERK NE YVBAK-WAERK OR   " Changes Added By Harish on 22.07.2020 T.R->
****  IF VBKD-ZTERM NE YVBKD-ZTERM OR VBAK-WAERK NE YVBAK-WAERK OR
**     VBAK-KUNNR NE YVBAK-KUNNR OR VBAK-NETWR NE YVBAK-NETWR.
*** IF XVBAK-WAERK NE YVBAK-WAERK OR
***     XVBAK-KUNNR NE YVBAK-KUNNR OR XVBAK-NETWR NE YVBAK-NETWR.
***  CLEAR : LV_OBJNR.
***  CONCATENATE 'VB'
***              VBAK-VBELN
***              '000000' INTO LV_OBJNR.
***  CONDENSE LV_OBJNR.
***  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
***    EXPORTING
***            client              = sy-mandt
***            objnr               = lv_objnr
***            user_status         = gc_status
***          EXCEPTIONS
***            object_not_found    = 1
***            status_inconsistent = 2
***            status_not_allowed  = 3
***            OTHERS              = 4.
***  IF sy-subrc EQ 0.
***          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
***            EXPORTING
***              wait = 'X'.
***  ENDIF.
*** ENDIF.
*** IF XVBKD-ZTERM NE YVBKD-ZTERM .
***   IF XVBKD-UPDKZ = 'U' AND XVBKD-POSNR = '000000'.
***     CLEAR : LV_OBJNR.
***  CONCATENATE 'VB'
***              VBAK-VBELN
***              '000000' INTO LV_OBJNR.
***  CONDENSE LV_OBJNR.
***  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
***    EXPORTING
***            client              = sy-mandt
***            objnr               = lv_objnr
***            user_status         = gc_status
***          EXCEPTIONS
***            object_not_found    = 1
***            status_inconsistent = 2
***            status_not_allowed  = 3
***            OTHERS              = 4.
***  IF sy-subrc EQ 0.
***          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
***            EXPORTING
***              wait = 'X'.
***  ENDIF.
***
*** ENDIF.
*** ENDIF.
***ENDIF.
ENDENHANCEMENT.
