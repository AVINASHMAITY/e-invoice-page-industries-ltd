class ZCL_IM_IMPL_MD_DISPLAY_ELE definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MD_DISPLAY_ELEMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_IMPL_MD_DISPLAY_ELE IMPLEMENTATION.


  method IF_EX_MD_DISPLAY_ELEMENT~CHANGE_MDEZX_DELB0.
*    BREAK-POINT.
**    CH_DELB0 = 'X'.
*    ch_changed = 'X'.

  endmethod.


  method IF_EX_MD_DISPLAY_ELEMENT~CHANGE_MDEZX_EXTRA.
*    BREAK-POINT.
**    CH_EXTRA = 'X'.
*    ch_changed = 'X'.

  endmethod.
ENDCLASS.
