*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZOPEN_SALESORDER................................*
DATA:  BEGIN OF STATUS_ZOPEN_SALESORDER              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZOPEN_SALESORDER              .
CONTROLS: TCTRL_ZOPEN_SALESORDER
            TYPE TABLEVIEW USING SCREEN '0001'.
*...processing: ZSTOCK_TRANSIST.................................*
DATA:  BEGIN OF STATUS_ZSTOCK_TRANSIST               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSTOCK_TRANSIST               .
CONTROLS: TCTRL_ZSTOCK_TRANSIST
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZOPEN_SALESORDER              .
TABLES: *ZSTOCK_TRANSIST               .
TABLES: ZOPEN_SALESORDER               .
TABLES: ZSTOCK_TRANSIST                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
