"Name: \PR:SAPMV45A\FO:USEREXIT_PRICING_PREPARE_TKOMP\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_KOMP_PRICE_TO_HEADER.
*MOVE FIELD KOMP-NETWR TO VBAK-NETWR.
*&--------------------Modification Log-----------------
*Date       : 28.07.2017
*Programmer : Ravindran/Iteanz
*TR No.     : DR1K934377
*Description: Get data LT_SALES from ZSD_SALES_RETURN
*&-----------------------------------------------------
*---------------------------------------------------------------------*
*                         Modification Log                            *
*---------------------------------------------------------------------*
* Author/Company Name    Date         TR No.        Description       *
* Chaithanya / Iteanz  22.02.2018   DR1K938789    New Order Type ZBSR *
*---------------------------------------------------------------------*
*---------------------------------------------------------------------*
* Author/Company Name    Date         TR No.        Description       *
* Bhagavan / Iteanz  16.09.2021       DR1K959654    Added KNUMV value in
*                                                   XKOMV for Multiple Line
*                                                  Item conditions Z004, Z005, Z007*
*---------------------------------------------------------------------*
Break sahoo.
DATA : lv_result type kbetr,
       lv_kwert type kwert,
       lv_kwmeng type KWMENG.
data: lv1 type kwert,
      lv4 type kwert,
      lv2 type KWMENG,
      lv3  type  kbetr,
      lv5  type  kbetr,
      lv6  type  kbetr.
data : lv_kwert8 type kwert,
        lv_kwert9 type kwert,
        lv_kwert10 type kwert,
        lv_kwert11 type kwert,
        lv_kwert12 type kwert,
        lv_kwert13 type kwert,
        lv_kwert14 type kwert,  "
        lv_kwert15 type kwert,
        lv_kwert16 type kwert,
        lv_kwert17 type kwert,
        lw_xkomv2 type  komv.
data :  wa_vbap type vbap,
        LV_YB3R TYPE AUART VALUE 'YB3R'.          "Added by Ravi on 14.09.2017 DR1K935283
CLEAR: lv_kwert , LV_KWMENG.
 CLEAR: lv1 , LV2,lv3.
   IF VBAK-KALSM = 'ZINCFA'
      OR VBAK-KALSM = 'ZINCF2'.        "Added by Ravi on 22.08.2017 DR1K934860
If Vbak-VBTYP = 'H' or Vbak-VBTYP = 'L' or Vbak-VBTYP = 'K'.
Delete XKOMV where KSCHL = 'ZOCT'.
endif.
BREAK sahoo.
***********Begin of changes by Ravi on 28.07.2017************************************
   DATA : LT_SALES TYPE TABLE OF ZSD_COND,
          LS_SALES TYPE ZSD_COND,
          lv_kbetr TYPE kbetr.
    IMPORT LT_SALES FROM MEMORY ID 'SALES_COND'.
    IF NOT LT_SALES IS INITIAL
       AND sy-subrc IS INITIAL.
       READ TABLE xkomv with key
                          kschl = 'ZPSM'
                          kposn  = vbap-posnr.
       IF SY-subrc EQ 0.
         READ TABLE LT_SALES INTO LS_SALES WITH KEY ITM_NUMBER = vbap-posnr
                                                    cond_type  = 'ZPSM'.
         IF SY-SUBRC EQ 0.
           CLEAR : lv_kbetr.
           lv_kbetr = ls_sales-cond_value.
           xkomv-kbetr = lv_kbetr.
           xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
           MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'ZPSM'
                                    and kposn  = vbap-posnr .
         ENDIF.

       ENDIF.

       READ TABLE xkomv with key
                          kschl = 'ZPRM'
                          kposn  = vbap-posnr.
       IF SY-subrc EQ 0.
         READ TABLE LT_SALES INTO LS_SALES WITH KEY ITM_NUMBER = vbap-posnr
                                                    cond_type  = 'ZPRM'.
         IF SY-SUBRC EQ 0.
           CLEAR : lv_kbetr.
           lv_kbetr = ls_sales-cond_value.
           xkomv-kbetr = lv_kbetr.
           xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
           MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'ZPRM'
                                    and kposn  = vbap-posnr .
         ENDIF.

       ENDIF.
*****************Begin of changes by Ravi on 21.11.2018 DR1K942763**************


       READ TABLE xkomv with key kschl = 'Z004'
                                kposn  = vbap-posnr.
       IF SY-subrc EQ 0.
         READ TABLE LT_SALES INTO LS_SALES WITH KEY ITM_NUMBER = vbap-posnr
                                                    cond_type  = 'Z004'.
         IF SY-SUBRC EQ 0.
           CLEAR : lv_kbetr.
           lv_kbetr = ls_sales-cond_value.
           xkomv-kbetr = lv_kbetr.
           xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
           MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'Z004'
                                             and kposn  = vbap-posnr .
         ENDIF.
       ENDIF.

       READ TABLE xkomv with key kschl = 'Z005'
                                kposn  = vbap-posnr.
       IF SY-subrc EQ 0.
         READ TABLE LT_SALES INTO LS_SALES WITH KEY ITM_NUMBER = vbap-posnr
                                                    cond_type  = 'Z005'.
         IF SY-SUBRC EQ 0.
           CLEAR : lv_kbetr.
           lv_kbetr = ls_sales-cond_value.
           xkomv-kbetr = lv_kbetr.
           xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
           MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'Z005'
                                             and kposn  = vbap-posnr .
**            *           ****************Code Starts by Bhagavan On 03/09/21 "DR1K959654******************************************************
*            ELSE.
*
*            IF SY-TCODE = 'ZSD_SALE_RETURN'.
*              CLEAR : LV_KBETR.
*              LV_KBETR = LS_SALES-COND_VALUE.
*              XKOMV-KBETR = LV_KBETR.
*              XKOMV-KPOSN = VBAP-POSNR.
*              APPEND XKOMV TO XKOMV  .
*            ENDIF.
**           ****************Code Ends by Bhagavan On 03/09/21 "DR1K959654******************************************************
         ENDIF.
       ENDIF.

       READ TABLE xkomv with key kschl = 'Z007'
                                kposn  = vbap-posnr.
       IF SY-subrc EQ 0.
         READ TABLE LT_SALES INTO LS_SALES WITH KEY ITM_NUMBER = vbap-posnr
                                                    cond_type  = 'Z007'.
         IF SY-SUBRC EQ 0.
           CLEAR : lv_kbetr.
           lv_kbetr = ls_sales-cond_value.
           xkomv-kbetr = lv_kbetr.
           xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
           MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'Z007'
                                             and kposn  = vbap-posnr .
*           ****************Code Starts by Bhagavan On 12/08/21 "DR1K959654******************************************************
*         ELSE.
*           DATA : LV_INDEX  TYPE TABIX.
*            DESCRIBE TABLE XKOMV LINES LV_INDEX .
*            IF SY-TCODE = 'ZSD_SALE_RETURN'.
*              CLEAR : LV_KBETR.
*              LV_KBETR = LS_SALES-COND_VALUE.
*              XKOMV-KBETR = LV_KBETR.
*              XKOMV-KPOSN = VBAP-POSNR.
*              append XKOMV TO XKOMV  ." WHERE KSCHL EQ 'Z007'.
*              INSERT XKOMV INTO XKOMV INDEX lv_index ." WHERE KSCHL EQ 'Z007'.
*              MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'Z007'
*              AND KPOSN  = VBAP-POSNR .
*            ENDIF.
         ENDIF.
*           ****************Code Ends by Bhagavan On 12/08/21 "DR1K959654******************************************************
       ENDIF.

       READ TABLE xkomv with key kschl = 'Z0BF'
                                kposn  = vbap-posnr.
       IF SY-subrc EQ 0.
         READ TABLE LT_SALES INTO LS_SALES WITH KEY ITM_NUMBER = vbap-posnr
                                                    cond_type  = 'Z0BF'.
         IF SY-SUBRC EQ 0.
           CLEAR : lv_kbetr.
           lv_kbetr = ls_sales-cond_value.
           xkomv-kbetr = lv_kbetr.
           xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
           MODIFY XKOMV TRANSPORTING KBETR WHERE KSCHL EQ 'Z0BF'
                                             and kposn  = vbap-posnr .
         ENDIF.
       ENDIF.
*****************End of changes by Ravi on 21.11.2018 DR1K942763**************
    ENDIF.
***********End of changes by Ravi on 28.07.2017**************************************
****************************************Code Starts by Bhagavan on 18/12/2020 DR1K953998
if sy-tcode = 'ZSD_QUOT_SO'.
data: count type i,
      lv_index type i.
clear :count , lv_index.
*sort xkomv by kschl kposn descending.
*DELETE ADJACENT DUPLICATES FROM  XKOMV COMPARING KPOSN KSCHL KBETR.
loop at xkomv where kschl = 'Z004' and kposn  = vbap-posnr .
lv_index = sy-tabix.
count = count + 1.
if count > 1.
delete xkomv where kschl = 'Z004' and kposn  = vbap-posnr and kbetr  = '0' .
if sy-subrc ne '0'.

delete xkomv index ( lv_index - 1 ).

endif.
endif.

endloop.

clear :count , lv_index.
LOOP AT xkomv WHERE kschl = 'Z007' and kposn  = vbap-posnr .
lv_index = sy-tabix.
count = count + 1.
if count > 1.
delete xkomv where kschl = 'Z007' and kposn  = vbap-posnr and kbetr  = '0' .
if sy-subrc ne '0'.
delete xkomv index ( lv_index - 1 ).
endif.
endif.

endloop.

clear :count , lv_index.
LOOP AT xkomv WHERE kschl = 'Z005' and kposn  = vbap-posnr .
lv_index = sy-tabix.
count = count + 1.
if count > 1.
delete xkomv where kschl = 'Z005' and kposn  = vbap-posnr and kbetr  = '0' .
if sy-subrc ne '0'.
delete xkomv index ( lv_index - 1 ).
endif.
endif.

endloop.



endif.

****************************************Code ends by Bhagavan on 18/12/2020 DR1K953998 ***********

   READ TABLE XKOMV with key KSCHL = 'ZPTR'
                          kposn  = vbap-posnr .
   IF SY-SUBRC = 0.
    CLEAR: lv1 , LV2 ,LV3.
*  if sy-tcode = 'VA02'.
*   if Yvbap[] is not INITIAL.
*    Read TABLE Yvbap[] INTO wa_vbap with key posnr =  vbap-posnr
*                                 KWMENG = VBAP-KWMENG.
*    if sy-subrc ne 0 .
*     CLEAR : XKOMV-kwert.
*    endif.
*   endif.
*  endif.
       lv1 = XKOMV-kwert.
       IF VBAK-auart  = 'YBCR' OR VBAK-auart  = 'YBDR'
          OR VBAK-AUART  = LV_YB3R OR VBAK-auart  = 'YBSR' OR VBAK-AUART = 'YBCD'. "Added YBCD Pranesh DR1K947516  "Added by Ravi on 14.09.2017 DR1K935283
       lv2 = VBAP-ZMENG.
       ELSE.
       lv2 = VBAP-KWMENG.
       ENDIF.
       if lv2 is not INITIAL.
      CALL FUNCTION 'ZFM_SD_ROUTINE_QTY'
       EXPORTING
         LV_KWERT        = lv1
         LV_KWMENG       = lv2
       IMPORTING
         LV_RESULT       =  lv3.
                 .
       endif.
      XKOMV-kbetr  = lv3.

       xkomv-kwert =  XKOMV-kbetr *  lv2 .
      xkomv-kwert = xkomv-kwert / 1000.
      lv_kwert8 = xkomv-kwert.
      xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
*        break sahoo.
*   XKOMV-KBETR = XKOMV-KBETR .
   MODIFY XKOMV TRANSPORTING KBETR kwert WHERE KSCHL EQ 'ZPTR'
                                    and kposn  = vbap-posnr .

  endif.
*       clear :lw_xkomv1.

   READ TABLE XKOMV with key KSCHL = 'ZPTS'
                          kposn  = vbap-posnr .
*   break sahoo.
  IF SY-SUBRC = 0.
    CLEAR : lw_xkomv2.
     read table xkomv into lw_xkomv2 with key
                          kschl = 'ZPSM'
                          kposn  = vbap-posnr.
       if sy-subrc  = 0.
       lv_kwert9 = lw_xkomv2-kwert.
       endif.
       clear :lw_xkomv2.

**********Begin of Changes by Ravi on 11.03.2019 DR1K944407*******************
******Read table Xkomv for kaschl JVAT****
       read table xkomv into lw_xkomv2 with key
                          kschl = 'ZPS1'
                          kposn  = vbap-posnr.
       if sy-subrc  = 0.
       lv_kwert10 = lw_xkomv2-kwert.
       endif.
       clear :lw_xkomv2.
**********Begin of Changes by Ravi on 11.03.2019 DR1K944407*******************
       lv_kwert11  =  lv_kwert8 + lv_kwert9.
       lv_kwert12  = lv_kwert11 +  lv_kwert10.

       clear :lw_xkomv2.
    CLEAR: lv1 , LV2 ,LV3.

      lv1 = lv_kwert12 ." XKOMV-kwert.
      IF VBAK-auart  = 'YBCR' OR VBAK-auart  = 'YBDR' OR VBAK-auart  = 'YBSR'
         OR VBAK-AUART  = LV_YB3R OR VBAK-AUART = 'YBCD'. "Added YBCD Pranesh DR1K947516       "Added by Ravi on 14.09.2017 DR1K935283
       lv2 = VBAP-ZMENG.
       ELSE.
       lv2 = VBAP-KWMENG.
       endif.
       if lv2 is not INITIAL.

      CALL FUNCTION 'ZFM_SD_ROUTINE_QTY'
       EXPORTING
         LV_KWERT        = lv1
         LV_KWMENG       = lv2
       IMPORTING
         LV_RESULT       =  lv3.
                 .
       endif.
      XKOMV-kbetr  = lv3.
      xkomv-kwert =  XKOMV-kbetr *  lv2 .
      xkomv-kwert = xkomv-kwert / 1000.
      xkomv-knumv = ls_sales-doc_cond_no.             " Added by bhagavan on 16.09.2021 " DR1K959654
    MODIFY  XKOMV TRANSPORTING KBETR kwert  WHERE KSCHL EQ 'ZPTS'
                                and kposn  = vbap-posnr .

 endif.

   ENDIF.
    CLEAR: lv1 , LV2,lv3.

ENDENHANCEMENT.
