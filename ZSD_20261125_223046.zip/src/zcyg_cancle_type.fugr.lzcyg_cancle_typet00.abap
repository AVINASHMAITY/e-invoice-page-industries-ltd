*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_CANCLE_TYPE................................*
DATA:  BEGIN OF STATUS_ZCYG_CANCLE_TYPE              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_CANCLE_TYPE              .
CONTROLS: TCTRL_ZCYG_CANCLE_TYPE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_CANCLE_TYPE              .
TABLES: ZCYG_CANCLE_TYPE               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
