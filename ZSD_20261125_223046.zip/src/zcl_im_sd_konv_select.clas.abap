class ZCL_IM_SD_KONV_SELECT definition
  public
  final
  create public .

public section.

  interfaces IF_EX_SD_KONV_SELECT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_SD_KONV_SELECT IMPLEMENTATION.


  method IF_EX_SD_KONV_SELECT~DATA_SELECTION.
*    BREAK PUSHPA.
  endmethod.
ENDCLASS.
