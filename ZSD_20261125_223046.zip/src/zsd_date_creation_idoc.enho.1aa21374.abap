"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_DATE_CREATION_IDOC.
*&------------------------------------------------------------------------------
*Date       : 25.05.2023
*Programmer : Sumit
*TR No.     : DR1K975334
*TR No.     : DR1K975848
*Description: Enhancment for last contact date and payment Term & PO header text
*&------------------------------------------------------------------------------
DATA : lv_idoc TYPE char1.
DATA : lv_ZTERM TYPE knb1-ZTERM.
DATA : lv_belnr TYPE VBAK-zzebeln.

import lv_idoc from MEMORY id 'LV_IDOC'.

If Sy-tcode = 'VA01' and lv_idoc = 'X'.
VBAK-MAHDT = sy-datum.

*****PO header text DR1K975848
*Import lv_belnr from MEMORY id 'LV_AUGRU'.
IMPORT lv_belnr from MEMORY id 'LV_BELNR'.
VBAK-zzebeln = lv_belnr.
*****PO header text DR1K975848

**import lv_ZTERM from MEMORY id 'ZTERM'.
*VBKD-ZTERM = lv_ZTERM.

endif.
ENDENHANCEMENT.
