"Name: \PR:SAPMV86E\FO:SHIFT_REST_TO_X\SE:END\EI
ENHANCEMENT 0 ZSD_SYG_DMS_LINK_USR.
"Code added by CC on 15.11.2019 DR1K948316
"Purpose::DMS attachment link in VX11N
if fcode = 'ZDMS_LINK' and ( sy-tcode = 'VX12N' or sy-tcode = 'VX13N' ).
SUBMIT ZRDMS_VX12N_ATTACHMENT_LIST AND RETURN.
endif.
"Code ended by CC
ENDENHANCEMENT.
