"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBKD\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_PAY_TERM_IDOC.
*&----------------------------------------------------------------
*Date       : 25.05.2023
*Programmer : Sumit
*TR No.     : DR1K975447
*Description: Enhancment for payment Term
*&----------------------------------------------------------------
DATA : lv_idoc TYPE char1.
DATA : lv_ZTERM TYPE knb1-ZTERM.
data:lv_check_flag type char1.

import lv_idoc from MEMORY id 'LV_IDOC'.

If Sy-tcode = 'VA01' and lv_idoc = 'X'.

import lv_check_flag from memory id 'lv_flag'.

if lv_check_flag = ''.

lv_check_flag = 'X'.
EXPORT lv_check_flag to memory id 'lv_flag'.

clear:lv_ZTERM.
Select single zterm from knvv into lv_ZTERM
where
KUNNR = XVBPA-KUNNR and
VKORG = XVBAK-VKORG and
VTWEG = XVBAK-VTWEG and
SPART = XVBAK-SPART.

VBKD-ZTERM = lv_ZTERM.
export lv_ZTERM TO MEMORY ID 'ZTERM'.

endif.
endif.

ENDENHANCEMENT.
