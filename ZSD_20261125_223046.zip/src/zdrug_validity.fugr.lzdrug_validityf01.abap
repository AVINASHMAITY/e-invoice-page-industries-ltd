*----------------------------------------------------------------------*
***INCLUDE LZDRUG_VALIDITYF01.
*----------------------------------------------------------------------*

FORM check_notinitial.

  IF zdrug_validity-kunnr IS INITIAL OR zdrug_validity-drug_licno IS INITIAL
     OR zdrug_validity-valid_from  IS INITIAL OR zdrug_validity-valid_to IS INITIAL.
    MESSAGE 'Fields Cannot Be Empty' TYPE 'E'.
  ENDIF.

  IF zdrug_validity-valid_from > zdrug_validity-valid_to .
    MESSAGE 'From Date Cannot Be Greater Than To Date' TYPE 'E'.
  ENDIF.


ENDFORM.
