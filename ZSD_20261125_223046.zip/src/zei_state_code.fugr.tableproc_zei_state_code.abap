*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZEI_STATE_CODE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZEI_STATE_CODE      .

  PERFORM TABLEPROC.

ENDFUNCTION.
