*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_SALES
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_SALES           .

  PERFORM TABLEPROC.

ENDFUNCTION.
