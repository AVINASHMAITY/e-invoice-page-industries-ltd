/*
----------------------------------------------------------
Object Name           : ZV_MIS_BOE
Author/Comapny Name   : Chandra Mohan/ITEANZ
Transport Request     : DR1K938213
Creation Date         : 19.01.2018
----------------------------------------------------------
Description : Bill of entry
----------------------------------------------------------
*/
@AbapCatalog.sqlViewName: 'ZSV_MIS_BOE'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@ClientDependent: true
@EndUserText.label: 'MIS View for BoE'
define view ZV_MIS_BOE as select from /obiz/zmb_beshd as _BOEREF
left outer join /obiz/zmb_behdr as _BOEH
    on _BOEREF.boetype = _BOEH.doctype
    and _BOEREF.boerefno = _BOEH.docno
    and _BOEREF.boeyr = _BOEH.docyear 
//left outer join /obiz/zmb_beitm as _BOEI
//    on _BOEH.doctype = _BOEI.doctype
//    and _BOEH.docno = _BOEI.docno
//    and _BOEH.docyear = _BOEI.docyear
{
    _BOEREF.refdocno as REFDOCNO,
    _BOEREF.refdocdat as refdocdat,
    _BOEH.docno as DOCNO,
    _BOEH.boedate as BOEDATE
    
}
