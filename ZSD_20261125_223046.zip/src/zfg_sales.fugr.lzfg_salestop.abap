FUNCTION-POOL ZFG_SALES                  MESSAGE-ID SV.

* INCLUDE LZFG_SALESD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_SALEST00                           . "view rel. data dcl.
