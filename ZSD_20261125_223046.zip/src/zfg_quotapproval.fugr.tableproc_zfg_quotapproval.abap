*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_QUOTAPPROVAL
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_QUOTAPPROVAL    .

  PERFORM TABLEPROC.

ENDFUNCTION.
