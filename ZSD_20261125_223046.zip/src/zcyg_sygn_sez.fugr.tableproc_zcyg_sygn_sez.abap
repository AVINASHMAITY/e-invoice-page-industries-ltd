*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_SYGN_SEZ
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_SYGN_SEZ       .

  PERFORM TABLEPROC.

ENDFUNCTION.
