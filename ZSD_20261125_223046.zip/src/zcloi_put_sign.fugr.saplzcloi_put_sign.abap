*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCLOI_PUT_SIGNTOP.                " Global Data
  INCLUDE LZCLOI_PUT_SIGNUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCLOI_PUT_SIGNF...                " Subroutines
* INCLUDE LZCLOI_PUT_SIGNO...                " PBO-Modules
* INCLUDE LZCLOI_PUT_SIGNI...                " PAI-Modules
* INCLUDE LZCLOI_PUT_SIGNE...                " Events
* INCLUDE LZCLOI_PUT_SIGNP...                " Local class implement.
* INCLUDE LZCLOI_PUT_SIGNT99.                " ABAP Unit tests
