"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SO_POTYPE.

""""SOC by Madhur on 150824
DATA: ls_mvgr2_vkorg TYPE ztabap_tvarvc,
      ls_mvgr2_vtweg TYPE ztabap_tvarvc,
      ls_mvgr2_spart TYPE ztabap_tvarvc.
*BOC by samata/PWC 03.09.2024 DR1K987540
DATA: lt_mvgr2_vkorg TYPE TABLE OF ztabap_tvarvc,
      lt_mvgr2_vtweg TYPE TABLE OF ztabap_tvarvc,
      lt_mvgr2_spart TYPE TABLE OF ztabap_tvarvc.
*EOC by samata/PWC 03.09.2024 DR1K987540
DATA: lv_flag_mvgr2 TYPE c.
  CLEAR: ls_mvgr2_vkorg,ls_mvgr2_vtweg,ls_mvgr2_spart,lv_flag_mvgr2.

    IF ( ( sy-ucomm = 'SICH' OR sy-ucomm = 'YES' ) AND ( sy-tcode = 'VA01' or sy-tcode = 'VA02' ) ) .
*      BOC by samata/PWC 03.09.2024 DR1K987540
*      SELECT SINGLE * FROM ztabap_tvarvc INTO ls_mvgr2_vkorg WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
*                                                                    AND name = 'VKORG'
*                                                                    AND type = 'S'.
*        IF ls_mvgr2_vkorg-low = vbak-vkorg.
*          SELECT SINGLE * FROM ztabap_tvarvc INTO ls_mvgr2_vtweg WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
*                                                              AND name = 'VTWEG'
*                                                              AND type = 'S'.
*            IF ls_mvgr2_vtweg-low = vbak-vtweg.
*              SELECT SINGLE * FROM ztabap_tvarvc INTO ls_mvgr2_SPART WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
*                                                              AND name = 'SPART'
*                                                              AND type = 'S'.
*               IF ls_mvgr2_spart-low = vbak-spart.
*                 LOOP AT xvbap INTO DATA(vbap_mvgr2).
*                   IF vbap_mvgr2-mvgr2 IS INITIAL.
*                     lv_flag_mvgr2 = 'X'.
*                   ENDIF.
*
*                 ENDLOOP.
*                ENDIF.
*            ENDIF.
*        ENDIF.
       SELECT * FROM ztabap_tvarvc INTO TABLE lt_mvgr2_vkorg WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
                                                                    AND name = 'VKORG'
                                                                    AND type = 'S'.
       SELECT * FROM ztabap_tvarvc INTO TABLE lt_mvgr2_vtweg WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
                                                              AND name = 'VTWEG'
                                                              AND type = 'S'.
       SELECT * FROM ztabap_tvarvc INTO TABLE lt_mvgr2_SPART WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
                                                              AND name = 'SPART'
                                                              AND type = 'S'.
        READ TABLE lt_mvgr2_vkorg into ls_mvgr2_vtweg with key low = vbak-vkorg.
        IF sy-subrc = 0 .
         READ TABLE lt_mvgr2_vtweg into ls_mvgr2_vkorg with key low = vbak-vtweg.
         IF sy-subrc = 0 .
            READ TABLE lt_mvgr2_SPART into ls_mvgr2_SPART with key low = vbak-spart.
         IF sy-subrc = 0.
            LOOP AT xvbap INTO DATA(vbap_mvgr2).
                   IF vbap_mvgr2-mvgr2 IS INITIAL.
                     lv_flag_mvgr2 = 'X'.
                   ENDIF.
           ENDLOOP.
         ENDIF.
         ENDIF.
        ENDIF.
*       EOC by samata/PWC 03.09.2024 DR1K987540
        IF lv_flag_mvgr2 = 'X'.
          MESSAGE '(Material Group 2) PO type cannot be blank for Sales Org, Division, Dist Channel' TYPE 'E'.
*          MESSAGE '"PO Type" cannot be blank for Sales Org, Division, Dist Channel' TYPE 'E'.
        ENDIF.
    ENDIF.
""""EOC by Madhur on 150824
ENDENHANCEMENT.
