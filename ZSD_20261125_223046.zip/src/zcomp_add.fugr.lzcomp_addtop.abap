FUNCTION-POOL ZCOMP_ADD                  MESSAGE-ID SV.

* INCLUDE LZCOMP_ADDD...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCOMP_ADDT00                           . "view rel. data dcl.
