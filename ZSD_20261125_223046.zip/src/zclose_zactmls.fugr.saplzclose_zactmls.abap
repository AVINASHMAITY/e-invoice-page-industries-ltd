*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCLOSE_ZACTMLSTOP.                " Global Data
  INCLUDE LZCLOSE_ZACTMLSUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCLOSE_ZACTMLSF...                " Subroutines
* INCLUDE LZCLOSE_ZACTMLSO...                " PBO-Modules
* INCLUDE LZCLOSE_ZACTMLSI...                " PAI-Modules
* INCLUDE LZCLOSE_ZACTMLSE...                " Events
* INCLUDE LZCLOSE_ZACTMLSP...                " Local class implement.
* INCLUDE LZCLOSE_ZACTMLST99.                " ABAP Unit tests
  INCLUDE LZCLOSE_ZACTMLSF00                      . " subprograms
  INCLUDE LZCLOSE_ZACTMLSI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
