FUNCTION-POOL ZCLOI_PUT_SIGN.               "MESSAGE-ID ..
TYPE-POOLS:
  CLOI.

*----------------------------------------------------------------------*
*--                     Internal tables                              --*
*----------------------------------------------------------------------*
DATA: CONV_INDEX TYPE CLOI_CONV_TAB WITH HEADER LINE,
      UNIT_INDEX TYPE CLOI_CONV_TAB WITH HEADER LINE,
      COND_INDEX TYPE CLOI_CONV_TAB WITH HEADER LINE,
      CURR_INDEX TYPE CLOI_CONV_TAB WITH HEADER LINE.

*----------------------------------------------------------------------*
*--                     Fields                                       --*
*----------------------------------------------------------------------*
DATA: CONV_LINES LIKE SY-TABIX,
      UNIT_LINES LIKE SY-TABIX,
      COND_LINES LIKE SY-TABIX,
      CURR_LINES LIKE SY-TABIX.
* INCLUDE LZCLOI_PUT_SIGND...                " Local class definition
