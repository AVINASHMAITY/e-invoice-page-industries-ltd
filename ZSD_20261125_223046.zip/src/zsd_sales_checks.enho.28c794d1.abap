"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SALES_CHECKS.


TYPES:BEGIN OF ty_mch1,
      matnr	TYPE matnr,  "Material Number
      charg	TYPE charg_d,"Batch Number

      laeda	TYPE laeda,  "Date of Last Change
      vfdat	TYPE vfdat,  "Shelf Life Expiration or Best-Before Date
      END OF ty_mch1.

TYPES:BEGIN OF ty_ztsd_b_so.
        INCLUDE TYPE ztsd_blocked_so.
TYPES:END OF ty_ztsd_b_so.

DATA:li_ztsd_b_so TYPE STANDARD TABLE OF ty_ztsd_b_so,
     li_ztsd_b_so2 TYPE STANDARD TABLE OF ty_ztsd_b_so,
     li_ztsd_b_so3 TYPE STANDARD TABLE OF ty_ztsd_b_so,
     lw_ztsd_b_so TYPE ty_ztsd_b_so,
     lw_yvbap TYPE vbap,
     lw_xvbap TYPE vbap,
     lw_yvbkd TYPE vbkd,
     lw_xvbkd TYPE vbkd,
     lw_xkomv TYPE komv,
     lw_knvv  TYPE knvv,
     li_mch1 TYPE STANDARD TABLE OF ty_mch1,
     lw_mch1 TYPE ty_mch1.

DATA:lv_kwmeng_f TYPE flag,
     lv_charg_f TYPE flag.


FIELD-SYMBOLS:<fs_ztsd_b_so> TYPE ty_ztsd_b_so.

CONSTANTS:c_va01 TYPE syst_tcode VALUE 'VA01',
          c_va02 TYPE syst_tcode VALUE 'VA02',
          c_1102 TYPE vkorg VALUE '1102',
          c_ztnn TYPE pstyv VALUE 'ZTNN',
          c_z004 TYPE kscha VALUE 'Z004',
          c_z005 TYPE kscha VALUE 'Z005',
          c_z007 TYPE kscha VALUE 'Z007',
          c_z1 TYPE lifsk VALUE 'Z1',
          c_0 TYPE i VALUE '0',
          c_x  TYPE flag VALUE 'X'.



******
********Changes for authorization check against block SO
******** Made by Parul Kumar Sharma
******
******DATA   : lW_ZAUTH TYPE ZAUTH,
******         IT_ZAUTH type table of ZAUTH.
******DATA   : lv_vbeln type vbeln..
******
******IF SY-TCODE = 'VA02'.
******      SELECT single SNO
******             VKORG
******             VTWEG
******             AUART
******             USERID
******             UNAME
******        FROM ZAUTH
******        INTO lW_ZAUTH"IT_ZAUTH
******        WHERE USERID = SY-UNAME
******        and vkorg = vbak-vkorg
******        and vtweg = vbak-vtweg
******        and auart = vbak-auart.
******        IF sy-subrc <> 0.
******           select single vbeln into lv_vbeln
******              from ZTSD_BLOCKED_SO
******              where VBELN = vbak-vbeln
******              and  REJECTED = 'X'.
******            IF sy-subrc = 0.
******              message 'You are not aothorised to change a blocked SO.'
******              type 'E'.
******            ENDIF.
******        ENDIF.
******
******endif.
******** Made by Parul Kumar Sharma
********Changes for authorization check against block SO

*-->Trigerring Credit Workflow

types : begin of lt_mch1,
          MATNR	TYPE MATNR,
          CHARG	TYPE CHARG_D,
          VFDAT	TYPE VFDAT,
          HSDAT	TYPE HSDAT,
        end of lt_mch1,

        begin of lt_mara,
          matnr type matnr,
          MHDRZ	TYPE MHDRZ,
        end of lt_mara.
data : li1_mch1 type table of lt_mch1,
       lw1_mch1 type lt_mch1,
       li_mara type table of lt_mara,
       lw_mara type lt_mara,
       lv_days type numc5.

  select MATNR
          CHARG
          VFDAT
          HSDAT
         into table li1_mch1
         from mch1
         for all entries in xvbap[]
         where matnr = xvbap-matnr
         and charg = xvbap-charg.
    IF sy-subrc = 0.
      sort li1_mch1 by matnr charg.
      select matnr MHDRZ
             into table li_mara
             from mara
             for all entries in li1_mch1
             where matnr = li1_mch1-matnr.
        IF sy-subrc = 0.
         sort li_mara by matnr.
        ENDIF.
    ENDIF.

data:WI_CONTAINER_VALUES LIKE SWACONEXTV  OCCURS 0 WITH HEADER LINE,
     lv_work_id type SWR_STRUCT-WORKITEMID,
     lv_ATT_LIST type  SOATTLSTI1 OCCURS 0 WITH HEADER LINE.

break praveens.


IF ( sy-tcode = c_va01 OR  sy-tcode = 'ZSD_QUOT_SO' ) AND vbak-vkorg = c_1102 and VBUK-CMGST = 'B'.  " 'Zsd_quot_so'Added by Bhagavan on 06.11.2020  DR1K953998

*WI_CONTAINER_VALUES-ELEMENT = 'I_VBELN'.
*WI_CONTAINER_VALUES-value = VBAk-vbeln.
*append WI_CONTAINER_VALUES.
*
*CALL FUNCTION 'SWU_START_WORKFLOW'
*  EXPORTING
*    task                  = 'WS90100023'
**   LANGUAGE              = SY-LANGU
*    user                  = sy-uname
**   SENDER_ID             =
* IMPORTING
**   RETURN_CODE           =
*   WORKITEM_ID           = lv_work_id
*  TABLES
*   CONTAINER             = WI_CONTAINER_VALUES
**   MESSAGE_LINES         =
*    attachment_list       =     lv_ATT_LIST
*     .


endif.

**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************

*-->Check When Create
*IF sy-tcode = c_va01 AND vbak-vkorg = c_1102 and vbak-lifsk = c_z1.
IF ( sy-tcode = c_va01 OR  sy-tcode = 'ZSD_QUOT_SO' )  AND vbak-vkorg IN ra_vkorg and vbak-lifsk = c_z1.  "Added by Ravi on 06.06.2019 DR1K945737   " 'Zsd_quot_so'Added by Bhagavan on 06.11.2020  DR1K953998

  CLEAR:li_ztsd_b_so,lw_ztsd_b_so.

*-->Check Item Category
  LOOP AT xvbap INTO lw_xvbap WHERE pstyv = c_ztnn.
    lw_ztsd_b_so-vbeln = vbak-vbeln.
    lw_ztsd_b_so-posnr = lw_xvbap-posnr.
    lw_ztsd_b_so-zchang = sy-datum.
    lw_ztsd_b_so-pstyv = c_ztnn.
    APPEND lw_ztsd_b_so TO li_ztsd_b_so.
    CLEAR:lw_ztsd_b_so.
  ENDLOOP.


*-->Check Item Condition Type.
  SORT li_ztsd_b_so BY vbeln posnr.
  LOOP AT xkomv INTO lw_xkomv WHERE kschl = c_z004 OR kschl = c_z005 OR kschl = c_z007.
    CLEAR:lw_ztsd_b_so.
    IF lw_xkomv-kschl = c_z004 AND lw_xkomv-kbetr ne  c_0.
      lw_ztsd_b_so-kbetr_4 = lw_xkomv-kbetr.
    ENDIF.
    IF lw_xkomv-kschl = c_z005 AND lw_xkomv-kbetr ne  c_0.
      lw_ztsd_b_so-kbetr_5 = lw_xkomv-kbetr.
    ENDIF.
    IF lw_xkomv-kschl = c_z007 AND lw_xkomv-kbetr ne  c_0.
      lw_ztsd_b_so-kbetr_7 = lw_xkomv-kbetr.
    ENDIF.

    IF lw_ztsd_b_so-kbetr_4 IS NOT INITIAL OR lw_ztsd_b_so-kbetr_5 IS NOT INITIAL OR lw_ztsd_b_so-kbetr_7 IS NOT INITIAL.
      SORT li_ztsd_b_so BY vbeln posnr.
      READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = vbak-vbeln
                                                                 posnr = lw_xkomv-KPOSN BINARY SEARCH.
      IF sy-subrc = 0.
        <fs_ztsd_b_so>-zchang = sy-datum.
        IF lw_xkomv-kschl = c_z004.
        <fs_ztsd_b_so>-kbetr_4 = lw_ztsd_b_so-kbetr_4.
        ELSEIF lw_xkomv-kschl = c_z005.
        <fs_ztsd_b_so>-kbetr_5 = lw_ztsd_b_so-kbetr_5.
        ELSEIF lw_xkomv-kschl = c_z007.
        <fs_ztsd_b_so>-kbetr_7 = lw_ztsd_b_so-kbetr_7.
        ENDIF.
      ELSE.
          lw_ztsd_b_so-vbeln = vbak-vbeln.
          lw_ztsd_b_so-posnr = lw_xkomv-kposn.
          lw_ztsd_b_so-zchang = sy-datum.

          APPEND lw_ztsd_b_so TO li_ztsd_b_so.
          CLEAR:lw_ztsd_b_so.
        ENDIF.
      ENDIF.
    ENDLOOP.


*-->Batch Number Change
  IF xvbap IS NOT INITIAL.
    SELECT matnr charg laeda vfdat FROM mch1
           INTO TABLE li_mch1
           FOR ALL ENTRIES IN xvbap
           WHERE matnr = xvbap-matnr.
    IF sy-subrc = 0.
      SORT li_mch1 BY vfdat laeda.
      DELETE ADJACENT DUPLICATES FROM li_mch1 COMPARING matnr.
      SORT li_mch1 BY matnr.
      SORT li_ztsd_b_so BY vbeln posnr.
      CLEAR:lw_ztsd_b_so.
      LOOP AT xvbap INTO lw_xvbap.
*        READ TABLE li_mch1 INTO lw_mch1 WITH KEY matnr = lw_xvbap-matnr BINARY SEARCH.
*        IF sy-subrc = 0.
*          IF lw_mch1-charg NE lw_xvbap-charg.
*            vbak-lifsk = c_z1.
*            READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = vbak-vbeln
*                                                                      posnr = lw_xvbap-posnr BINARY SEARCH.
*            IF sy-subrc = 0.
*              <fs_ztsd_b_so>-charg = lw_xvbap-charg.
*              <fs_ztsd_b_so>-kwmeng = lw_xvbap-kwmeng.
*            ELSE.
*              lw_ztsd_b_so-vbeln = vbak-vbeln.
*              lw_ztsd_b_so-posnr = lw_xvbap-posnr.
*              lw_ztsd_b_so-zchang = sy-datum.
*              lw_ztsd_b_so-charg = lw_xvbap-charg.
*              APPEND lw_ztsd_b_so TO li_ztsd_b_so.
*              CLEAR:lw_ztsd_b_so.
*              SORT li_ztsd_b_so BY vbeln posnr.
*            ENDIF.
*          ENDIF.
*        ENDIF.
       read table li1_mch1 into lw1_mch1
                          with key matnr = lw_xvbap-matnr
                                   charg = lw_Xvbap-charg.
       IF sy-subrc = 0.
        read table li_mara into lw_mara
                            with key matnr = lw1_mch1-matnr.
        IF sy-subrc = 0.
          lv_days = lw1_mch1-vfdat - lw1_mch1-hsdat.
         IF lv_days < lw_mara-mhdrz.
          vbak-lifsk = c_z1.
            unassign <fs_ztsd_b_so>.
       READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = vbak-vbeln
                                                                      posnr = lw_xvbap-posnr BINARY SEARCH.
            IF <fs_ztsd_b_so> is assigned.
              <fs_ztsd_b_so>-kwmeng = lw_xvbap-kwmeng.
            ELSE.
              clear lw_ztsd_b_so.
              lw_ztsd_b_so-vbeln = vbak-vbeln.
              lw_ztsd_b_so-posnr = lw_xvbap-posnr.
              lw_ztsd_b_so-zchang = sy-datum.
              lw_ztsd_b_so-charg = lw_xvbap-charg.
              lw_ztsd_b_so-kwmeng = lw_xvbap-kwmeng.
              APPEND lw_ztsd_b_so TO li_ztsd_b_so.
              CLEAR:lw_ztsd_b_so.
              SORT li_ztsd_b_so BY vbeln posnr.
      endif.
         ENDIF.
       ENDIF.
       endif.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDIF.

*****
  IF vbak-lifsk = c_z1 AND li_ztsd_b_so IS NOT INITIAL.
    MODIFY ztsd_blocked_so FROM TABLE li_ztsd_b_so.
  ENDIF.

*****************************Start of Code by Shivam***********************
*BREAK shivam.
*field-symbols : <lx_vbap> type vbapvb.
*if xvbap[] is not INITIAL  .
*LOOP AT xvbap[] ASSIGNING <lx_vbap>.
*if <lx_vbap>-block_order IS INITIAL AND <lx_vbap>-block_order NE '0' .
*call function 'ZSALES_DOCUMENT_UPDATE' IN UPDATE TASK
*  exporting
*    vbeln         = vbak-vbeln
*    xvbap         = xvbap[]
*    xkomv         = XKOMV[]
*    vbak          = vbak
* .
*ENDIF.
*ENDLOOP.
*endif.
*****************************End of Code by Shivam************************88

ENDENHANCEMENT.
