*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_VENDOR.....................................*
DATA:  BEGIN OF STATUS_ZCYG_VENDOR                   .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_VENDOR                   .
CONTROLS: TCTRL_ZCYG_VENDOR
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_VENDOR                   .
TABLES: ZCYG_VENDOR                    .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
