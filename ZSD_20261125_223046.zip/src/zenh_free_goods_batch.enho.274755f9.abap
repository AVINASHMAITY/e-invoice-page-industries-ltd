"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:END\EN:ZSD_HIDE_ORDER_REASON\SE:END\EI
ENHANCEMENT 0 ZENH_FREE_GOODS_BATCH.
**&---------------------------------------------------------------------*
**& Developer                   : Ravindran
**& Created On                  : 12.07.2017
**& Title                       : Pass batch for Free Goods
**& Request Key to Prod         : DR1K933968
**&---------------------------------------------------------------------*
*DATA : LV_VA01 TYPE SYST_TCODE VALUE 'VA01',
*       LV_VA02 TYPE SYST_TCODE VALUE 'VA02',
*       LV_VA03 TYPE SYST_TCODE VALUE 'VA03'.
*
*IF SY-TCODE EQ LV_VA01 OR SY-TCODE EQ LV_VA02 OR SY-TCODE EQ LV_VA03.
*
*DATA : LT_VBAP TYPE TABLE OF vbapvb,
*       LS_VBAP TYPE vbapvb.
*
*  LT_VBAP[] = XVBAP[].
*
*  LOOP AT XVBAP.
*   IF XVBAP-PSTYV EQ 'ZTNN'.
*     READ TABLE LT_VBAP INTO LS_VBAP WITH KEY MATNR = XVBAP-MATNR
*                                              PSTYV = 'YTAN'.
*     IF SY-SUBRC EQ 0.
*      XVBAP-CHARG = LS_VBAP-CHARG.
*      MODIFY XVBAP.
*    ENDIF.
*   ENDIF.
*  ENDLOOP.
*
*ENDIF.
ENDENHANCEMENT.
