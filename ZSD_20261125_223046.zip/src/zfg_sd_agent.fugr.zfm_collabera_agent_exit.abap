*&----------------------------------------------------------*
*** Modification Log
*&----------------------------------------------------------*
* Object Name : ZFM_COLLABERA_AGENT_EXIT
* Author/Comapny Name : Chandra Mohan/ITEANZ
* Transport Request : DR1K938715
* Creation Date : 15.02.2018
*&----------------------------------------------------------*
* Description : Agent SH control
*&----------------------------------------------------------*
function zfm_collabera_agent_exit.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  TABLES
*"      SHLP_TAB TYPE  SHLP_DESCT
*"      RECORD_TAB STRUCTURE  SEAHLPRES
*"  CHANGING
*"     REFERENCE(SHLP) TYPE  SHLP_DESCR
*"     REFERENCE(CALLCONTROL) LIKE  DDSHF4CTRL STRUCTURE  DDSHF4CTRL
*"----------------------------------------------------------------------

  constants : lc_disp(4) value 'DISP'.
  data : lv_flag type abap_bool.
  import gv_agent_flag to lv_flag from memory id 'ZAGENT_CHK'.
  if callcontrol-step eq lc_disp.
    if lv_flag eq abap_undefined.
      delete record_tab where string+0(12) ne sy-uname.
    endif.
  endif.
  if lv_flag eq abap_undefined.
    delete shlp_tab where shlpname ne 'ZSH_COLLABERA_AGENT'. "Added by chandru "DR1K938715
  endif.
endfunction.
