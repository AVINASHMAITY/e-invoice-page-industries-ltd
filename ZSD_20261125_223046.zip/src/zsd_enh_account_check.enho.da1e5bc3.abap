"Name: \PR:SAPMV60A\FO:FCODE_DRCK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_ACCOUNT_CHECK.
*&--------------------------------------------------------------------*
* Enhancement             : ZSD_ENH_ACCOUNT_CHECK                     *
* Author/Company Name     : Chaithanya/Iteanz                         *
* Transport Request       : DR1K934505                                *
* Creation Date           : 02.08.2017                                *
* Desc                    : Billing Document Print Blocking           *
*&--------------------------------------------------------------------*
DATA : GT_CONSTANTS TYPE ZTT_ZTABAP_TVARVC,
       GW_CONSTANTS TYPE ZTABAP_TVARVC.

CONSTANTS : GC_BILL   VALUE 'ZSD_ENH_ACCOUNT_CHECK'
              TYPE SOBJ_NAME ,
            LC_VKORG(13) VALUE 'SO_BUKRS_BILL'.

REFRESH : GT_CONSTANTS.
CLEAR : GW_CONSTANTS.

CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
  EXPORTING
    IM_OBJNAME = GC_BILL
  IMPORTING
    EX_TAB     = GT_CONSTANTS.

    READ TABLE GT_CONSTANTS INTO GW_CONSTANTS
    WITH KEY   OBJ_NAME    = GC_BILL
               NAME        = LC_VKORG
               LOW         = VBRK-VKORG.

IF SY-SUBRC EQ 0.

   IF VBRK-RFBSK  = ' ' OR
      VBRK-RFBSK  = 'F' OR
      VBRK-RFBSK  = 'G' OR
      VBRK-RFBSK  = 'B'.
       MESSAGE 'Accounting Document Not created, Invoice Cannot be printed!' TYPE 'I' DISPLAY LIKE 'E'.
       LEAVE TO CURRENT TRANSACTION.
    ENDIF.
ENDIF.
ENDENHANCEMENT.
