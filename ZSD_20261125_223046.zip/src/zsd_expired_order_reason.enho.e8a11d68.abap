"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAP\SE:BEGIN\EN:ZSD_WBS_VALIDATE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_EXPIRED_ORDER_REASON.
************************************************************************
* Date       Programmer  Client Ref No.     Correction                  *
*  28.03.2017  Kavin                       DR1K931091
*  04.04.2017  Chaithanya                  DR1K932131                   *
* Description   Expired BATCH Order Reason(YB5)  for YBSC & YBRE Doc Type
************************************************************************

TYPES: BEGIN OF TP_MCH1,
         MATNR TYPE MCH1-MATNR,
         CHARG TYPE MCH1-CHARG,
         LICHA TYPE MCH1-LICHA,
         VFDAT TYPE MCH1-VFDAT,
       END OF TP_MCH1.

DATA :  LT_MCH1 TYPE TABLE OF TP_MCH1,
        LW_MCH1 TYPE TP_MCH1.

DATA  :  LC_BSART(11) VALUE 'SO_BSART_SO'.

CONSTANTS : GC_ORD_REASON       TYPE SOBJ_NAME   VALUE 'ZSD_EXPIRED_ORDER_REASON'.

if  sy-tcode = 'VA01' OR SY-TCODE ='VA02'.

DATA : GT_CONSTANT TYPE ZTT_ZTABAP_TVARVC,
       GW_CONSTANT TYPE ZTABAP_TVARVC.

REFRESH :  LT_MCH1,GT_CONSTANT.
CLEAR : LW_MCH1,GW_CONSTANT.

*----------------------------------------------------------------------*
*ZCMAIN PARAMTER  FOR Order Reason doc type
*----------------------------------------------------------------------*
CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
  EXPORTING
    IM_OBJNAME = GC_ORD_REASON
  IMPORTING
    EX_TAB     = GT_CONSTANT.


READ TABLE GT_CONSTANT TRANSPORTING NO FIELDS
     WITH KEY   OBJ_NAME = GC_ORD_REASON
                NAME     = LC_BSART
                LOW      = VBAK-AUART.

IF SY-SUBRC EQ 0.

*----------------------------------------------------------------------*
*Logic to check batch is expired or not
*----------------------------------------------------------------------*
if VBAP-MATNR is NOT INITIAL AND VBAP-CHARG IS NOT INITIAL.

  SELECT      MATNR
              CHARG
              LICHA
              VFDAT
        FROM MCH1
        INTO TABLE LT_MCH1
        WHERE MATNR = VBAP-MATNR AND
              CHARG = VBAP-CHARG.

  IF SY-SUBRC = 0.
    SORT LT_MCH1 BY MATNR.
  ENDIF.


  READ TABLE LT_MCH1  INTO LW_MCH1 WITH KEY MATNR = VBAP-MATNR
                                            CHARG = VBAP-CHARG.
  IF SY-SUBRC EQ 0.

    DATA : LV_DATE TYPE DATUM.
    DATA : LV_DATE1 TYPE DATUM.
    CLEAR LV_DATE.
    CLEAR LV_DATE1.

    CALL FUNCTION 'LAST_DAY_OF_MONTHS'
      EXPORTING
        DAY_IN            = SY-DATUM
      IMPORTING
        LAST_DAY_OF_MONTH = LV_DATE
      EXCEPTIONS
        DAY_IN_NO_DATE    = 1
        OTHERS            = 2.
    IF SY-SUBRC <> 0.
* Implement suitable error handling here
    ENDIF.

    LV_DATE = LV_DATE + 1.

    CALL FUNCTION 'LAST_DAY_OF_MONTHS'
      EXPORTING
        DAY_IN            = LV_DATE
      IMPORTING
        LAST_DAY_OF_MONTH = LV_DATE1
      EXCEPTIONS
        DAY_IN_NO_DATE    = 1
        OTHERS            = 2.
    IF SY-SUBRC <> 0.
* Implement suitable error handling here
    ENDIF.
*----------------------------------------------------------------------*
*Assign Order reason to Screen Field
*----------------------------------------------------------------------*
    IF LW_MCH1-VFDAT IS NOT INITIAL.
      IF  LV_DATE1  GE LW_MCH1-VFDAT.
*        VBAP-ZZAUGRU = 'YB5'.
         VBAP-ZZAUGRU = 'YB5'.
      ENDIF.
    ENDIF.
  ENDIF.
*  ELSE.
*    IF  VBAP-ZZAUGRU EQ 'YB5'.
*    VBAP-ZZAUGRU = ''.
*    ENDIF.
ENDIF.
ENDIF.
ENDIF.
****************************************************************
************************************************************************
* Date       Programmer  Client Ref No.     Correction                  *
*  28.03.2017  Samatha                       DR1K976694
************************************************************************

Data : lw_komv type komv,
       lw_yvbap TYPE vbap,
       lv_kwert_cred type KOMV-KWERT,
       lv_kbetr_cred TYPE konp-KBETR,
       lv_flag_cred type c,
       lv_cred type c,
       lv_mail_cred type AD_SMTPADR,
       lw_kna1_cred type kna1,
       lv_tot_cred type string,
       lv_25k(13) type p decimals 2 value 2500000.
DATA: LV_XVBAP TYPE I,
      LV_YVBAP TYPE I.
data:   lt_ZTSD_SAMPLE25K type TABLE OF ZTSD_SAMPLE25K,
         lw_ZTSD_SAMPLE25K type ZTSD_SAMPLE25K,
         lt_A850 TYPE TABLE OF a850,
         lw_a850 type a850,
         lt_konp TYPE TABLE OF konp,
         lw_konp TYPE konp,
         lw_xvbap_cred type vbap,
         lt_zsd_cust_mails type TABLE OF zsd_cust_mails,
         lw_zsd_cust_mails TYPE zsd_cust_mails.
DATA: lt_objtxt       TYPE bcsy_text,
      ls_objtxt       LIKE LINE OF lt_objtxt, "lt_objtxt       LIKE solisti1 OCCURS 10 WITH HEADER LINE,
      doc_chng        LIKE sodocchgi1,
      tab_lines       LIKE sy-tabix,
      w_longtext(255) TYPE c,
      lt_objbin       LIKE solisti1 OCCURS 10 WITH HEADER LINE,
      lv_string       TYPE string,
      lt_reclist      LIKE somlreci1 OCCURS 5 WITH HEADER LINE,
      lt_objpack      LIKE sopcklsti1 OCCURS 2 WITH HEADER LINE.
DATA : "lv_string      TYPE string,
  lv_long_sub    TYPE string,
  lv_data_string TYPE string,
  lv_xstring     TYPE xstring.


DATA:     lv_sub        TYPE so_obj_des.
DATA : lv_system(25) TYPE c,
       lt_text       TYPE bcsy_text,
       ls_text       LIKE LINE OF lt_text.
DATA : lo_bcs       TYPE REF TO cl_bcs,
       lo_doc       TYPE REF TO cl_document_bcs,
       lo_sender    TYPE REF TO if_sender_bcs VALUE IS INITIAL,
       lo_recipient TYPE REF TO if_recipient_bcs VALUE IS INITIAL,
       lv_string1   TYPE string.
DATA: l_num_rows    TYPE i,
      l_text_length TYPE so_obj_len,
      l_num_line    TYPE i.
DATA: LW_XVBAK_CRED TYPE VBAK.
if sy-tcode = 'VA01' or sy-tcode = 'VA02'.

  select * from ZTSD_SAMPLE25K into TABLE lt_ZTSD_SAMPLE25K.
  READ TABLE lt_ZTSD_SAMPLE25K into lw_ZTSD_SAMPLE25K with key vkorg = vbak-vkorg auart = vbak-auart.
  IF sy-subrc eq 0.
    IF sy-tcode = 'VA01'.
     lv_cred = 'X'.
    ENDIF.
    IF sy-tcode = 'VA02'.
      DESCRIBE TABLE xvbap LINES lv_xvbap.
      DESCRIBE TABLE yvbap LINES lv_yvbap.
*      if lv_xvbap = 1.
      IF lv_xvbap NE lv_yvbap and lv_xvbap LT lv_yvbap .
        lv_cred = 'X'.
*      endif.
      else.
        LOOP AT xvbap.
          READ TABLE yvbap into lw_yvbap with key posnr = xvbap-posnr.
          IF sy-subrc = 0.
             if xvbap-kwmeng ne yvbap-kwmeng.
               lv_cred = 'X'.
               exit.
             endif.
          ENDIF.

        ENDLOOP.
      ENDIF.
    ENDIF.

  IF LV_CRED = 'X'.

*    DOMESTIC SAMPLE SALES ORDER
    if vbak-vtweg = '10'.
*    if vbak-auart = 'ZBFD' or vbak-auart = 'ZBFG' or vbak-auart = 'ZBFS' or vbak-auart = 'ZPFD' or vbak-auart = 'ZPFS'.
    clear :lv_flag_cred,lv_kwert_cred.
    READ TABLE xkomv into lw_komv with key kschl = 'JASS'.
    IF sy-subrc = 0.
     lv_kwert_cred =  lw_komv-KWERT.
     IF lv_kwert_cred GE lv_25k.
       lv_tot_cred = lv_kwert_cred.
      lv_flag_cred = 'X'.
     ENDIF.
    ENDIF.
   endif.
*    EXPORT SAMPLE SALES ORDER
   if vbak-vtweg = '20'.
*   IF vbak-auart = 'ZBF1' or vbak-auart = 'ZBFZ' or vbak-auart = 'ZPFZ'.
     clear :lv_flag_cred,lv_kbetr_cred.
     IF xvbap is not INITIAL.
         select * from A850 into TABLE lt_A850 FOR ALL ENTRIES IN xvbap where matnr = xvbap-matnr.
         IF lt_a850 is not INITIAL.
           select * from konp into table lt_konp FOR ALL ENTRIES IN lt_a850 where KNUMH = lt_a850-KNUMH.
         ENDIF.
     ENDIF.

     LOOP AT xvbap INTO lw_xvbap_cred .
       READ TABLE lt_a850 into lw_a850 with key matnr = lw_xvbap_cred-matnr.
       IF sy-subrc = 0.
         READ TABLE lt_konp into lw_konp with key knumh = lw_a850-knumh.
         IF sy-subrc = 0.
           lw_konp-KBETR = lw_konp-KBETR / 100.
           lw_xvbap_cred-KWMENG = lw_xvbap_cred-KWMENG / 10.
          lv_KBETR_cred = lv_KBETR_cred + ( lw_konp-KBETR * lw_xvbap_cred-KWMENG ).
         ENDIF.
       ENDIF.
     endloop.
     IF lv_kbetr_cred GE lv_25k.
       lv_tot_cred = lv_kbetr_cred.
       lv_flag_cred = 'X'.
     ENDIF.
   ENDIF.
  ENDIF.
  ENDIF.
  IF lv_flag_cred = 'X'.
   VBAK-AUGRU = 'ZC3'.
*   MODIFY vbak."from vbak TRANSPORTING augru.
   XVBAK-AUGRU = 'ZC3'.
   EXPORT lv_flag_cred TO MEMORY ID 'LV_25K'.
*   MODIFY XVBAK.
*   MODIFY vbak FROM LW_XVBAK_CRED TRANSPORTING AUGRU..
   ENDIF.
   ENDIF.
*   select SINGLE * from kna1 into lw_kna1_cred where kunnr = vbak-kunnr.
* SELECT * FROM zsd_cust_mails INTO  table lt_zsd_cust_mails WHERE katr6 = lw_kna1_cred-katr6.
*loop at lt_zsd_cust_mails into  lw_zsd_cust_mails.
* lv_mail_cred = lw_zsd_cust_mails-smtp_addr.
*  IF lv_mail_cred IS NOT INITIAL.
*
*    CONCATENATE 'Dear Team' ',' INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*
*    CONCATENATE 'Following sample order value is exceeded 25K, Hence SO is closed.' '' INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*
*
*    CONCATENATE 'SO Date: ' VBAK-ERDAT+6(2) '.' VBAK-ERDAT+4(2) '.' VBAK-ERDAT(4)
*                INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*    CONCATENATE 'SO Number:' VBAK-VBELN INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*    CONCATENATE 'Sold To party :' VBAK-KUNNR '-' lw_kna1_cred-name1 INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*    CONCATENATE 'Total Value:' lv_tot_cred INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*
*    CONCATENATE '' '' INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*
*    CONCATENATE 'Regards' '' INTO ls_objtxt-line SEPARATED BY space.
*    APPEND ls_objtxt TO lt_objtxt.
*    CLEAR ls_objtxt.
*
*     CONCATENATE VBAK-VBELN ':Sample Order Value exceeded 25K' INTO lv_sub.
*    DESCRIBE TABLE lt_objtxt LINES tab_lines.
*
*
*    DESCRIBE TABLE lt_objtxt LINES l_num_rows.
*    l_num_rows = l_num_rows * 255.
*    MOVE l_num_rows TO l_text_length.
*    TRY.
*        lo_doc = cl_document_bcs=>create_document(
*                              i_type = 'RAW'
*                              i_length  = l_text_length
*                              i_text =  lt_objtxt
*                              i_subject = lv_sub ).
*
**      * Set Sender
*        lo_bcs = cl_bcs=>create_persistent( ).
*
*        CALL METHOD lo_bcs->set_document( lo_doc ).
*
*        lo_sender = cl_sapuser_bcs=>create( 'WF-BATCH' ).
*
*        lo_bcs->set_sender(
*        EXPORTING
*        i_sender = lo_sender ).
*
*
*        lo_recipient = cl_cam_address_bcs=>create_internet_address( lv_mail_cred ).
*        lo_bcs->add_recipient(
*            EXPORTING
*            i_recipient = lo_recipient
*            i_express = 'X' ).
*
*        CALL METHOD lo_bcs->set_send_immediately
*          EXPORTING
*            i_send_immediately = 'X'.
**    * Send email
*
*        lo_bcs->send(
*        EXPORTING
*        i_with_error_screen = 'X' ).
**        COMMIT WORK.             "Committed by Ravi on 15.06.2023
*      CATCH cx_send_req_bcs.
*    ENDTRY.
*
*    REFRESH :  lt_objtxt.
*
*
*  ENDIF.
* ENDLOOP.
*  ENDIF.
*ENDIF.
ENDENHANCEMENT.
