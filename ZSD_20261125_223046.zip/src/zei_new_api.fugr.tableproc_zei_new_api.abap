*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZEI_NEW_API
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZEI_NEW_API         .

  PERFORM TABLEPROC.

ENDFUNCTION.
