"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_DELIV_BLOCK_UPDATE.
*&-------------------------------------------------------------------
*Date       : 11.02.2025
*Programmer : Suganya Palanisamy
*TR No.     : DR1K990793
*Description: Enhancment to update Delivery block for duplicate record in ORDERS05
*&-------------------------------------------------------------------
DATA lv_lifsk_1   TYPE lifsk.
IMPORT lv_lifsk_1 FROM MEMORY ID 'LV_LIFSK'.
IF lv_lifsk_1 IS NOT INITIAL.
  vbak-lifsk = lv_lifsk_1.
ENDIF.
ENDENHANCEMENT.
