"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:END\EI
ENHANCEMENT 0 ZSD_BILL_BLOCK_EHS_APPROVAL.
****************************************************************************
* Date       Programmer  Client Ref No.                                *
* 20.12.2016  Kavin/iteanz                         DR1K930090
* Description   Auto Billing Block for Sales Organisation 1102 During Sales
*               Order Creation for order type YBEX
***************************************************************************
*&--------------------Modification Log---------------------------------*
*Date       : 06.06.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K945737                                               *
*Description: Remove Sales Org. 1102 and Add ZCMAIN for BFI            *
*&---------------------------------------------------------------------*
*****************************************************************
* Developer         : Bhagavan/Iteanz
* Changes           : To update  the Z1 Block in ZTSD_blocked_so table
*                     for the ZSD_QUOT_SO Tcode
* Transaport        : DR1K953998
*****************************************************************
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

*CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
*            gc_vkorg(15) VALUE 'BFI_VKORG'.

*DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
*TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

 ra_vkorg = VALUE tt_vkorg( FOR gs_vkorg1 IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg1-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************
DATA :  c_z4 TYPE FAKSK  VALUE 'Z4'.
*  *-->Check When Create
*IF sy-tcode = c_va01 AND ( vbak-vkorg = c_1102 AND vbak-AUART  = 'YBEX' ).
IF ( sy-tcode = c_va01 OR  sy-tcode = 'ZSD_QUOT_SO' ) AND ( vbak-vkorg IN ra_vkorg AND vbak-AUART  = 'YBEX' ).   "Added by Ravi on 06.06.2019 DR1K945737 "Added by Bhagavan on 18.11.2020  DR1K953998
    vbak-FAKSK = c_z4.
 ENDIF.

*IF sy-tcode = c_va02 AND ( vbak-vkorg = c_1102 AND vbak-AUART  = 'YBEX' ).
IF sy-tcode = c_va02 AND ( vbak-vkorg IN ra_vkorg AND vbak-AUART  = 'YBEX' ).    "Added by Ravi on 06.06.2019 DR1K945737
 IF   vbak-FAKSK EQ ABAP_FALSE.
  MESSAGE E075(ZSD_MESSAGES).
 ENDIF.
 ENDIF.

ENDENHANCEMENT.
