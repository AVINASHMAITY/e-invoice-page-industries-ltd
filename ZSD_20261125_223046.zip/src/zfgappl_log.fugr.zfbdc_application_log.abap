FUNCTION zfbdc_application_log.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_OBJECT) TYPE  BALOBJ_D
*"     VALUE(I_SUBOBJECT) TYPE  BALSUBOBJ
*"     VALUE(I_USER) TYPE  SY-UNAME
*"     VALUE(I_REPID) TYPE  SY-REPID
*"  CHANGING
*"     REFERENCE(I_MESSAGES) TYPE  BAPIRET2_T
*"----------------------------------------------------------------------
*Field Symbol
  FIELD-SYMBOLS:
    <lv_msg>          TYPE bapiret2.
* Data Declaration
  DATA:
    lv_message(300)   TYPE c,
    ls_log            TYPE bal_s_log,
    lv_loghandle      TYPE balloghndl,
    lt_loghandle      TYPE bal_t_logh.
*
* open log
  ls_log-object    = i_object.
  ls_log-subobject = i_subobject.
  ls_log-aluser    = i_user.
  ls_log-alprog    = i_repid.
*
* Function Module To create the Application Log
*
  CALL FUNCTION 'BAL_LOG_CREATE'
    EXPORTING
      i_s_log      = ls_log
    IMPORTING
      e_log_handle = lv_loghandle
    EXCEPTIONS
      OTHERS       = 1.
*
*
  LOOP AT i_messages ASSIGNING <lv_msg>.
*
    lv_message = <lv_msg>-message.
*
    IF NOT <lv_msg>-message_v1 IS INITIAL.
      REPLACE FIRST OCCURRENCE OF '&' IN lv_message WITH <lv_msg>-message_v1.
    ENDIF.
    IF NOT <lv_msg>-message_v2 IS INITIAL.
      REPLACE FIRST OCCURRENCE OF '&' IN lv_message WITH <lv_msg>-message_v2.
    ENDIF.
    IF NOT <lv_msg>-message_v3 IS INITIAL.
      REPLACE FIRST OCCURRENCE OF '&' IN lv_message WITH <lv_msg>-message_v3.
    ENDIF.
    IF NOT <lv_msg>-message_v4 IS INITIAL.
      REPLACE FIRST OCCURRENCE OF '&' IN lv_message WITH <lv_msg>-message_v4.
    ENDIF.
*
    CALL FUNCTION 'BAL_LOG_MSG_ADD_FREE_TEXT'
      EXPORTING
        i_log_handle              = lv_loghandle
        i_msgty                   = <lv_msg>-type
        i_text                    = lv_message
      EXCEPTIONS
        log_not_found             = 1
        msg_inconsistent          = 2
        log_is_full               = 3
        OTHERS                    = 4.
*
  ENDLOOP.
*
    INSERT lv_loghandle INTO TABLE lt_loghandle.

    CALL FUNCTION 'BAL_DB_SAVE'                               "#EC *
      EXPORTING
        i_save_all       = ' '
        i_t_log_handle   = lt_loghandle
      EXCEPTIONS
        log_not_found    = 1
        save_not_allowed = 2
        numbering_error  = 3
        OTHERS           = 4.
*

ENDFUNCTION.
