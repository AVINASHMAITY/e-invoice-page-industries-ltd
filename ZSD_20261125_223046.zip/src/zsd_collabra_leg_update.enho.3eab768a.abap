"Name: \PR:SAPLV60A\FO:USEREXIT_PRICING_PREPARE_TKOMK\SE:END\EN:ZSD_ACCUMULATION_REVERT\SE:END\EI
ENHANCEMENT 0 ZSD_COLLABRA_LEG_UPDATE.

DATA: LS_INV_LEGS  TYPE ZOBIZ_LEG,
      LT_LINES     TYPE TABLE OF TLINE,
      LS_LINE      TYPE TLINE,
      LV_NAME      TYPE THEAD-TDNAME,
      WA_BUKRS     TYPE VBRK-BUKRS,
      LV_TIMESTAMP TYPE TIMESTAMP.

IF SY-DYNNR = '6001' AND SY-DYNGR = 'HEAD' AND SY-UCOMM = 'SICH' AND ( SY-TCODE = 'VF01' OR SY-TCODE = 'VF02' ).
  IF (  VBRK-BUKRS = '2500' OR VBRK-BUKRS = '3100' OR VBRK-BUKRS = '3200' ) .

    LV_NAME = VBRK-VBELN.

    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        CLIENT                  = SY-MANDT
        ID                      = 'ZBUK'
        LANGUAGE                = SY-LANGU
        NAME                    = LV_NAME
        OBJECT                  = 'VBBK'
      TABLES
        LINES                   = LT_LINES
      EXCEPTIONS
        ID                      = 1
        LANGUAGE                = 2
        NAME                    = 3
        NOT_FOUND               = 4
        OBJECT                  = 5
        REFERENCE_CHECK         = 6
        WRONG_ACCESS_TO_ARCHIVE = 7
        OTHERS                  = 8.

    IF SY-SUBRC = 0.
      READ TABLE LT_LINES INTO LS_LINE INDEX 1.

      GET TIME STAMP FIELD LV_TIMESTAMP.

      IF SY-SUBRC = 0 AND LS_LINE-TDLINE IS NOT INITIAL.
        LS_INV_LEGS-MANDT      = SY-MANDT.
        LS_INV_LEGS-LEG2_INV   = VBRK-VBELN.         " Leg 2 invoice
        LS_INV_LEGS-LEG1_INV   = LS_LINE-TDLINE.     " Leg 1 invoice
        LS_INV_LEGS-CREATED_BY = SY-UNAME.           " User
        LS_INV_LEGS-DATE_TIME  = LV_TIMESTAMP .      " Timestamp

        SELECT SINGLE BUKRS FROM VBRK INTO WA_BUKRS WHERE VBELN = LS_INV_LEGS-LEG1_INV.
        IF WA_BUKRS = '1400' OR WA_BUKRS = '2700'.

          CONDENSE LS_INV_LEGS-LEG1_INV.

          CALL FUNCTION 'ZUPDATE_INV_LEGS' IN UPDATE TASK
            EXPORTING
              IS_INV_LEGS = LS_INV_LEGS.

        ENDIF.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.

ENDENHANCEMENT.
