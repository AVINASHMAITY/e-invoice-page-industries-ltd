class ZBIOCL_SI_GOOD_RECEIPTS_IN definition
  public
  create public .

public section.

  interfaces ZBIOII_SI_GOOD_RECEIPTS_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOCL_SI_GOOD_RECEIPTS_IN IMPLEMENTATION.


  METHOD zbioii_si_good_receipts_in~si_good_receipts_in.

************************ Data Declaration *************************
    DATA: lt_movement       TYPE TABLE OF zbiosi_good_receipts_in_messag,
          lt_mvmt           TYPE zbiosi_good_receipts_in_mo_tab,
          ls_mvmt           TYPE zbiosi_good_receipts_in_moveme,
          ls_ud             TYPE zbiosi_good_receipts_in_moveme,
          ls_flow           TYPE zskp_sales_flow,
          ls_ud_data        TYPE bapi2045ud,
          ls_ud_return_data TYPE bapi2045ud_return,
          ls_stock_data     TYPE bapi2045d_il2,
          ls_return         TYPE bapireturn1,
          lt_system         TYPE TABLE OF bapi2045ss,
          lt_user           TYPE TABLE OF bapi2045us,
          lt_qty_tabl       TYPE TABLE OF zsd_skp_ud_qty,
          ls_qty            TYPE zsd_skp_ud_qty.

    DATA : lv_bismt    TYPE bismt,
           lv_ctumode  TYPE ctu_params,
           lv_line     TYPE bsvx-sttxt,
           lv_insp_lot TYPE qplos,
           lv_insp     TYPE bapi2045ud-insplot,
           lv_quant    TYPE qvmenge01.

    CONSTANTS : c_space   TYPE c VALUE ' ',
                c_x       TYPE c VALUE 'X',
                c_success TYPE zskp_doc_typ VALUE 'Success',
                c_error   TYPE zskp_doc_typ VALUE 'Error',
                c_321     TYPE bwart VALUE '321',
                c_10      TYPE char2 VALUE '10',
                c_0       TYPE char2 VALUE '0'.
*************************** End of Decleration ***********************

    lt_movement = input-message.

    IF lt_movement[] IS NOT INITIAL.
      LOOP AT lt_movement ASSIGNING FIELD-SYMBOL(<fs_mvmt>).
        IF <fs_mvmt> IS ASSIGNED.
          lt_mvmt = <fs_mvmt>-movement.
        ENDIF.
      ENDLOOP.
      UNASSIGN <fs_mvmt>.

*$$ --> Perform UD based on <QTY> defined on SKP MBGMCR file
      LOOP AT lt_mvmt INTO ls_mvmt.
* Material
        lv_bismt = ls_mvmt-material.
        TRANSLATE lv_bismt TO UPPER CASE.
        SELECT SINGLE matnr FROM mara INTO @DATA(lv_matnr) WHERE bismt = @lv_bismt.
        IF sy-subrc = 0.
          lv_matnr = |{ lv_matnr ALPHA = IN }|.
* Batch
          SELECT SINGLE matnr,charg,licha FROM mch1 INTO
            ( @DATA(lv_material), @DATA(lv_charg), @DATA(lv_licha) )
            WHERE licha = @ls_mvmt-batch AND
                  matnr = @lv_matnr.
          IF sy-subrc = 0.

            SELECT prueflos, herkunft, objnr, losmenge FROM qals INTO TABLE @DATA(lt_qals)
                 WHERE matnr = @lv_matnr AND
                       werk = @ls_mvmt-plant AND
                       charg = @lv_charg.
            IF sy-subrc = 0.
* Fetch correct BL movement type from table ZSD_SKP_MOVEMENT
              SELECT SINGLE bwart FROM zsd_skp_movement INTO @DATA(lv_bl_mvmt) WHERE zskp_mvmt = @ls_mvmt-movement_key.
              IF sy-subrc = 0.
                LOOP AT lt_qals INTO DATA(ls_qals).
                  CALL FUNCTION 'STATUS_TEXT_EDIT'
                    EXPORTING
                      client      = sy-mandt
                      objnr       = ls_qals-objnr
                      only_active = 'X'
                      spras       = sy-langu
                    IMPORTING
                      line        = lv_line.

                  IF sy-subrc EQ 0.
                    IF lv_line(3) EQ 'REL'.
                      lv_insp_lot = ls_qals-prueflos.
                      DATA(flag) = 'X'.
                      EXIT.
                    ENDIF.
                  ENDIF.
                ENDLOOP.

                IF flag = 'X'.
                  CLEAR : ls_qty, lt_qty_tabl[].

                  ls_qty-zdate = sy-datum.
                  ls_qty-ztime = sy-uzeit.
                  ls_qty-insplot = lv_insp_lot.
                  ls_qty-bwart = lv_bl_mvmt.
                  ls_qty-zappr_qty = ls_mvmt-qty.
                  ls_qty-zfile_name = ls_mvmt-file_name.
                  APPEND ls_qty TO lt_qty_tabl.
                  INSERT zsd_skp_ud_qty FROM ls_qty.
                  COMMIT WORK.

                  EXPORT zsd_skp_ud_qty = lt_qty_tabl TO MEMORY ID 'ZSKP_UD_QTY'.

                  CLEAR: lt_system[],lt_user[],ls_ud_return_data,ls_stock_data,ls_return,lv_insp.

                  lv_insp = ls_qals-prueflos.

                  CALL FUNCTION 'BAPI_INSPLOT_SETUSAGEDECISION'   " enhancement ZQM_ENCH_AUTOUD
                    EXPORTING
                      number         = lv_insp
                      ud_data        = ls_ud_data
                    IMPORTING
                      ud_return_data = ls_ud_return_data
                      stock_data     = ls_stock_data
                      return         = ls_return
                    TABLES
                      system_status  = lt_system
                      user_status    = lt_user.
                  IF sy-subrc = 0 AND ls_return-id EQ 'QV' AND ls_return-number EQ '050'.
                    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
                      EXPORTING
                        wait = c_x.

                    ls_flow-zdate = sy-datum.
                    ls_flow-ztime = sy-uzeit.
                    ls_flow-zdoc_type = c_success.
                    ls_flow-msg =  | UD completed with QTY | && c_space && ls_mvmt-qty && c_space && | for material - | && c_space && lv_matnr && c_space && | and batch - |
                                   && c_space && lv_charg && c_space && | combination |.
                    ls_flow-zfile_name = ls_mvmt-file_name.
                    INSERT zskp_sales_flow FROM ls_flow.
                    COMMIT WORK.
                    CLEAR : ls_flow.
                  ELSE.
                    ls_flow-zdate = sy-datum.
                    ls_flow-ztime = sy-uzeit.
                    ls_flow-zdoc_type = c_error.
                    ls_flow-msg =  | Error while posting UD for material - | && c_space && lv_matnr && c_space && | and Batch - |
                                   && c_space && lv_charg && c_space && | combination |.
                    ls_flow-zfile_name = ls_mvmt-file_name.
                    INSERT zskp_sales_flow FROM ls_flow.
                    COMMIT WORK.
                    CLEAR : ls_flow.
                  ENDIF.
                ENDIF.
              ELSE.
                ls_flow-zdate = sy-datum.
                ls_flow-ztime = sy-uzeit.
                ls_flow-zdoc_type = c_error.
                ls_flow-msg =  | No BL Movement type has found for SKP movement - | && c_space && ls_mvmt-movement_key.
                ls_flow-zfile_name = ls_mvmt-file_name.
                INSERT zskp_sales_flow FROM ls_flow.
                COMMIT WORK.
                CLEAR : ls_flow.
              ENDIF.
            ENDIF.
          ELSE.
            ls_flow-zdate = sy-datum.
            ls_flow-ztime = sy-uzeit.
            ls_flow-zdoc_type = c_error.
            ls_flow-msg =  | No BL Batch found for SKP batch - | && c_space && ls_mvmt-batch.
            ls_flow-zfile_name = ls_mvmt-file_name.
            INSERT zskp_sales_flow FROM ls_flow.
            COMMIT WORK.
            CLEAR : ls_flow.
          ENDIF.
        ELSE.
          ls_flow-zdate = sy-datum.
          ls_flow-ztime = sy-uzeit.
          ls_flow-zdoc_type = c_error.
          ls_flow-msg =  | No BL Material found for SKP material - | && c_space && lv_bismt.
          ls_flow-zfile_name = ls_mvmt-file_name.
          INSERT zskp_sales_flow FROM ls_flow.
          COMMIT WORK.
          CLEAR : ls_flow.
        ENDIF.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
