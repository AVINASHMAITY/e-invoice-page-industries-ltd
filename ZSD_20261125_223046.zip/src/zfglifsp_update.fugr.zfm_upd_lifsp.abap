FUNCTION zfm_upd_lifsp.
*"----------------------------------------------------------------------
*"*"Update Function Module:
*"
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(I_VBELN) TYPE  VBELN_VA
*"     VALUE(I_VBAK) TYPE  VBAK
*"  TABLES
*"      I_XVBAP STRUCTURE  VBAPVB
*"----------------------------------------------------------------------
  CONSTANTS : gc_z6block   VALUE 'ZSD_QUOTE_Z6BLOCK' TYPE sobj_name,
              gc_vkorg(15) VALUE 'Z6_VKORG',
              gc_auart(15) VALUE 'Z6_AUART'.
  DATA : gt_constants TYPE ztt_ztabap_tvarvc.
  DATA : ra_vkorg TYPE RANGE OF vkorg,
         ra_auart TYPE RANGE OF auart.
  CALL METHOD zcl_abap_utility=>get_options
    EXPORTING
      im_objname = gc_z6block
    IMPORTING
      ex_tab     = gt_constants.
  ra_vkorg = VALUE #( FOR gs IN gt_constants WHERE ( obj_name = gc_z6block
                                                AND   name    = gc_vkorg ) ( sign =  'I'
                                                                            option = 'EQ'
                                                                            low = gs-low ) ).
  ra_auart = VALUE #( FOR gs1 IN gt_constants WHERE ( obj_name = gc_z6block
                                              AND     name     = gc_auart ) ( sign =  'I'
                                                                              option = 'EQ'
                                                                               low = gs1-low ) ).
  CHECK i_vbak-vkorg IN ra_vkorg AND i_vbak-auart IN ra_auart.
  LOOP AT i_xvbap ASSIGNING FIELD-SYMBOL(<fs_vbap>).
    UPDATE vbep
    SET lifsp = 'Z6'
    WHERE vbeln = i_vbeln
    AND posnr  = <fs_vbap>-posnr.
    IF sy-subrc EQ 0.
      COMMIT WORK AND WAIT.
    ENDIF.
  ENDLOOP.




ENDFUNCTION.
