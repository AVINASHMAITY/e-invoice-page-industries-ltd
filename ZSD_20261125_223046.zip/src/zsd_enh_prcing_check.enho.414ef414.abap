"Name: \PR:SAPLV69A\FO:USEREXIT_PRICING_CHECK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_PRCING_CHECK.
*************************************************************************
* Program Defintion log                                           *
***********************************************************************
*&---------------------------------------------------------------------*
*& Developer                   : Kavin K
*& Functional                  : Venkatasen
*& Created On                  : 07/11/2016
*& Title                       : Multiple condition Type Duplicate Validation
*& Request Key to Prod         : DR1K927563
*&---------------------------------------------------------------------*
***********************************************************************
* *&-------------------------------------------------------------------*
* Date        Programmer Client Ref No.        *
* 28.12.2016  Kavin/Iteanz             Manual Entry Billing Blocking  *
*                                      by Sales Organsation wise
*                                        Blocking
*Transport Request -  DR1K930305                                     *
*&--------------------------------------------------------------------*

IF SY-TCODE  EQ 'VF01' OR  SY-TCODE  EQ 'VF02'  OR   SY-TCODE  EQ 'VF03'  OR
   SY-TCODE  EQ 'VA01' OR  SY-TCODE  EQ 'VA02' OR  SY-TCODE  EQ 'VA03'.
***********************************************************************
**    Declaration Part
*&---------------------------------------------------------------------*
    CONSTANTS : GC_ZSD_ENH     TYPE SOBJ_NAME    VALUE 'ZSD_ENH_PRCING_CHECK'.

    DATA :  GC_VKORG         TYPE VBAK-VKORG,
            GT_CONSTANTS     TYPE ZTT_ZTABAP_TVARVC,
            GW_CONSTANTS     TYPE ZTABAP_TVARVC,
            LC_VKORG_ENH(12) VALUE 'SO_VKORG_ENH',
            LC_VKORG_BLK(12) VALUE 'SO_VKORG_BLK'.

    DATA   : LT_XKOMV  TYPE STANDARD TABLE OF KOMV WITH HEADER LINE
                                                 INITIAL SIZE 50,
             LW_XKOMV  LIKE LINE OF XKOMV,
             LW_XKOMV1 LIKE LINE OF XKOMV.

    DATA: LV_COUNT    TYPE I,
          LV_STUNR(3) TYPE N,
          INDEX       TYPE SY-TABIX.
***********************************************************************
**    Import Sales Organisation fro Header
*&---------------------------------------------------------------------*
    IMPORT GC_VKORG FROM MEMORY ID 'ZZVKORG'.


    REFRESH : GT_CONSTANTS.
    CLEAR : GW_CONSTANTS.

* ***********************************************************************
**   ZCMAIN Parameter for Duplicate Condition type Validation
*&---------------------------------------------------------------------*

    CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
      EXPORTING
        IM_OBJNAME = GC_ZSD_ENH
      IMPORTING
        EX_TAB     = GT_CONSTANTS.


    READ TABLE GT_CONSTANTS INTO GW_CONSTANTS
    WITH KEY   OBJ_NAME    = GC_ZSD_ENH
               NAME        = LC_VKORG_ENH
               LOW         = GC_VKORG.

    IF SY-SUBRC EQ 0.

      READ TABLE XKOMV INTO  LW_XKOMV INDEX 1.
      LV_STUNR = LW_XKOMV-STUNR.

***********************************************************************
**   Below Validation for Multiple Duplicate Condition Type Validation
*&---------------------------------------------------------------------*

      IF KOMV-KSCHL IS NOT INITIAL.
        READ TABLE XKOMV INTO LW_XKOMV WITH KEY KSCHL = KOMV-KSCHL.
        INDEX = SY-TABIX.
        IF SY-SUBRC EQ 0.
          CLEAR LW_XKOMV.
          READ TABLE XKOMV INTO LW_XKOMV WITH KEY KSCHL  = KOMV-KSCHL
                                                  ZAEHK  = KOMV-ZAEHK.
          IF SY-SUBRC NE 0.
            MESSAGE E000(ZSD_MESSAGE) WITH  KOMV-KSCHL.
          ELSEIF LW_XKOMV-KSCHL = KOMV-KSCHL AND INDEX = 1 AND KOMV-KBETR IS INITIAL.
            MESSAGE E000(ZSD_MESSAGE) WITH  KOMV-KSCHL.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

*************************Added By Kavin/iteanz On 22/12/2016 for Manual Entry Blocking

***********************************************************************
**   Below Validation for Manual Billing Block entry
*&---------------------------------------------------------------------*

 IF SY-TCODE EQ 'VF01' OR SY-TCODE EQ 'VF02'.

***********************************************************************
**   ZCMAIN Parameter for Billing Block
*&---------------------------------------------------------------------*

      REFRESH GT_CONSTANTS.
      CLEAR GW_CONSTANTS.

      CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
        EXPORTING
          IM_OBJNAME = GC_ZSD_ENH
        IMPORTING
          EX_TAB     = GT_CONSTANTS.


      READ TABLE GT_CONSTANTS INTO GW_CONSTANTS
      WITH KEY   OBJ_NAME    = GC_ZSD_ENH
                 NAME        = LC_VKORG_BLK
                 LOW         = GC_VKORG.

IF SY-SUBRC EQ 0.
   IF KOMV-KSCHL IS NOT INITIAL .
    MESSAGE E009(ZSD_MESSAGE) .
   ENDIF.
 ENDIF.
  ENDIF.
ENDIF.
***************************************End Of addition by Kavin/iteanz on 20/12/2016


ENDENHANCEMENT.
