class ZCL_WORKFLOW_SD07 definition
  public
  final
  create public .

public section.

  class-methods TRIGGER_WORKFLOW
    importing
      !TOTAL_AMOUNT type ZAMOUNT_TOT optional
      !SUBTOT_AMOUNT type ZAMOUNT_TOT optional
      !SALES_DOC type VBELN optional
      !MATERIAL type MATNR optional
      !ITEM type POSNR optional .
protected section.
private section.
ENDCLASS.



CLASS ZCL_WORKFLOW_SD07 IMPLEMENTATION.


  method trigger_workflow.


    data :
    lv_objtype type sibftypeid,
    lv_event type sibfevent,
    lv_objkey type sibfinstid,
    lr_event_parameters type ref to if_swf_ifs_parameter_container,
    lv_param_name type swfdname,
    lv_mode       type pin_cnvcd,
    lv_cartp      type pin_carty,
    lv_note       type vbeln,
    lv_reg_date   type datum,
    lv_pernr      type pernr_d,
    lv_retcode type sysubrc .


    lv_objtype = 'ZCL_WORKFLOW_ESS'.
    lv_event = 'EVENT_ACTION'.

    call method cl_swf_evt_event=>get_event_container
      exporting
        im_objcateg  = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype   = lv_objtype
        im_event     = lv_event
      receiving
        re_reference = lr_event_parameters.

*Set up the name/value pair to be added to the container.
*Set up the name/value pair to be added to the container
    clear : lv_param_name.
    lv_param_name = 'SALES_DOC'.
    lv_note        = sales_doc .
*Add the name/value pair to the event conainer
    try.
        call method lr_event_parameters->set
          exporting
            name       = lv_param_name
            value      = lv_note
          importing
            returncode = lv_retcode.
*Set up the name/value pair to be added to the container*.
      catch cx_swf_cnt_cont_access_denied .
      catch cx_swf_cnt_elem_access_denied .
      catch cx_swf_cnt_elem_not_found .
      catch cx_swf_cnt_elem_type_conflict .
      catch cx_swf_cnt_unit_type_conflict .
      catch cx_swf_cnt_elem_def_invalid .
      catch cx_swf_cnt_container .
    endtry.


*Set up the name/value pair to be added to the container.
*Set up the name/value pair to be added to the container
    clear : lv_param_name.
    lv_param_name      = 'TOTAL_AMOUNT'.
*Add the name/value pair to the event conainer
    try.
        call method lr_event_parameters->set
          exporting
            name       = lv_param_name
            value      = total_amount
          importing
            returncode = lv_retcode.
*Set up the name/value pair to be added to the container*.
      catch cx_swf_cnt_cont_access_denied .
      catch cx_swf_cnt_elem_access_denied .
      catch cx_swf_cnt_elem_not_found .
      catch cx_swf_cnt_elem_type_conflict .
      catch cx_swf_cnt_unit_type_conflict .
      catch cx_swf_cnt_elem_def_invalid .
      catch cx_swf_cnt_container .
    endtry.


*Set up the name/value pair to be added to the container.
*Set up the name/value pair to be added to the container
    clear : lv_param_name.
    lv_param_name      = 'SUBTOT_AMOUNT'.
*Add the name/value pair to the event conainer
    try.
        call method lr_event_parameters->set
          exporting
            name       = lv_param_name
            value      = subtot_amount
          importing
            returncode = lv_retcode.
*Set up the name/value pair to be added to the container*.
      catch cx_swf_cnt_cont_access_denied .
      catch cx_swf_cnt_elem_access_denied .
      catch cx_swf_cnt_elem_not_found .
      catch cx_swf_cnt_elem_type_conflict .
      catch cx_swf_cnt_unit_type_conflict .
      catch cx_swf_cnt_elem_def_invalid .
      catch cx_swf_cnt_container .
    endtry.

*    *Set up the name/value pair to be added to the container.
*Set up the name/value pair to be added to the container
    clear : lv_param_name.
    lv_param_name      = 'MATERIAL'.
*Add the name/value pair to the event conainer
    try.
        call method lr_event_parameters->set
          exporting
            name       = lv_param_name
            value      =  MATERIAL
          importing
            returncode = lv_retcode.
*Set up the name/value pair to be added to the container*.
      catch cx_swf_cnt_cont_access_denied .
      catch cx_swf_cnt_elem_access_denied .
      catch cx_swf_cnt_elem_not_found .
      catch cx_swf_cnt_elem_type_conflict .
      catch cx_swf_cnt_unit_type_conflict .
      catch cx_swf_cnt_elem_def_invalid .
      catch cx_swf_cnt_container .
    endtry.


*    *Set up the name/value pair to be added to the container.
*Set up the name/value pair to be added to the container
    clear : lv_param_name.
    lv_param_name      = 'ITEM'.
*Add the name/value pair to the event conainer
    try.
        call method lr_event_parameters->set
          exporting
            name       = lv_param_name
            value      = ITEM
          importing
            returncode = lv_retcode.
*Set up the name/value pair to be added to the container*.
      catch cx_swf_cnt_cont_access_denied .
      catch cx_swf_cnt_elem_access_denied .
      catch cx_swf_cnt_elem_not_found .
      catch cx_swf_cnt_elem_type_conflict .
      catch cx_swf_cnt_unit_type_conflict .
      catch cx_swf_cnt_elem_def_invalid .
      catch cx_swf_cnt_container .
    endtry.



*,Raise the event passing the prepared event container
    try.
        call method cl_swf_evt_event=>raise
          exporting
            im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
            im_objtype         = lv_objtype
            im_event           = lv_event
            im_objkey          = lv_objkey
            im_event_container = lr_event_parameters.
      catch cx_swf_evt_invalid_objtype .
      catch cx_swf_evt_invalid_event .
    endtry.
    commit work.

  endmethod.
ENDCLASS.
