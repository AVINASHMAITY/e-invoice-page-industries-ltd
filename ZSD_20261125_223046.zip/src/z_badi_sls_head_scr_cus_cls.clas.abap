class Z_BADI_SLS_HEAD_SCR_CUS_CLS definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_SLS_HEAD_SCR_CUS .
protected section.
private section.
ENDCLASS.



CLASS Z_BADI_SLS_HEAD_SCR_CUS_CLS IMPLEMENTATION.


  METHOD if_ex_sls_head_scr_cus~activate_tab_page.

    DATA:ls_head_tab LIKE LINE OF ct_cus_head_tab.

    TYPES:BEGIN OF ty_auart,
            auart TYPE vbak-auart,
          END OF ty_auart.
    DATA lt_auart TYPE TABLE OF ty_auart.
    DATA lw_auart TYPE  ty_auart.

    DATA: lr_dir_range TYPE RANGE OF char50,
          ls_dir_name  LIKE LINE OF lr_dir_range.

    SELECT sign
           opti
           low
           high
    INTO TABLE lr_dir_range
    FROM tvarvc
    WHERE name = 'ZSD_SYN_SO_FFS'
    AND type = 'S'.

    IF sy-subrc = 0 AND lr_dir_range IS NOT INITIAL.
      LOOP AT lr_dir_range INTO ls_dir_name.
        CLEAR lw_auart.
        IF ls_dir_name-low IS NOT INITIAL.
          lw_auart-auart =  ls_dir_name-low.
          APPEND lw_auart TO lt_auart.
        ENDIF.
        CLEAR lw_auart.
        IF ls_dir_name-high IS NOT INITIAL.
          lw_auart-auart =  ls_dir_name-high.
          APPEND lw_auart TO lt_auart.
        ENDIF.
      ENDLOOP.
    ENDIF.

    READ TABLE lt_auart INTO lw_auart
    WITH KEY auart = is_vbak-auart.
    IF sy-subrc = 0.
      ls_head_tab-head_caption = 'Activity '.
      ls_head_tab-head_program = 'ZACTMLS'.
      ls_head_tab-head_dynpro = '9000'.
      APPEND ls_head_tab TO ct_cus_head_tab.
    ENDIF.
    IF sy-tcode = 'VA02' OR sy-tcode = 'VA03'.
      DATA(gv_vbeln) = is_vbak-vbeln.
      EXPORT gv_vbeln FROM gv_vbeln TO MEMORY ID 'GV_VBELN'.
    ENDIF.

    IF sy-tcode = 'VA01' or sy-tcode = 'VA02'.
      DATA(gv_netwr) = is_vbak-netwr.
      EXPORT gv_netwr FROM gv_netwr TO MEMORY ID 'GV_NETWR'.

      DATA(gv_waerk) = is_vbak-waerk.
      EXPORT gv_waerk FROM gv_waerk TO MEMORY ID 'GV_WAERK'.
    ENDIF.

  ENDMETHOD.


  method IF_EX_SLS_HEAD_SCR_CUS~PASS_FCODE_TO_SUBSCREEN.
  endmethod.


  method IF_EX_SLS_HEAD_SCR_CUS~TRANSFER_DATA_FROM_SUBSCREEN.
  endmethod.


  method IF_EX_SLS_HEAD_SCR_CUS~TRANSFER_DATA_TO_SUBSCREEN.
  endmethod.
ENDCLASS.
