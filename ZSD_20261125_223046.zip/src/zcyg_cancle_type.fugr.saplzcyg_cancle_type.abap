*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_CANCLE_TYPETOP.              " Global Data
  INCLUDE LZCYG_CANCLE_TYPEUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_CANCLE_TYPEF...              " Subroutines
* INCLUDE LZCYG_CANCLE_TYPEO...              " PBO-Modules
* INCLUDE LZCYG_CANCLE_TYPEI...              " PAI-Modules
* INCLUDE LZCYG_CANCLE_TYPEE...              " Events
* INCLUDE LZCYG_CANCLE_TYPEP...              " Local class implement.
* INCLUDE LZCYG_CANCLE_TYPET99.              " ABAP Unit tests
  INCLUDE LZCYG_CANCLE_TYPEF00                    . " subprograms
  INCLUDE LZCYG_CANCLE_TYPEI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
