*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDLVKORG
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDLVKORG            .

  PERFORM TABLEPROC.

ENDFUNCTION.
