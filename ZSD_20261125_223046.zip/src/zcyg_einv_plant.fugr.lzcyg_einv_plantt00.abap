*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_EINV_PLANT.................................*
DATA:  BEGIN OF STATUS_ZCYG_EINV_PLANT               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_EINV_PLANT               .
CONTROLS: TCTRL_ZCYG_EINV_PLANT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_EINV_PLANT               .
TABLES: ZCYG_EINV_PLANT                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
