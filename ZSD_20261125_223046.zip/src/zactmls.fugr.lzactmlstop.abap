FUNCTION-POOL ZACTMLS                    MESSAGE-ID SV.

* INCLUDE LZACTMLSD...                       " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZACTMLST00                             . "view rel. data dcl.
