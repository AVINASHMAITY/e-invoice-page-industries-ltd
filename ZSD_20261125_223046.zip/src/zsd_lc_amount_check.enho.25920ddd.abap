"Name: \PR:SAPLV60A\EX:RV_INVOICE_DOCUMENT_ADD_14\EI
ENHANCEMENT 0 ZSD_LC_AMOUNT_CHECK.
*
  DATA : lv_lc_refnr TYPE	/obiz/zlcelcrfnr,
         lv_version TYPE /obiz/zlciverson,
         lv_lc_amount TYPE  /obiz/zlcilcamt.

*-->Begin of PDC Decleration
TYPES:BEGIN OF ty_bill1, "Get first billing doc no
      bill1_z1 TYPE char16,  "Billing Document
      bill1_zb1 TYPE vbeln_vf,  "Billing Document
      END OF ty_bill1.

TYPES:BEGIN OF ty_bkpf,
      bukrs TYPE bukrs,   "Company CODE
      belnr TYPE belnr_d, "Accounting Document NUMBER
      gjahr TYPE gjahr,   "Fiscal Year
      xblnr TYPE xblnr1,  "Reference Document Number
      END OF ty_bkpf.

TYPES:BEGIN OF ty_bseg,
      bukrs	TYPE bukrs,   "Company Code
      belnr	TYPE belnr_d, "Accounting Document Number
      gjahr	TYPE gjahr,   "Fiscal Year

      zfbdt	TYPE dzfbdt,  "Baseline Date for Due Date Calculation
      END OF ty_bseg.

TYPES:BEGIN OF ty_base, "Base line date
      bill1_zb1 TYPE vbeln_vf,  "Billing Document
      zfbdt_g TYPE dzfbdt,  "Baseline Date for Due Date Calculation
      END OF ty_base.


DATA:li_cheques TYPE STANDARD TABLE OF zsd_pd_cheques,
     li_cheques2 TYPE STANDARD TABLE OF zsd_pd_cheques,
     li_cheques3 TYPE STANDARD TABLE OF zsd_pd_cheques,
     li_cheques4 TYPE STANDARD TABLE OF zsd_pd_cheques,
     lw_cheques TYPE zsd_pd_cheques,
     l_flag TYPE flag.

DATA:li_bill1 TYPE STANDARD TABLE OF ty_bill1,
     lw_bill1 TYPE ty_bill1,
     li_bkpf TYPE STANDARD TABLE OF ty_bkpf,
     lw_bkpf TYPE ty_bkpf,
     li_bseg TYPE STANDARD TABLE OF ty_bseg,
     lw_bseg TYPE ty_bseg,
     li_base TYPE STANDARD TABLE OF ty_base,
     lw_base TYPE ty_base.

DATA:t_bill TYPE netwr,
     t_cheq_v TYPE netwr,
     l_diff TYPE netwr,
     l_adj_amt TYPE netwr,
     l_date TYPE sy-datum.

DATA:lv_vbrp TYPE vbrp,
     lv_vbrk type vbrk.

DATA:im_xubname TYPE  xubname,
     im_subject  TYPE  char50,
     li_solitab  TYPE  soli_tab,
     lw_solitab TYPE soli.

DATA:lv_sytabix TYPE sy-tabix.

FIELD-SYMBOLS:<fs_cheques> TYPE zsd_pd_cheques.

CONSTANTS:c_000 TYPE zcheque_bal VALUE '0.00',
          c_001 TYPE buzei VALUE '01',
          c_005 TYPE i VALUE '5'.

*-->End of PDC Decleration

  IF vbkd-zterm CS 'LC'.
    SELECT SINGLE lc_refnr version
           INTO (lv_lc_refnr,lv_version)
           FROM /obiz/zlceord
           WHERE vbeln = vbak-vbeln.
      IF sy-subrc = 0.
        SELECT SINGLE lc_amount
             INTO lv_lc_amount
             FROM /obiz/zlcelcmst
             WHERE lc_refnr = lv_lc_refnr
             AND version = lv_version.
          IF sy-subrc = 0 AND lv_lc_amount < ( xvbrk-netwr +
                                               xvbrk-mwsbk ).
             MESSAGE e029(zsd_messages).
          ENDIF.
      ENDIF.
  ENDIF.

*-->Begin of PDC Chnages
*BREAK-POINT.
If VBRK-VBTYP NE 'O' and VBRK-VBTYP NE 'P' .
 IF sy-tcode = 'VF01' AND vbrk-zlsch = 'X'.
  CLEAR:li_cheques,li_cheques2,li_cheques3,li_cheques4,li_bill1,li_base,t_bill,t_cheq_v,l_flag,l_date,
        lv_vbrp,l_adj_amt.
  DATA lv_flag.
  "Import from ZENH_SD_PDC_CHEQUE Enhancement for PDC Cheque Validation
  IMPORT lv_flag FROM MEMORY ID 'LV_FLAG'.

  IF lv_flag IS NOT INITIAL.
   MESSAGE e005(zsd_messages) WITH 'No PDC Amount Available for Customer'
                                     xvbrk-vkorg lv_vbrp-vkbur xvbrk-kunag.
  ENDIF.

  l_date = sy-datum.
  READ TABLE xvbrp INTO lv_vbrp INDEX 1.

  SELECT * FROM zsd_pd_cheques INTO TABLE li_cheques
     WHERE bukrs = vbrk-bukrs
     AND vkorg  = vbrk-vkorg
     AND vkbur  = lv_vbrp-vkbur
     AND kunnr = vbrk-kunag
     AND valut GE l_date
     AND bal_amt NE c_000.

*  IF li_cheques IS NOT INITIAL.

read table xvbrk INTO lv_vbrk INDEX 1.

*  t_bill = lv_vbrk-netwr + lv_vbrk-mwsbk.
  t_bill = xvbrk-netwr + xvbrk-mwsbk.
  DELETE li_cheques WHERE bal_amt IS INITIAL.

  SELECT * FROM zsd_pd_cheques INTO TABLE li_cheques2
           WHERE bukrs = vbrk-bukrs
           AND vkorg  = vbrk-vkorg
           AND vkbur  = lv_vbrp-vkbur
           AND kunnr = vbrk-kunag
           AND valut GE l_date
           AND cheque_type = 'L'.
  IF sy-subrc = 0.
    APPEND LINES OF li_cheques2 TO li_cheques.
    SORT li_cheques BY guid_16 cheque_type.
    DELETE ADJACENT DUPLICATES FROM li_cheques COMPARING guid_16.
  ENDIF.

  IF li_cheques IS NOT INITIAL.

    SORT li_cheques BY valut.

*-->Remove 4 times utilised Cheque
    LOOP AT li_cheques INTO lw_cheques WHERE vbeln1 IS NOT INITIAL
                                   AND   vbeln2 IS NOT INITIAL
                                   AND   vbeln3 IS NOT INITIAL
                                   AND   vbeln4 IS NOT INITIAL.
      DELETE li_cheques INDEX sy-tabix.
    ENDLOOP.

    IF li_cheques IS INITIAL.

*      MESSAGE e005(zsd_messages) WITH 'No PDC Amount Available for Customer'
*                                      vbrk-vkorg lv_vbrp-vkbur vbrk-kunag.
    ELSE.

*--> Taking All Cheques
      LOOP AT li_cheques INTO lw_cheques.
        t_cheq_v = t_cheq_v + lw_cheques-bal_amt.

*-->For Local Cheques
        IF lw_cheques-cheque_type = 'L'.
          APPEND lw_cheques TO li_cheques3.  " Logic
          l_flag = 'X'.
          EXIT.
        ENDIF.
*-->Non Local Cheques
        IF t_cheq_v GE t_bill.
          APPEND lw_cheques TO li_cheques3.  " Logic
          l_flag = 'X'.
          EXIT.
        ELSE.
          APPEND lw_cheques TO li_cheques3.
        ENDIF.
      ENDLOOP.

      IF l_flag NE 'X'.

*        MESSAGE e005(zsd_messages) WITH 'No Sufficent PDC Amount Available for Customer'
*                                   vbrk-vkorg lv_vbrp-vkbur vbrk-kunag.
      ENDIF.
    ENDIF.
  ELSE.

*    MESSAGE e005(zsd_messages) WITH 'No PDC Amount Available for Customer'
*                               vbrk-vkorg lv_vbrp-vkbur vbrk-kunag.
  ENDIF.
ENDIF.
Endif.
*-->End of PDC Chnages

ENDENHANCEMENT.
