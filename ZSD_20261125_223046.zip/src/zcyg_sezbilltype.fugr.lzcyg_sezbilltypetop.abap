FUNCTION-POOL ZCYG_SEZBILLTYPE           MESSAGE-ID SV.

* INCLUDE LZCYG_SEZBILLTYPED...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_SEZBILLTYPET00                    . "view rel. data dcl.
