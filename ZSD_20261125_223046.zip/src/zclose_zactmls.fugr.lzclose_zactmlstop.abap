FUNCTION-POOL ZCLOSE_ZACTMLS             MESSAGE-ID SV.

* INCLUDE LZCLOSE_ZACTMLSD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCLOSE_ZACTMLST00                      . "view rel. data dcl.
