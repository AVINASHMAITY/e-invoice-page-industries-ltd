"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:END\EN:ZSD_HIDE_ORDER_REASON\SE:END\EI
ENHANCEMENT 0 ZSD_REQ_DEL_DATE_IDOC.
*&---------------------------------------------------------------------------------
*Date       : 23.05.2023
*Programmer : Sumit
*TR No.     : DR1K975396
*Description: Enhancment for Requsted Delivery Date
*&---------------------------------------------------------------------------------
DATA : lv_idoc TYPE char1.
import lv_idoc from MEMORY id 'LV_IDOC'.
data:lv_ZTERM type vbkd-zterm.

If Sy-tcode = 'VA01' and lv_idoc = 'X'.
vbak-VDATU = sy-datum .

ENDIF.
ENDENHANCEMENT.
