"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZACT_VALIDATION_SYNGENE.


if sy-tcode = 'VA01' or sy-tcode = 'VA02'.
DATA:lt_zactmls_update TYPE TABLE OF zactmls,
     lw_zactmls_update TYPE zactmls.
data lt_zactmls2 TYPE TABLE OF zactmls.
data lw_zactmls3  TYPE zactmls.

TYPES:BEGIN OF ty_zactmls,
        act_ml  TYPE zactmls-act_ml,
        act_dt  TYPE zactmls-act_dt,
        percen  TYPE zactmls-percen,
        act_val TYPE zactmls-act_val,
        curren  TYPE zactmls-curren,
      END OF ty_zactmls.
DATA: lt_zactmls        TYPE TABLE OF ty_zactmls,
      "$. Region PWC : Activity Validation modification : 29.07.2024
      lt_zactmls_mod    TYPE STANDARD TABLE OF zactmls,
      ls_zactmls_mod    TYPE  zactmls,
      ls_zactmls_update TYPE  zactmls.
DATA : lr_act_ml TYPE RANGE OF ZMLST_ZAEHL.
      "$. Endregion PWC : Activity Validation modification : 29.07.2024
DATA lw_zactmls TYPE ty_zactmls.
data lv_act_val_tot TYPE zactmls-act_val.
DATA : lv_err_chk TYPE char1. " ADDED By Sagar Desai on 23.08.2024
**********************validation
TYPES:BEGIN OF ty_auart,
            auart TYPE vbak-auart,
      END OF ty_auart.
    DATA lt_auart TYPE TABLE OF ty_auart.
    DATA lw_auart TYPE  ty_auart.
"$. Region PWC : Activity Validation modification : 29.07.2024
    DATA : lt_blocks TYPE STANDARD TABLE OF tvarvc,
           lr_blocks TYPE RANGE OF faksp,
           lv_blocks TYPE string.
    CLEAR : lt_blocks, lr_blocks , lv_blocks.
"$. Endregion PWC : Activity Validation modification : 29.07.2024

    DATA: lr_dir_range TYPE RANGE OF char50,
          ls_dir_name  LIKE LINE OF lr_dir_range.
    "$. Region PWC : Activity Validation modification : 29.07.2024

    SELECT *
           FROM tvarvc
           INTO TABLE lt_blocks
           WHERE name = 'ZACTMLS_BLOCKS'.
    IF lt_blocks IS NOT INITIAL.
      lr_blocks = VALUE #( FOR ls_blocks IN lt_blocks ( sign   = ls_blocks-sign
                                                        option = ls_blocks-opti
                                                        low    = ls_blocks-low
                                                        high   = ls_blocks-high ) ).
      IF lr_blocks IS NOT INITIAL.
        DATA(lt_fplt) = xfplt[].
        DELETE lt_fplt WHERE faksp NOT IN lr_blocks.
      ENDIF.
    ENDIF.

*    READ TABLE xfplt TRANSPORTING NO FIELDS WITH KEY faksp = 'Z9'.
          IF lt_fplt IS NOT INITIAL.
            SELECT COUNT( * ) FROM ZCLOSE_ZACTMLS UP TO 1 ROWS WHERE vbeln = vbak-vbeln.
              IF sy-subrc <> 0.
               DATA(lv_Z9_error) = |{ 'Closing Block is not allowed in the Billing Plan, SO: ' }| && vbak-vbeln && |{ ' missing in TCODE: ZSD_PROJ_CLOSURE.' }|.
               MESSAGE lv_Z9_error TYPE 'E'.
              ENDIF.
          ENDIF.
    "$. Endregion PWC : Activity Validation modification : 29.07.2024
    SELECT sign
           opti
           low
           high
    INTO TABLE lr_dir_range
    FROM tvarvc
    WHERE name = 'ZSD_SYN_SO_FFS'
    AND type = 'S'.

    IF sy-subrc = 0 AND lr_dir_range IS NOT INITIAL.
      LOOP AT lr_dir_range INTO ls_dir_name.
        CLEAR lw_auart.
        IF ls_dir_name-low IS NOT INITIAL.
          lw_auart-auart =  ls_dir_name-low.
          APPEND lw_auart TO lt_auart.
        ENDIF.
        CLEAR lw_auart.
        IF ls_dir_name-high IS NOT INITIAL.
          lw_auart-auart =  ls_dir_name-high.
          APPEND lw_auart TO lt_auart.
        ENDIF.
      ENDLOOP.
    ENDIF.
**********************End of validation

"$. Region PWC : Activity Validation modification : 29.07.2024
    CLEAR lw_auart.
*****************    comm by mohan
*    READ TABLE lt_auart INTO lw_auart
*    WITH KEY auart = vbak-auart.
*    IF sy-subrc = 0.
*       IF xfplt[] IS INITIAL.
*         MESSAGE 'Please maintain billing plan value' TYPE 'E'.
*       ENDIF.
*     ENDIF.
**************     comm by mohan

***********add by mohan************************************************
        LOOP AT xvbap INTO DATA(ls_vbap_A).
          IF ls_vbap_A-PSTYV = 'ZTO1'.
            IF xfplt[] IS INITIAL.
              MESSAGE 'Please maintain billing plan value' TYPE 'E'.
            ENDIF.
          ENDIF.

        ENDLOOP.
*************add by mohan**********************************************



"$. Endregion PWC : Activity Validation modification : 29.07.2024
IMPORT lt_zactmls_update[]  FROM MEMORY ID 'LT_ZACTMLS'.
FIELD-SYMBOLS: <fs_table> like LINE OF lt_zactmls_update.
loop at lt_zactmls_update assigning <fs_table>.
   <fs_table>-vbeln = vbak-vbeln.
   <fs_table>-bukrs = vbak-bukrs_vf.
   <fs_table>-vkorg = vbak-vkorg.
   <fs_table>-curren = vbak-waerk.
   <fs_table>-kunnr  = vbak-kunnr.
   modify lt_zactmls_update from <fs_table>.
   IF <fs_table>-project_closure IS INITIAL.   "(+)PWC : Activity Validation modification : 29.07.2024
     lv_act_val_tot = lv_act_val_tot + <fs_table>-act_val.
   ENDIF.                                      "(+)PWC : Activity Validation modification : 29.07.2024
ENDLOOP.

    "BOC activity issue 10.7.24
    DATA: lv_vbap_netwr TYPE zactmls-act_val.
    CLEAR lv_vbap_netwr.
"$. Region PWC : Activity Validation modification : 29.07.2024
*    LOOP AT xvbap into DATA(ls_xvbap).
*      if ls_xvbap-pstyv eq 'ZTO1'.
*        lv_vbap_netwr = lv_vbap_netwr + ls_xvbap-netwr.
*      endif.
*    ENDLOOP.
    LOOP AT xfplt into DATA(ls_xfplt) WHERE faksp NOT IN lr_blocks.
      lv_vbap_netwr = lv_vbap_netwr + ls_xfplt-fakwr.
    ENDLOOP.
"$. Endregion PWC : Activity Validation modification : 29.07.2024
    "EOC activity issue 10.7.24

    if lt_zactmls_update is NOT INITIAL .

    CLEAR lw_auart.
    READ TABLE lt_auart INTO lw_auart
    WITH KEY auart = vbak-auart.
    IF sy-subrc = 0.

**** Soc By Sagar Desai on 23.08.2024 ****
      CLEAR : lv_err_chk.
      LOOP AT lt_zactmls_update INTO DATA(wa_zactmls_v).
        IF wa_zactmls_v-act_ml IS INITIAL
        OR wa_zactmls_v-ml_desc IS INITIAL
        OR wa_zactmls_v-act_dt IS INITIAL
        OR wa_zactmls_v-act_val IS INITIAL
        OR wa_zactmls_v-curren IS INITIAL.
          lv_err_chk = 'X'.
        ENDIF.

"$. Region PWC : Activity Validation modification : 29.07.2024
*        IF sy-tcode EQ 'VA02'.
*          IF wa_zactmls_v-cmpl_dt IS INITIAL.
*            lv_err_chk = 'X'.
*          ENDIF.
*        ENDIF.
"$. Endregion PWC : Activity Validation modification : 29.07.2024

        IF lv_err_chk = 'X'.
          EXIT.
        ENDIF.
      ENDLOOP.

      IF lv_err_chk = 'X'.
        MESSAGE 'Activity tab row data missing' TYPE 'E'.
      ENDIF.
**** Eoc By Sagar Desai on 23.08.2024 ****

        if lv_act_val_tot ne lv_vbap_netwr."vbak-netwr.
        MESSAGE 'Activity milestones value do not match sales order value' TYPE 'E'.
        ENDIF.
      ELSE.

*      ENDIF.   "(+)PWC : Activity Validation modification : 29.07.2024
    ENDIF.

    "$. Region PWC : Activity Validation modification : 29.07.2024
    CLEAR : ls_zactmls_update, lt_zactmls_mod , ls_zactmls_mod.
        SELECT * FROM zactmls INTO
          TABLE lt_zactmls_mod
          WHERE vbeln = vbak-vbeln
            AND vkorg = vbak-vkorg.
        IF sy-subrc = 0.
          "Insert and update zactmls
          LOOP AT lt_zactmls_update INTO ls_zactmls_update.
            MODIFY zactmls FROM ls_zactmls_update.
            CLEAR : ls_zactmls_update.
          ENDLOOP.
          "Delete records from zactmls
          LOOP AT lt_zactmls_mod INTO ls_zactmls_mod.
            READ TABLE lt_zactmls_update INTO ls_zactmls_update WITH KEY vbeln  = ls_zactmls_mod-vbeln
                                                                         act_ml = ls_zactmls_mod-act_ml
                                                                         vkorg  = ls_zactmls_mod-vkorg
                                                                         bukrs  = ls_zactmls_mod-bukrs.
            IF sy-subrc <> 0.
              DELETE zactmls FROM ls_zactmls_mod.
            ENDIF.
            CLEAR : ls_zactmls_mod, ls_zactmls_update.
          ENDLOOP.
    "$. Endregion PWC : Activity Validation modification : 29.07.2024
    ENDIF.
      else.

        SELECT  * from zactmls INTO TABLE
         lt_zactmls_update   "(+)PWC : Activity Validation modification : 29.07.2024
         WHERE vbeln = vbak-vbeln AND
                                 vkorg = vbak-vkorg AND
                                 bukrs = vbak-bukrs_vf.

      if sy-subrc = 0.
       "$. Region PWC : Activity Validation modification : 29.07.2024
        LOOP at lt_zactmls_update assigning <fs_table> WHERE project_closure IS INITIAL.
                 lv_act_val_tot = lv_act_val_tot + <fs_table>-act_val.
        ENDLOOP.
                CLEAR lw_auart.
                READ TABLE lt_auart INTO lw_auart
                     WITH KEY auart = vbak-auart.
                IF sy-subrc = 0.
                     IF lv_act_val_tot ne lv_vbap_netwr."vbak-netwr.
                        MESSAGE 'Activity milestones value do not match sales order value' TYPE 'E'.
                     ENDIF.
                 ENDIF.
       "$. Endregion PWC : Activity Validation modification : 29.07.2024
        else.

          CLEAR lw_auart.
          READ TABLE lt_auart INTO lw_auart
          WITH KEY auart = vbak-auart.
         IF sy-subrc = 0.
          if lv_act_val_tot ne lv_vbap_netwr."vbak-netwr.
          MESSAGE 'Activity milestones value do not match sales order value' TYPE 'E'.
          ENDIF.
         ENDIF.

      endif.

    endif.
    endif.   " va02 checking

ENDENHANCEMENT.
