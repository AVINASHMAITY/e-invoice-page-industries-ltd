"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_VA02_STATUS.
*****************************************************************************
*Created on        : 22.04.2020
*Developer         : Harish Paduchuri
*Functional        : Kishore Varma
*Transaport        : DR1K950441
*Description       : Status need to update on Change of Sold to party,Currency,
*                     Net Value,Payment terms in va02.
*****************************************************************************
*Modification Log
*  *Transaport        : DR1K955403
* *Description       : Condtion Payment Terms Inculded
*****************************************************************************
IF sy-tcode = 'VA02'. "and vbak-vkorg = '5100'. "commented by Samata P/Iteanz DR1K965100 26.04.2022
  Data : gc_status TYPE JEST-STAT VALUE 'E0001', " In Progress
         lv_objnr(22) TYPE c.
*  begin of code added by Samata P/Iteanz DR1K965100 26.04.2022
 DATA: lt_cons TYPE ztt_ztabap_tvarvc,
       lw_cons TYPE ztabap_tvarvc.
 CONSTANTS: lc_obj  TYPE char40 VALUE 'MV45AFZZ'.
  IF lt_cons[] IS INITIAL.
    REFRESH lt_cons[].
    CALL METHOD zcl_abap_utility=>get_options
      EXPORTING
        im_objname = lc_obj
      IMPORTING
        ex_tab     = lt_cons.
  ENDIF.
   CLEAR lw_cons.
  READ TABLE lt_cons INTO lw_cons WITH KEY low = vbak-vkorg.
  IF sy-subrc eq 0.
    IF lw_cons-low = '5100'.
*end of code by Samata P/Iteanz DR1K965100 26.04.2022

*IF XVBAK-WAERK NE YVBAK-WAERK OR
*     XVBAK-KUNNR NE YVBAK-KUNNR OR XVBAK-NETWR NE YVBAK-NETWR. "Commented By Harish on 05.01.2021 T.R->DR1K955403
*  Changes By Harish on 05.01.2021 T.R->DR1K955403
*  New Condtion Payment Terms Inculded .
  IF ( VBAK-WAERK NE YVBAK-WAERK OR
     VBAK-KUNNR NE YVBAK-KUNNR OR VBAK-NETWR NE YVBAK-NETWR ) .
*    End By Harish.
  CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.
*  Changes By Harish on 05.01.2021 T.R->DR1K955403
  ELSEIF XVBAP-NETPR NE YVBAP-NETPR AND XVBAP-UPDKZ = 'U' .
     CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.
 ENDIF.
* Ended By Harish.
 DATA : lt_vkd type table of vbkd,
        ls_vkd type vbkd.
 REFRESH : lt_vkd.
 clear : ls_vkd.
    lt_vkd[] = XVBKD[].
 IF XVBKD-ZTERM NE YVBKD-ZTERM.
   READ TABLE lt_vkd INTO ls_vkd with key posnr = '000000'.
   if sy-subrc = 0.
   IF XVBKD-UPDKZ = 'U' .
     CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.

 ENDIF.
 ENDIF.
 ENDIF.
 ENDIF.
* begin of code by Samata P/Iteanz DR1K965100 26.04.2022
 ENDIF.
 IF lw_cons-LOW EQ '1101' OR lw_cons-LOW EQ '1301'. " '1301' ADDED by Samata P/Iteanz DR1K965100 30.06.2022
* Begin of code by Samata P/Iteanz DR1K972180 16.02.2023
* IF vbuk-LFGSK = 'C'. " "Commented by Samata P/Iteanz DR1K972180 22.02.2023
*   CLEAR : LV_OBJNR.
*   CONCATENATE 'VB'
*              VBAK-VBELN
*              '000000' INTO LV_OBJNR.
*  CONDENSE LV_OBJNR.
*  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
*    EXPORTING
*            client              = sy-mandt
*            objnr               = lv_objnr
*            user_status         = gc_status
*          EXCEPTIONS
*            object_not_found    = 1
*            status_inconsistent = 2
*            status_not_allowed  = 3
*            OTHERS              = 4.
*  IF sy-subrc EQ 0.
*          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*            EXPORTING
*              wait = 'X'.
*  ENDIF.
* ENDIF.
* IF XVBAP-abgru is not INITIAL AND XVBAP-UPDKZ = 'U' .
*     CLEAR : LV_OBJNR.
*  CONCATENATE 'VB'
*              VBAK-VBELN
*              '000000' INTO LV_OBJNR.
*  CONDENSE LV_OBJNR.
*  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
*    EXPORTING
*            client              = sy-mandt
*            objnr               = lv_objnr
*            user_status         = gc_status
*          EXCEPTIONS
*            object_not_found    = 1
*            status_inconsistent = 2
*            status_not_allowed  = 3
*            OTHERS              = 4.
*  IF sy-subrc EQ 0.
*          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*            EXPORTING
*              wait = 'X'.
*  ENDIF.
*  ENDIF.    "Commented by Samata P/Iteanz DR1K972180 22.02.2023
*end by Samata P/Iteanz DR1K972180 16.02.2023
 IF YVBPA-KUNNR IS NOT INITIAL.
   IF YVBPA-KUNNR NE KUWEV-KUNNR. "  AND XVBPA-UPDKZ = 'U' .
     CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.

 ELSEif  XVBPA-KUNNR EQ YVBPA-KUNNR .
*   IF XVBPA-UPDKZ = 'U'.
    CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.
  ENDIF.
ELSEif  XVBPA-KUNNR ne YVBPA-KUNNR .
   IF XVBPA-UPDKZ = 'U'.
    CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.
ENDIF.
 ENDIF.
*  begin of code by Samata P/Iteanz DR1K965100 09.06.2022
* IF ( XVBAP-MATNR NE YVBAP-MATNR OR XVBAP-KWMENG NE YVBAP-KWMENG ) "commented by Samata P/Iteanz DR1K965100 30.06.2022
*   AND XVBAP-UPDKZ = 'U' .
*     CLEAR : LV_OBJNR.
*  CONCATENATE 'VB'
*              VBAK-VBELN
*              '000000' INTO LV_OBJNR.
*  CONDENSE LV_OBJNR.
*  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
*    EXPORTING
*            client              = sy-mandt
*            objnr               = lv_objnr
*            user_status         = gc_status
*          EXCEPTIONS
*            object_not_found    = 1
*            status_inconsistent = 2
*            status_not_allowed  = 3
*            OTHERS              = 4.
*  IF sy-subrc EQ 0.
*          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
*            EXPORTING
*              wait = 'X'.
*  ENDIF.
*  ENDIF.

* ended by Samata P/Iteanz DR1K965100 09.06.2022
 DATA : lt_vkd1 type table of vbkd,
        ls_vkd1 type vbkd.
 REFRESH : lt_vkd1.
 clear : ls_vkd1.
    lt_vkd1[] = XVBKD[].
 IF XVBKD-ZTERM NE YVBKD-ZTERM OR XVBKD-INCO1 NE YVBKD-INCO1
    OR XVBKD-BSTKD NE YVBKD-BSTKD OR XVBKD-BSTDK NE YVBKD-BSTDK.
   READ TABLE lt_vkd1 INTO ls_vkd1 with key posnr = '000000'.
   if sy-subrc = 0.
   IF XVBKD-UPDKZ = 'U' .
     CLEAR : LV_OBJNR.
  CONCATENATE 'VB'
              VBAK-VBELN
              '000000' INTO LV_OBJNR.
  CONDENSE LV_OBJNR.
  CALL FUNCTION 'STATUS_CHANGE_EXTERN'
    EXPORTING
            client              = sy-mandt
            objnr               = lv_objnr
            user_status         = gc_status
          EXCEPTIONS
            object_not_found    = 1
            status_inconsistent = 2
            status_not_allowed  = 3
            OTHERS              = 4.
  IF sy-subrc EQ 0.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = 'X'.
  ENDIF.

 ENDIF.
 ENDIF.
 ENDIF.

ENDIF.
* end of code by Samata P/Iteanz DR1K965100 26.04.2022
ENDIF.
*** ENDIF.
***ENDIF.
ENDENHANCEMENT.
