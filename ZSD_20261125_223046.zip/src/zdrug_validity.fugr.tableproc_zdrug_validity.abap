*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDRUG_VALIDITY
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDRUG_VALIDITY      .

  PERFORM TABLEPROC.

ENDFUNCTION.
