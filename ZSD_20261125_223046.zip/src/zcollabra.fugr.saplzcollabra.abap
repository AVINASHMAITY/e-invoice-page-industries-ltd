*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCOLLABRATOP.                     " Global Data
  INCLUDE LZCOLLABRAUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCOLLABRAF...                     " Subroutines
* INCLUDE LZCOLLABRAO...                     " PBO-Modules
* INCLUDE LZCOLLABRAI...                     " PAI-Modules
* INCLUDE LZCOLLABRAE...                     " Events
* INCLUDE LZCOLLABRAP...                     " Local class implement.
* INCLUDE LZCOLLABRAT99.                     " ABAP Unit tests
