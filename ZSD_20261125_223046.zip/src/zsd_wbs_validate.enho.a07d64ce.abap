"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAP\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_WBS_VALIDATE.
*                                                                                           *
*  Begin of - SAP_ARVIVI (Arvind), Requested by Naga Ramesh Solasa on 15-June-2015          *
*  Validation in Sales order : Plant in Sales order and Plant in WBS element should be same *
if vbap-ps_psp_pnr is not INITIAL AND VBAK-VBTYP = 'C'. " DR1K938817 22-Feb-2018 SAP_KARTHM / JKT
*
DATA : lw_constants TYPE ztabap_tvarvc,
       li_constants TYPE ztt_ztabap_tvarvc.
data : v_cutoff_date type sy-datum.
*
*
  CALL METHOD zcl_abap_utility=>get_parameters
    EXPORTING
      im_objname = sy-repid
    IMPORTING
      ex_tab     = li_constants.
*
  READ TABLE li_constants INTO lw_constants
  WITH KEY   obj_name = sy-repid
             name     = 'C_CUTOFF_DATE'.
*
  if sy-subrc eq 0.
*
    v_cutoff_date = lw_constants-low.
*
  endif.
*
if  vbak-erdat GE v_cutoff_date
and v_cutoff_date ne '' .
*
 if sy-tcode eq 'VA01'
 or sy-tcode eq 'VA02'.
*
 data: v_bukrs_s TYPE bukrs,
       v_werk_pj TYPE werks_d,
       w_bukrs_s TYPE knb1-bukrs.
*
 select single BUKRS
   from tvko
   into v_bukrs_s
  where vkorg eq vbak-vkorg.
*
  if ( v_bukrs_s eq '5100' ).
*
    select single WERKS
      from prps
      into v_werk_pj
     where pspnr eq vbap-ps_psp_pnr.
*
     if v_werk_pj ne vbap-werks.
*
       MESSAGE e067(zsd_messages) with vbap-posnr vbap-werks v_werk_pj.
*
     endif.
*
  endif.
*
 endif.
*
 endif.
*
endif.
*  End of - SAP_ARVIVI (Arvind), Requested by Naga Ramesh Solasa on 15-June-2015               *
ENDENHANCEMENT.
