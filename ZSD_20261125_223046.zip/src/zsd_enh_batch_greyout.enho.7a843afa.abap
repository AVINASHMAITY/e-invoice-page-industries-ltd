"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_BATCH_GREYOUT.
**********************************************************************
*Implementetaion   : ZSD_ENH_BATCH_GREYOUT                           *
*Created on        : 30.11.2017                                      *
*Developer         : Chaithanya/Iteanz                               *
*Functional        : Saroj                                           *
*Transaport        : DR1K937255                                      *
*Description       : Batch field Greyout in Return Sales Order       *
**********************************************************************
CONSTANTS : LC1_VA01(4) VALUE 'VA01',
            LC1_VA02(4) VALUE 'VA02',
            LC1_YBRE(4) VALUE 'YBRE',
            LC1_ZBRE(4) VALUE 'ZBRE',
            LC1_ZBRZ(4) VALUE 'ZBRZ',
            LC1_BATCH(10) VALUE 'VBAP-CHARG'.
IF  SY-TCODE = LC1_VA01 OR SY-TCODE = LC1_VA02.
IF  VBAK-AUART = LC1_YBRE OR VBAK-AUART = LC1_ZBRE OR
    VBAK-AUART = LC1_ZBRZ .
    IF SCREEN-NAME = LC1_BATCH.
    SCREEN-INPUT = 0.
    MODIFY SCREEN.
    ENDIF.
ENDIF.
ENDIF.

ENDENHANCEMENT.
