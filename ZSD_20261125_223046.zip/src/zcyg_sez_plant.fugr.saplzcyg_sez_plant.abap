*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_SEZ_PLANTTOP.                " Global Data
  INCLUDE LZCYG_SEZ_PLANTUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_SEZ_PLANTF...                " Subroutines
* INCLUDE LZCYG_SEZ_PLANTO...                " PBO-Modules
* INCLUDE LZCYG_SEZ_PLANTI...                " PAI-Modules
* INCLUDE LZCYG_SEZ_PLANTE...                " Events
* INCLUDE LZCYG_SEZ_PLANTP...                " Local class implement.
* INCLUDE LZCYG_SEZ_PLANTT99.                " ABAP Unit tests
  INCLUDE LZCYG_SEZ_PLANTF00                      . " subprograms
  INCLUDE LZCYG_SEZ_PLANTI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
