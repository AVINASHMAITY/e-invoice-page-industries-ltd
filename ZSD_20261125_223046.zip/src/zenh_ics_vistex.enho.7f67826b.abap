"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZENH_ICS_VISTEX.
  IF VBAK-KALSM = 'ZVXPRT'.
   DATA: lv_xld2 TYPE kbetr,
         lv_xld3 TYPE kbetr.
   READ TABLE xkomv WITH KEY kschl = 'XLD2'
                             kposn = vbap-posnr.
   IF sy-subrc IS INITIAL.
    lv_xld2 = xkomv-kbetr.
   ENDIF.

   READ TABLE xkomv WITH KEY kschl = 'XLD3'
                             kposn = vbap-posnr.
   IF sy-subrc IS INITIAL.
    lv_xld3 = xkomv-kbetr.
   ENDIF.

   IF lv_xld2 NE lv_xld3.
    MESSAGE 'XLD2 and XLD3 pricing is mismatch' TYPE 'E'.
   ENDIF.

  ENDIF.
ENDENHANCEMENT.
