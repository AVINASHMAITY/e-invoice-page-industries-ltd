"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ZBAS_MANDATORY.
************************************************************************
*Implementetaion   : ZSD_ZBAS_MANDATORY                                *
*Created on        : 26.11.2020                                        *
*Developer         : Ravindran                                         *
*Functional        : Ravi                                              *
*Transport         : DR1K954675                                        *
*Description       : ZBAS condition type mandatory for SO & Invoice    *
************************************************************************
CONSTANTS : lc_bas_prg TYPE sobj_name VALUE 'ZSD_ZBAS_PRICE',
            lc_bas_vkorg(10) VALUE 'ZBAS_VKORG'.
DATA : lt_bas_con TYPE ztt_ztabap_tvarvc,
       lw_bas_con TYPE ztabap_tvarvc.

IF  sy-tcode = 'VA01' OR sy-tcode = 'VA02' OR sy-tcode = 'VA03'.

  CLEAR : lw_bas_con.
  CALL METHOD zcl_abap_utility=>get_options
    EXPORTING
      im_objname = lc_bas_prg
    IMPORTING
      ex_tab     = lt_bas_con.

  READ TABLE lt_bas_con INTO lw_bas_con
         WITH KEY   obj_name = lc_bas_prg
                    name     = lc_bas_vkorg
                    low      = vbak-vkorg.
  IF sy-subrc = 0.
    IF komk-vbtyp EQ 'C' OR
       komk-vbtyp EQ 'M'.
      LOOP AT xvbap.
        READ TABLE xkomv WITH KEY kschl = 'ZBAS'
                                  kposn = xvbap-posnr.
        IF sy-subrc EQ 0.
*          IF xkomv-kawrt IS INITIAL.
*            MESSAGE 'Please enter ZBAS condition value' TYPE 'E'.
*          ENDIF.
        ELSE.
          MESSAGE 'Please enter ZBAS condition' TYPE 'E'.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
