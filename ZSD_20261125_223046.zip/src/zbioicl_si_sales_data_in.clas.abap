class ZBIOICL_SI_SALES_DATA_IN definition
  public
  create public .

public section.

  interfaces ZBIOIII_SI_SALES_DATA_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOICL_SI_SALES_DATA_IN IMPLEMENTATION.


  METHOD zbioiii_si_sales_data_in~si_sales_data_in.
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Object Name :  ZBIOIII_SI_SALES_DATA_IN~SI_SALES_DATA_IN             *
* Author/Company Name : Arya/ITZ                                       *
* Transport Request :  DR1K944102                                      *
* Creation Date : 21.02.2019                                           *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Modification History *
*&---------------------------------------------------------------------*
* Date Programmer Client Ref No. Description Correction *
* 27.06.2019  Arya/ITZ   DR1K946138        Change logic as per ftp logic
* 13.01.2020  Pranesh/ITZ   DR1K949078     Regiodesc & s_vkorg logic change *                                              *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*----------------------------------------------------------------------*
*  declaration
*----------------------------------------------------------------------*

    TYPES : BEGIN OF t_vbfa,
              vbelv   TYPE vbfa-vbelv,
              posnv   TYPE vbfa-posnv,
              vbeln   TYPE vbfa-vbeln,
              posnn   TYPE vbfa-posnn,
              vbtyp_v TYPE vbfa-vbtyp_v,
            END OF t_vbfa.

    DATA : i_vbfa TYPE TABLE OF t_vbfa,
           w_vbfa TYPE t_vbfa.


    TYPES : BEGIN OF t_tvk6t,
              katr6 TYPE tvk6t-katr6,
              vtext TYPE tvk6t-vtext,
            END OF t_tvk6t.

    DATA : i_tvk6t TYPE TABLE OF t_tvk6t,
           w_tvk6t TYPE t_tvk6t.


    TYPES  : BEGIN OF t_konv,
               knumv TYPE konv-knumv,
               kposn TYPE konv-kposn,
               kschl TYPE konv-kschl,
               kbetr TYPE konv-kbetr,
               waers TYPE konv-waers,
               kwert TYPE konv-kwert,
               kinak TYPE konv-kinak, " Added by khurshida on 6/2/2016 DR1K926881
               kstat TYPE kstat, "Added by chandru "DR1K941261
             END OF t_konv.

    DATA : i_konv TYPE TABLE OF t_konv,
           w_konv TYPE t_konv.

    TYPES : BEGIN OF t_vbpa,
              vbeln TYPE vbpa-vbeln,
              posnr TYPE vbpa-posnr,
              parvw TYPE vbpa-parvw,
              kunnr TYPE vbpa-kunnr,
              adrnr TYPE vbpa-adrnr,
            END OF t_vbpa.

    DATA : i_vbpa  TYPE TABLE OF t_vbpa,
           i_vbpa1 TYPE TABLE OF t_vbpa,
           w_vbpa  TYPE t_vbpa.

    TYPES : BEGIN OF t_kna1_sh,
              kunnr TYPE kna1-kunnr,
              land1 TYPE land1_gp,  "Added by chandru "DR1K938567
              name1 TYPE kna1-name1,
              ort01 TYPE kna1-ort01,
              regio TYPE regio, "Added by chandru "DR1K938567
              stras TYPE stras_gp, "Added by chandru "DR1K938567
            END OF t_kna1_sh.

    DATA : i_kna1_sh TYPE TABLE OF t_kna1_sh,
           w_kna1_sh TYPE t_kna1_sh.

    TYPES : BEGIN OF t_cepct,
              prctr TYPE cepct-prctr,
              ktext TYPE cepct-ktext,
            END OF t_cepct.

    DATA : i_cepct TYPE TABLE OF t_cepct,
           w_cepct TYPE t_cepct.

    TYPES : BEGIN OF t_adrc_land1,
              addrnumber TYPE adrc-addrnumber,
              country    TYPE adrc-country,
              landx      TYPE t005t-landx,
            END OF t_adrc_land1.

    DATA : i_adrc_land1 TYPE TABLE OF t_adrc_land1,
           w_adrc_land1 TYPE t_adrc_land1.
    TYPES : BEGIN OF t_t005t ,
              land1 TYPE t005t-land1,
              landx TYPE t005t-landx,
            END OF t_t005t.

    DATA : i_t005t TYPE TABLE OF t_t005t,
           w_t005t TYPE t_t005t.

    TYPES : BEGIN OF t_knvp,
              kunnr TYPE knvp-kunnr,
              vkorg TYPE knvp-vkorg,
              vtweg TYPE knvp-vtweg,
              spart TYPE knvp-spart,
              parvw TYPE knvp-parvw,
              kunn2 TYPE knvp-kunn2,
            END OF t_knvp.

    DATA : i_knvp TYPE TABLE OF t_knvp,
           w_knvp TYPE t_knvp.

    TYPES : BEGIN OF t_adrc,
              addrnumber TYPE adrc-addrnumber,
              city1      TYPE adrc-city1,
            END OF t_adrc.

    DATA : i_adrc TYPE TABLE OF t_adrc,
           w_adrc TYPE t_adrc.

    TYPES : BEGIN OF t_vbrk_p,
              vbeln         TYPE vbrk-vbeln,
              fkart         TYPE vbrk-fkart,
              vbtyp         TYPE vbrk-vbtyp, "" Added by Lokesh/iteanz DR1K924390
              waerk         TYPE vbrk-waerk,
              vkorg         TYPE vbrk-vkorg,
              vtweg         TYPE vbrk-vtweg,
              knumv         TYPE vbrk-knumv,
              fkdat         TYPE vbrk-fkdat,
              inco1         TYPE vbrk-inco1,
              inco2         TYPE vbrk-inco2,
              kurrf         TYPE vbrk-kurrf,
              kunag         TYPE vbrk-kunag,
              p_vbeln       TYPE vbrp-vbeln,
              posnr         TYPE vbrp-posnr,
              meins         TYPE vbrp-meins,
              fklmg         TYPE vbrp-fklmg,
              netwr         TYPE vbrp-netwr,
              matnr         TYPE vbrp-matnr,
              arktx         TYPE vbrp-arktx,
              charg         TYPE vbrp-charg,
              pstyv         TYPE vbrp-pstyv,
              spart         TYPE vbrp-spart,
              bukrs         TYPE vbrk-bukrs, " Added by Parth on 11/07/2014
              butxt         TYPE t001-butxt, " Added by Parth on 11/07/2014
              werks         TYPE vbrp-werks,
              lgort         TYPE vbrp-lgort,
              bzirk_auft    TYPE vbrp-bzirk_auft,
              mwsbp         TYPE vbrp-mwsbp,
              prctr         TYPE vbrp-prctr,
              ktext         TYPE cepct-ktext,

              aubel         TYPE vbrp-aubel, "17.6.2014 performance tunning
              aupos         TYPE vbrp-aupos,
              vgtyp         TYPE vbrp-vgtyp,


              mwsbp_curr    TYPE vbrp-mwsbp,
              spart_desc    TYPE tspat-vtext,
              werks_desc    TYPE t001w-name1,
              waerk_curr    TYPE vbrk-waerk,
              upwaerk       TYPE vbap-waerk,
              upwaerk_curr  TYPE vbap-waerk,
              vbelv         TYPE vbfa-vbelv,
              netwr_curr    TYPE vbrp-netwr,
              upnetwr       TYPE vbrp-netwr,
              upnetwr_curr  TYPE vbrp-netwr,
              netvalue(16)  TYPE p DECIMALS 2 , " TYPE vbrp-netwr,
              pstyv_desc    TYPE tvapt-vtext,
              name1         TYPE kna1-name1,
              ship_name     TYPE adrc-name1,
              sold_name     TYPE adrc-name1,
              ort01         TYPE kna1-ort01,
              regio_desc    TYPE t005u-bezei,
              bztxt         TYPE t171t-bztxt,
              katr6         TYPE tvk6t-vtext,
*           KATR6 TYPE kna1-KATR6,
              bstkd         TYPE vbkd-bstkd,
              bstdk         TYPE vbkd-bstdk,
              svbeln        TYPE vbak-vbeln,
              erdat         TYPE vbak-erdat,
              city1         TYPE adrc-city1,
              audat         TYPE vbak-audat,
              auart         TYPE vbak-auart,
              sold_kunnr    TYPE vbak-kunnr,
              ship_kunnr    TYPE knvp-kunn2,
              sold_country  TYPE t005t-landx,
              ship_country  TYPE t005t-landx,
              zterm         TYPE vbkd-zterm,
              fre           TYPE konv-kbetr,
              insu          TYPE konv-kbetr,
              sales_tax     TYPE konv-kbetr,
              excise        TYPE konv-kbetr,
************Begin of changes by Ravi on 01.07.2017 DR1K933640****************
              jocg_g        TYPE konv-kbetr,
              josg_g        TYPE konv-kbetr,
              joig_g        TYPE konv-kbetr,
************End of changes by Ravi on 01.07.2017 DR1K933640****************
              ship_place    TYPE kna1-ort01,
              lgort_desc    TYPE t001l-lgobe,
              exchange_rate TYPE vbkd-kursk,
              pts           TYPE konv-kbetr,
              sort2         TYPE adrc-sort2,
              nam(73)       TYPE c,
              mcod3         TYPE kna1-mcod3,
              bztxt1        TYPE t171t-bztxt,
              "Begin of addition by chandru "DR1K938567
              ricode        TYPE kunnr,
              riaddr        TYPE stras_gp,
              ristat        TYPE bezei20,
              "End of addition by chandru "DR1K938567
              text          TYPE string,
** Added by Lokesh/iteanz
              mvgr1         TYPE mvgr1,
              bezei         TYPE bezei40,
** End of change
              zzaugru       TYPE augru,
*           VKBUR TYPE TVKBT-bezei,
              xblnr         TYPE xblnr_v1,     "Added by Ravi on 12.07.2017 DR1K933984
              ship_grp      TYPE tvk6t-vtext,  "Added by Ravi on 03.08.2017 DR1K934548
              act_team      TYPE string, "Added by chandru "DR1K937960 "Changed by chadnru "DR1K938126
              zerdat        TYPE erdat, "Added by chandru "DR1K938881
              zerzet        TYPE erzet, "Added by chandru "DR1K938881
              zdisc(16)     TYPE p DECIMALS 2, "Added by chandru "DR1K938981
*          VBELV_S       TYPE VBRK-VBELN, " Added by Chaithanya DR1K939679 " Schema
*          VBELV_R       TYPE VBRK-VBELN, " Added by Chaithanya DR1K939679 " Return

            END OF t_vbrk_p.

    CONSTANTS : obj      TYPE sobj_name VALUE 'ZSDR_CUST_SALES_REP',
                gc_blank TYPE string VALUE ' '.
*Begin of the changes by Gokul - 28.07.2016
    CONSTANTS : gc_1101 TYPE vkorg VALUE '1101',
                gc_1103 TYPE vkorg VALUE '1103',
                gc_1200 TYPE vkorg VALUE '1200',
                gc_2100 TYPE vkorg VALUE '2100',
                gc_2200 TYPE vkorg VALUE '2200',
                gc_2300 TYPE vkorg VALUE '2300',
                gc_2500 TYPE vkorg VALUE '2500',
                gc_2600 TYPE vkorg VALUE '2600',
                gc_2700 TYPE vkorg VALUE '2700'.

    DATA : i_vbrk_p      TYPE TABLE OF t_vbrk_p,
           w_vbrk_p      TYPE t_vbrk_p,
           i_vbrk_p_curr TYPE TABLE OF t_vbrk_p.

    DATA: lv_quan(20),
          lv_amt(20),
          lv_mvgr1    TYPE mvke-mvgr1,
          lv_bezei    TYPE tvm1t-bezei.

    DATA : gt_tcurr TYPE TABLE OF tcurr.

    TYPES: BEGIN OF t_knvv_n,
             kunnr TYPE knvv-kunnr,
             bzirk TYPE knvv-bzirk,
           END OF t_knvv_n.

    DATA: i_knvv_n TYPE TABLE OF t_knvv_n,
          w_knvv_n TYPE t_knvv_n.

    TYPES: BEGIN OF t_t171t_n,
             bzirk TYPE t171t-bzirk,
             bztxt TYPE t171t-bztxt,
           END OF t_t171t_n.

    DATA: i_t171t_n TYPE TABLE OF t_t171t_n,
          w_t171t_n TYPE t_t171t_n.


    TYPES: BEGIN OF t_kna1_n,
             kunnr TYPE kna1-kunnr,
             name1 TYPE kna1-name1,
             name2 TYPE kna1-name2,
             ort01 TYPE kna1-ort01,
             mcod3 TYPE kna1-mcod3,
           END OF t_kna1_n.
    DATA: i_kna1_n TYPE TABLE OF t_kna1_n,
          w_kna1_n TYPE t_kna1_n.
    TYPES: BEGIN OF t_adrc_n,
             addrnumber TYPE adrc-addrnumber,
             sort2      TYPE adrc-sort2,
           END OF t_adrc_n.
    DATA: i_adrc_n TYPE TABLE OF t_adrc_n,
          w_adrc_n TYPE t_adrc_n.
    DATA : l_fklmg,
           l_netwr,
           l_mwsbp,
           l_netvalue,
           l_upnetwr,
           l_insu,
           l_fre,
           l_excise,
           l_sales_tax,
           l_netwr_curr,
           l_mwsbp_curr,
           l_upnetwr_curr.

    DATA :  l_fklmg_v(20),
            l_netwr_v(20),
            l_mwsbp_v(20),
            l_netvalue_v(20),
            l_upnetwr_v(20),
            l_insu_v(20),
            l_fre_v(20),
            l_excise_v(20),
            l_sales_tax_v(20),
            l_netwr_curr_v(20),
            l_mwsbp_curr_v(20),
            l_upnetwr_curr_v(20),
            l_jocg(20),
            l_josg(20),
            l_joig(20).


    DATA : l_str_fklmg(10),
           l_str_netwr(10),
           l_str_mwsbp(10),
           l_str_netvalue(10),
           l_str_upnetwr(10),
           l_str_insu(10),
           l_str_fre(10),
           l_str_excise(10),
           l_str_sales_tax(10),
           l_str_netwr_curr(10),
           l_str_mwsbp_curr(10),
           l_str_upnetwr_curr(10).

    TYPES : BEGIN OF t_vbkd_curr,
              vbeln TYPE vbkd-vbeln,
              posnr TYPE vbkd-posnr,
              kursk TYPE vbkd-kursk,
            END OF t_vbkd_curr.

    DATA : i_vbkd_curr TYPE TABLE OF t_vbkd_curr,
           w_vbkd_curr TYPE t_vbkd_curr.

    TYPES : BEGIN OF t_t001l,
              werks TYPE t001l-werks,
              lgort TYPE t001l-lgort,
              lgobe TYPE t001l-lgobe,
            END OF t_t001l.

    DATA : i_t001l TYPE TABLE OF t_t001l,
           w_t001l TYPE t_t001l.

    DATA : l_ukurs_1       TYPE tcurr-ukurs,
           l_ffac_1(10),
           l_lamt_1        TYPE vbrp-netwr,
           l_lfac_1(10),
           l_ukurs_x_1(50),
           l_fixed_1       TYPE vbrp-netwr,
           l_der_rate_1    TYPE tcurr-kurst.

    DATA : l_ukurs_2       TYPE tcurr-ukurs,
           l_ffac_2(10),
           l_lamt_2        TYPE vbrp-netwr,
           l_lfac_2(10),
           l_ukurs_x_2(50),
           l_fixed_2       TYPE vbrp-netwr,
           l_der_rate_2    TYPE  tcurr-kurst.

    DATA : l_ukurs_3       TYPE tcurr-ukurs,
           l_ffac_3(10),
           l_lamt_3        TYPE vbrp-netwr,
           l_lfac_3(10),
           l_ukurs_x_3(50),
           l_fixed_3       TYPE vbrp-netwr,
           l_der_rate_3    TYPE tcurr-kurst.

    TYPES : BEGIN OF t_t001w,
              werks TYPE t001w-werks,
              name1 TYPE t001w-name1,
            END OF t_t001w.

    DATA : i_t001w TYPE TABLE OF t_t001w,
           w_t001w TYPE t_t001w.

    TYPES : BEGIN OF t_tspat,
              spart TYPE tspat-spart,
              vtext TYPE tspat-vtext,
            END OF t_tspat.

    DATA : i_tspat TYPE TABLE OF t_tspat,
           w_tspat TYPE t_tspat.

    TYPES : BEGIN OF t_pstyv,
              pstyv TYPE tvapt-pstyv,
              vtext TYPE tvapt-vtext,
            END OF t_pstyv.

    DATA : i_pstyv TYPE TABLE OF t_pstyv,
           w_pstyv TYPE t_pstyv.

    TYPES : BEGIN OF t_tspat_a,
              spart TYPE tspat-spart,
            END OF t_tspat_a.

    TYPES : BEGIN OF t_vtweg,
              vtweg TYPE vbrk-vtweg,
            END OF t_vtweg.

    TYPES : BEGIN OF t_vkorg,
              vkorg TYPE vbrk-vkorg,
            END OF t_vkorg.

    DATA : i_tspat_a TYPE TABLE OF t_tspat_a,
           w_tspat_a TYPE t_tspat_a.

    DATA : i_vtweg TYPE TABLE OF t_vtweg,
           w_vtweg TYPE t_vtweg.

    DATA : i_vkorg TYPE TABLE OF t_vkorg,
           w_vkorg TYPE t_vkorg.

    TYPES : BEGIN OF t_final,
              kunnr      TYPE vbak-kunnr,
              posnr      TYPE vbap-posnr,
              vbeln      TYPE vbak-vbeln,
              zmeng      TYPE vbap-zmeng,
              zieme      TYPE vbap-zieme,
              netwr      TYPE vbap-netwr,
              waerk      TYPE vbap-waerk,
              name1      TYPE kna1-name1,
              ort01      TYPE kna1-ort01,
              bztxt      TYPE t171t-bztxt,
*          REGIO TYPE kna1-REGIO,
              regio_desc TYPE t005u-bezei,
            END OF t_final.

    TYPES : BEGIN OF t_final_i,
              vkorg      TYPE vbrk-vkorg,
              vtweg      TYPE vbrk-vtweg,
              waerk      TYPE vbrk-waerk,
              vbeln      TYPE vbrk-vbeln,
              kunag      TYPE vbrk-kunag,
              fkdat      TYPE vbrk-fkdat,
              fkart      TYPE vbrk-fkart,
              spart      TYPE vbrp-spart,
              werks      TYPE vbrp-werks,
              matnr      TYPE vbrp-matnr,
              arktx      TYPE vbrp-arktx,
              fklmg      TYPE vbrp-fklmg,
              meins      TYPE vbrp-meins,
              netwr      TYPE vbrp-netwr,
              mwsbp      TYPE vbrp-mwsbp,
              bzirk_auft TYPE vbrp-bzirk_auft,
              charg      TYPE vbrp-charg,
              p_vbeln    TYPE vbrp-vbeln,
              spart_desc TYPE tspat-vtext,
              werks_desc TYPE t001w-name1,
              pstyv      TYPE vbrp-pstyv,
              pstyv_desc TYPE tvapt-vtext,
              kunnr      TYPE vbak-kunnr,
              posnr      TYPE vbap-posnr,
*           vbeln TYPE vbak-vbeln,
*           ZMENG TYPE vbap-ZMENG,
*           ZIEME TYPE vbap-ZIEME,
*           NETWR TYPE vbap-NETWR,
*           WAERK TYPE vbap-WAERK,
              name1      TYPE kna1-name1,
              ort01      TYPE kna1-ort01,
              bztxt      TYPE t171t-bztxt,
*          REGIO TYPE kna1-REGIO,
              regio_desc TYPE t005u-bezei,
            END OF t_final_i.

    DATA : i_final_i TYPE TABLE OF t_final_i,
           w_final_i TYPE t_final_i.

    DATA : i_final TYPE TABLE OF t_final,
           w_final TYPE t_final.

    TYPES : BEGIN OF t_t171t,
              bzirk TYPE t171t-bzirk,
              bztxt TYPE t171t-bztxt,
            END OF t_t171t.

    DATA : i_t171t TYPE TABLE OF t_t171t,
           w_t171t TYPE t_t171t.

    TYPES : BEGIN OF t_vbkd,
              vbeln TYPE vbkd-vbeln,
              posnr TYPE vbkd-posnr,
              kursk TYPE vbkd-kursk,
              zterm TYPE vbkd-zterm,
              bstkd TYPE vbkd-bstkd,
              bstdk TYPE vbkd-bstdk,
            END OF t_vbkd.

    DATA : i_vbkd TYPE TABLE OF t_vbkd,
           w_vbkd TYPE t_vbkd.

    TYPES : BEGIN OF t_t005u,
              land1 TYPE t005u-land1,
              bland TYPE t005u-bland,
              bezei TYPE t005u-bezei,
            END OF t_t005u.

    DATA : i_t005u TYPE TABLE OF t_t005u,
           w_t005u TYPE t_t005u.

    TYPES : BEGIN OF t_vbak,
              vbeln TYPE vbak-vbeln,
              erdat TYPE vbak-erdat,
              audat TYPE vbak-audat,
              auart TYPE vbak-auart,
              kunnr TYPE vbak-kunnr,
            END OF t_vbak.

    DATA : i_vbak TYPE TABLE OF t_vbak,
           w_vbak TYPE t_vbak.

    TYPES : BEGIN OF t_vbap,
              vbeln   TYPE vbap-vbeln,
              posnr   TYPE vbap-posnr,
              netwr   TYPE vbap-netwr,
              waerk   TYPE vbap-waerk,
**Code added by lokesh/iteanz on 21 feb 2017 # TR DR1K931438
              zzaugru TYPE augru,
**End of Code added by lokesh/iteanz on 21 feb 2017 # TR DR1K931438
            END OF t_vbap.

    DATA : i_vbap TYPE TABLE OF t_vbap,
           w_vbap TYPE t_vbap.

    TYPES : BEGIN OF t_kna1,
              kunnr TYPE kna1-kunnr,
              land1 TYPE kna1-land1,
              name1 TYPE kna1-name1,
              ort01 TYPE kna1-ort01,
              regio TYPE kna1-regio,
              adrnr TYPE kna1-adrnr,
              ort02 TYPE kna1-ort02,
              katr6 TYPE kna1-katr6,
              city1 TYPE adrc-city1,
            END OF t_kna1.

    DATA : i_kna1 TYPE TABLE OF t_kna1,
           w_kna1 TYPE t_kna1.
    DATA: lv_name TYPE tdobname.
    DATA: lt_lines TYPE TABLE OF tline,
          wa_lines TYPE  tline.
    TYPES : BEGIN OF t_t001,              " Added by Parth 11/07/2014
              bukrs TYPE t001-bukrs,
              butxt TYPE t001-butxt,
              land1 TYPE land1, "Added by chandru "DR1K937367
            END OF t_t001.

    DATA : i_t001 TYPE TABLE OF t_t001,   " Added by Parth 11/07/2014
           w_t001 TYPE          t_t001.   " Added by Parth 11/07/2014
*** Code start by Chaithanya DR1K942775 ****
    TYPES : BEGIN OF t_makt,
              matnr TYPE makt-matnr,
              spras TYPE makt-spras,
              maktx TYPE makt-maktx,
            END OF t_makt.

    DATA : i_makt TYPE TABLE OF t_makt,
           w_makt TYPE t_makt.

**********************************************************
* Types declaration                                      *
**********************************************************

    TYPES : BEGIN OF tp_down,
              spart_desc(35),
              werks          TYPE vbrp-werks,
              werks_desc(35),
              ort01(40),
              bztxt(25),
              kunag          TYPE vbrk-kunag,
              name1(40),
              vbeln          TYPE vbrk-vbeln,
              matnr          TYPE vbrp-matnr,
              arktx(45),
              vtext          TYPE vtxtk,
              fklmg(20),
              netvalue(20),
              fkdat(10),"          TYPE vbrk-fkdat, "changed by lokesh/iteanz DR1K926132
              t_qty(20),
              t_val(20),
              mvgr1          TYPE mvke-mvgr1,
              bezei          TYPE tvm1t-bezei,
**********Begin of Changes by Ravi on 24.07.2017 DR1K934256*********************************
              vtweg          TYPE vbrk-vtweg,
              spart          TYPE vbrp-spart,
              regio          TYPE kna1-regio,
              charg          TYPE vbrp-charg,
              auart          TYPE vbak-auart,
**********End of Changes by Ravi on 24.07.2017 DR1K934256***********************************
              "Begin of changes by chandru "DR1K938567
              nam(73)        TYPE c,
              ricode         TYPE kunnr,
              riaddr         TYPE stras_gp,
              ristat         TYPE bezei20,
              mcod3          TYPE kna1-mcod3,
              bztxt1         TYPE t171t-bztxt,
              "End of changes by chandru "DR1K938567
            END OF tp_down,

            BEGIN OF st_mvke,
              matnr TYPE matnr,
              vkorg TYPE vkorg,
              vtweg TYPE vtweg,
              mvgr1 TYPE mvgr1,
            END OF st_mvke,

            BEGIN OF st_tvm1,
              mvgr1 TYPE mvgr1,
              bezei TYPE bezei40,
            END OF st_tvm1.


**********************************************************
** Internal table                                         *
**********************************************************

    DATA : gt_down  TYPE TABLE OF tp_down,
           gt_down1 TYPE TABLE OF tp_down.

    DATA : gt_mvke   TYPE TABLE OF st_mvke,
           gt_tvm1   TYPE TABLE OF st_tvm1,
           gt_global TYPE TABLE OF ztabap_tvarvc.
**********************************************************
* Work Area                                              *
**********************************************************

    DATA gw_down TYPE tp_down.

    DATA : gw_mvke TYPE st_mvke,
           gw_tvm1 TYPE st_tvm1
*           gw_global type ztabap_tvarvc
           .
    DATA : back.
    FIELD-SYMBOLS : <lx_const> TYPE any.
************************************************************
* Constants
***********************************************************


    TYPES : tt_hy TYPE TABLE OF ztsd_hq_hybrid WITH EMPTY KEY.

    DATA : lv_flag TYPE c.

    DATA: s_vkorg  TYPE RANGE OF vbrk-vkorg,
          s_vtweg  TYPE RANGE OF vbrk-vtweg,
          s_spart  TYPE RANGE OF vbrp-spart,
          s_matnr  TYPE RANGE OF vbrp-matnr,
          s_werks  TYPE RANGE OF vbrp-werks,
          s_lgort  TYPE RANGE OF vbrp-lgort,
          s_kunnr  TYPE RANGE OF vbak-kunnr,
          s_fkart  TYPE RANGE OF vbrk-fkart,
          s_vbeln  TYPE RANGE OF vbrk-vbeln,
          s_fkdat  TYPE RANGE OF vbrk-fkdat,
          lw_vkorg LIKE LINE OF s_vkorg,
          lw_vtweg LIKE LINE OF s_vtweg,
          lw_spart LIKE LINE OF s_spart,
          lw_matnr LIKE LINE OF s_matnr,
          lw_werks LIKE LINE OF s_werks,
          lw_lgort LIKE LINE OF s_lgort,
          lw_kunnr LIKE LINE OF s_kunnr,
          lw_fkart LIKE LINE OF s_fkart,
          lw_vbeln LIKE LINE OF s_vbeln,
          lw_fkdat LIKE LINE OF s_fkdat
          .
    DATA : rb_cc TYPE c,
           rb_gc TYPE c.
    DATA : l_layout TYPE disvariant.
    DATA : l_layout1(20).
    DATA : l_uname(20).
    DATA : p_layout  TYPE slis_vari.
    DATA: gt_final TYPE TABLE OF zbioidt_sales_data_res_records,
          gw_final TYPE zbioidt_sales_data_res_records.
    CONSTANTS : lc_o(1)   VALUE 'O',
                lc_n(1)   VALUE 'N',
                lc_ftp(5) VALUE 'FTP*'.
    DATA : lv_index TYPE i.
    DATA:lv_report   TYPE  rsvar-report VALUE 'ZSDR_CUST_SALES_REP',
         lv_variant  TYPE  rsvar-variant VALUE 'SMART1',
         lt_valutab  TYPE TABLE OF rsparams,
         lw_valutab  LIKE LINE OF lt_valutab,
         lv_s_vkorg  TYPE  rsscr_name VALUE 'S_VKORG',
         lv_s_vtweg  TYPE  rsscr_name VALUE 'S_VTWEG',
         lv_s_spart  TYPE  rsscr_name VALUE 'S_SPART',
         lv_s_matnr  TYPE  rsscr_name VALUE 'S_MATNR',
         lv_s_werks  TYPE  rsscr_name VALUE 'S_WERKS',
         lv_s_lgort  TYPE  rsscr_name VALUE 'S_LGORT',
         lv_s_kunnr  TYPE  rsscr_name VALUE 'S_KUNNR',
         lv_s_fkart  TYPE  rsscr_name VALUE 'S_FKART',
         lv_s_vbeln  TYPE  rsscr_name VALUE 'S_VBELN',
         lv_s_fkdat  TYPE  rsscr_name VALUE 'S_FKDAT',
         lv_rb_cc    TYPE  rsscr_name VALUE 'RB_CC',
         lv_rb_gc    TYPE  rsscr_name VALUE 'RB_GC',
         lv_p_layout TYPE  rsscr_name VALUE 'P_LAYOUT'
         .
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

    CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
                gc_vkorg(15) VALUE 'BFI_VKORG'.

    DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
    TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

    CALL METHOD zcl_abap_utility=>get_options
      EXPORTING
        im_objname = gc_bfi
      IMPORTING
        ex_tab     = gt_vkorg.

    DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                      ( sign = 'I'
                        option = 'EQ'
                        low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************
*--------------------------------------------------
*  end of declaration
*--------------------------------------------------
**    select single layout
**    into l_layout1
**    from zsd_layout
**    where usrid = sy-uname.

**    if sy-subrc = 0.
**      p_layout  = l_  layout1.
*--------------------------------------------------
*  GET VARIANT
*--------------------------------------------------

    CALL FUNCTION 'RS_VARIANT_CONTENTS'
      EXPORTING
        report               = lv_report
        variant              = lv_variant
      TABLES
        valutab              = lt_valutab
      EXCEPTIONS
        variant_non_existent = 1
        variant_obsolete     = 2
        OTHERS               = 3.
    IF sy-subrc = 0.
****  Pranesh Changes Start DR1K949079 13.01.2020 ****
      TRY .
          s_vkorg = VALUE #( FOR lw_valuta IN lt_valutab WHERE (
             selname = lv_s_vkorg )
             ( low = lw_valuta-low
               high = lw_valuta-high
               sign = lw_valuta-sign
               option = lw_valuta-option )
             ).
        CATCH cx_sy_itab_line_not_found .
      ENDTRY.
****  Pranesh Changes END DR1K949079 13.01.2020 ****

      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_vtweg.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_vtweg-low = lw_valutab-low .
          lw_vtweg-high = lw_valutab-high .
          lw_vtweg-sign = lw_valutab-sign .
          lw_vtweg-option = lw_valutab-option .
          APPEND lw_vtweg TO s_vtweg.
          CLEAR :lw_vtweg,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_spart.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_spart-low = lw_valutab-low .
          lw_spart-high = lw_valutab-high .
          lw_spart-sign = lw_valutab-sign .
          lw_spart-option = lw_valutab-option .
          APPEND lw_spart TO s_spart.
          CLEAR :lw_spart,lw_valutab.
        ELSE.
          gw_final-message = 'Mandatory field missing in Variant' .
          gw_final-status = 'E'.
          gw_final-date = sy-datum.
          APPEND gw_final TO gt_final.
          CLEAR: gw_final.
          MOVE-CORRESPONDING gt_final TO output-mt_sales_data_res-records.
          EXIT.
        ENDIF.

      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_matnr.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_matnr-low = lw_valutab-low .
          lw_matnr-high = lw_valutab-high .
          lw_matnr-sign = lw_valutab-sign .
          lw_matnr-option = lw_valutab-option .
          APPEND lw_matnr TO s_matnr.
          CLEAR :lw_matnr,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_werks.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_werks-low = lw_valutab-low .
          lw_werks-high = lw_valutab-high .
          lw_werks-sign = lw_valutab-sign .
          lw_werks-option = lw_valutab-option .
          APPEND lw_werks TO s_werks.
          CLEAR :lw_werks,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_lgort.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_lgort-low = lw_valutab-low .
          lw_lgort-high = lw_valutab-high .
          lw_lgort-sign = lw_valutab-sign .
          lw_lgort-option = lw_valutab-option .
          APPEND lw_lgort TO s_lgort.
          CLEAR :lw_lgort,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_kunnr.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_kunnr-low = lw_valutab-low .
          lw_kunnr-high = lw_valutab-high .
          lw_kunnr-sign = lw_valutab-sign .
          lw_kunnr-option = lw_valutab-option .
          APPEND lw_kunnr TO s_kunnr.
          CLEAR :lw_kunnr,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_fkart.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_fkart-low = lw_valutab-low .
          lw_fkart-high = lw_valutab-high .
          lw_fkart-sign = lw_valutab-sign .
          lw_fkart-option = lw_valutab-option .
          APPEND lw_fkart TO s_fkart.
          CLEAR :lw_fkart,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_vbeln.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          lw_vbeln-low = lw_valutab-low .
          lw_vbeln-high = lw_valutab-high .
          lw_vbeln-sign = lw_valutab-sign .
          lw_vbeln-option = lw_valutab-option .
          APPEND lw_vbeln TO s_vbeln.
          CLEAR :lw_vbeln,lw_valutab.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_s_fkdat.
      IF sy-subrc = 0.
        IF lw_valutab-low IS NOT INITIAL OR
        lw_valutab-high IS NOT INITIAL .
          IF lw_valutab-low IS NOT INITIAL.
            CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
              EXPORTING
                date_external            = lw_valutab-low
              IMPORTING
                date_internal            = lw_valutab-low
              EXCEPTIONS
                date_external_is_invalid = 1
                OTHERS                   = 2.

          ENDIF.
          IF lw_valutab-high IS NOT INITIAL.
            CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
              EXPORTING
                date_external            = lw_valutab-high
              IMPORTING
                date_internal            = lw_valutab-high
              EXCEPTIONS
                date_external_is_invalid = 1
                OTHERS                   = 2.
          ENDIF.
          lw_fkdat-low = lw_valutab-low .
          lw_fkdat-high = lw_valutab-high .
          lw_fkdat-sign = lw_valutab-sign .
          lw_fkdat-option = lw_valutab-option .
          APPEND lw_fkdat TO s_fkdat.
          CLEAR :lw_fkdat,lw_valutab.

        ELSE.
          gw_final-message = 'Mandatory field missing in Variant' .
          gw_final-status = 'E'.
          gw_final-date = sy-datum.
          APPEND gw_final TO gt_final.
          CLEAR: gw_final.
          MOVE-CORRESPONDING gt_final TO output-mt_sales_data_res-records.
          EXIT.
        ENDIF.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_rb_cc.
      IF sy-subrc = 0.
        rb_cc = lw_valutab-low.
      ENDIF.
      READ TABLE lt_valutab INTO lw_valutab WITH KEY selname = lv_rb_gc.
      IF sy-subrc = 0.
        rb_gc = lw_valutab-low.
      ENDIF.
*----------------------------------------------------------
*----------------------------------------------------------
*-------------------------------------------------------------------------------*
*-------------------------------------------------------------------------------*
      DATA : lv_curr TYPE datum,
             lv_prev TYPE datum.

      DATA : lv_mon  TYPE t009b-bumon,
             lv_year TYPE t009b-bdatj,
             lv_day  TYPE t009b-butag.


      CLEAR : lv_curr,lv_year,lv_day.
      lv_curr = sy-datum.

      IF lv_curr+6(2) = '01'.
        CALL FUNCTION 'OIL_GET_PREV_MONTH'
          EXPORTING
            i_date = lv_curr
          IMPORTING
            e_date = lv_prev.

        lv_mon  = lv_prev+4(2).
        lv_year = lv_prev+0(4).

        CALL FUNCTION 'NUMBER_OF_DAYS_PER_MONTH_GET'
          EXPORTING
            par_month = lv_mon
            par_year  = lv_year
          IMPORTING
            par_days  = lv_day.

        LOOP AT s_fkdat INTO lw_fkdat.
          CONCATENATE  lv_year lv_mon '01' INTO lw_fkdat-low.
          CONCATENATE  lv_year lv_mon lv_day INTO lw_fkdat-high.
          MODIFY s_fkdat FROM lw_fkdat.
          CLEAR:lw_fkdat.
        ENDLOOP.

      ELSE.
        LOOP AT s_fkdat INTO lw_fkdat.
          lv_curr+6(2)  = '01'.
          lw_fkdat-low   = lv_curr.
          lw_fkdat-high  = sy-datum.
          MODIFY s_fkdat FROM lw_fkdat.
          CLEAR:lw_fkdat.
        ENDLOOP.
        CLEAR:lv_year,lv_mon,lv_day,
        lv_curr,lv_prev,lv_mon ,
        lv_year,lv_day.
      ENDIF.
*-------------------------------------------------------------------------------*
*-------------------------------------------------------------------------------*


**      select single layout
**      into l_layout1
**      from zsd_layout
**      where usrid = sy-uname.
*      clear gw_global.

*-------------------------------------------------------------
**      read table gt_global into gw_global with key low = sy-uname binary search.
**      if sy-subrc ne 0.
**        if l_layout1 is initial .
**          l_uname = sy-uname.
**          concatenate 'Layout is not created for  ' l_uname into gw_final-message.
**          gw_final-status = 'E'.
**          gw_final-date = sy-datum.
**          append gw_final to gt_final.
**          clear: gw_final.
**          move-corresponding gt_final to output-mt_sales_data_res-records.
**          exit.
**        endif.
**        if l_layout1 <> p_layout.
**          l_uname = sy-uname.
**          concatenate 'Wrong Variant For  ' l_uname into gw_final-message.
**          gw_final-status = 'E'.
**          gw_final-date = sy-datum.
**          append gw_final to gt_final.
**          clear: gw_final.
**          move-corresponding gt_final to output-mt_sales_data_res-records.
**          exit.
**        endif.
**      endif.

*-------------------------------------------------------------
      SELECT  vbrk~vbeln
      vbrk~fkart
      vbrk~vbtyp
      vbrk~waerk
      vbrk~vkorg
      vbrk~vtweg
      vbrk~knumv
      vbrk~inco1
      vbrk~inco2
      vbrk~fkdat
      vbrk~kurrf
      vbrk~kunag
      vbrk~bukrs
      vbrk~xblnr
      vbrk~erdat AS zerdat
      vbrk~erzet AS zerzet
      vbrp~vbeln
      vbrp~posnr
      vbrp~meins
      vbrp~fklmg
      vbrp~netwr
      vbrp~matnr
      vbrp~arktx
      vbrp~charg
      vbrp~pstyv
      vbrp~spart
      vbrp~werks
      vbrp~lgort
      vbrp~bzirk_auft
      vbrp~mwsbp
      vbrp~aubel
      vbrp~aupos
      vbrp~vgtyp
      vbrp~prctr
      vbrp~mvgr1
      FROM ( vbrk
      INNER JOIN vbrp
      ON  vbrp~vbeln = vbrk~vbeln )
      INTO CORRESPONDING FIELDS OF  TABLE i_vbrk_p
      WHERE vbrk~vkorg IN s_vkorg
      AND vbrk~vtweg IN s_vtweg
      AND vbrk~fkart IN s_fkart
      AND vbrk~vbeln IN s_vbeln
      AND vbrk~fkdat IN s_fkdat
      AND vbrp~spart IN s_spart
      AND vbrp~werks IN s_werks
      AND vbrp~matnr IN s_matnr
      AND vbrk~kunag IN s_kunnr
      AND vbrp~lgort IN s_lgort.

      IF i_vbrk_p[] IS NOT INITIAL.
        CONSTANTS : lc_hybrid(6) VALUE 'Hybrid'.
        SELECT spart, bzirk, fdate, tdate
        FROM ztsd_hq_hybrid
        FOR ALL ENTRIES IN @i_vbrk_p
        WHERE bzirk EQ @i_vbrk_p-bzirk_auft
        INTO TABLE @DATA(lt_hybrid).
      ENDIF.
      SELECT werks
      name1
      FROM t001w
      INTO TABLE i_t001w
      WHERE werks IN s_werks.

      SELECT spart
      vtext
      FROM tspat
      INTO TABLE i_tspat
      WHERE spras = sy-langu
      AND spart IN s_spart .
      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT pstyv
        vtext
        FROM tvapt
        INTO TABLE i_pstyv
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE spras = sy-langu AND
        pstyv = i_vbrk_p-pstyv.

        SELECT matnr
        vkorg
        vtweg
        mvgr1
        FROM mvke INTO TABLE gt_mvke
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE matnr = i_vbrk_p-matnr AND
        vkorg = i_vbrk_p-vkorg AND
        vtweg = i_vbrk_p-vtweg.
        IF sy-subrc EQ 0.
          SORT gt_mvke BY matnr vkorg vtweg.

          SELECT mvgr1
          bezei
          FROM tvm1t INTO TABLE gt_tvm1
          FOR ALL ENTRIES IN gt_mvke
          WHERE spras = 'E' AND
          mvgr1 = gt_mvke-mvgr1.
          SORT gt_tvm1 BY mvgr1.
        ENDIF.
        SELECT matnr
        spras
        maktx FROM makt INTO TABLE i_makt
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE matnr = i_vbrk_p-matnr
        AND   spras = 'EN'.
      ENDIF.
      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT kunnr
        land1
        name1
        ort01
        regio
        adrnr
        ort02
        katr6
        FROM kna1
        INTO CORRESPONDING FIELDS OF TABLE i_kna1 "corresponding
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE kunnr = i_vbrk_p-kunag.
      ENDIF.

      IF i_kna1[] IS NOT INITIAL.
        SELECT katr6
        vtext
        FROM tvk6t
        INTO TABLE i_tvk6t
        FOR ALL ENTRIES IN i_kna1
        WHERE spras = sy-langu
        AND katr6 = i_kna1-katr6.

      ENDIF.
      IF i_kna1[] IS NOT INITIAL.
        SELECT land1
        bland
        bezei
        FROM t005u
        INTO TABLE i_t005u
        FOR ALL ENTRIES IN i_kna1
        WHERE spras = sy-langu
        AND bland = i_kna1-regio
        AND land1 = i_kna1-land1.
      ENDIF.
      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT  bzirk
        bztxt
        FROM t171t
        INTO TABLE i_t171t
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE bzirk = i_vbrk_p-bzirk_auft.
      ENDIF.
      IF i_kna1[] IS NOT INITIAL.
        SELECT addrnumber
        city1
        FROM adrc
        INTO TABLE i_adrc
        FOR ALL ENTRIES IN i_kna1
        WHERE addrnumber = i_kna1-adrnr.
      ENDIF.
      LOOP AT i_kna1 INTO w_kna1.
        READ TABLE i_adrc INTO w_adrc WITH KEY addrnumber = w_kna1-adrnr.
        IF sy-subrc = 0.
          w_kna1-city1 = w_adrc-city1.
          MODIFY i_kna1 FROM w_kna1 TRANSPORTING city1.
          CLEAR : w_kna1, w_adrc.
        ENDIF.
      ENDLOOP.
      IF i_vbrk_p[] IS NOT INITIAL."added - performance tunning
        SELECT vbeln
        erdat
        audat
        auart
        kunnr
        FROM vbak
        INTO TABLE i_vbak
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE vbeln = i_vbrk_p-aubel.
      ENDIF.
      IF i_vbak[] IS NOT INITIAL.
        SELECT vbeln
        posnr
        netwr
        waerk
        zzaugru " Added by lokesh/iteanz on 21 feb 2017 # TR DR1K931438
        FROM vbap
        INTO TABLE i_vbap
        FOR ALL ENTRIES IN i_vbak
        WHERE vbeln = i_vbak-vbeln.
      ENDIF.
      IF i_vbak[] IS NOT INITIAL.
        SELECT vbeln
        posnr
        kursk
        zterm
        bstkd
        bstdk
        FROM vbkd
        INTO TABLE i_vbkd
        FOR ALL ENTRIES IN i_vbak
        WHERE vbeln = i_vbak-vbeln.
      ENDIF.
      IF i_vbrk_p[] IS NOT INITIAL. "performance tunning
        SELECT vbeln
        posnr
        parvw
        kunnr
        adrnr
        FROM vbpa
        INTO TABLE i_vbpa
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE vbeln = i_vbrk_p-aubel
        AND ( parvw = 'WE' OR parvw = 'AG' OR parvw = 'ZI' )."and POSNR = I_vbfa-posnv "Changed by chandru 'ZI "DR1K938567
        SELECT vbeln
        posnr
        parvw
        kunnr
        adrnr
        FROM vbpa
        INTO TABLE i_vbpa1
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE vbeln = i_vbrk_p-vbeln
        AND ( parvw = 'WE' OR parvw = 'ZI' )."and POSNR = I_vbfa-posnv

        IF i_vbpa1 IS NOT INITIAL.
          SELECT kunnr
          name1
          "added 5.6.2014
          name2
          ort01
          mcod3
          FROM kna1
          INTO TABLE i_kna1_n
          FOR ALL ENTRIES IN i_vbpa1
          WHERE kunnr = i_vbpa1-kunnr.
          IF i_kna1_n IS NOT  INITIAL.
            SELECT kunnr
            bzirk
            FROM knvv
            INTO TABLE i_knvv_n
            FOR ALL ENTRIES IN i_kna1_n
            WHERE kunnr = i_kna1_n-kunnr.
            IF i_knvv_n IS NOT INITIAL.
              SELECT bzirk
              bztxt
              FROM t171t
              INTO TABLE i_t171t_n
              FOR ALL ENTRIES IN i_knvv_n
              WHERE spras = 'E'
              AND   bzirk = i_knvv_n-bzirk .
            ENDIF.
          ENDIF.
          SELECT addrnumber
          sort2
          FROM adrc
          INTO TABLE i_adrc_n
          FOR ALL ENTRIES IN i_vbpa1
          WHERE addrnumber = i_vbpa1-adrnr.
        ENDIF.
      ENDIF.
      IF i_vbpa[] IS NOT INITIAL.
        SELECT kunnr
        land1 "Added by chandru "DR1K938567
        name1
        ort01"added 5.6.2014
        regio stras "Added by chandru "DR1K938567
        FROM kna1
        INTO TABLE i_kna1_sh
        FOR ALL ENTRIES IN i_vbpa
        WHERE kunnr = i_vbpa-kunnr.
        "Begin of addition by chandru "DR1K938567
        SELECT land1, bland, bezei
        FROM t005u
        INTO TABLE @DATA(lt_t005u)
              FOR ALL ENTRIES IN @i_kna1_sh
              WHERE spras EQ @sy-langu
              AND land1 EQ @i_kna1_sh-land1
              AND bland EQ @i_kna1_sh-regio.
        "End of addition by chandru "DR1K938567
      ENDIF.
      IF i_vbrk_p[] IS NOT INITIAL. "changes 25.6.2014
        SELECT prctr
        ktext
        FROM cepct
        INTO TABLE i_cepct
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE spras = sy-langu AND prctr = i_vbrk_p-prctr.
      ENDIF.

      IF i_vbpa[] IS NOT INITIAL.
        SELECT addrnumber
        country
        FROM adrc
        INTO CORRESPONDING FIELDS OF TABLE i_adrc_land1
        FOR ALL ENTRIES IN i_vbpa
        WHERE addrnumber = i_vbpa-adrnr.
      ENDIF.

      IF i_adrc_land1[] IS NOT INITIAL.
        SELECT land1
        landx
        FROM t005t
        INTO TABLE i_t005t
        FOR ALL ENTRIES IN i_adrc_land1
        WHERE spras = sy-langu
        AND land1 = i_adrc_land1-country.
      ENDIF.
      LOOP AT i_adrc_land1 INTO w_adrc_land1.
        READ TABLE i_t005t INTO w_t005t WITH KEY land1 = w_adrc_land1-country.
        IF sy-subrc  = 0.
          w_adrc_land1-landx = w_t005t-landx.
          MODIFY i_adrc_land1 FROM w_adrc_land1 TRANSPORTING landx.
          CLEAR : w_adrc_land1, w_t005t.
        ENDIF.
      ENDLOOP.
      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT knumv
        kposn
        kschl
        kbetr
        waers
        kwert
        kinak                           " Added by khurshida on 6/2/2016 DR1K926881
        kstat "Added by chandru "DR1K941261
        FROM konv
        INTO TABLE i_konv
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE knumv = i_vbrk_p-knumv AND kposn = i_vbrk_p-posnr AND kschl IN ('JASS','PR00','ZP00','ZP01','ZP02','ZP03','ZP04',
        'ZP05','ZP06','ZP07','ZP08','ZPCD','ZPTS','ZSPL',
        'K004','K005','K007','Z004','Z005','Z007','ZFRE',
        'JINS','ZOTH','ZLSR','JIVP','ZVAM','JIVC','JEXP',
        'JECS','JHCS','JADC','ZS02',
        'JOCG','JOSG','JOIG','Z0BF','PI01','ZHB0').
      ENDIF.
      SORT i_konv BY knumv kposn kschl.
      LOOP AT i_vbrk_p INTO w_vbrk_p.
        "Begin of Addition by chandru " DR1K937960
*      data(lw_vbkd) = value #( lt_vbkd[ vbeln = w_vbrk_p-aubel ] optional ).
*      if lw_vbkd is not initial.
*        w_vbrk_p-bzirk_auft = lw_vbkd-bzirk.
*        w_vbrk_p-bztxt1 = lw_vbkd-bztxt.
*        w_vbrk_p-bztxt = lw_vbkd-bztxt.
*      endif.

        DATA(hy) = VALUE tt_hy( FOR lw_hy IN lt_hybrid WHERE ( spart EQ w_vbrk_p-spart
              AND bzirk EQ w_vbrk_p-bzirk_auft
              AND fdate LE w_vbrk_p-fkdat
              AND tdate GE w_vbrk_p-fkdat )
              ( spart   = lw_hy-spart
              bzirk   = lw_hy-bzirk
              fdate   = lw_hy-fdate
              tdate   = lw_hy-tdate )
              ).
        IF hy[] IS NOT INITIAL.
          w_vbrk_p-act_team = lc_hybrid.
        ENDIF.
*      clear : hy[]. "commented by chandru ""DR1K938126
        "End of Addition by chandru " DR1K937960
        READ TABLE i_cepct INTO w_cepct WITH KEY prctr = w_vbrk_p-prctr.
        IF sy-subrc = 0.
          w_vbrk_p-ktext = w_cepct-ktext.
          TRANSLATE w_vbrk_p-ktext TO UPPER CASE.
        ENDIF.

*************************  First Loop
        IF ( w_vbrk_p-werks = '1140' OR  w_vbrk_p-werks = '1141' OR  w_vbrk_p-werks = '1142' ).
          DELETE i_vbrk_p  .
          CONTINUE.
        ENDIF.

        IF w_vbrk_p-fkart = 'YBF8'.
          DELETE i_vbrk_p  .
          CONTINUE.
        ENDIF.

        READ TABLE i_t001w INTO w_t001w WITH KEY werks = w_vbrk_p-werks.
        IF sy-subrc = 0.
          w_vbrk_p-werks_desc = w_t001w-name1.
          TRANSLATE w_vbrk_p-werks_desc TO UPPER CASE.
        ENDIF.

        READ TABLE i_tspat INTO w_tspat WITH KEY spart = w_vbrk_p-spart.
        IF sy-subrc = 0.
          w_vbrk_p-spart_desc = w_tspat-vtext.
          TRANSLATE  w_vbrk_p-spart_desc TO UPPER CASE.
        ENDIF.

        READ TABLE i_pstyv INTO w_pstyv WITH KEY pstyv = w_vbrk_p-pstyv.
        IF sy-subrc = 0.
          w_vbrk_p-pstyv_desc = w_pstyv-vtext.
          TRANSLATE w_vbrk_p-pstyv_desc TO UPPER CASE.
        ENDIF.
*** Code start by Chaithanya DR1K942775 ****
        READ TABLE i_makt INTO w_makt WITH KEY matnr = w_vbrk_p-matnr.
        IF sy-subrc = 0.
          CLEAR : w_vbrk_p-arktx.
          w_vbrk_p-arktx = w_makt-maktx.
        ENDIF.
*** Code end by Chaithanya DR1K942775 ****
        TRANSLATE w_vbrk_p-arktx TO UPPER CASE .

*************************End of  First Loop
***************************start second loop
        READ TABLE i_kna1 INTO w_kna1 WITH KEY kunnr = w_vbrk_p-kunag.
        IF sy-subrc = 0.
          w_vbrk_p-name1 = w_kna1-name1.
          TRANSLATE w_vbrk_p-name1 TO UPPER CASE.
          w_vbrk_p-ort01 = w_kna1-ort01.
          TRANSLATE w_vbrk_p-ort01 TO UPPER CASE.
          w_vbrk_p-city1 = w_kna1-city1.
          TRANSLATE w_vbrk_p-city1 TO UPPER CASE.
          w_vbrk_p-katr6 = w_kna1-katr6.
          READ TABLE i_tvk6t INTO w_tvk6t WITH KEY katr6 = w_kna1-katr6.
          IF sy-subrc = 0.
            w_vbrk_p-katr6 = w_tvk6t-vtext.
            TRANSLATE w_vbrk_p-katr6 TO UPPER CASE.
          ENDIF.
          READ TABLE i_t005u INTO w_t005u WITH KEY bland = w_kna1-regio land1 = w_kna1-land1.
          IF sy-subrc = 0.
            w_vbrk_p-regio_desc = w_t005u-bland.   "Changed By Pranesh DR1K949078 on 13.01.2019
            TRANSLATE w_vbrk_p-regio_desc TO UPPER CASE.
          ENDIF.
          CLEAR : w_kna1, w_t005u.
        ENDIF.
        READ TABLE i_t171t INTO w_t171t WITH KEY bzirk = w_vbrk_p-bzirk_auft.
        IF sy-subrc = 0.
          w_vbrk_p-bztxt = w_t171t-bztxt.
          TRANSLATE w_vbrk_p-bztxt TO UPPER CASE.
          CLEAR : w_vbkd, w_t171t.
        ENDIF.
        READ TABLE i_knvp INTO w_knvp WITH KEY kunnr = w_vbrk_p-kunag
        vkorg = w_vbrk_p-vkorg
        vtweg = w_vbrk_p-vtweg
        spart = w_vbrk_p-spart.
        IF sy-subrc = 0.
          w_vbrk_p-ship_kunnr = w_knvp-kunn2.
        ENDIF.
***************************end second loop
*  READ TABLE i_vbfa INTO w_vbfa WITH KEY vbeln = w_vbrk_p-vbeln posnn = w_vbrk_p-posnr. "performance tunning
*    IF sy-subrc = 0.
*      w_vbrk_p-vbelv = w_vbfa-vbelv.
        READ TABLE i_vbkd INTO w_vbkd WITH KEY vbeln = w_vbrk_p-aubel."w_vbrk_p-aubel."  posnr = w_vbfa-posnv."changed for header
        IF sy-subrc = 0.
          w_vbrk_p-zterm = w_vbkd-zterm.
          w_vbrk_p-bstkd = w_vbkd-bstkd.
          w_vbrk_p-bstdk = w_vbkd-bstdk.
        ENDIF.
        READ TABLE i_vbak INTO w_vbak WITH KEY vbeln = w_vbrk_p-aubel."w_vbrk_p-aubel." w_vbfa-vbelv
        IF sy-subrc = 0.
          w_vbrk_p-svbeln = w_vbak-vbeln.

          w_vbrk_p-erdat =  w_vbak-erdat.
          w_vbrk_p-audat =  w_vbak-audat.
          w_vbrk_p-sold_kunnr =  w_vbak-kunnr.
          w_vbrk_p-auart =  w_vbak-auart.
          TRANSLATE w_vbrk_p-auart TO UPPER CASE.
** Code Added by Lokesh/iteanz on 21 Feb 2017 # TR DR1K931438
*** Code Start By Chaithanya DR1K943955 *****
*        READ TABLE i_vbap INTO w_vbap WITH KEY vbeln = w_vbak-vbeln.
          READ TABLE i_vbap INTO w_vbap WITH KEY vbeln = w_vbrk_p-aubel
          posnr = w_vbrk_p-aupos.
*** Code End By Chaithanya DR1K943955 *****
          IF sy-subrc EQ 0.
            w_vbrk_p-zzaugru =  w_vbap-zzaugru.
          ENDIF.
**End of Code Added by Lokesh/iteanz on 21 Feb 2017 # TR DR1K931438
        ENDIF.
        READ TABLE i_vbpa INTO w_vbpa WITH KEY vbeln = w_vbrk_p-aubel parvw = 'WE'."  w_vbfa-vbelv posnr = w_vbfa-posnv
        IF sy-subrc = 0.
          w_vbrk_p-ship_kunnr = w_vbpa-kunnr.
          READ TABLE i_kna1_sh INTO w_kna1_sh WITH KEY kunnr = w_vbpa-kunnr.
          IF sy-subrc = 0.
            w_vbrk_p-ship_name = w_kna1_sh-name1.
            TRANSLATE w_vbrk_p-ship_name TO UPPER CASE.
            w_vbrk_p-ship_place = w_kna1_sh-ort01.
          ENDIF.
          READ TABLE i_adrc_land1 INTO w_adrc_land1 WITH KEY addrnumber = w_vbpa-adrnr.
          IF sy-subrc = 0.
            w_vbrk_p-ship_country = w_adrc_land1-landx.
            TRANSLATE w_vbrk_p-ship_country TO UPPER CASE.
          ENDIF.
        ENDIF.
        READ TABLE i_vbpa INTO w_vbpa WITH KEY vbeln = w_vbrk_p-aubel parvw = 'AG'." w_vbfa-vbelv posnr = w_vbfa-posnv
        IF sy-subrc = 0.
          w_vbrk_p-sold_kunnr = w_vbpa-kunnr.
          READ TABLE i_kna1_sh INTO w_kna1_sh WITH KEY kunnr = w_vbpa-kunnr.
          IF sy-subrc = 0.
            w_vbrk_p-sold_name = w_kna1_sh-name1.
            TRANSLATE w_vbrk_p-sold_name TO UPPER CASE.
          ENDIF.
          READ TABLE i_adrc_land1 INTO w_adrc_land1 WITH KEY addrnumber = w_vbpa-adrnr.
          IF sy-subrc = 0.
            w_vbrk_p-sold_country = w_adrc_land1-landx.
            TRANSLATE w_vbrk_p-sold_country TO UPPER CASE.
          ENDIF.
        ENDIF.
        "Begin of addition by chandru "DR1K938567
        READ TABLE i_vbpa INTO w_vbpa WITH KEY vbeln = w_vbrk_p-aubel parvw = 'ZI'." w_vbfa-vbelv posnr = w_vbfa-posnv
        IF sy-subrc = 0.
          w_vbrk_p-ricode = w_vbpa-kunnr.
          READ TABLE i_kna1_sh INTO w_kna1_sh WITH KEY kunnr = w_vbpa-kunnr.
          IF sy-subrc = 0.
            w_vbrk_p-riaddr = w_kna1_sh-stras.
            READ TABLE lt_t005u ASSIGNING FIELD-SYMBOL(<fs_t005u>) WITH KEY land1 = w_kna1_sh-land1
            bland = w_kna1_sh-regio.
            IF sy-subrc EQ 0.
              w_vbrk_p-ristat = <fs_t005u>-bezei.
            ENDIF.
          ENDIF.
        ENDIF.
        "End of addition by chandru "DR1K938567
*        if w_vbrk_p-vkorg = '1102'.
        IF w_vbrk_p-vkorg IN ra_vkorg.        "Added by Ravi on 06.06.2019 DR1K945737
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZPTS'
          kstat = abap_false "Added by chandru "DR1K941261
          BINARY SEARCH .
          IF sy-subrc = 0.
            READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
            kposn = w_vbrk_p-posnr
            kschl = 'ZSPL'
            kstat = abap_false "Added by chandru "DR1K941261
            BINARY SEARCH .
            IF sy-subrc = 0.
              IF w_vbrk_p-pstyv <> 'ZTNN' AND w_vbrk_p-pstyv <> 'YRNN'
                AND w_vbrk_p-pstyv <> 'YRN1' AND w_vbrk_p-pstyv <> 'YRN2'
                AND w_vbrk_p-pstyv <> 'YRN3'.
                IF w_vbrk_p-fklmg IS INITIAL..
                  w_vbrk_p-upnetwr = ( w_konv-kwert ).
                ELSE.
                  w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
                ENDIF.
              ENDIF.
              IF w_vbrk_p-fklmg IS INITIAL.
                w_vbrk_p-pts =  w_konv-kwert.
              ELSE.
                w_vbrk_p-pts =  ( w_konv-kwert / w_vbrk_p-fklmg )."10.6.2014 additional changes
              ENDIF.
              w_vbrk_p-upwaerk = w_konv-waers.
            ELSE.
              READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
              kposn = w_vbrk_p-posnr
              kschl = 'ZPTS'
              kstat = abap_false "Added by chandru "DR1K941261
              BINARY SEARCH.
              IF sy-subrc = 0.
                IF w_vbrk_p-pstyv <> 'ZTNN' AND w_vbrk_p-pstyv <> 'YRNN' AND w_vbrk_p-pstyv <> 'YRN1' AND w_vbrk_p-pstyv <> 'YRN2' AND w_vbrk_p-pstyv <> 'YRN3'."10.6.2014 additional changes
                  IF  w_vbrk_p-fklmg IS INITIAL.
                    w_vbrk_p-upnetwr = ( w_konv-kwert ).
                  ELSE.
                    w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
                  ENDIF.
                ENDIF.
                IF w_vbrk_p-fklmg IS INITIAL.
                  w_vbrk_p-pts = w_konv-kwert.
                ELSE.
                  w_vbrk_p-pts =  ( w_konv-kwert / w_vbrk_p-fklmg )."10.6.2014 additional changes
                ENDIF.
                w_vbrk_p-upwaerk = w_konv-waers.
              ENDIF.
            ENDIF.
          ELSE.
            READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
            kposn = w_vbrk_p-posnr
            kschl = 'ZSPL'
            kstat = abap_false "Added by chandru "DR1K941261
            BINARY SEARCH.
            IF sy-subrc = 0.
              IF w_vbrk_p-pstyv <> 'ZTNN' AND w_vbrk_p-pstyv <> 'YRNN' AND w_vbrk_p-pstyv <> 'YRN1' AND w_vbrk_p-pstyv <> 'YRN2' AND w_vbrk_p-pstyv <> 'YRN3'."10.6.2014 additional changes
                IF w_vbrk_p-fklmg IS INITIAL .
                  w_vbrk_p-upnetwr = ( w_konv-kwert ).
                ELSE.
                  w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
                ENDIF.
              ENDIF.
              IF w_vbrk_p-fklmg IS INITIAL.
                w_vbrk_p-pts = w_konv-kwert.
              ELSE.
                w_vbrk_p-pts =  ( w_konv-kwert / w_vbrk_p-fklmg )."10.6.2014 additional changes
              ENDIF.
              w_vbrk_p-upwaerk = w_konv-waers.
            ENDIF.
          ENDIF.
          READ TABLE  i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z004'  "BINARY SEARCH .
          kinak = gc_blank.  " Added by khurshida on 6/2/2016 DR1K926881
*                                                kstat = abap_false. "Added by chandru "DR1K941261
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_konv-kwert IS INITIAL OR w_konv-kwert LT '0'.
              IF w_vbrk_p-fklmg IS INITIAL.
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
              ELSE.
                "Begin of addition by chandru "DR1K941261
                IF w_konv-kwert IS INITIAL.
                  w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
                ELSE.
                  "End of addition by chandru "DR1K941261
                  w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
                ENDIF. "Added by chandru "DR1K941261
              ENDIF.
*           postab-upnetwr = ( postab-upnetwr  +  ( w_konv-kwert / postab-KWMENG ) ).
            ELSE.
              CLEAR : w_vbrk_p-upnetwr.
              IF w_vbrk_p-fklmg IS INITIAL.
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
              ELSE.
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF.
*              postab-upnetwr = ( postab-upnetwr  +  ( w_konv-kwert / postab-KWMENG ) ).
            ENDIF.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'K004' BINARY SEARCH.
          IF sy-subrc = 0.
            IF  w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
            ENDIF.
          ENDIF.

          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'K005' BINARY SEARCH.
          IF sy-subrc = 0.
            IF  w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
            ENDIF.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'K007' BINARY SEARCH .
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
            ENDIF.
          ENDIF.
*        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
*                                               kposn = w_vbrk_p-posnr
*                                               kschl = 'Z004' BINARY SEARCH .
*        IF sy-subrc = 0.
*          IF w_vbrk_p-fklmg IS INITIAL.
*            w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
*          ELSE.
*            w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*          ENDIF.
*        ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z005'
*                                               kstat = abap_false "Added by chandru "DR1K941261
          BINARY SEARCH.
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              "Begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z007'
*                                               kstat = abap_false "Added by chandru "DR1K941261
          BINARY SEARCH .
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              "Begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
            "Begin of addition by chandru "DR1K938981
            IF w_vbrk_p-fklmg IS INITIAL.
              DATA(lv_disc) = w_konv-kwert.
            ELSE.
*            lv_disc = ( w_konv-kwert / w_vbrk_p-fklmg ).  " Code Commented by Chaithanya DR1K939005
              lv_disc = lv_disc + w_konv-kwert .   " Code Added by Chaithanya DR1K939005
            ENDIF.
            "End of addition by chandru "DR1K938981
          ENDIF.
          "Begin of addition by chandru "DR1K941764
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'PI01'
          BINARY SEARCH .
          IF sy-subrc = 0.
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF.
            ENDIF.
          ENDIF.
          "End of addition by chandru "DR1K941764
          "Begin of addition by chandru "DR1K938881
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z0BF' BINARY SEARCH.
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              "begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
            "End of addition by chandru "DR1K938881
            "Begin of addition by chandru "DR1K938981
            IF w_vbrk_p-fklmg IS INITIAL.
              lv_disc = lv_disc + w_konv-kwert.
            ELSE.
*            lv_disc = lv_disc + ( w_konv-kwert / w_vbrk_p-fklmg ). " Code Commented by Chaithanya DR1K939005
              lv_disc = lv_disc + w_konv-kwert. " Code added by Chaithanya DR1K939005
            ENDIF.
          ENDIF.
**Code start by Chaithanya DR1K943426 ZHB0**********
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZHB0' BINARY SEARCH.
          IF sy-subrc = 0.

            IF w_vbrk_p-fklmg IS INITIAL.
              lv_disc = lv_disc + w_konv-kwert.
            ELSE.
              lv_disc = lv_disc + w_konv-kwert.
            ENDIF.
          ENDIF.
**Code end by Chaithanya DR1K943426 ZHB0**********
          w_vbrk_p-zdisc = lv_disc.
          CLEAR lv_disc.
          "End of addition by chandru "DR1K938981
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv " ZPCD 26.6.2014
          kposn = w_vbrk_p-posnr
          kschl = 'ZPCD' BINARY SEARCH.
          IF sy-subrc = 0 AND w_konv-kwert IS NOT INITIAL. "Changed by chandru "DR1K940980
            IF w_vbrk_p-fklmg IS INITIAL .
              w_vbrk_p-upnetwr = w_konv-kwert .
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg )..
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.


        ELSEIF w_vbrk_p-vkorg = gc_1101 "****************
*        Begin of the changes by Gokul on 28.07.2016
          OR w_vbrk_p-vkorg = gc_1103
          OR w_vbrk_p-vkorg = gc_1200
          OR w_vbrk_p-vkorg = gc_2100
          OR w_vbrk_p-vkorg = gc_2200
          OR w_vbrk_p-vkorg = gc_2300
          OR w_vbrk_p-vkorg = gc_2500
          OR w_vbrk_p-vkorg = gc_2600
          OR w_vbrk_p-vkorg = gc_2700.
*        End of the changes by Gokul on 28.07.2016
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'JASS' BINARY SEARCH.
          IF sy-subrc = 0.
            IF  w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'PR00' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL .
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP00' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL .
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP01' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP02' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP03' BINARY SEARCH .
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP04' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP05' BINARY SEARCH .
          IF sy-subrc = 0.
            IF  w_vbrk_p-fklmg IS INITIAL .
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg )..
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP06' BINARY SEARCH .
          IF sy-subrc = 0.
            IF   w_vbrk_p-fklmg  IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg )..
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          "Begin of addition by chandru "DR1K940980
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'PI01' BINARY SEARCH .
          IF sy-subrc = 0.
            IF   w_vbrk_p-fklmg  IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg )..
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          "End of addition by chandru "DR1K940980

          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP07' BINARY SEARCH .
          IF sy-subrc = 0.
            IF  w_vbrk_p-fklmg  IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg )..
            ENDIF.

            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZP08' BINARY SEARCH.
          IF sy-subrc = 0.
            IF  w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg )..
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
*           READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
*                                                  kposn = w_vbrk_p-posnr
*                                                  kschl = 'ZP04' BINARY SEARCH.
*               IF sy-subrc = 0.
*                 IF w_vbrk_p-fklmg IS INITIAL .
*                   w_vbrk_p-upnetwr = ( w_konv-kwert ).
*                 ELSE.
*                   w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
*                 ENDIF.
*                 w_vbrk_p-upwaerk = w_konv-waers.
*               ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZPCD' BINARY SEARCH.
          IF sy-subrc = 0 AND w_konv-kwert IS NOT INITIAL. "Changed by chandru "DR1K940980
            IF  w_vbrk_p-fklmg IS INITIAL .
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.

          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'K004' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
            ENDIF.
          ENDIF.
*        Begin of the changes by Gokul on 28.07.2016

          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZS02' BINARY SEARCH .
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_konv-kwert / w_vbrk_p-fklmg ).
            ENDIF.
            w_vbrk_p-upwaerk = w_konv-waers.
          ENDIF.
*        End of the changes by Gokul on 28.07.2016

          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'K005' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
            ENDIF.

          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'K007' BINARY SEARCH.
          IF sy-subrc = 0.
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
            ENDIF.

          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z004'
*                                               kstat = abap_false "Added by chandru "DR1K941261
          BINARY SEARCH.
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
            ELSE.
              "Begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z005'
*                                               kstat = abap_false "Added by chandru "DR1K941261
          BINARY SEARCH.
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              "Begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
          ENDIF.
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z007'
*                                               kstat = abap_false "Added by chandru "DR1K941261
          BINARY SEARCH.
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  w_konv-kwert ).
            ELSE.
              "Begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
            "Begin of addition by chandru "DR1K938981
            IF w_vbrk_p-fklmg IS INITIAL.
              lv_disc = w_konv-kwert.
            ELSE.
*            LV_DISC = ( W_KONV-KWERT / W_VBRK_P-FKLMG ).
              lv_disc = lv_disc + w_konv-kwert .   " Code Added by Chaithanya DR1K939005
            ENDIF.
          ENDIF.
          "End of addition by chandru "DR1K938981
          "Begin of addition by chandru "DR1K938881
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'Z0BF' BINARY SEARCH.
          IF sy-subrc = 0.
            "Begin of addition by chandru "DR1K941261
            IF w_konv-kstat = abap_true.
              w_konv-kwert = 0.
            ENDIF.
            "End of addition by chandru "DR1K941261
            IF w_vbrk_p-fklmg IS INITIAL.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  + w_konv-kwert ).
            ELSE.
              "Begin of addition by chandru "DR1K941261
              IF w_konv-kwert IS INITIAL.
                w_vbrk_p-upnetwr = w_vbrk_p-upnetwr.
              ELSE.
                "End of addition by chandru "DR1K941261
                w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
              ENDIF. "Added by chandru "DR1K941261
            ENDIF.
            "End of addition by chandru "DR1K938881
            "Begin of addition by chandru "DR1K938981
            IF w_vbrk_p-fklmg IS INITIAL.
              lv_disc = lv_disc + w_konv-kwert.
            ELSE.
*            LV_DISC = LV_DISC + ( W_KONV-KWERT / W_VBRK_P-FKLMG ).
              lv_disc = lv_disc + w_konv-kwert. " Code added by Chaithanya DR1K939005
            ENDIF.
          ENDIF.
**Code start by Chaithanya DR1K943426 ZHB0**********
          READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
          kposn = w_vbrk_p-posnr
          kschl = 'ZHB0' BINARY SEARCH.
          IF sy-subrc = 0.

            IF w_vbrk_p-fklmg IS INITIAL.
              lv_disc = lv_disc + w_konv-kwert.
            ELSE.
              lv_disc = lv_disc + w_konv-kwert.
            ENDIF.
          ENDIF.
**Code end by Chaithanya DR1K943426 ZHB0**********
          w_vbrk_p-zdisc = lv_disc.
          CLEAR lv_disc.
          "End of addition by chandru "DR1K938981
        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'ZFRE' BINARY SEARCH .
        IF sy-subrc = 0.
*              IF w_vbrk_p-fklmg IS INITIAL.
          w_vbrk_p-fre =   w_konv-kwert .
*              else."Fireight changes on 12.4.2014
*                w_vbrk_p-fre =   ( w_konv-kwert / w_vbrk_p-fklmg ).."w_konv-kwert." (  w_konv-kbetr / 10 )."10.6.2014 additional changes
*              ENDIF.
        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JINS' BINARY SEARCH. "%
        IF sy-subrc = 0.
          IF w_vbrk_p-fklmg IS INITIAL.
            w_vbrk_p-insu = w_konv-kwert.
          ELSE.
            w_vbrk_p-insu = ( w_konv-kwert / w_vbrk_p-fklmg )."(  w_konv-kbetr / 10 )."   (  w_konv-kbetr / 10 )."10.6.2014 additional changes
          ENDIF.
        ENDIF.

        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'ZOTH' BINARY SEARCH.
        IF sy-subrc = 0.
          IF  w_vbrk_p-fklmg IS INITIAL.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +  w_konv-kwert ).
          ELSE.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
          ENDIF.
        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'ZLSR' BINARY SEARCH.
        IF sy-subrc = 0.
          IF w_vbrk_p-fklmg IS INITIAL.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +  w_konv-kwert ).
          ELSE.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
          ENDIF.
        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JIVP' BINARY SEARCH.
        IF sy-subrc = 0.
          IF   w_vbrk_p-fklmg IS INITIAL.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +  w_konv-kwert ).
          ELSE.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
          ENDIF.

        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'ZVAM' BINARY SEARCH.
        IF sy-subrc = 0.
          IF  w_vbrk_p-fklmg IS INITIAL .
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +  w_konv-kwert ).
          ELSE.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
          ENDIF.

        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JIVC' BINARY SEARCH.
        IF sy-subrc = 0.
          IF w_vbrk_p-fklmg IS INITIAL.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +   w_konv-kwert ).
          ELSE.
            w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
          ENDIF.

        ENDIF.
************Begin of changes by Ravi on 01.07.2017 DR1K933640****************
*************Begin of changes by Ravi on 03.08.2017 DR1K934548*********************
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JOCG' BINARY SEARCH.
        IF sy-subrc = 0.
*        IF w_vbrk_p-fklmg IS INITIAL.
          w_vbrk_p-jocg_g = ( w_vbrk_p-jocg_g  +   w_konv-kwert ).
*        ELSE.
*          w_vbrk_p-jocg_g = ( w_vbrk_p-jocg_g  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*        ENDIF.

        ENDIF.

        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JOSG' BINARY SEARCH.
        IF sy-subrc = 0.
*        IF w_vbrk_p-fklmg IS INITIAL.
          w_vbrk_p-josg_g = ( w_vbrk_p-josg_g  +   w_konv-kwert ).
*        ELSE.
*          w_vbrk_p-josg_g = ( w_vbrk_p-josg_g  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*        ENDIF.

        ENDIF.

        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JOIG' BINARY SEARCH.
        IF sy-subrc = 0.
*        IF w_vbrk_p-fklmg IS INITIAL.
          w_vbrk_p-joig_g = ( w_vbrk_p-joig_g  +   w_konv-kwert ).
*        ELSE.
*          w_vbrk_p-joig_g = ( w_vbrk_p-joig_g  +   ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*        ENDIF.

        ENDIF.
************End of changes by Ravi on 01.07.2017 DR1K933640****************
*************End of changes by Ravi on 03.08.2017 DR1K934548*********************

        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JEXP' BINARY SEARCH.
        IF sy-subrc = 0.
*                  IF  w_vbrk_p-fklmg IS INITIAL.
          w_vbrk_p-excise = ( w_vbrk_p-excise  +  w_konv-kwert ).
*                  ELSE. " Excise change on 12.4.2014
*                      w_vbrk_p-excise = ( w_vbrk_p-excise  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*                  ENDIF.
        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JECS' BINARY SEARCH.
        IF sy-subrc = 0.
*                  IF  w_vbrk_p-fklmg IS INITIAL .
          w_vbrk_p-excise = ( w_vbrk_p-excise  +  w_konv-kwert ).
*                  ELSE." Excise change on 12.4.2014
*                    w_vbrk_p-excise = ( w_vbrk_p-excise  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*                  ENDIF.

        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JHCS' BINARY SEARCH.
        IF sy-subrc = 0.
*                  IF w_vbrk_p-fklmg IS INITIAL .
          w_vbrk_p-excise = ( w_vbrk_p-excise  +  w_konv-kwert ).
*                   ELSE." Excise change on 12.4.2014
*                     w_vbrk_p-excise = ( w_vbrk_p-excise  +  ( w_konv-kwert / w_vbrk_p-fklmg ) ).
*                  ENDIF.

        ENDIF.
        READ TABLE i_konv INTO w_konv WITH KEY knumv = w_vbrk_p-knumv
        kposn = w_vbrk_p-posnr
        kschl = 'JADC' BINARY SEARCH.
        IF sy-subrc = 0.
*                  IF  w_vbrk_p-fklmg  IS INITIAL .
          w_vbrk_p-excise = ( w_vbrk_p-excise  +  w_konv-kwert ).


        ENDIF.

        CLEAR gw_mvke.
        READ TABLE gt_mvke INTO gw_mvke WITH KEY matnr = w_vbrk_p-matnr
        vkorg = w_vbrk_p-vkorg
        vtweg = w_vbrk_p-vtweg .
        "BINARY SEARCH."commented by Gokul - 20.07.2016
        IF sy-subrc EQ 0.
          w_vbrk_p-mvgr1 = gw_mvke-mvgr1.
          CLEAR gw_tvm1.
          READ TABLE gt_tvm1 INTO gw_tvm1 WITH KEY mvgr1 = gw_mvke-mvgr1 BINARY SEARCH.
          IF sy-subrc EQ 0.
            w_vbrk_p-bezei = gw_tvm1-bezei.
          ENDIF.
        ENDIF.
        "Begin of addition by chanru "DR1K938126
        IF hy[] IS INITIAL.
          w_vbrk_p-act_team = w_vbrk_p-bezei.
        ENDIF.
        CLEAR : hy[].
        MODIFY i_vbrk_p FROM w_vbrk_p TRANSPORTING vbelv
        bstkd
        bstdk
        svbeln
        sold_kunnr
        zdisc "Added by chandru ""DR1K938981
        netvalue
        upnetwr
        upwaerk
        erdat
        audat
        auart
        ship_kunnr
        sold_country
        ship_country
        zterm
*                                                  VKBUR
        insu
        fre
        excise
        sales_tax
        ship_name
        ship_place
        sold_name
        pts
*********************************************  first
        arktx
        fklmg
        netwr
        mwsbp
        spart_desc
        werks_desc
        pstyv_desc
********************************************* End first     .
***************************************** second start
        name1
        ort01
        regio_desc
        bztxt
        ship_kunnr
        katr6
        ktext
        mvgr1
        bezei
        zzaugru "=> Added by lokesh/iteanz # TR DR1K931438
        jocg_g
        josg_g
        joig_g
        ricode riaddr ristat
        act_team. "Added by chandru "DR1K937960
***************************************** second end
        CLEAR : w_vbrk_p, w_vbfa, w_vbkd .
        CLEAR : w_vbrk_p,  w_tspat, w_t001w, w_pstyv.
        CLEAR : w_vbkd, w_t171t.
        CLEAR : w_kna1, w_t005u.
        CLEAR : w_vbak, w_vbap, w_vbrk_p.

*    ENDIF.
      ENDLOOP.

      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT vbeln
        posnr
        kursk
        FROM vbkd
        INTO TABLE i_vbkd_curr
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE vbeln = i_vbrk_p-vbelv.
*          and posnr = i_vbrk_p-posnr.
      ENDIF.
      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT werks
        lgort
        lgobe
        FROM t001l
        INTO TABLE i_t001l
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE werks = i_vbrk_p-werks
        AND lgort = i_vbrk_p-lgort.
      ENDIF.

*Code added by Parth on 11/07/2014 - Start
      IF i_vbrk_p[] IS NOT INITIAL.
        SELECT bukrs butxt land1 FROM t001 "Added by chandru "DR1K937367
        INTO CORRESPONDING FIELDS OF TABLE i_t001
        FOR ALL ENTRIES IN i_vbrk_p
        WHERE bukrs = i_vbrk_p-bukrs.

      ENDIF.
*Code added by Parth on 11/07/2014 - Start


      DATA : lw_exch TYPE ukursp.
      IF i_vbrk_p[] IS NOT INITIAL.

        SELECT kunnr, katr6
        FROM kna1
        INTO TABLE @DATA(lt_kna1)
              FOR ALL ENTRIES IN @i_vbrk_p
              WHERE kunnr EQ @i_vbrk_p-ship_kunnr.

        IF lt_kna1 IS NOT INITIAL.
          SELECT * FROM tvk6t CLIENT SPECIFIED
          INTO TABLE @DATA(lt_tvk6t)
                FOR ALL ENTRIES IN @lt_kna1
                WHERE mandt EQ @sy-mandt
                AND spras EQ @sy-langu
                AND katr6 EQ @lt_kna1-katr6.
        ENDIF.

      ENDIF.
      LOOP AT i_vbrk_p INTO w_vbrk_p.
        CLEAR :  lw_exch.
*   *** Added by Kavin/iteanz on 15/02/2017 for absolute value
**Changed by lokesh/iteanz on 21 feb 2017 TR DR1K931438
        IF w_vbrk_p-kurrf LT 0.
          w_vbrk_p-kurrf = ( 1 / abs( w_vbrk_p-kurrf ) ).
        ELSE.
          w_vbrk_p-kurrf =  abs( w_vbrk_p-kurrf ) .
        ENDIF.
**End of Code Changed by lokesh/iteanz on 21 feb 2017 TR DR1K931438
* *   ***ended by Kavin/iteanz on 15/02/2017

**Code Changed by Lokesh/iteanz on 21 feb 2017 TR DR1K931438
        IF rb_gc EQ abap_true."==> addded by lokesh DR1K931438
** below logic For Group Currency only
          DATA(lw_t001) = VALUE #( i_t001[ bukrs = w_vbrk_p-bukrs ] OPTIONAL ). ""Added by chandru "DR1K937367
          IF w_vbrk_p-waerk <> 'INR' .
*Change done by Pushpa 18.01.2017 : DR1K930839 SOLMAN 8000002517 ----Start
*          IF w_vbrk_p-kurrf = 1. : Commented by Lokesh/iteanz on 21 feb 2017 TR DR1K931460
            IF lw_t001-land1 NE 'IN'. ""Added by chandru "DR1K937367
              CALL FUNCTION 'CONVERT_AMOUNT_TO_CURRENCY'
                EXPORTING
                  date             = w_vbrk_p-fkdat
                  foreign_currency = w_vbrk_p-waerk
                  foreign_amount   = '100000'
                  local_currency   = 'INR'
                IMPORTING
                  local_amount     = lw_exch.
              w_vbrk_p-kurrf =    lw_exch.
*          ENDIF.                 Commented by Lokesh/iteanz on 21 feb 2017 TR DR1K931460
            ENDIF. ""Added by chandru "DR1K937367
*Change done by Pushpa 18.01.2017 : DR1K930839 SOLMAN 8000002517 ----End
            w_vbrk_p-netwr_curr = ( w_vbrk_p-netwr * w_vbrk_p-kurrf ).
            w_vbrk_p-exchange_rate =  w_vbrk_p-kurrf .
            w_vbrk_p-mwsbp_curr = ( w_vbrk_p-mwsbp * w_vbrk_p-kurrf ).
            w_vbrk_p-waerk_curr = 'INR'.
          ELSE.
            w_vbrk_p-netwr_curr =  w_vbrk_p-netwr.
            w_vbrk_p-mwsbp_curr =   w_vbrk_p-mwsbp.
            w_vbrk_p-waerk_curr = 'INR'.
          ENDIF.
          CLEAR : lw_t001. "Added by chandru "DR1K937367
**Code added by Lokesh/iteanz on 21 feb 2017 TR DR1K931438
        ELSE.
          IF w_vbrk_p-waerk <> 'INR' .
            w_vbrk_p-netwr_curr =  ( w_vbrk_p-netwr * w_vbrk_p-kurrf ).
            w_vbrk_p-exchange_rate =  w_vbrk_p-kurrf .
            w_vbrk_p-mwsbp_curr =  ( w_vbrk_p-mwsbp * w_vbrk_p-kurrf ).
            w_vbrk_p-waerk_curr =  w_vbrk_p-waerk.
          ELSE.
            w_vbrk_p-netwr_curr =  w_vbrk_p-netwr.
            w_vbrk_p-mwsbp_curr =   w_vbrk_p-mwsbp.
            w_vbrk_p-waerk_curr = 'INR'.
          ENDIF.
        ENDIF.
** End of Code Changed by Lokesh/iteanz on 21 feb 2017 TR DR1K931438


**Code Changed by Lokesh/iteanz on 21 feb 2017 TR DR1K931438
        IF rb_gc EQ abap_true."==> addded by lokesh DR1K931438
** below logic For Group Currency only
          lw_t001 = VALUE #( i_t001[ bukrs = w_vbrk_p-bukrs ] OPTIONAL ). ""Added by chandru "DR1K937367
          IF  w_vbrk_p-upwaerk <> 'INR'.
*Change done by Pushpa 18.01.2017 : DR1K930839 SOLMAN 8000002517 ----Start
*          IF w_vbrk_p-kurrf = 1. Commented by Lokesh/iteanz on 21 feb 2017 TR DR1K931460
            IF lw_t001-land1 NE 'IN'. ""Added by chandru "DR1K937367
              CALL FUNCTION 'CONVERT_AMOUNT_TO_CURRENCY'
                EXPORTING
                  date             = w_vbrk_p-fkdat
                  foreign_currency = w_vbrk_p-waerk
                  foreign_amount   = '100000'
                  local_currency   = 'INR'
                IMPORTING
                  local_amount     = lw_exch.
              w_vbrk_p-kurrf =    lw_exch.
            ENDIF. ""Added by chandru "DR1K937367
*          ENDIF.              Commented by Lokesh/iteanz on 21 feb 2017 TR DR1K931460
*Change done by Pushpa 18.01.2017 : DR1K930839 SOLMAN 8000002517 ----End
            w_vbrk_p-upnetwr_curr = ( w_vbrk_p-upnetwr * w_vbrk_p-kurrf ).
            w_vbrk_p-exchange_rate =  w_vbrk_p-kurrf .
            w_vbrk_p-upwaerk_curr = 'INR'.
          ELSE.
            w_vbrk_p-upnetwr_curr =  w_vbrk_p-upnetwr .
            w_vbrk_p-upwaerk_curr = 'INR'.
          ENDIF.
          CLEAR : lw_t001. "Added by chandru "DR1K937367
**Code Added by Lokesh/iteanz on 21 feb 2017 TR DR1K931438
        ELSE.
          IF  w_vbrk_p-upwaerk <> 'INR'.
            w_vbrk_p-upnetwr_curr = ( w_vbrk_p-upnetwr * w_vbrk_p-kurrf ) .
            w_vbrk_p-exchange_rate =  w_vbrk_p-kurrf .
            w_vbrk_p-upwaerk_curr = w_vbrk_p-upwaerk.
          ELSE.
            w_vbrk_p-upnetwr_curr =  w_vbrk_p-upnetwr .
            w_vbrk_p-upwaerk_curr = 'INR'.
          ENDIF.
        ENDIF.
**End of Code Changed by Lokesh/iteanz on 21 feb 2017 TR DR1K931438

        IF w_vbrk_p-upwaerk <> 'INR'"13.6.2014
        AND rb_gc EQ abap_true. " ==> addded by lokesh DR1K931438
*IF w_vbrk_p-upnetwr_curr IS NOT INITIAL.
          w_vbrk_p-netvalue = ( w_vbrk_p-fklmg * w_vbrk_p-upnetwr_curr ).
        ELSE.
          w_vbrk_p-netvalue = ( w_vbrk_p-fklmg * w_vbrk_p-upnetwr ).
        ENDIF.
        "Begin of changes by chandru "DR1K937332
*      IF  w_vbrk_p-fkart = 'YBS1' OR  w_vbrk_p-fkart = 'ZBRE' OR  w_vbrk_p-fkart = 'ZBCR' OR
*      w_vbrk_p-fkart = 'ZBRZ' OR  w_vbrk_p-fkart = 'ZBCZ' OR   w_vbrk_p-fkart = 'YBRE' OR
*      w_vbrk_p-fkart = 'YBNR' OR   w_vbrk_p-fkart = 'YBCR' OR   w_vbrk_p-fkart = 'YNRE' OR
*      w_vbrk_p-fkart = 'YNNR' OR  w_vbrk_p-fkart = 'ZRRE' OR  w_vbrk_p-fkart = 'ZRCR' OR
*      "Cancellation & Returns
*      w_vbrk_p-fkart = 'ZBS1' OR  w_vbrk_p-fkart = 'Z1S1' OR   w_vbrk_p-fkart = 'Z0S1' OR
*      w_vbrk_p-fkart = 'ZBW1' OR  w_vbrk_p-fkart = 'Z2S1' OR
*      w_vbrk_p-fkart = 'Z3S1'  OR w_vbrk_p-fkart = 'ZMS1' OR "Change done by Pushpa 18.01.2017 : DR1K930839 SOLMAN 8000002517
*      w_vbrk_p-fkart = 'ZRS1' . " Code Added By Chaithanya on 01.09.2017    DR1K935077
*        "OR   w_vbrk_p-fkart = 'YBS2' w_vbrk_p-fkart = 'ZBS2' OR  OR w_vbrk_p-fkart = 'Z2S2'
        IF w_vbrk_p-vbtyp EQ lc_o OR w_vbrk_p-vbtyp EQ lc_n. "Changed by chandru "DR1K937353
          "End of changes by chandru "DR1K937332
          CLEAR : lv_flag. " Code Added By Chaithanya DR1K943218
          lv_flag = 'X'.  " Code Added By Chaithanya DR1K943218
          w_vbrk_p-fklmg = ( w_vbrk_p-fklmg * -1 ) .
          w_vbrk_p-netwr = ( w_vbrk_p-netwr * -1 ) .
          w_vbrk_p-mwsbp = ( w_vbrk_p-mwsbp * -1 ) .
          w_vbrk_p-netvalue  = ( w_vbrk_p-netvalue * -1 ).
          w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr * -1 ).
          w_vbrk_p-insu = ( w_vbrk_p-insu * -1 ).
          w_vbrk_p-fre = ( w_vbrk_p-fre * -1 ).
          w_vbrk_p-excise = ( w_vbrk_p-excise * -1 ).
          w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax * -1 ).
          w_vbrk_p-netwr_curr = ( w_vbrk_p-netwr_curr * -1 ).
          w_vbrk_p-mwsbp_curr = ( w_vbrk_p-mwsbp_curr * -1 ).
          w_vbrk_p-upnetwr_curr = ( w_vbrk_p-upnetwr_curr * -1 ).
        ENDIF.

* READ TABLE i_vbfa INTO w_vbfa WITH KEY vbeln  = w_vbrk_p-vbeln posnn = w_vbrk_p-posnr vbtyp_v = 'K'. "13.6.2014 for Credit/Debit Memo
*   IF sy-subrc = 0.
        IF w_vbrk_p-vgtyp = 'K'.
          IF w_vbrk_p-vbtyp NE 'S'. "" Added by Lokesh/Iteanz on 28.01.2016 " checking subseq cat 'S'
            l_fklmg_v = w_vbrk_p-fklmg.
            CONDENSE l_fklmg_v.
            l_str_fklmg = strlen( l_fklmg_v ).
            l_str_fklmg = l_str_fklmg - 1.
            CONDENSE l_fklmg_v.

            l_fklmg =  l_fklmg_v+l_str_fklmg(1).
*      l_fklmg =  l_fklmg_v+0(1).
            IF l_fklmg <> '-'.
              w_vbrk_p-fklmg = ( w_vbrk_p-fklmg * -1 ).
            ENDIF.

            l_netwr_v = w_vbrk_p-netwr.
            CONDENSE l_netwr_v.
            l_str_netwr = strlen( l_netwr_v ).
            l_str_netwr = l_str_netwr - 1.
            CONDENSE l_netwr_v.
            l_netwr =  l_netwr_v+l_str_netwr(1).
            IF l_netwr <> '-'.
              w_vbrk_p-netwr = ( w_vbrk_p-netwr * -1 ).
            ENDIF.

            l_mwsbp_v = w_vbrk_p-mwsbp.
            CONDENSE l_mwsbp_v.
            l_str_mwsbp = strlen( l_mwsbp_v ).
            l_str_mwsbp = l_str_mwsbp - 1.
            CONDENSE l_mwsbp_v.
            l_mwsbp = l_mwsbp_v+l_str_mwsbp(1).
            IF l_mwsbp <> '-'.
              w_vbrk_p-mwsbp = ( w_vbrk_p-mwsbp * -1 ).
            ENDIF.

            l_netvalue_v = w_vbrk_p-netvalue.
            CONDENSE l_netvalue_v.
            l_str_netvalue = strlen( l_netvalue_v ).
            l_str_netvalue = l_str_netvalue - 1.
            CONDENSE l_netvalue_v.
            l_netvalue = l_netvalue_v+l_str_netvalue(1).
            IF l_netvalue <> '-'.
              w_vbrk_p-netvalue = ( w_vbrk_p-netvalue * -1 ).
            ENDIF.

            l_upnetwr_v =  w_vbrk_p-upnetwr.
            CONDENSE l_upnetwr_v.
            l_str_upnetwr = strlen( l_upnetwr_v ).
            l_str_upnetwr = l_str_upnetwr - 1.
            CONDENSE l_upnetwr_v.
            l_upnetwr = l_upnetwr_v+l_str_upnetwr(1).
            IF l_upnetwr <> '-'.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr * -1 ).
            ENDIF.

            l_insu_v =  w_vbrk_p-insu.
            CONDENSE l_insu_v.
            l_str_insu = strlen( l_insu_v ).
            l_str_insu = l_str_insu - 1.
            CONDENSE l_insu_v.
            l_insu = l_insu_v+l_str_insu(1).
            IF l_insu <> '-'.
              w_vbrk_p-insu = ( w_vbrk_p-insu * -1 ).
            ENDIF.

            l_fre_v = w_vbrk_p-fre.
            CONDENSE l_fre_v.
            l_str_fre = strlen( l_fre_v ).
            l_str_fre = l_str_fre - 1.
            CONDENSE l_fre_v.
            l_fre = l_fre_v+l_str_fre(1).
            IF l_fre <> '-'.
              w_vbrk_p-fre = ( w_vbrk_p-fre * -1 ).
            ENDIF.

            l_excise_v = w_vbrk_p-excise.
            CONDENSE l_excise_v.
            l_str_excise = strlen( l_excise_v ).
            l_str_excise = l_str_excise - 1.
            CONDENSE l_excise_v.
            l_excise =  l_excise_v+l_str_excise(1).
            IF l_excise <> '-'.
              w_vbrk_p-excise = ( w_vbrk_p-excise * -1 ).
            ENDIF.

            l_sales_tax_v =  w_vbrk_p-sales_tax.
            CONDENSE l_sales_tax_v.
            l_str_sales_tax = strlen( l_sales_tax_v ).
            l_str_sales_tax = l_str_sales_tax - 1.
            CONDENSE l_sales_tax_v.
            l_sales_tax = l_sales_tax_v+l_str_sales_tax(1).
            IF l_sales_tax <> '-'.
              w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax * -1 ).
            ENDIF.

            l_sales_tax_v =  w_vbrk_p-sales_tax.
            CONDENSE l_sales_tax_v.
            l_str_sales_tax = strlen( l_sales_tax_v ).
            l_str_sales_tax = l_str_sales_tax - 1.
            CONDENSE l_sales_tax_v.
            l_sales_tax = l_sales_tax_v+l_str_sales_tax(1).
            IF l_sales_tax <> '-'.
              w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax * -1 ).
            ENDIF.

            l_netwr_curr_v =  w_vbrk_p-netwr_curr.
            CONDENSE l_netwr_curr_v.
            l_str_netwr_curr = strlen( l_netwr_curr_v ).
            l_str_netwr_curr = l_str_netwr_curr - 1.
            CONDENSE l_netwr_curr_v.
            l_netwr_curr = l_netwr_curr_v+l_str_netwr_curr(1).
            IF l_netwr_curr <> '-'.
              w_vbrk_p-netwr_curr = ( w_vbrk_p-netwr_curr * -1 ).
            ENDIF.

            l_mwsbp_curr_v =  w_vbrk_p-mwsbp_curr.
            CONDENSE l_mwsbp_curr_v.
            l_str_mwsbp_curr = strlen( l_mwsbp_curr_v ).
            l_str_mwsbp_curr = l_str_mwsbp_curr - 1.
            CONDENSE l_mwsbp_curr_v.
            l_mwsbp_curr = l_mwsbp_curr_v+l_str_mwsbp_curr(1).
            IF l_mwsbp_curr <> '-'.
              w_vbrk_p-mwsbp_curr = ( w_vbrk_p-mwsbp_curr * -1 ).
            ENDIF.

            l_upnetwr_curr_v = w_vbrk_p-upnetwr_curr.
            CONDENSE l_upnetwr_curr_v.
            l_str_upnetwr_curr = strlen( l_upnetwr_curr_v ).
            l_str_upnetwr_curr = l_str_upnetwr_curr - 1.
            CONDENSE l_upnetwr_curr_v.
            l_upnetwr_curr = l_upnetwr_curr_v+l_str_upnetwr_curr(1).
            IF l_upnetwr_curr <> '-'.
              w_vbrk_p-upnetwr_curr = ( w_vbrk_p-upnetwr_curr * -1 ).
            ENDIF.
          ENDIF.
        ENDIF.

*  READ TABLE i_vbfa INTO w_vbfa WITH KEY vbeln  = w_vbrk_p-vbeln posnn = w_vbrk_p-posnr  vbtyp_v = 'L'. "13.6.2014 for Credit/Debit Memo
*   IF sy-subrc = 0  .

        IF w_vbrk_p-vgtyp = 'L'.
          IF lv_flag <> 'X'.  " Code Added By Chaithanya DR1K943218
            l_fklmg_v = w_vbrk_p-fklmg.
            CONDENSE l_fklmg_v.
            l_str_fklmg = strlen( l_fklmg_v ).
            l_str_fklmg = l_str_fklmg - 1.
            CONDENSE l_fklmg_v.
            l_fklmg =  l_fklmg_v+l_str_fklmg(1).
            IF l_fklmg = '-'.
              w_vbrk_p-fklmg = ( w_vbrk_p-fklmg * -1 ).
            ENDIF.

            l_netwr_v = w_vbrk_p-netwr.
            CONDENSE l_netwr_v.
            l_str_netwr = strlen( l_netwr_v ).
            l_str_netwr = l_str_netwr - 1.
            CONDENSE l_netwr_v.
            l_netwr =  l_netwr_v+l_str_netwr(1).
            IF l_netwr = '-'.
              w_vbrk_p-netwr = ( w_vbrk_p-netwr * -1 ).
            ENDIF.

            l_mwsbp_v = w_vbrk_p-mwsbp.
            CONDENSE l_mwsbp_v.
            l_str_mwsbp = strlen( l_mwsbp_v ).
            l_str_mwsbp = l_str_mwsbp - 1.
            CONDENSE l_mwsbp_v.
            l_mwsbp = l_mwsbp_v+l_str_mwsbp(1).
            IF l_mwsbp = '-'.
              w_vbrk_p-mwsbp = ( w_vbrk_p-mwsbp * -1 ).
            ENDIF.

            l_netvalue_v = w_vbrk_p-netvalue.
            CONDENSE l_netvalue_v.
            l_str_netvalue = strlen( l_netvalue_v ).
            l_str_netvalue = l_str_netvalue - 1.
            CONDENSE l_netvalue_v.
            l_netvalue = l_netvalue_v+l_str_netvalue(1).
            IF l_netvalue = '-'.
              w_vbrk_p-netvalue = ( w_vbrk_p-netvalue * -1 ).
            ENDIF.

            l_upnetwr_v =  w_vbrk_p-upnetwr.
            CONDENSE l_upnetwr_v.
            l_str_upnetwr = strlen( l_upnetwr_v ).
            l_str_upnetwr = l_str_upnetwr - 1.
            CONDENSE l_upnetwr_v.
            l_upnetwr = l_upnetwr_v+l_str_upnetwr(1).
            IF l_upnetwr = '-'.
              w_vbrk_p-upnetwr = ( w_vbrk_p-upnetwr * -1 ).
            ENDIF.

            l_insu_v =  w_vbrk_p-insu.
            CONDENSE l_insu_v.
            l_str_insu = strlen( l_insu_v ).
            l_str_insu = l_str_insu - 1.
            CONDENSE l_insu_v.
            l_insu = l_insu_v+l_str_insu(1).
            IF l_insu = '-'.
              w_vbrk_p-insu = ( w_vbrk_p-insu * -1 ).
            ENDIF.

            l_fre_v = w_vbrk_p-fre.
            CONDENSE l_fre_v.
            l_str_fre = strlen( l_fre_v ).
            l_str_fre = l_str_fre - 1.
            CONDENSE l_fre_v.
            l_fre = l_fre_v+l_str_fre(1).
            IF l_fre = '-'.
              w_vbrk_p-fre = ( w_vbrk_p-fre * -1 ).
            ENDIF.

            l_excise_v = w_vbrk_p-excise.
            CONDENSE l_excise_v.
            l_str_excise = strlen( l_excise_v ).
            l_str_excise = l_str_excise - 1.
            CONDENSE l_excise_v.
            l_excise =  l_excise_v+l_str_excise(1).
            IF l_excise = '-'.
              w_vbrk_p-excise = ( w_vbrk_p-excise * -1 ).
            ENDIF.

            l_sales_tax_v =  w_vbrk_p-sales_tax.
            CONDENSE l_sales_tax_v.
            l_str_sales_tax = strlen( l_sales_tax_v ).
            l_str_sales_tax = l_str_sales_tax - 1.
            CONDENSE l_sales_tax_v.
            l_sales_tax = l_sales_tax_v+l_str_sales_tax(1).
            IF l_sales_tax = '-'.
              w_vbrk_p-sales_tax = ( w_vbrk_p-sales_tax * -1 ).
            ENDIF.

            l_netwr_curr_v =  w_vbrk_p-netwr_curr.
            CONDENSE l_netwr_curr_v.
            l_str_netwr_curr = strlen( l_netwr_curr_v ).
            l_str_netwr_curr = l_str_netwr_curr - 1.
            CONDENSE l_netwr_curr_v.
            l_netwr_curr = l_netwr_curr_v+l_str_netwr_curr(1).
            IF l_netwr_curr = '-'.
              w_vbrk_p-netwr_curr = ( w_vbrk_p-netwr_curr * -1 ).
            ENDIF.

            l_mwsbp_curr_v =  w_vbrk_p-mwsbp_curr.
            CONDENSE l_mwsbp_curr_v.
            l_str_mwsbp_curr = strlen( l_mwsbp_curr_v ).
            l_str_mwsbp_curr = l_str_mwsbp_curr - 1.
            CONDENSE l_mwsbp_curr_v.
            l_mwsbp_curr = l_mwsbp_curr_v+l_str_mwsbp_curr(1).
            IF l_mwsbp_curr = '-'.
              w_vbrk_p-mwsbp_curr = ( w_vbrk_p-mwsbp_curr * -1 ).
            ENDIF.

            l_upnetwr_curr_v = w_vbrk_p-upnetwr_curr.
            CONDENSE l_upnetwr_curr_v.
            l_str_upnetwr_curr = strlen( l_upnetwr_curr_v ).
            l_str_upnetwr_curr = l_str_upnetwr_curr - 1.
            CONDENSE l_upnetwr_curr_v.
            l_upnetwr_curr = l_upnetwr_curr_v+l_str_upnetwr_curr(1).
            IF l_upnetwr_curr = '-'.
              w_vbrk_p-upnetwr_curr = ( w_vbrk_p-upnetwr_curr * -1 ).
            ENDIF.
          ENDIF..
        ENDIF.


        READ TABLE i_t001l INTO w_t001l WITH KEY werks = w_vbrk_p-werks lgort = w_vbrk_p-lgort.
        IF sy-subrc = 0.
          w_vbrk_p-lgort_desc = w_t001l-lgobe.
          TRANSLATE w_vbrk_p-lgort_desc  TO  UPPER CASE.
        ENDIF.
*  IF w_vbrk_p-svbeln IS INITIAL . "commented for Deletion of Order
*    DELETE i_vbrk_p.
*    CONTINUE.
*  ENDIF.
* Code added by Parth on 11/07/2014- Start
        CLEAR : w_t001.
        READ TABLE i_t001 INTO w_t001 WITH KEY bukrs = w_vbrk_p-bukrs.
        IF sy-subrc EQ 0.
          w_vbrk_p-butxt = w_t001-butxt.
          TRANSLATE w_vbrk_p-butxt TO UPPER CASE.
        ENDIF.
* Code added by Parth on 11/07/2014- End
        IF w_vbrk_p-pstyv = 'G2N' OR w_vbrk_p-pstyv = 'L2N'.
          CLEAR: w_vbrk_p-fklmg.
        ENDIF.
        READ TABLE i_vbpa1 INTO w_vbpa WITH KEY vbeln = w_vbrk_p-vbeln
        parvw = 'WE'.
        IF sy-subrc = 0.
          READ TABLE i_adrc_n INTO w_adrc_n WITH KEY addrnumber = w_vbpa-adrnr.
          IF sy-subrc = 0.
            w_vbrk_p-sort2 = w_adrc_n-sort2.
          ENDIF.
        ENDIF.
        READ TABLE i_vbpa1 INTO w_vbpa WITH KEY vbeln = w_vbrk_p-vbeln
        parvw = 'ZI'.
        IF sy-subrc = 0.
          READ TABLE i_adrc_n INTO w_adrc_n WITH KEY addrnumber = w_vbpa-adrnr.
          IF sy-subrc = 0.
            w_vbrk_p-sort2 = w_adrc_n-sort2.
          ENDIF.
          READ TABLE i_kna1_n INTO w_kna1_n WITH KEY kunnr = w_vbpa-kunnr.
          IF sy-subrc = 0.
            CONCATENATE w_kna1_n-name1 w_kna1_n-name2 INTO w_vbrk_p-nam SEPARATED BY space.
            w_vbrk_p-mcod3 = w_kna1_n-mcod3.
            READ TABLE i_knvv_n INTO w_knvv_n WITH KEY kunnr = w_kna1_n-kunnr.
            IF sy-subrc = 0.
              READ TABLE i_t171t_n INTO w_t171t_n WITH KEY bzirk = w_knvv_n-bzirk.
              IF sy-subrc = 0.
                w_vbrk_p-bztxt1 = w_t171t_n-bztxt.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.


        lv_name = w_vbrk_p-vbeln."IS_BIL_INVOICE-HD_GEN-Bil_number.

        CALL FUNCTION 'READ_TEXT'
          EXPORTING
*           CLIENT                  = SY-MANDT
            id                      = '0005'
            language                = 'E'
            name                    = lv_name
            object                  = 'VBBK'
          TABLES
            lines                   = lt_lines
          EXCEPTIONS
            id                      = 1
            language                = 2
            name                    = 3
            not_found               = 4
            object                  = 5
            reference_check         = 6
            wrong_access_to_archive = 7
            OTHERS                  = 8.

        LOOP AT lt_lines INTO wa_lines.
          CONCATENATE  w_vbrk_p-text wa_lines-tdline INTO w_vbrk_p-text.
          CLEAR wa_lines.
        ENDLOOP.
*************Begin of changes by Ravi on 03.08.2017 DR1K934548*********************
        READ TABLE lt_kna1 INTO DATA(ls_kna1) WITH KEY kunnr = w_vbrk_p-ship_kunnr.
        IF sy-subrc EQ 0.
          READ TABLE lt_tvk6t INTO DATA(ls_tvk6t) WITH KEY katr6 = ls_kna1-katr6.
          IF sy-subrc EQ 0.
            w_vbrk_p-ship_grp = ls_tvk6t-vtext.
          ENDIF.
        ENDIF.



        MODIFY i_vbrk_p FROM w_vbrk_p TRANSPORTING fklmg
        netwr
        mwsbp
        netvalue
        upnetwr
        insu
        fre
        excise
        sales_tax
        netvalue
        netwr_curr
        mwsbp_curr
        upnetwr_curr
        waerk_curr
        lgort_desc
        exchange_rate
        upwaerk_curr
        butxt
        sort2
        nam
        mcod3
        bztxt1
        text
        ship_grp. "Added by Ravi on 03.08.2017 DR1K934548
*                                                 VBELV_S
*                                                 VBELV_R.

*----------------------------------------------------------
*----------------------------------------------------------
*        Begin of changes added  by Arya on 27.06.2019
*     Begin of changes added by Arya on 26.06.2019
        CONCATENATE 'BF' w_vbrk_p-spart_desc INTO w_vbrk_p-spart_desc SEPARATED BY ''.
        REPLACE ALL OCCURRENCES OF '-' IN w_vbrk_p-spart_desc WITH ' '.
        TRANSLATE w_vbrk_p-spart_desc USING ', '.
        TRANSLATE w_vbrk_p-werks_desc USING ', '.
        TRANSLATE gw_down-ort01 USING ', '.
        TRANSLATE gw_down-bztxt USING ', '.
        TRANSLATE gw_down-name1 USING ', '.
        TRANSLATE gw_down-arktx USING ', '.
        IF w_vbrk_p-mvgr1 IS INITIAL.

          CLEAR : lv_mvgr1,
          lv_bezei.
          SELECT SINGLE mvgr1 FROM mvke INTO lv_mvgr1 WHERE matnr = w_vbrk_p-matnr AND
          vkorg = w_vbrk_p-vkorg AND
          vtweg = w_vbrk_p-vtweg.
          IF sy-subrc EQ 0.
            w_vbrk_p-mvgr1 = lv_mvgr1.
            TRANSLATE w_vbrk_p-mvgr1 USING ', '.
            CLEAR:lv_mvgr1.
            SELECT SINGLE bezei FROM tvm1t INTO lv_bezei WHERE spras = 'E' AND
            mvgr1 = w_vbrk_p-mvgr1.
            IF sy-subrc EQ 0.
              w_vbrk_p-bezei = lv_bezei.
              TRANSLATE w_vbrk_p-bezei USING ', '.
              CLEAR: lv_bezei.
            ENDIF.
          ENDIF.
        ELSE.

          SELECT SINGLE bezei FROM tvm1t INTO lv_bezei WHERE spras = 'E' AND
          mvgr1 = w_vbrk_p-mvgr1.
          IF sy-subrc EQ 0.
            w_vbrk_p-bezei = lv_bezei.
            TRANSLATE w_vbrk_p-bezei USING ', '.
            CLEAR:lv_bezei.
          ENDIF.
        ENDIF.

**      read table i_kna1 into w_kna1 with key kunnr = w_vbrk_p-kunag.
**      if sy-subrc = 0.
**        w_vbrk_p-regio = w_kna1-regio.
**        clear:w_kna1.
**      endif.
        REPLACE ',' WITH space INTO w_vbrk_p-nam.
        REPLACE ',' WITH space INTO w_vbrk_p-ricode.
        REPLACE ',' WITH space INTO w_vbrk_p-riaddr.
        REPLACE ',' WITH space INTO w_vbrk_p-ristat.
        REPLACE ',' WITH space INTO w_vbrk_p-mcod3.
        REPLACE ',' WITH space INTO w_vbrk_p-bztxt1.

*        End of changes added  by Arya on 27.06.2019
*----------------------------------------------------------
*----------------------------------------------------------
        MOVE-CORRESPONDING w_vbrk_p TO gw_final.
*        Begin of changes added  by Arya on 27.06.2019
        IF w_vbrk_p-fklmg < 0.
          lv_quan = w_vbrk_p-fklmg * -1.
          CONDENSE lv_quan.
          CONCATENATE '-' lv_quan INTO lv_quan.
          gw_final-fklmg = lv_quan.
        ELSE.     "Pranesh Changes Start DR1K949079 13.01.2020
          DATA: lv_quant TYPE string.
          lv_quant = trunc( w_vbrk_p-fklmg ).
          gw_final-fklmg = lv_quant.    "Pranesh Changes End DR1K949079 13.01.2020
        ENDIF.
        IF w_vbrk_p-netvalue < 0.
          lv_amt = w_vbrk_p-netvalue * -1.
          CONDENSE lv_amt.
          CONCATENATE '-' lv_amt INTO lv_amt.
          gw_final-netvalue = lv_amt.
        ENDIF.
        CLEAR:lv_quan,lv_amt.

*        End of changes added  by Arya on 27.06.2019
        gw_final-stext = ''.
        gw_final-t_qty = ''.
        gw_final-t_val = ''.
        gw_final-status = 'S'.
        gw_final-message = 'Success'.
        gw_final-date = sy-datum.
        APPEND gw_final TO gt_final.
        CLEAR gw_final.
        CLEAR: w_vbrk_p,w_vbpa,w_adrc_n,w_kna1_n,w_knvv_n,w_t171t_n,lv_name."W_VBFA_S, W_VBFA_S, W_VBRK_S .

      ENDLOOP.
      IF gt_final[] IS NOT INITIAL.
        MOVE-CORRESPONDING gt_final TO output-mt_sales_data_res-records.
      ENDIF.

*----------------------------------------------------------
*----------------------------------------------------------

    ELSE.
      gw_final-status = 'E'.
      gw_final-message = 'variant Doesnot Exist'.
      gw_final-date = sy-datum.
      APPEND gw_final TO gt_final.
      CLEAR: gw_final.
      MOVE-CORRESPONDING gt_final TO output-mt_sales_data_res-records.
      EXIT.
    ENDIF.














*    else.
*      l_uname = sy-uname.
*      concatenate 'Layout is not created for  ' l_uname into gw_final-message.
*      gw_final-status = 'E'.
*      gw_final-date = sy-datum.
*      append gw_final to gt_final.
*      clear: gw_final.
*      move-corresponding gt_final to output-mt_sales_data_res-records.
*      exit.
*    endif.


  ENDMETHOD.
ENDCLASS.
