FUNCTION zcloi_put_sign_in_front.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  CHANGING
*"     REFERENCE(VALUE) TYPE  CLIKE
*"----------------------------------------------------------------------
  DATA: text1(1) TYPE c.
  DATA : lv_c1(4) TYPE c,
         lv_c2(2) TYPE c,
         lv_c3(5) TYPE c,
         len      TYPE i,
         lv_v(100)  TYPE c.
  CLEAR : lv_c1,lv_c2,lv_c3,len.
  SPLIT VALUE AT '-' INTO lv_v lv_c1.

  IF lv_v is NOT INITIAL.
    SPLIT lv_v AT '.' INTO lv_v lv_c3.
    CONDENSE lv_v.
    len = strlen( lv_c3 ).
    CASE len.
      WHEN 0.
        lv_c2 = '00'.
      WHEN 1.
        CONCATENATE lv_c3 '0' INTO lv_c2.
      WHEN 2.
        lv_c2 = lv_c3.
      WHEN OTHERS.
        lv_c2 = lv_c3+0(2).
    ENDCASE.
    CONCATENATE lv_v '.' lv_c2 INTO value.
    CONDENSE value.
    IF VALUE NE '0.00'.
     CONCATENATE '-' value INTO value.
    ENDIF.

  ELSE.
    IF lv_v = ' '.
    VALUE = '0.00'.
    ELSE.
    CONCATENATE value '.00' INTO value.
    CONDENSE value.
    ENDIF.
    IF VALUE NE '0.00'.
     CONCATENATE '-' value INTO value.
    ENDIF.
  ENDIF.



  SEARCH value FOR '-'.
  IF sy-subrc = 0 AND sy-fdpos <> 0.
    SPLIT value AT '-' INTO value text1.
    CONDENSE value.
    CONCATENATE '-' value INTO value.
  ELSE.
    CONDENSE value.
  ENDIF.




ENDFUNCTION.
