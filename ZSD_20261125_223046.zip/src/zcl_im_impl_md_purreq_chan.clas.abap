class ZCL_IM_IMPL_MD_PURREQ_CHAN definition
  public
  final
  create public .

public section.

  interfaces IF_EX_MD_PURREQ_CHANGE .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_IMPL_MD_PURREQ_CHAN IMPLEMENTATION.


  method IF_EX_MD_PURREQ_CHANGE~CHANGE_BEFORE_SAVE_CONV.
*   BREAK-POINT.
*    ch_changed = 'X'.
  endmethod.


  method IF_EX_MD_PURREQ_CHANGE~CHANGE_BEFORE_SAVE_MRP.
*    BREAK-POINT.
     CH_EBAN-BSART = 'ZSMR'.
    ch_changed = 'X'.
  endmethod.
ENDCLASS.
