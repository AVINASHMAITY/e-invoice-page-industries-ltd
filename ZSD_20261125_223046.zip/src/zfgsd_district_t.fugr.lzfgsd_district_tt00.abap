*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTSD_DISTRICT...................................*
DATA:  BEGIN OF STATUS_ZTSD_DISTRICT                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTSD_DISTRICT                 .
CONTROLS: TCTRL_ZTSD_DISTRICT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTSD_DISTRICT                 .
TABLES: ZTSD_DISTRICT                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
