FUNCTION-POOL ZFGAPPL_LOG.                  "MESSAGE-ID ..

* INCLUDE LZFGAPPL_LOGD...                   " Local class definition
