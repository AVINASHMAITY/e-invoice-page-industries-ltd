"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_BATCH_FLIP_IDOC.
*&-------------------------------------------------------------------
*Date       : 05.01.2024
*Programmer : Suganya
*TR No.     : DR1K982078
*Description: Enhancment for Batch flip from vendor batch to SAP batch
*&-------------------------------------------------------------------
DATA: lwa_e1edk14_org TYPE e1edk14.
LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_idoc01>) WHERE segnam = 'E1EDK14' .
  lwa_e1edk14_org = <fs_idoc01>-sdata.
  IF lwa_e1edk14_org-qualf = '008'.
   DATA(lv_orgid)   = lwa_e1edk14_org-orgid.
   EXPORT lv_orgid TO MEMORY id 'LV_ORGID'.
  ENDIF.
ENDLOOP.
ENDENHANCEMENT.
