"Name: \TY:/STTPEC/CL_INT_TRN_DL\ME:COMPOSE_ATT_HEADER\SE:END\EI
ENHANCEMENT 0 ZDEL_ATTP_PO_SYNC.

*  SELECT  vbeln, wadat_ist FROM likp INTO TABLE @DATA(lt_likp) " Commented on 21/02/2025
*   WHERE vbeln = @es_int_trn_head-docnum.
*  IF sy-subrc = 0.
*    SORT lt_likp  BY vbeln ASCENDING.
*  ENDIF.
*
*  SELECT  vbeln, vgbel FROM lips INTO TABLE @DATA(lt_lips)
*    WHERE vbeln = @es_int_trn_head-docnum.
*  IF sy-subrc = 0.
*    SORT lt_lips BY vgbel ASCENDING.
*  ENDIF.
*
*  IF lt_lips IS NOT INITIAL.
*
*  SELECT  vbeln, bstkd FROM vbkd INTO TABLE  @DATA(lt_vbkd)
*    FOR ALL ENTRIES IN @lt_lips
*    WHERE vbeln = @lt_lips-vgbel.
*  IF sy-subrc = 0.
*    SORT lt_vbkd BY vbeln ASCENDING.
*  ENDIF.
*
*   ENDIF.
*
*  SORT lt_lips BY vbeln ASCENDING.
*
*  READ TABLE lt_likp INTO DATA(ls_likp) WITH KEY vbeln = es_int_trn_head-docnum.
*  IF sy-subrc = 0.
*    READ TABLE lt_lips INTO DATA(ls_lips) WITH KEY vbeln = es_int_trn_head-docnum.
*    IF sy-subrc = 0.
*      READ TABLE lt_vbkd INTO DATA(ls_vbkd) WITH KEY vbeln = ls_lips-vgbel.
*      IF sy-subrc = 0.
*        es_int_trn_head-zzdocnum_po = ls_vbkd-bstkd.
*      ENDIF.
*    ENDIF.
*  ENDIF.
ENDENHANCEMENT.
