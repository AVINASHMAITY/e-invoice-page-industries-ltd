class ZBIOCO_CANCEL_WAY_BILL definition
  public
  inheriting from CL_PROXY_CLIENT
  create public .

public section.

  methods CANCEL_WAY_BILL
    importing
      !OUTPUT type ZBIOMT_CANCEL_WAYBILL
    exporting
      !INPUT type ZBIOENVELOPE4
    raising
      CX_AI_SYSTEM_FAULT .
  methods CONSTRUCTOR
    importing
      !LOGICAL_PORT_NAME type PRX_LOGICAL_PORT_NAME optional
    raising
      CX_AI_SYSTEM_FAULT .
protected section.
private section.
ENDCLASS.



CLASS ZBIOCO_CANCEL_WAY_BILL IMPLEMENTATION.


  method CANCEL_WAY_BILL.

  data:
    ls_parmbind type abap_parmbind,
    lt_parmbind type abap_parmbind_tab.

  ls_parmbind-name = 'OUTPUT'.
  ls_parmbind-kind = cl_abap_objectdescr=>importing.
  get reference of OUTPUT into ls_parmbind-value.
  insert ls_parmbind into table lt_parmbind.

  ls_parmbind-name = 'INPUT'.
  ls_parmbind-kind = cl_abap_objectdescr=>exporting.
  get reference of INPUT into ls_parmbind-value.
  insert ls_parmbind into table lt_parmbind.

  if_proxy_client~execute(
    exporting
      method_name = 'CANCEL_WAY_BILL'
    changing
      parmbind_tab = lt_parmbind
  ).

  endmethod.


  method CONSTRUCTOR.

  super->constructor(
    class_name          = 'ZBIOCO_CANCEL_WAY_BILL'
    logical_port_name   = logical_port_name
  ).

  endmethod.
ENDCLASS.
