*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZEI_PAYEETOP.                     " Global Data
  INCLUDE LZEI_PAYEEUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZEI_PAYEEF...                     " Subroutines
* INCLUDE LZEI_PAYEEO...                     " PBO-Modules
* INCLUDE LZEI_PAYEEI...                     " PAI-Modules
* INCLUDE LZEI_PAYEEE...                     " Events
* INCLUDE LZEI_PAYEEP...                     " Local class implement.
* INCLUDE LZEI_PAYEET99.                     " ABAP Unit tests
  INCLUDE LZEI_PAYEEF00                           . " subprograms
  INCLUDE LZEI_PAYEEI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
