*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCLOSE_ZACTMLS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCLOSE_ZACTMLS      .

  PERFORM TABLEPROC.

ENDFUNCTION.
