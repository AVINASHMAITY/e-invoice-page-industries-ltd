*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCOLL_PRINTOUT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCOLL_PRINTOUT      .

  PERFORM TABLEPROC.

ENDFUNCTION.
