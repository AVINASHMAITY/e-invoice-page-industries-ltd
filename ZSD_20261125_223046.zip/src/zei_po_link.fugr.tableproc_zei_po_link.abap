*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZEI_PO_LINK
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZEI_PO_LINK         .

  PERFORM TABLEPROC.

ENDFUNCTION.
