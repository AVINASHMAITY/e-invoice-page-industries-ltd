*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTSD_PACK_UNIT..................................*
DATA:  BEGIN OF STATUS_ZTSD_PACK_UNIT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTSD_PACK_UNIT                .
CONTROLS: TCTRL_ZTSD_PACK_UNIT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTSD_PACK_UNIT                .
TABLES: ZTSD_PACK_UNIT                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
