FUNCTION ZUPDATE_INV_LEGS.
*"----------------------------------------------------------------------
*"*"Update Function Module:
*"
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IS_INV_LEGS) TYPE  ZOBIZ_LEG
*"----------------------------------------------------------------------

  MODIFY ZOBIZ_LEG FROM IS_INV_LEGS.

ENDFUNCTION.
