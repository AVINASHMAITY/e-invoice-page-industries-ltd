"Name: \PR:SAPMJ1IIN\FO:COMPANY_CODE_VALIDATIONS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_INVOICE_BACK_DATE1.
BREAK Sahoo.
If Wa_vbrk-vkorg = '1101'.
If wa_vbrk-fkdat ne Sy-datum.
MESSAGE 'Invoice is back dated Posting not allowed' type 'E'.
endif.

FIELD-SYMBOLS : <lx_BUDAT> type any.
  ASSIGN ('(SAPMJ1IIN)BKPF-BUDAT') TO <lx_BUDAT>.
*  ASSIGN ('(SAPMV45A)VBAK-VKORG') TO <lx_VKORG>.
if <lx_BUDAT> is ASSIGNED.
  if <lx_BUDAT> is not INITIAL.
    if <lx_BUDAT> ne sy-datum.
      MESSAGE 'Invoice is back dated Posting not allowed' type 'E'.
    endif.
  endif.
endif.
endif.
ENDENHANCEMENT.
