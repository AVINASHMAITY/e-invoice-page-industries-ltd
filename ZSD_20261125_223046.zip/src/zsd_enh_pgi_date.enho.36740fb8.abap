"Name: \PR:SAPLV50Q\EX:EHP_UCOMM_WABU_01\EI
ENHANCEMENT 0 ZSD_ENH_PGI_DATE.
*&------------------------------------------------------------------------------
*Date       : 23.01.2025
*Programmer : Suganya
*TR No.     : DR1K990472
*Description: Enhancment for updating Actual PGI date in Delivery when PGI posted via Job
*             Program: WS_MONITOR_OUTB_DEL_GDSI in foreground
*&------------------------------------------------------------------------------
 IF sy-cprog = 'WS_MONITOR_OUTB_DEL_GDSI'.
  SELECT SINGLE *
    FROM tvarvc
    INTO @DATA(ls_tvarvc)
   WHERE name = 'ZSD_UPDATE_PGIDATE'
     AND low  = @lt_worktab-lfart             "Delivery Type
     AND high = @lt_worktab-vstel.            "Shipping Point
  IF sy-subrc = 0.
    SELECT SINGLE vbelv                       "Sales Order
      FROM vbfa
      INTO @data(lv_vbelv)
     WHERE vbeln = @lt_worktab-vbeln.         "Delivery Number
    IF sy-subrc = 0.
      SELECT SINGLE fkdat                     "Billing Date
        FROM vbkd
        INTO @DATA(lv_fkdat)
       WHERE vbeln = @lv_vbelv.
      IF sy-subrc = 0.
        gf_wadat_ist = lv_fkdat.              "Actual PGI Date
      ENDIF.
    ENDIF.
  ENDIF.
 ENDIF.
ENDENHANCEMENT.
