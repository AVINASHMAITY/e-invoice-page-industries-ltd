*&----------------------------------------------------------*
*** Modification Log
*&----------------------------------------------------------*
* Object Name : LZFG_VA02F01
* Author/Comapny Name : Chandra Mohan/ITEANZ
* Transport Request : DR1K904776
* Creation Date : 08.03.2018
*&----------------------------------------------------------*
* Description : SNO generation bug fix
*&----------------------------------------------------------*
*----------------------------------------------------------------------*
***INCLUDE LZFG_VA02F01.
*----------------------------------------------------------------------*
form counter.

  data :count    type i,
        lt_zauth type table of zauth,
        w_zauth  type zauth.


  select     vkorg
             vtweg
             auart
             userid
             uname
  into table lt_zauth
  from       zauth
  where vkorg = zauth-vkorg
  and   vtweg = zauth-vtweg
  and   auart = zauth-auart
  and   userid = zauth-userid.
*  and   uname = zauth-uname . "Changed by chandru ""DR1K904776

  if lt_zauth is not initial.
    message 'Same Entry Already exist' type 'E'.
  endif.

  clear lt_zauth.


  "Begin of addition by chandru "DR1K904776
  data : lt_int type table of char255,
         lv_key type char4.
  lt_int[] = extract[].
  delete lt_int where table_line+3(4) = abap_false.
  describe table lt_int[] lines data(lv_index).
  read table lt_int assigning field-symbol(<fs_row>) index lv_index.
  if sy-subrc = 0.
    zauth-sno = <fs_row>+3(4) + 1.
  endif.
  read table total assigning field-symbol(<fs_del>) with key table_line+3(4) = zauth-sno.
  if sy-subrc = 0.
    delete total index sy-tabix.
  endif.
  if zauth-sno is initial.
    describe table total[] lines data(lv_lines).
    read table total assigning field-symbol(<fs_line>) index lv_lines.
    if sy-subrc = 0.
      zauth-sno = <fs_line>+3(4) + 1.
    endif.
  endif.

  if zauth-sno is initial.
    "End of addition by chandru "DR1K904776
    select     sno
    into table lt_zauth
    from       zauth  .

    sort lt_zauth by sno descending.
    read table lt_zauth into w_zauth index 1.
    if sy-subrc = 0.
      zauth-sno = w_zauth-sno + 1.
    else.
      zauth-sno = 1.
    endif.
  endif. "Added by chandru "DR1K904776

endform.
