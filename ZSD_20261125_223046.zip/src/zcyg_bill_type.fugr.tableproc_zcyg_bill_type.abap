*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_BILL_TYPE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_BILL_TYPE      .

  PERFORM TABLEPROC.

ENDFUNCTION.
