*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCOMP_ADDTOP.                     " Global Data
  INCLUDE LZCOMP_ADDUXX.                     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCOMP_ADDF...                     " Subroutines
* INCLUDE LZCOMP_ADDO...                     " PBO-Modules
* INCLUDE LZCOMP_ADDI...                     " PAI-Modules
* INCLUDE LZCOMP_ADDE...                     " Events
* INCLUDE LZCOMP_ADDP...                     " Local class implement.
* INCLUDE LZCOMP_ADDT99.                     " ABAP Unit tests
  INCLUDE LZCOMP_ADDF00                           . " subprograms
  INCLUDE LZCOMP_ADDI00                           . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
