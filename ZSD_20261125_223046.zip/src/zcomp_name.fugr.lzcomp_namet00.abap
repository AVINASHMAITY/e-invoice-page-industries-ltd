*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCOMP_NAME......................................*
DATA:  BEGIN OF STATUS_ZCOMP_NAME                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCOMP_NAME                    .
CONTROLS: TCTRL_ZCOMP_NAME
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCOMP_NAME                    .
TABLES: ZCOMP_NAME                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
