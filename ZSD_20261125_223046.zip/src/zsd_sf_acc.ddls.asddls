/*
----------------------------------------------------------
Object Name           : ZSD_SF_ACC
Author/Comapny Name   : Ayan Bose/Iteanz
Transport Request     : DR1K962134
Creation Date         : 29.11.2021
----------------------------------------------------------
Description : Salesforce Integration
----------------------------------------------------------
*/
@AbapCatalog.sqlViewName: 'ZS_SF_ACC'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #CHECK
@ClientDependent: true
@EndUserText.label: 'SF Account View'
define view ZSD_SF_ACC 
with parameters language : abap.lang, client :abap.clnt
as select from kna1[ spras = $parameters.language  ] as _kna1 /*" DR1K962134-> DR1K962499 vkorg condition addded by pooja 10.01.22"*/
association [0..1] to knb1 as _knb1 
on _knb1.kunnr = _kna1.kunnr 
association [0..1] to knb5 as _knb5
on _knb5.kunnr = _kna1.kunnr
association [0..1] to knkk as _knkk
on _knkk.kunnr = _kna1.kunnr
association [0..1] to adrc as _adrc
on _adrc.addrnumber = _kna1.adrnr
association [0..1] to adr6 as _adr6
on _adr6.addrnumber = _kna1.adrnr


 {
   _kna1.kunnr as kunnr,
   _kna1.werks as werks,
   _kna1.erdat as erdat,
   _kna1.updat as updat,
   _kna1.name1 as name1,
   _kna1.adrnr as adrnr,
   _kna1.lzone as lzone,
   _kna1.spras as spras,
   _knb1.zterm as zterm,
   _knb1.akont as akont,
   _knb1.vzskz as vzskz,
   _knb1.xzver as xzver,
   _knb1.xausz as xausz,
   _knb1.bukrs as bukrs,
   _knb5.maber as maber,
   _knkk.klimk as klimk,
   _adrc.street as street,
   _adrc.city1 as city1,
   _adrc.country as country,
   _adrc.region as region,
   _adrc.post_code1 as post_code1,
   _adrc.fax_number as fax_number,
   _adr6.smtp_addr as smtp_addr 
}
