"Name: \PR:SAPLV50G\FO:CREATE_ALV_GRID_2100\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_ALV_ZVE01.
*Enhancement to add additional fields in ZVE01 output screen
  TYPES:  BEGIN OF ts_vbrp,
            matnr TYPE vbrp-matnr,
            arktx TYPE vbrp-arktx,
            fkimg TYPE vbrp-fkimg,
            brgew TYPE vbrp-brgew,
          END OF ts_vbrp.
    DATA: lw_vbrp type ts_vbrp.

    IF sy-tcode = 'ZVE01' AND sy-cprog = 'RVEXST00'.
    FIELD-SYMBOLS:<fs_ls_vbrp> TYPE ts_vbrp.
    ASSIGN lw_vbrp to <fs_ls_vbrp>.
    LOOP AT selection_log_tab ASSIGNING FIELD-SYMBOL(<fs_logt>).
     SELECT SINGLE matnr arktx fkimg brgew FROM vbrp INTO <fs_ls_vbrp>
        WHERE vbeln = <fs_logt>-belegnumr AND posnr = <fs_logt>-hauptposi.
       IF sy-subrc = 0.
          <fs_logt>-matnr = <fs_ls_vbrp>-matnr.
          <fs_logt>-arktx = <fs_ls_vbrp>-arktx.
          <fs_logt>-fkimg = <fs_ls_vbrp>-fkimg.
          <fs_logt>-brgew = <fs_ls_vbrp>-brgew.
       ENDIF.
    ENDLOOP.
  ENDIF.
ENDENHANCEMENT.
