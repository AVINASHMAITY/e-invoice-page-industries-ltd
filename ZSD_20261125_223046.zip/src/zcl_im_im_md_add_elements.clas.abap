class ZCL_IM_IM_MD_ADD_ELEMENTS definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_MD_ADD_ELEMENTS .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_IM_MD_ADD_ELEMENTS IMPLEMENTATION.


  method IF_EX_MD_ADD_ELEMENTS~ADD_CHANGE_ELEMENTS.
  endmethod.
ENDCLASS.
