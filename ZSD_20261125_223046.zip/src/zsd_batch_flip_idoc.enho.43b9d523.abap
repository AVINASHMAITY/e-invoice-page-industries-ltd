"Name: \PR:SAPLVEDA\FO:ZUORDNEN_ORDERS_E1EDP01\SE:END\EI
ENHANCEMENT 0 ZSD_BATCH_FLIP_IDOC.
*&-------------------------------------------------------------------
*Date       : 05.01.2024
*Programmer : Suganya
*TR No.     : DR1K982078
*Description: Enhancment for Batch flip from vendor batch to SAP batch
*&-------------------------------------------------------------------
  PERFORM IDOC_MOVE USING E1EDP01-WERKS XVBAP-WERKS D_FLAG_P-PDE3.
ENDENHANCEMENT.
