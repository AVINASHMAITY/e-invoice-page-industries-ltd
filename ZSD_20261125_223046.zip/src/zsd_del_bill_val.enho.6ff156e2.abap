"Name: \PR:SAPLV60A\FO:USEREXIT_FILL_VBRK_VBRP\SE:END\EI
ENHANCEMENT 0 ZSD_DEL_BILL_VAL.
*  ***********************************************************************
* Modification Overview                                                *
***********************************************************************
*&---------------------------------------------------------------------*
*& Developer                   : Kavin K
*& Functional                  : Venkatasen
*& Created On                  : 07/11/2016
*& Title                       : Multiple condition Type Duplicate Validation
*& Request Key to Prod         : DR1K927563
*&---------------------------------------------------------------------*
***********************************************************************
  DATA: lw_ekko TYPE ekko,
        lw_ekbe TYPE ekbe,
        gc_vkorg type vbrk-vkorg.

  DATA: lt_zparam TYPE TABLE OF zparam,
        lw_zparam TYPE          zparam.

  DATA: l_msg(255).

  CLEAR: lw_ekko, lw_ekbe.

  SELECT * FROM zparam
           INTO TABLE lt_zparam
           WHERE parameter1 EQ 'ZPOBILLVAL'.
  IF sy-subrc = 0.
    SORT lt_zparam.
      SELECT SINGLE * FROM ekbe
                      INTO lw_ekbe
                      WHERE belnr EQ vbrp-vbeln
                      AND   bewtp EQ 'L'.
      IF sy-subrc = 0.
        SELECT SINGLE * FROM ekko
                        INTO lw_ekko
                        WHERE ebeln EQ lw_ekbe-ebeln.
        IF sy-subrc = 0.
          READ TABLE lt_zparam INTO lw_zparam
                               WITH KEY parameter2 = lw_ekko-bsart.
          IF sy-subrc = 0.
            READ TABLE lt_zparam INTO lw_zparam
                                 WITH KEY parameter2 = lw_ekko-bsart
                                          parameter3 = vbrk-fkart.
            IF sy-subrc NE 0.
              CLEAR: l_msg.
              CONCATENATE 'You cannot create billing type'
                          vbrk-fkart
                          'against PO type'
                          lw_ekko-bsart
                          INTO l_msg
                          SEPARATED BY space.
              MESSAGE: l_msg TYPE 'E'.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
  ENDIF.
    "Begin Of Addition By Kavin/iteanz on 07/11/2016
      CLEAR gc_vkorg.
      gc_vkorg = vbrk-vkorg.
      export gc_vkorg to MEMORY id 'ZZVKORG'.
      "end Of Addition By Kavin/iteanz on 07/11/2016



************************************************************************
* Modification Log                                            *
***********************************************************************
*&---------------------------------------------------------------------*
*& Developer                   : Kavin K
*& Functional                  : Pushpa
*& Created On                  : 02/02/2017
*& Title                       : License Validation
*& Request Key to Prod         : DR1K931272
*&---------------------------------------------------------------------*

TYPES : BEGIN OF TP_VBAP,
          VBELN   TYPE VBAP-VBELN,
          APLNO   TYPE VBAP-APLNO,
          LICENCE TYPE VBAP-LICENCE,
        END OF TP_VBAP.

DATA : LT_VBAP TYPE TABLE OF TP_VBAP,
       LW_VBAP TYPE TP_VBAP.

DATA :    LT_ZTCA_LICMAST TYPE TABLE OF ZTCA_LICMAST,
          LW_ZTCA_LICMAST TYPE ZTCA_LICMAST,
          LT_RET          TYPE TABLE OF ESP1_MESSAGE_WA_TYPE WITH HEADER LINE,
          LC_W            TYPE SY-MSGTY  VALUE 'E',
          LC_ID           TYPE SYMSGID VALUE 'ZSD_MESSAGE',
          LC_000          TYPE SYMSGNO VALUE '010'.


REFRESH : LT_VBAP,LT_ZTCA_LICMAST.
CLEAR : LW_ZTCA_LICMAST,LW_VBAP.


DATA : GT_CONSTANTS TYPE ZTT_ZTABAP_TVARVC,
       GW_CONSTANTS TYPE ZTABAP_TVARVC.

REFRESH: GT_CONSTANTS.
CLEAR : GW_CONSTANTS.
DATA  :   LC_VKORG(13)  VALUE 'SO_VKORG_ZTCA'.

*----------------------------------------------------------------------*
*ZCMAIN PARAMTER  SHORTCLOSE_PO_COMP GET
*----------------------------------------------------------------------*
CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
  EXPORTING
    IM_OBJNAME = SY-REPID
  IMPORTING
    EX_TAB     = GT_CONSTANTS.

READ TABLE GT_CONSTANTS INTO GW_CONSTANTS
    WITH KEY   OBJ_NAME    = SY-REPID
               NAME        = LC_VKORG
               LOW         = VBRK-VKORG.

IF SY-SUBRC EQ 0.

  SELECT  VBELN
          APLNO
          LICENCE FROM VBAP INTO  TABLE LT_VBAP
          WHERE VBELN = VBRP-VBELN.

  IF SY-SUBRC EQ 0.

    SELECT * FROM  ZTCA_LICMAST
       INTO TABLE  LT_ZTCA_LICMAST
      FOR ALL ENTRIES IN  LT_VBAP WHERE   APLNO  =  LT_VBAP-APLNO AND
                                          LIC_NO =  LT_VBAP-LICENCE.

*** Added by Kavin/iteanz on 22/03/2017
DELETE LT_ZTCA_LICMAST WHERE  APLNO  is INITIAL .
*** End of Added by Kavin/iteanz on 22/03/2017
    LOOP AT LT_VBAP INTO LW_VBAP.
      READ TABLE  LT_ZTCA_LICMAST INTO LW_ZTCA_LICMAST WITH KEY APLNO  =  LW_VBAP-APLNO
                                                                LIC_NO =  LW_VBAP-LICENCE.
      IF SY-SUBRC EQ 0.
        IF   VBRK-FKDAT LE LW_ZTCA_LICMAST-T_DATE .
        ELSE.
          LT_RET-MSGTY      =  LC_W.
          LT_RET-MSGID      =  LC_ID  .
          LT_RET-MSGNO      =  LC_000.
          LT_RET-MSGV1      =  LW_VBAP-LICENCE.
          APPEND LT_RET.
        ENDIF.
      ENDIF.
      CLEAR :  LW_ZTCA_LICMAST,LW_VBAP,LW_ZTCA_LICMAST.
    ENDLOOP.

  ENDIF.
*----------------------------------------------------------------------*
*POP UP Display
*----------------------------------------------------------------------*
  IF LT_RET  IS NOT INITIAL.

    CALL FUNCTION 'C14Z_MESSAGES_SHOW_AS_POPUP'
      TABLES
        I_MESSAGE_TAB = LT_RET.
    MESSAGE E010(ZSD_MESSAGE) .
  ENDIF.
ENDIF.

ENDENHANCEMENT.
