*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGSD_DISTRICT_TTOP.              " Global Data
  INCLUDE LZFGSD_DISTRICT_TUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGSD_DISTRICT_TF...              " Subroutines
* INCLUDE LZFGSD_DISTRICT_TO...              " PBO-Modules
* INCLUDE LZFGSD_DISTRICT_TI...              " PAI-Modules
* INCLUDE LZFGSD_DISTRICT_TE...              " Events
* INCLUDE LZFGSD_DISTRICT_TP...              " Local class implement.
* INCLUDE LZFGSD_DISTRICT_TT99.              " ABAP Unit tests
  INCLUDE LZFGSD_DISTRICT_TF00                    . " subprograms
  INCLUDE LZFGSD_DISTRICT_TI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
