*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_SEZ_PLANT..................................*
DATA:  BEGIN OF STATUS_ZCYG_SEZ_PLANT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_SEZ_PLANT                .
CONTROLS: TCTRL_ZCYG_SEZ_PLANT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_SEZ_PLANT                .
TABLES: ZCYG_SEZ_PLANT                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
