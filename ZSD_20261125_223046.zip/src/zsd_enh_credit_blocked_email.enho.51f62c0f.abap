"Name: \PR:SAPMV45A\FO:USEREXIT_AVAIL_CHECK_CREDIT\SE:END\EI
ENHANCEMENT 0 ZSD_ENH_CREDIT_BLOCKED_EMAIL.
*&---------------------------------------------------------------------*
*Implementetaion   : ZSD_ENH_CREDIT_BLOCKED_EMAIL                      *
*Created on        : 24.09.2018                                        *
*Developer         : Chaithanya/Iteanz                                 *
*Functional        : Akki                                              *
*Transport         : DR1K942042                                        *
*Description       : Credit blocked released Email Process             *
*&---------------------------------------------------------------------*
*&                    Modification Log                                 *
*&---------------------------------------------------------------------*
*&  DATE        PROGRAMMER    CLIENT REF NO.          DESCRIPTION      *
*& 28.09.2018   Chaithanya     DR1K942133   Credit Block Email Process *
*&---------------------------------------------------------------------*

*** Code Begin By Chaithanya DR1K942133 ****
CONSTANTS : LC_VKM3 TYPE SYST_TCODE VALUE 'VKM3',
            LC_D    TYPE CMGST VALUE 'D'.
DATA: LV_VBELN  TYPE VBAK-VBELN,
      LV_VBELN1 TYPE VBAK-VBELN.
*Begin of code by Samata P /Iteanz 13.02.2023 DR1K972180
DATA: LT_ZTSD_SO_MAIL TYPE TABLE OF ZTSD_SO_MAIL,
      LW_ZTSD_SO_MAIL TYPE ZTSD_SO_MAIL.
*end by Samata P /Iteanz 13.02.2023 DR1K972180
IF SY-TCODE = LC_VKM3.
  IF VBUK-CMGST = LC_D.
    GET PARAMETER ID 'SOD' FIELD LV_VBELN1.
    IF LV_VBELN1 NE VBAK-VBELN.
  DATA :  LW_DOC_CHNG TYPE SODOCCHGI1,
          I_OBJPACK   LIKE SOPCKLSTI1 OCCURS 0 WITH HEADER LINE,
          I_OBJTXT    LIKE SOLISTI1 OCCURS 0 WITH HEADER LINE,
          I_OBJBIN    LIKE SOLISTI1 OCCURS 0 WITH HEADER LINE,
          I_RECLIST   LIKE SOMLRECI1 OCCURS 0 WITH HEADER LINE,
          V_FORM_NAME TYPE RS38L_FNAM,
          V_LEN_IN    LIKE SOOD-OBJLEN,
          V_LEN_OUT   LIKE SOOD-OBJLEN,
          V_LEN_OUTN  TYPE I,
          V_LINES_TXT TYPE I,
          V_LINES_BIN TYPE I.

  DATA : LT_RECIPIENTS TYPE TABLE OF UIYS_IUSR,
         LW_RECIPIENTS LIKE LINE OF LT_RECIPIENTS,
         LT_RETURN     TYPE TABLE OF RPBENERR,
         LW_OBJHEAD    TYPE SOLI_TAB.

  DATA : LV_UNAME TYPE SY-UNAME,
         LW_VKORG TYPE VBAK-VKORG,
         LV_ERNAM TYPE VBAK-ERNAM,
         LV_FLAG  TYPE C,
         lv_werks type vbap-werks. "added by Samata P/Iteanz DR1K972966 01.03.2023

  CONSTANTS : LC_PRG TYPE SOBJ_NAME VALUE 'VKM3'.
  DATA : LT_CON TYPE ZTT_ZTABAP_TVARVC,
         LW_CON TYPE ZTABAP_TVARVC.
  CONSTANTS : LC_VKORG(5) VALUE 'VKORG'.

    CLEAR: LW_VKORG.
    SELECT SINGLE VKORG FROM VBAK INTO LW_VKORG
                        WHERE VBELN = VBAK-VBELN.
    select single werks from vbap into lv_werks where vbeln = vbak-vbeln. "added by Samata P/Iteanz DR1K972966 01.03.2023
    CLEAR : LW_CON.
    CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
      EXPORTING
        IM_OBJNAME = LC_PRG
      IMPORTING
        EX_TAB     = LT_CON.

    READ TABLE LT_CON INTO LW_CON
           WITH KEY   OBJ_NAME = LC_PRG
                      NAME     = LC_VKORG
                      LOW      = LW_VKORG.
    IF SY-SUBRC = 0.
*Begin of Chnages by Samata P /Iteanz 13.02.2023 DR1K972180
*      SELECT SINGLE ERNAM FROM VBAK
*                          INTO LV_ERNAM
*                          WHERE VBELN EQ VBAK-VBELN.
*
*
*
*    CALL FUNCTION 'HR_FBN_GET_USER_EMAIL_ADDRESS'
*      EXPORTING
*        USER_ID       = LV_ERNAM
*        REACTION      = ' '
*      IMPORTING
*        EMAIL_ADDRESS = LW_RECIPIENTS-EMAIL
*      TABLES
*        ERROR_TABLE   = LT_RETURN.
    SELECT * FROM ZTSD_SO_MAIL INTO TABLE LT_ZTSD_SO_MAIL WHERE VKORG = LW_VKORG and werks = lv_werks. "'werks' by Samata P/Iteanz DR1K972966 01.03.2023
*    I_RECLIST-RECEIVER = LW_RECIPIENTS-EMAIL.
    LOOP AT LT_ZTSD_SO_MAIL INTO LW_ZTSD_SO_MAIL.
    I_RECLIST-RECEIVER = Lw_ZTSD_SO_MAIL-SMTP_ADDR.
    I_RECLIST-REC_TYPE = 'U'.
    APPEND I_RECLIST.
    ENDLOOP.
*   * end of changes by Samata P /Iteanz 13.02.2023 DR1K972180
    CONCATENATE 'SO Credit block has been released :' VBAK-VBELN INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    I_OBJTXT = ' '.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    I_OBJTXT = 'NOTE: THIS IS SYSTEM GENERATED E-MAIL.'.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    DESCRIBE TABLE I_OBJTXT LINES V_LINES_TXT.
    READ TABLE I_OBJTXT INDEX V_LINES_TXT.


    LW_DOC_CHNG-OBJ_DESCR = 'SO Credit block has been released'.
    LW_DOC_CHNG-SENSITIVTY = 'F'.
    LW_DOC_CHNG-DOC_SIZE = V_LINES_TXT * 255.

*    Main Text
    CLEAR I_OBJPACK-TRANSF_BIN.
    I_OBJPACK-HEAD_START = 1.
    I_OBJPACK-HEAD_NUM = 0.
    I_OBJPACK-BODY_START = 1.
    I_OBJPACK-BODY_NUM = V_LINES_TXT.
    I_OBJPACK-DOC_TYPE = 'RAW'.
    APPEND I_OBJPACK.
    IF I_RECLIST IS NOT INITIAL.
      DELETE ADJACENT DUPLICATES FROM I_RECLIST.
    ENDIF.

    CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
      EXPORTING
        DOCUMENT_DATA              = LW_DOC_CHNG
        PUT_IN_OUTBOX              = 'X'
        SENDER_ADDRESS             = CONV SOEXTRECI1-RECEIVER( SY-UNAME )
*       SENDER_ADDRESS_TYPE        = 'B'
        COMMIT_WORK                = 'X'
*       SENDER_ID                  =
      TABLES
        PACKING_LIST               = I_OBJPACK
        OBJECT_HEADER              = LW_OBJHEAD
        CONTENTS_BIN               = I_OBJBIN
        CONTENTS_TXT               = I_OBJTXT
        RECEIVERS                  = I_RECLIST
      EXCEPTIONS
        TOO_MANY_RECEIVERS         = 1
        DOCUMENT_NOT_SENT          = 2
        DOCUMENT_TYPE_NOT_EXIST    = 3
        OPERATION_NO_AUTHORIZATION = 4
        PARAMETER_ERROR            = 5
        X_ERROR                    = 6
        ENQUEUE_ERROR              = 7
        OTHERS                     = 8.
    IF SY-SUBRC <> 0.
      WRITE:/ 'Error When Sending the File', SY-SUBRC.
    ENDIF.
  ENDIF.
      LV_VBELN = VBAK-VBELN.
      SET PARAMETER ID 'SOD' FIELD LV_VBELN.
    ENDIF.
  ENDIF.
ENDIF.


*      DATA: GC_SUBJECT TYPE SO_OBJ_DES,
*            GC_RAW     TYPE CHAR03 VALUE 'RAW'.
*
*      DATA: GV_MLREC         TYPE SO_OBJ_NAM,
*            GV_SENT_TO_ALL   TYPE OS_BOOLEAN,
*            GV_EMAIL         TYPE ADR6-SMTP_ADDR,
*            GV_SUBJECT       TYPE SO_OBJ_DES,
*            GV_TEXT          TYPE BCSY_TEXT,
*            W_TEXT1          TYPE CHAR120,
*
*            GR_SEND_REQUEST  TYPE REF TO CL_BCS,
*            GR_BCS_EXCEPTION TYPE REF TO CX_BCS,
*            GR_RECIPIENT     TYPE REF TO IF_RECIPIENT_BCS,
*            GR_SENDER        TYPE REF TO CL_SAPUSER_BCS,
*            GR_DOCUMENT      TYPE REF TO CL_DOCUMENT_BCS.
*
*      DATA : LT_RECIPIENTS TYPE TABLE OF UIYS_IUSR,
*             LW_RECIPIENTS LIKE LINE OF LT_RECIPIENTS,
*             LT_RETURN     TYPE TABLE OF RPBENERR.
*
*      DATA : LV_UNAME TYPE SY-UNAME,
*             LW_VKORG TYPE VBAK-VKORG,
*             LV_ERNAM TYPE VBAK-ERNAM.
*
*      CONSTANTS : LC_PRG TYPE SOBJ_NAME VALUE 'VKM3'.
*      DATA : LT_CON TYPE ZTT_ZTABAP_TVARVC,
*             LW_CON TYPE ZTABAP_TVARVC.
*      CONSTANTS : LC_VKORG(5) VALUE 'VKORG'.
*
*      CLEAR: LW_VKORG.
*      SELECT SINGLE VKORG FROM VBAK INTO LW_VKORG
*                          WHERE VBELN = VBUK-VBELN.
*      CLEAR : LW_CON.
*      CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
*        EXPORTING
*          IM_OBJNAME = LC_PRG
*        IMPORTING
*          EX_TAB     = LT_CON.
*
*      READ TABLE LT_CON INTO LW_CON
*             WITH KEY   OBJ_NAME = LC_PRG
*                        NAME     = LC_VKORG
*                        LOW      = LW_VKORG.
*      IF SY-SUBRC = 0.
*
*
*        SELECT SINGLE ERNAM FROM VBAK
*                            INTO LV_ERNAM
*                            WHERE VBELN EQ VBUK-VBELN.
*        CONCATENATE 'Credit blocked has been released SO:' VBUK-VBELN INTO  GC_SUBJECT.
*        TRY.
*            "CREATE SEND REQUEST
*            GR_SEND_REQUEST = CL_BCS=>CREATE_PERSISTENT( ).
*
*
*            "EMAIL FROM...
*            GR_SENDER = CL_SAPUSER_BCS=>CREATE( SY-UNAME ).
*            "ADD SENDER TO SEND REQUEST
*            CALL METHOD GR_SEND_REQUEST->SET_SENDER
*              EXPORTING
*                I_SENDER = GR_SENDER.
*
*
*            IF LV_ERNAM IS NOT INITIAL.
*              CALL FUNCTION 'HR_FBN_GET_USER_EMAIL_ADDRESS'
*                EXPORTING
*                  USER_ID       = LV_ERNAM
*                  REACTION      = ' '
*                IMPORTING
*                  EMAIL_ADDRESS = LW_RECIPIENTS-EMAIL
*                TABLES
*                  ERROR_TABLE   = LT_RETURN.
*              .
*            ENDIF.
*
*            GV_EMAIL = LW_RECIPIENTS-EMAIL.
*            GR_RECIPIENT = CL_CAM_ADDRESS_BCS=>CREATE_INTERNET_ADDRESS( GV_EMAIL ).
*            "ADD RECIPIENT TO SEND REQUEST
*            CALL METHOD GR_SEND_REQUEST->ADD_RECIPIENT
*              EXPORTING
*                I_RECIPIENT = GR_RECIPIENT
*                I_EXPRESS   = 'X'.
*
*            CLEAR GV_EMAIL.
*
**
**        APPEND 'Dear User,' TO GV_TEXT.
**        APPEND ' ' TO GV_TEXT.
*            CONCATENATE 'Credit blocked has been released SO:' VBUK-VBELN INTO W_TEXT1 SEPARATED BY ''.
*            APPEND W_TEXT1 TO GV_TEXT.
*            CLEAR W_TEXT1.
*            APPEND ' ' TO GV_TEXT.
**        APPEND 'Regards' TO GV_TEXT.
**        APPEND 'BRM TEAM' TO GV_TEXT.
*
*            APPEND ' ' TO GV_TEXT.
*            APPEND ' ' TO GV_TEXT.
*
*            APPEND 'NOTE: THIS IS SYSTEM GENERATED E-MAIL.' TO GV_TEXT.
*            GR_DOCUMENT = CL_DOCUMENT_BCS=>CREATE_DOCUMENT(
*                             I_TYPE    = GC_RAW
*                             I_TEXT    = GV_TEXT
*                             I_LENGTH  = '12'
*                             I_SUBJECT = GC_SUBJECT ).
*            "ADD DOCUMENT TO SEND REQUEST
*            CALL METHOD GR_SEND_REQUEST->SET_DOCUMENT( GR_DOCUMENT ).
*
*
*            "SEND EMAIL
*            CALL METHOD GR_SEND_REQUEST->SEND(
*              EXPORTING
*                I_WITH_ERROR_SCREEN = 'X'
*              RECEIVING
*                RESULT              = GV_SENT_TO_ALL ).
*            IF GV_SENT_TO_ALL = 'X'.
**        WRITE 'EMAIL SENT!'.
*            ENDIF.
*
*            "COMMIT TO SEND EMAIL
*            COMMIT WORK.
*
*            "EXCEPTION HANDLING
*          CATCH CX_BCS INTO GR_BCS_EXCEPTION.
*            WRITE:
*              'ERROR!',
*              'ERROR TYPE:',
*              GR_BCS_EXCEPTION->ERROR_TYPE.
*        ENDTRY.
*      ENDIF.
*** Code End By Chaithanya DR1K942133 ****
ENDENHANCEMENT.
