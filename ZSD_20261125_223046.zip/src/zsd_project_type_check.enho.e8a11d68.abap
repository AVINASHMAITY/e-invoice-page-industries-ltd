"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAP\SE:BEGIN\EN:ZSD_WBS_VALIDATE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_PROJECT_TYPE_CHECK.
************************************************************************
* Date       Programmer  Client Ref No.     Correction                 *
* 21/02/2022  Sudhakar   DR1K963530
* Description   Validation to restrict project type in SO
************************************************************************
DATA : lw_cons TYPE ztabap_tvarvc,
       lt_cons TYPE ztt_ztabap_tvarvc,
       lv_prart TYPE prps-prart.

CONSTANTS : lc_obj TYPE SOBJ_NAME VALUE 'S_WBS_RESTR_SO',
            lc_name TYPE RVARI_VNAM VALUE 'WERKS_SO_WBS '.

IF sy-tcode = 'VA01' or sy-tcode = 'VA02'.

  CALL METHOD zcl_abap_utility=>GET_OPTIONS
    EXPORTING
      im_objname = lc_obj
    IMPORTING
      ex_tab     = lt_cons.

  IF vbap-ps_psp_pnr IS NOT INITIAL AND vbap-werks+0(1) = '5'.
    SELECT SINGLE PRART FROM prps INTO lv_prart WHERE pspnr = vbap-ps_psp_pnr.
      IF sy-subrc = 0 and lv_prart IS NOT INITIAL.
        READ TABLE lt_cons INTO lw_cons with KEY low = lv_prart name = lc_name.
        IF sy-subrc = 0.
          MESSAGE e088(zsd_messages) with lv_prart.
        endif.
      endif.
  ENDIF.
  CLEAR: lv_prart, lw_cons.
ENDIF.
ENDENHANCEMENT.
