class ZCL_EI_SEND_DATA_PIPO_SYN_IN_S definition
  public
  create public .

public section.

  interfaces ZII_EI_SEND_DATA_PIPO_SYN_IN_S .
protected section.
private section.
ENDCLASS.



CLASS ZCL_EI_SEND_DATA_PIPO_SYN_IN_S IMPLEMENTATION.


  method ZII_EI_SEND_DATA_PIPO_SYN_IN_S~EI_SEND_DATA_PIPO_SYN_IN_SI.
*** **** INSERT IMPLEMENTATION HERE **** ***
  endmethod.
ENDCLASS.
