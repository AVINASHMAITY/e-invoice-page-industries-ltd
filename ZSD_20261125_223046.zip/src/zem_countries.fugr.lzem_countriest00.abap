*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZEM_COUNTRIES...................................*
DATA:  BEGIN OF STATUS_ZEM_COUNTRIES                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZEM_COUNTRIES                 .
CONTROLS: TCTRL_ZEM_COUNTRIES
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZEM_COUNTRIES                 .
TABLES: ZEM_COUNTRIES                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
