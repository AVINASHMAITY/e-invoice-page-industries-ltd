class ZCL_IM_SD_HP_TAB_CUST_HEAD definition
  public
  final
  create public .

public section.

  interfaces IF_EX_LE_SHP_TAB_CUST_HEAD .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_SD_HP_TAB_CUST_HEAD IMPLEMENTATION.


  method IF_EX_LE_SHP_TAB_CUST_HEAD~ACTIVATE_TAB_PAGE.
    break sahoo.

     EF_CAPTION = 'Excise Tab'.
     EF_PROGRAM = 'SAPLZSDF_CT3_VALIDATION'.
     EF_POSITION = 4.
     EF_DYNPRO   = '9000'.
     cs_v50agl_cust = 'X'.
  endmethod.


  method IF_EX_LE_SHP_TAB_CUST_HEAD~PASS_FCODE_TO_SUBSCREEN.
  endmethod.


  method IF_EX_LE_SHP_TAB_CUST_HEAD~TRANSFER_DATA_FROM_SUBSCREEN.
    break sahoo.

    CALL FUNCTION 'ZSDF_CT3_VALIDATION_DELIVERY'
     IMPORTING
       CS_LIKP       = CS_LIKP
              .

  endmethod.


  method IF_EX_LE_SHP_TAB_CUST_HEAD~TRANSFER_DATA_TO_SUBSCREEN.
    break sahoo.

    CALL FUNCTION 'ZSDF_CT3_VALIDATION_DELIVERY1'
      EXPORTING
        IS_LIKP       = IS_LIKP
              .


  endmethod.
ENDCLASS.
