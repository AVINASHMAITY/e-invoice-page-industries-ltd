"Name: \PR:SAPMV86E\FO:SET_PF_STATUS\SE:END\EI
ENHANCEMENT 0 ZSD_SYG_DMS_LINK_ACC.
"Code added by CC on 15.11.2019 DR1K948316
"Purpose::DMS attachment link in VX11N
IF sy-dynnr = '0601' AND ( sy-tcode = 'VX12N' OR sy-tcode = 'VX13N' ) .
  DATA lv_vbeln TYPE akkp-lcnum."vbrk-vbeln.

  GET PARAMETER ID 'AKN' FIELD lv_vbeln.

  SET PF-STATUS 'ZSTATUS' OF PROGRAM 'ZSYG_SD_VX12N'  EXCLUDING cua_exclude.
  PERFORM set_master_title USING
                             disp_mode.
ENDIF.
"Code ended by CC
ENDENHANCEMENT.
