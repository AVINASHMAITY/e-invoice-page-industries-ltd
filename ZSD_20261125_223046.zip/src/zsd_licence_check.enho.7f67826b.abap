"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_LICENCE_CHECK.
TYPES: BEGIN        OF   ty_marc,
       matnr        TYPE marc-matnr,
       werks        TYPE marc-werks,
       zzlicence1   TYPE marc-zzlicence1,
       zzlicencenr1 TYPE marc-zzlicencenr1,
       zzlicence2   TYPE marc-zzlicence2,
       zzlicencenr2 TYPE marc-zzlicencenr2,
       zzlicence3   TYPE marc-zzlicence3,
       zzlicencenr3 TYPE marc-zzlicencenr3,
       zzlicence4   TYPE marc-zzlicence4,
       zzlicencenr4 TYPE marc-zzlicencenr4,
       zzlicence5   TYPE marc-zzlicence5,
       zzlicencenr5 TYPE marc-zzlicencenr5,
       END          OF   ty_marc,

       BEGIN OF   ty_mara,
       matnr TYPE mara-matnr,
       mtart TYPE mara-mtart,
       matkl TYPE mara-matkl,
       END   OF   ty_mara,

       BEGIN OF   ty_type,
       lityp TYPE zmmcode,
       END   OF   ty_type,

       BEGIN  OF   ty_lic,
       lic_no TYPE ztca_licmast-lic_no,
       END    OF   ty_lic,

       BEGIN OF ty_kna1,
       kunnr TYPE kna1-kunnr,
       land1 TYPE kna1-land1,
       END   OF ty_kna1.

DATA: it_marc TYPE TABLE OF ty_marc,
      it_mara TYPE TABLE OF ty_mara,
      it_lipr TYPE TABLE OF ztca_licpr,
      it_limt TYPE TABLE OF ztca_licmast,
      it_lity TYPE TABLE OF ty_type,
      it_retn TYPE TABLE OF bapiret2,
      it_lic  TYPE TABLE OF ty_lic,
      it_msd  TYPE TABLE OF zsd_license,
      wa_lic  TYPE ty_lic,
      wa_retn TYPE bapiret2,
      wa_lity TYPE ty_type,
      wa_limt TYPE ztca_licmast,
      wa_lipr TYPE ztca_licpr,
      wa_mara TYPE ty_mara,
      wa_marc TYPE ty_marc,
      wa_vbpa TYPE vbpa,
      wa_kna1 TYPE ty_kna1.

DATA: lv_plan TYPE c,
      lv_coun TYPE c,
      lv_cust TYPE c,
      lv_matn TYPE c,
      lv_quan TYPE c,
      lv_qaty TYPE zca_util,
      lv_lic  TYPE c,
      lv_flag TYPE c,
      lv_msd  TYPE c.

DATA: lv_licls TYPE ztca_licpr-licclass,
      lv_lityp TYPE ztca_licpr-lictype.

FIELD-SYMBOLS <fs_vbap> TYPE vbapvb.

REFRESH : it_lipr,it_lic,it_retn, it_lity, it_limt, it_mara, it_marc.

CLEAR lv_flag.

IF ( sy-tcode = 'VA01' OR sy-tcode = 'VA02' ) AND vbak-vkorg = '1101'.
  CLEAR: lv_licls, lv_lityp.
  CASE vbak-auart.
    WHEN 'ZBEX' OR 'ZBE1' OR 'ZBEZ'.
      lv_licls = 'EXP'.
    WHEN 'ZBFZ'.
      lv_licls = 'EXP'.
      lv_lityp = 'F29'.
    WHEN 'ZBOR' OR 'ZBDE' OR 'ZBA1' OR 'ZBAL' OR 'ZBE2' OR 'ZBD1'." OR 'ZBAS'.
      lv_licls = 'MFG'.
    WHEN 'ZBFG'.
      lv_licls = 'MFG'.
      lv_lityp = 'F29'.
    WHEN 'ZB1' OR 'ZB2' OR 'ZB3'OR 'ZB4'.
      lv_flag = 'X'.
    WHEN OTHERS.
      lv_flag = 'X'.
  ENDCASE.
  IF lv_flag IS INITIAL.
    CLEAR wa_vbpa.
    READ TABLE xvbpa INTO wa_vbpa WITH KEY parvw = 'WE'.
    IF sy-subrc = 0.
      CLEAR wa_kna1.
      SELECT SINGLE kunnr land1 FROM kna1 INTO wa_kna1 WHERE kunnr = wa_vbpa-kunnr.
      IF sy-subrc = 0.
      ENDIF.
    ENDIF.
    UNASSIGN <fs_vbap>.
    REFRESH it_msd.
    SELECT * FROM zsd_license INTO TABLE it_msd.
    LOOP AT xvbap ASSIGNING <fs_vbap>.
      CLEAR lv_msd.
      REFRESH : it_lipr, it_lic, it_lity, it_limt, it_mara, it_marc.
      IF <fs_vbap>-updkz = 'I' OR <fs_vbap>-updkz = 'U'.
        CLEAR wa_mara.
        IF <fs_vbap>-matnr IS NOT INITIAL.
          SELECT SINGLE matnr mtart matkl
            FROM mara
            INTO wa_mara
           WHERE matnr = <fs_vbap>-matnr.
          IF sy-subrc = 0.
            READ TABLE it_msd TRANSPORTING NO FIELDS WITH KEY matkl = wa_mara-matkl.
            IF sy-subrc = 0.
              lv_msd = 'X'.
            ELSE.
              CLEAR lv_msd.
            ENDIF.
          ENDIF.
          CLEAR wa_marc.
          SELECT SINGLE
                 matnr      werks
                 zzlicence1 zzlicencenr1
                 zzlicence2 zzlicencenr2
                 zzlicence3 zzlicencenr3
                 zzlicence4 zzlicencenr4
                 zzlicence5 zzlicencenr5
            FROM marc
            INTO wa_marc
           WHERE matnr = <fs_vbap>-matnr
             AND werks = <fs_vbap>-werks.
          IF sy-subrc = 0.
            REFRESH: it_lity, it_lic.
            IF wa_marc IS NOT INITIAL..
              CLEAR: wa_lity, wa_lic.
              MOVE wa_marc-zzlicence1 TO wa_lity-lityp.
              IF wa_lity-lityp IS NOT INITIAL.
                APPEND wa_lity TO it_lity.
              ENDIF.

              MOVE wa_marc-zzlicencenr1 TO wa_lic-lic_no.
              IF wa_lic-lic_no IS NOT INITIAL.
                APPEND wa_lic TO it_lic.
              ENDIF.

              CLEAR: wa_lity, wa_lic.
              MOVE wa_marc-zzlicence2 TO wa_lity-lityp.
              IF wa_lity-lityp IS NOT INITIAL.
                APPEND wa_lity TO it_lity.
              ENDIF.

              MOVE wa_marc-zzlicencenr2 TO wa_lic-lic_no.
              IF wa_lic-lic_no IS NOT INITIAL.
                APPEND wa_lic TO it_lic.
              ENDIF.

              CLEAR: wa_lity, wa_lic.
              MOVE wa_marc-zzlicence3 TO wa_lity-lityp.
              IF wa_lity-lityp IS NOT INITIAL.
                APPEND wa_lity TO it_lity.
              ENDIF.

              MOVE wa_marc-zzlicencenr3 TO wa_lic-lic_no.
              IF wa_lic-lic_no IS NOT INITIAL.
                APPEND wa_lic TO it_lic.
              ENDIF.

              CLEAR: wa_lity, wa_lic.
              MOVE wa_marc-zzlicence4 TO wa_lity-lityp.
              IF wa_lity-lityp IS NOT INITIAL.
                APPEND wa_lity TO it_lity.
              ENDIF.

              MOVE wa_marc-zzlicencenr4 TO wa_lic-lic_no.
              IF wa_lic-lic_no IS NOT INITIAL.
                APPEND wa_lic TO it_lic.
              ENDIF.

              CLEAR: wa_lity, wa_lic.
              MOVE wa_marc-zzlicence5 TO wa_lity-lityp.
              IF wa_lity-lityp IS NOT INITIAL.
                APPEND wa_lity TO it_lity.
              ENDIF.

              MOVE wa_marc-zzlicencenr5 TO wa_lic-lic_no.
              IF wa_lic-lic_no IS NOT INITIAL.
                APPEND wa_lic TO it_lic.
              ENDIF.

            ENDIF.

            IF vbak-auart = 'ZBFG' OR vbak-auart = 'ZBFZ'.
            ELSE.
              IF lv_msd = 'X'.
                READ TABLE it_lity TRANSPORTING NO FIELDS WITH KEY lityp = '012'.
                IF sy-subrc = 0.
                  CLEAR wa_retn.
                  wa_retn-type = 'E'.
                  wa_retn-id = 'ZSD_MESSAGES'.
                  wa_retn-number = '005'.
                  wa_retn-message_v1 = 'Sample License Type maintained for the Material and Plant'.
                  wa_retn-message_v2 = 'Item Number'.
                  wa_retn-message_v3 = <fs_vbap>-posnr.
                  APPEND wa_retn TO it_retn.
                ENDIF.
              ENDIF.
            ENDIF.
            SORT it_lity BY lityp.
            DELETE ADJACENT DUPLICATES FROM it_lity COMPARING lityp.
            IF it_lity[] IS NOT INITIAL.
              IF ( vbak-auart = 'ZBEX' OR vbak-auart =  'ZBE1' OR vbak-auart = 'ZBEZ' OR vbak-auart = 'ZBFZ' ).
                LOOP AT it_lity INTO wa_lity.
                  IF wa_lity-lityp = '018' OR wa_lity-lityp = '019' OR wa_lity-lityp = '011'.
                    SELECT *
                FROM ztca_licpr
                APPENDING TABLE it_lipr
               WHERE licclass = 'EXP'
                 AND mtart = 'FERT'
                 AND zzcode = wa_lity-lityp.
                    IF sy-subrc = 0.
                    ENDIF.
                  ELSE.
                    SELECT *
              FROM ztca_licpr
              APPENDING TABLE it_lipr
             WHERE licclass = 'MFG'
               AND mtart = 'FERT'
               AND zzcode = wa_lity-lityp.
                    IF sy-subrc = 0.
                    ENDIF.
                  ENDIF.
                ENDLOOP.
              ELSE.
                SELECT *
                  FROM ztca_licpr
                  INTO TABLE it_lipr
                   FOR ALL ENTRIES IN it_lity
                 WHERE licclass = lv_licls
                   AND mtart = 'FERT'
                   AND zzcode = it_lity-lityp.
                IF sy-subrc = 0.
                ENDIF.
              ENDIF.
            ELSE.
              SELECT *
              FROM ztca_licpr
              INTO TABLE it_lipr
             WHERE licclass = lv_licls
               AND mtart = 'FERT'.
              IF sy-subrc = 0.
                SORT it_lipr BY pref_no.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.

        IF lv_msd = 'X'.
          IF wa_mara-mtart = 'FERT'.
            IF it_lipr[] IS INITIAL.
              CLEAR wa_retn.
              wa_retn-type = 'E'.
              wa_retn-id = 'ZSD_MESSAGES'.
              wa_retn-number = '005'.
              wa_retn-message_v1 = 'No License Type maintained for the Material and Plant'.
              wa_retn-message_v2 = 'Item Number'.
              wa_retn-message_v3 = <fs_vbap>-posnr.
              APPEND wa_retn TO it_retn.
            ELSE.
              REFRESH it_limt.
              SELECT *
                FROM ztca_licmast
                INTO TABLE it_limt
                 FOR ALL ENTRIES IN it_lipr
               WHERE licclas  EQ it_lipr-licclass
                 AND lictype  EQ it_lipr-lictype
                 AND material EQ <fs_vbap>-matnr
                 AND f_date   LE sy-datum
                 AND t_date   GE sy-datum
                 AND status   EQ 'A'.
              IF sy-subrc   EQ 0.
                CLEAR: lv_lic, lv_flag.
                LOOP AT it_lipr INTO wa_lipr.
                  LOOP AT it_limt INTO wa_limt WHERE licclas = wa_lipr-licclass
                                                 AND lictype = wa_lipr-lictype.
                    IF lv_flag IS INITIAL.
                      CLEAR lv_lic.
                      IF it_lic[] IS NOT INITIAL.
                        READ TABLE it_lic INTO wa_lic WITH KEY lic_no = wa_limt-lic_no.
                        IF sy-subrc = 0.

                        ELSE.
                          lv_lic = 'X'.
                        ENDIF.
                      ENDIF.
                      IF lv_lic IS INITIAL.
                        CLEAR: lv_plan, lv_coun, lv_cust, lv_matn, lv_quan.
                        IF wa_limt-lictype = 'NOCI'.              "Customer Validation
                          IF wa_vbpa-kunnr <> wa_limt-t_customer.
                            lv_cust = 'X'.
                          ENDIF.
                        ENDIF.
                        IF wa_limt-lictype = 'F29'  OR wa_limt-lictype = 'F46'  OR
                           wa_limt-lictype = 'F46A' OR wa_limt-lictype = 'NOC'.     "Plant Validation
                          IF wa_limt-werks <> <fs_vbap>-werks.
                            lv_plan = 'X'.
                          ENDIF.
                        ENDIF.
                        IF wa_limt-lictype = 'F25'  OR wa_limt-lictype = 'F25A' OR
                           wa_limt-lictype = 'F28A' OR wa_limt-lictype = 'F28'  OR
                           wa_limt-lictype = 'F28D' OR wa_limt-lictype = 'FO28' OR
                           wa_limt-lictype = 'F32'  OR wa_limt-lictype = 'F32A' OR
                           wa_limt-lictype = 'NOC'.               "Country Validation
                          IF wa_limt-cntry_exp IS NOT INITIAL.
                            IF wa_limt-cntry_exp <> wa_kna1-land1.
                              lv_coun = 'X'.
                            ENDIF.
                          ENDIF.
                        ENDIF.

                        IF wa_limt-lictype = 'F25'  OR wa_limt-lictype = 'F25A' OR
                           wa_limt-lictype = 'F28A' OR wa_limt-lictype = 'F28'  OR
                           wa_limt-lictype = 'F28D' OR wa_limt-lictype = 'FO28' OR
                           wa_limt-lictype = 'F32'  OR wa_limt-lictype = 'F32A' OR
                           wa_limt-lictype = 'NOC'.               "Quantity Validation
                          IF wa_limt-qty_rel = 'YES'.
                            lv_qaty = lv_qaty + wa_limt-util_qty.
                            IF lv_qaty LT <fs_vbap>-kwmeng.
                              lv_quan = 'X'.
                            ELSE.
                              CLEAR lv_quan.
                            ENDIF.
                          ENDIF.
                        ENDIF.

                        IF lv_plan IS INITIAL AND lv_coun IS INITIAL AND lv_cust IS INITIAL AND lv_quan IS INITIAL.
                          lv_flag = 'X'.
                          <fs_vbap>-aplno = wa_limt-aplno.
                          <fs_vbap>-licence = wa_limt-lic_no.
                          IF wa_limt-qty_rel = 'YES'.
                            <fs_vbap>-quantity = <fs_vbap>-kwmeng.
                          ENDIF.
                          EXIT.
                        ENDIF.
                      ENDIF.
                    ENDIF.
                  ENDLOOP.
                ENDLOOP.
              ELSE.
                CLEAR wa_retn.
                wa_retn-type = 'E'.
                wa_retn-id = 'ZSD_MESSAGES'.
                wa_retn-number = '005'.
                wa_retn-message_v1 = 'No License Type maintained for the Material and Plant'.
                wa_retn-message_v2 = 'Item Number'.
                wa_retn-message_v3 = <fs_vbap>-posnr.
                APPEND wa_retn TO it_retn.
              ENDIF.
            ENDIF.

            IF <fs_vbap>-licence IS INITIAL." and <fs_vbap>-quantity IS INITIAL.
              CLEAR wa_retn.
              wa_retn-type = 'E'.
              wa_retn-id = 'ZSD_MESSAGES'.
              wa_retn-number = '005'.
              wa_retn-message_v1 = 'No Valid License for'.
              wa_retn-message_v2 = 'Item Number'.
              wa_retn-message_v3 = <fs_vbap>-posnr.
              APPEND wa_retn TO it_retn.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDIF.

*&--------------------Modification Log---------------------------------*
*Date       : 06.06.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K945737                                               *
*Description: Remove Sales Org. 1102 and Add ZCMAIN for BFI            *
*&---------------------------------------------------------------------*
**********Begin of changes by Ravi on 17.06.2019 DR1K945940*************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg1 IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg1-low ) ).
************End of changes by Ravi on 17.06.2019 DR1K945940*************
***********code added by praveen yadav on 09/10/2014
**** <<<< ----- Code ends here
*******Code start on 10.08.2014 for Pending For HO Aprvl
If sy-tcode = 'VA01' or Sy-tcode = 'VA02'.
If sy-ucomm = 'SICH'.
*If VBAK-VKORG = '1102' and VBAK-LIFSK = 'Z1'.
If VBAK-VKORG IN ra_vkorg and VBAK-LIFSK = 'Z1'.         "Added by Ravi on 17.06.2019 DR1K945940
   LOOP AT XVBAP.
      XVBAP-fixmg = abap_true.
      MODIFY XVBAP.
    ENDLOOP.
    else.
   LOOP AT XVBAP.
      XVBAP-fixmg = abap_false.
      MODIFY XVBAP.
    ENDLOOP.
endif.
endif.
endif.

*****************************************
IF it_retn IS NOT INITIAL.
  CALL FUNCTION 'FINB_BAPIRET2_DISPLAY'
    EXPORTING
      it_message = it_retn.
  MESSAGE 'Please correct the Errors' TYPE'E'.
ENDIF.


""""SOC by Madhur on 020824
DATA: lt_ZTEXPNOC_LIC TYPE TABLE OF ZTEXPNOC_LIC,
      ls_ZTEXPNOC_LIC TYPE ZTEXPNOC_LIC.
DATA  ls_vkorg TYPE ztabap_tvarvc.
CLEAR: ls_vkorg.

SELECT SINGLE * FROM ztabap_tvarvc INTO ls_vkorg
                                    WHERE OBJ_NAME = 'ZEXPONOC'
                                      AND name = 'ZX_VKORG'
                                      AND low = vbak-vkorg.
IF sy-subrc = 0.

IF sy-tcode = 'VA01' or sy-tcode = 'VA02'.

SELECT SINGLE * FROM ZTEXPNOC_LIC INTO ls_ZTEXPNOC_LIC WHERE SALES_ORG = vbak-vkorg.
  IF sy-subrc = 0.
    SELECT * FROM ZTEXPNOC_LIC INTO TABLE lt_ZTEXPNOC_LIC FOR ALL ENTRIES IN xvbap WHERE PROD_CODE = xvbap-matnr.
      IF sy-subrc = 0.
        vbak-faksk = 'Z9'.
      ENDIF.
  ENDIF.

ENDIF.

ENDIF.
*ENDIF.
""""EOC by Madhur on 020824
**""""SOC by Madhur on 020824
**DATA: lt_comm_mvgr2 TYPE TABLE OF ztabap_tvarvc,
**      ls_mvgr2_vkorg TYPE ztabap_tvarvc,
**      ls_mvgr2_vtweg TYPE ztabap_tvarvc,
**      ls_mvgr2_spart TYPE ztabap_tvarvc.
**DATA: lv_flag_mvgr2 TYPE c.
**  CLEAR: ls_mvgr2_vkorg,ls_mvgr2_vtweg,ls_mvgr2_spart,lv_flag_mvgr2.
**
**    IF ( ( sy-ucomm = 'SICH' OR sy-ucomm = 'YES' ) AND ( sy-tcode = 'VA01' or sy-tcode = 'VA02' ) ) .
**      SELECT SINGLE * FROM ztabap_tvarvc INTO ls_mvgr2_vkorg WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
**                                                                    AND name = 'VKORG'
**                                                                    AND type = 'S'.
**        IF ls_mvgr2_vkorg-low = vbak-vkorg.
**          SELECT SINGLE * FROM ztabap_tvarvc INTO ls_mvgr2_vtweg WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
**                                                              AND name = 'VTWEG'
**                                                              AND type = 'S'.
**            IF ls_mvgr2_vtweg-low = vbak-vtweg.
**              SELECT SINGLE * FROM ztabap_tvarvc INTO ls_mvgr2_SPART WHERE  OBJ_NAME = 'ZSO_COMM_MVGR2'
**                                                              AND name = 'SPART'
**                                                              AND type = 'S'.
**               IF ls_mvgr2_spart-low = vbak-spart.
**                 LOOP AT xvbap INTO DATA(vbap_mvgr2).
**                   IF vbap_mvgr2-mvgr2 IS INITIAL.
**                     lv_flag_mvgr2 = 'X'.
**                   ENDIF.
**
**                 ENDLOOP.
**                ENDIF.
**            ENDIF.
**        ENDIF.
**        IF lv_flag_mvgr2 = 'X'.
**          MESSAGE '"PO Type" cannot be blank for Sales Org, Division, Dist Channel' TYPE 'E'.
**        ENDIF.
**    ENDIF.
**""""EOC by Madhur on 020824
ENDENHANCEMENT.
