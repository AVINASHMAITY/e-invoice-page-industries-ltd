"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SO_CREATE_MASS.
*&------------------------------------------------------------------------------
*Date       : 10.09.2024
*Programmer : Suganya
*TR No.     : DR1K988281
*Description: Enhancment for sales order mass upload idoc additonal fields update
*&------------------------------------------------------------------------------
DATA: lv_lifsk TYPE lifsk, "Delivery block
      lv_faksk TYPE faksk, "Billing block
      lv_vdatu TYPE edatu_vbak,  "Req Delivery date
      lv_bsark TYPE bsark, "Cutomer order type
      lv_idocx TYPE char1,
      lv_fkdat TYPE fkdat. "Billing date in VBKD

IMPORT lv_idocx FROM MEMORY ID 'LV_IDOCX'.

IF sy-tcode = 'VA01' AND lv_idocx = 'X'.
  "Delivery block
  IMPORT lv_lifsk FROM MEMORY ID 'LIFSK'.
  vbak-lifsk = lv_lifsk.

  "Billing block
  IMPORT lv_faksk FROM MEMORY ID 'FAKSK'.
  vbak-faksk = lv_faksk.

  "Req Delivery date
  IMPORT lv_vdatu FROM MEMORY ID 'VDATU'.
  vbak-vdatu = lv_vdatu.

  "Cutomer order type
  IMPORT lv_bsark FROM MEMORY ID 'BSARK'.
  vbak-bsark = lv_bsark.

  "Billing Date
  IMPORT lv_fkdat FROM MEMORY ID 'FKDAT'.
  vbkd-fkdat = lv_fkdat. "Billing date in VBKD
  vbkd-prsdt = lv_fkdat. "Pricing date in VBKD
ENDIF.
ENDENHANCEMENT.
