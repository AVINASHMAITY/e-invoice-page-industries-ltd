CLASS lcl_zewb_extraction DEFINITION DEFERRED.
CLASS j_1ig_cl_ebill DEFINITION LOCAL FRIENDS lcl_zewb_extraction.
CLASS lcl_zewb_extraction DEFINITION.
  PUBLIC SECTION.
    CLASS-DATA obj TYPE REF TO lcl_zewb_extraction.         "#EC NEEDED
    DATA core_object TYPE REF TO j_1ig_cl_ebill .           "#EC NEEDED
 INTERFACES  IOW_ZEWB_EXTRACTION.
    METHODS:
      constructor IMPORTING core_object
                              TYPE REF TO j_1ig_cl_ebill OPTIONAL.
ENDCLASS.
CLASS lcl_zewb_extraction IMPLEMENTATION.
  METHOD constructor.
    me->core_object = core_object.
  ENDMETHOD.

  METHOD iow_zewb_extraction~upload_data.
*"------------------------------------------------------------------------*
*" Declaration of Overwrite-method, do not insert any comments here please!
*"
*"methods UPLOAD_DATA
*"  importing
*"    value(IM_DATA) type ANY TABLE optional .
*"------------------------------------------------------------------------*

    DATA: lt_filedata    TYPE TABLE OF  j_1ig_cl_ebill=>ty_filedata,
          lt_intern      TYPE STANDARD TABLE OF alsmex_tabline,
          lr_steuc       TYPE RANGE OF steuc,
          lr_hsn_sac     TYPE RANGE OF j_1ig_hsn_sac,
          lr_vbeln       TYPE RANGE OF vbeln_vf,
          lr_ebillno     TYPE RANGE OF j_1ig_ebillno,
          lr_ebillno_dup TYPE RANGE OF j_1ig_ebillno,
          lr_bukrs       TYPE RANGE OF bukrs,
          lr_ind_cc      TYPE RANGE OF bukrs,
          lwa_filedata   TYPE j_1ig_cl_ebill=>ty_filedata,
          l_index        TYPE i.

    FIELD-SYMBOLS: <lfs_data> TYPE any.

    IF sy-cprog <> 'ZSDR_EWB' AND sy-cprog <> 'ZEINV_EWB'
      AND sy-cprog <> 'ZSD_ZEI_GLOBAL_TO_J_1IG_INVREF'. "Added by Lakshmi/iteanz "01.12.2020
*---Get the data from Excel
      CALL FUNCTION 'ALSM_EXCEL_TO_INTERNAL_TABLE'
        EXPORTING
          filename                = j_1ig_cl_ebill=>gv_file
          i_begin_col             = j_1ig_cl_ebill=>c_begin_col
          i_begin_row             = j_1ig_cl_ebill=>c_begin_row
          i_end_col               = j_1ig_cl_ebill=>c_end_col
          i_end_row               = j_1ig_cl_ebill=>c_end_row
        TABLES
          intern                  = lt_intern
        EXCEPTIONS
          inconsistent_parameters = 1
          upload_ole              = 2
          OTHERS                  = 3.
      IF sy-subrc NE 0.
        MESSAGE i000 WITH text-e33.
        LEAVE LIST-PROCESSING.
      ENDIF.

      SORT lt_intern BY row col.

*---Delete the field names
      DELETE lt_intern WHERE row EQ 1.

      IF lt_intern IS INITIAL.
        MESSAGE i000 WITH text-e10.
        LEAVE LIST-PROCESSING.
      ELSE.

*---Prepare Internal table from file
        LOOP AT lt_intern ASSIGNING FIELD-SYMBOL(<lfs_intern>).
          l_index = <lfs_intern>-col.
          ASSIGN COMPONENT l_index OF STRUCTURE lwa_filedata TO <lfs_data>.
          IF sy-subrc EQ 0.
            MOVE <lfs_intern>-value TO <lfs_data>.
          ENDIF.
          AT END OF row.
            lwa_filedata-bukrs   = |{ lwa_filedata-bukrs   ALPHA = IN }|.
            lwa_filedata-docno   = |{ lwa_filedata-docno   ALPHA = IN }|.
            lwa_filedata-gjahr   = |{ lwa_filedata-gjahr   ALPHA = IN }|.
            lwa_filedata-ebillno = |{ lwa_filedata-ebillno ALPHA = IN }|.

            APPEND lwa_filedata TO lt_filedata.
            IF lr_ebillno[] IS INITIAL.
              IF lwa_filedata-ebillno IS NOT INITIAL.
                lr_ebillno = VALUE #( ( sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                                        low  = lwa_filedata-ebillno ) ).
              ENDIF.
            ELSE.
              IF lwa_filedata-ebillno IN lr_ebillno[].
                APPEND VALUE #( sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                                low = lwa_filedata-ebillno )
                      TO lr_ebillno_dup.
              ELSE.
                APPEND VALUE #( sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                                low = lwa_filedata-ebillno )
                     TO lr_ebillno.
              ENDIF.
            ENDIF.

            CLEAR lwa_filedata.
          ENDAT.
        ENDLOOP.
      ENDIF.

    ELSE.
      LOOP AT im_data INTO lwa_filedata.
        lwa_filedata-bukrs   = |{ lwa_filedata-bukrs   ALPHA = IN }|.
        lwa_filedata-docno   = |{ lwa_filedata-docno   ALPHA = IN }|.
        lwa_filedata-gjahr   = |{ lwa_filedata-gjahr   ALPHA = IN }|.
        lwa_filedata-ebillno = |{ lwa_filedata-ebillno ALPHA = IN }|.

        APPEND lwa_filedata TO lt_filedata.
        IF lr_ebillno[] IS INITIAL.
          IF lwa_filedata-ebillno IS NOT INITIAL.
            lr_ebillno = VALUE #( ( sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                                    low  = lwa_filedata-ebillno ) ).
          ENDIF.
        ELSE.
          IF lwa_filedata-ebillno IN lr_ebillno[].
            APPEND VALUE #( sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                            low = lwa_filedata-ebillno )
                  TO lr_ebillno_dup.
          ELSE.
            APPEND VALUE #( sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                            low = lwa_filedata-ebillno )
                 TO lr_ebillno.
          ENDIF.
        ENDIF.

        CLEAR lwa_filedata.
      ENDLOOP.
    ENDIF.

    DATA(lt_filedata_tmp) = lt_filedata.
    DELETE lt_filedata_tmp WHERE bukrs     IS INITIAL OR
                                 doctyp    IS INITIAL OR
                                 docno     IS INITIAL OR
                                 ebillno   IS INITIAL OR
                                 egen_dat  IS INITIAL OR
                                 egen_time IS INITIAL OR
                                 vdfmdate  IS INITIAL OR
                                 vdfmtime  IS INITIAL
                                 .
    IF lt_filedata_tmp[] IS INITIAL.
      MESSAGE i000 WITH text-e36.
      LEAVE LIST-PROCESSING.
    ENDIF.

    IF lt_filedata_tmp IS NOT INITIAL.

*---Get the duplicate Document Number details,partial Primary Key is passed
*---User can enter Document number which exists in table
*---with different Primary Key combination
      SELECT bukrs,
             doctyp,
             docno,
             gjahr,
             ebillno
             FROM j_1ig_ewaybill
             INTO TABLE @DATA(lt_ewaybill_active)
             FOR ALL ENTRIES IN @lt_filedata_tmp
             WHERE bukrs     EQ @lt_filedata_tmp-bukrs
               AND doctyp    EQ @lt_filedata_tmp-doctyp
               AND docno     EQ @lt_filedata_tmp-docno
               AND status    EQ @j_1ig_cl_ebill=>c_status_a.
      IF sy-subrc EQ 0.
        SORT lt_ewaybill_active BY bukrs docno gjahr.
      ENDIF.

*---Fetch Billing document details, full Primary Key is passed
      SELECT vbeln,fkart,fkdat,bukrs,sfakn,fksto
        FROM vbrk
        INTO TABLE @DATA(lt_vbrk)
        FOR ALL ENTRIES IN @lt_filedata_tmp
        WHERE vbeln     EQ @lt_filedata_tmp-docno
          AND fkart     EQ @lt_filedata_tmp-doctyp
          AND bukrs     EQ @lt_filedata_tmp-bukrs.
      IF sy-subrc EQ 0.
        SORT lt_vbrk BY vbeln.

*---Consider only goods movement
        lr_steuc = VALUE #( sign = 'I' option = j_1ig_cl_ebill=>c_sign_eq
                            ( low = '00' ) ).
*                            ( low = '90' ) )." Added by Arya DR1K944551

        lr_vbeln = VALUE #( FOR lwa_vbrk IN lt_vbrk
                            sign = j_1ig_cl_ebill=>c_sign_i option = j_1ig_cl_ebill=>c_sign_eq
                            ( low = lwa_vbrk-vbeln ) ).

*---Fetch Material details for validation
        SELECT v1~vbeln,v1~matnr,m1~steuc
          INTO TABLE @DATA(lt_vbrk_mat)
          FROM vbrp AS v1
          INNER JOIN marc AS m1
          ON v1~matnr EQ m1~matnr AND
             v1~werks EQ m1~werks
          WHERE vbeln IN @lr_vbeln.
        IF sy-subrc EQ 0.
          SORT lt_vbrk_mat BY vbeln.
          DELETE: lt_vbrk_mat WHERE steuc IS INITIAL,
                  lt_vbrk_mat WHERE steuc+0(2) IN lr_steuc,
                  lt_vbrk_mat WHERE steuc+0(1) EQ 'S'.
        ENDIF.

      ENDIF.

*---Fetch Account Document details, full Primary Key is passed
      SELECT bukrs,belnr,gjahr,blart,bldat
        FROM bkpf
        INTO TABLE @DATA(lt_bkpf)
        FOR ALL ENTRIES IN @lt_filedata_tmp
        WHERE bukrs EQ @lt_filedata_tmp-bukrs
          AND belnr EQ @lt_filedata_tmp-docno
          AND gjahr EQ @lt_filedata_tmp-gjahr
          AND blart EQ @lt_filedata_tmp-doctyp+0(2)
          AND stblg EQ @space
          AND glvor EQ @j_1ig_cl_ebill=>c_rfbu.
      IF sy-subrc EQ 0.
        SORT lt_bkpf BY bukrs belnr gjahr.

        IF lt_bkpf IS NOT INITIAL.

*---Fetch HSN code details for validation, partial Primary Key is passed
          SELECT bukrs,belnr,gjahr,buzei,koart,hsn_sac
            FROM bseg
            INTO TABLE @DATA(lt_bseg)
            FOR ALL ENTRIES IN @lt_bkpf
            WHERE bukrs     EQ @lt_bkpf-bukrs
              AND belnr     EQ @lt_bkpf-belnr
              AND gjahr     EQ @lt_bkpf-gjahr.
          IF sy-subrc EQ 0.
            SORT lt_bseg BY bukrs belnr gjahr.
            DATA(lt_bseg1) = lt_bseg.
            DELETE lt_bseg WHERE koart NE j_1ig_cl_ebill=>c_d.
            lr_hsn_sac = VALUE #( sign = 'I' option = j_1ig_cl_ebill=>c_sign_eq
                                ( low = '00' ) ).
*                                ( low = '90' ) )." Added by Arya DR1K944551

            DELETE: lt_bseg1 WHERE hsn_sac IS INITIAL,
                    lt_bseg1 WHERE hsn_sac+0(2) IN lr_hsn_sac,
                    lt_bseg1 WHERE hsn_sac+0(1) EQ 'S'.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    IF lt_vbrk IS INITIAL AND lt_bkpf IS INITIAL.
      MESSAGE i000 WITH text-e53.
      LEAVE LIST-PROCESSING.
    ELSEIF lt_vbrk_mat IS INITIAL AND
           ( lt_bseg IS INITIAL OR lt_bseg1 IS INITIAL ).
      MESSAGE i000 WITH text-e55 text-e57.
      LEAVE LIST-PROCESSING.
    ENDIF.

    IF lr_ebillno_dup[] IS NOT INITIAL.
      SORT lr_ebillno_dup BY low.
      DELETE ADJACENT DUPLICATES FROM lr_ebillno_dup
        COMPARING low.
    ENDIF.

    SORT lt_filedata_tmp BY bukrs.
    DELETE ADJACENT DUPLICATES FROM lt_filedata_tmp COMPARING bukrs.
    CLEAR lr_ind_cc.

    LOOP AT lt_filedata_tmp ASSIGNING FIELD-SYMBOL(<lfs_filedata>).

*---Check Document belongs to India Company Code or not
*---Didn't put Not Initial check as no entry exists without company code
      CALL FUNCTION 'J_1BSA_COMPONENT_ACTIVE'
        EXPORTING
          bukrs                = <lfs_filedata>-bukrs
          component            = j_1ig_cl_ebill=>c_in
        EXCEPTIONS
          component_not_active = 1
          OTHERS               = 2.
      IF sy-subrc EQ 0.
        APPEND VALUE #( sign = 'I' option = j_1ig_cl_ebill=>c_sign_eq
                        low  = <lfs_filedata>-bukrs )
                     TO lr_ind_cc.
      ENDIF.

    ENDLOOP.
    IF lr_ind_cc[] IS INITIAL.
      MESSAGE i000 WITH text-e56.
      LEAVE LIST-PROCESSING.
    ENDIF.
    SORT lr_ind_cc BY low.
    DELETE ADJACENT DUPLICATES FROM lr_ind_cc COMPARING low.

    lt_filedata_tmp = lt_filedata.
    SORT lt_filedata_tmp BY ebillno.
    DELETE ADJACENT DUPLICATES FROM lt_filedata_tmp COMPARING ebillno.

    IF lt_filedata_tmp IS NOT INITIAL.
*---Fetch Duplicate EWay Bill Number details, Partial Primary Key is passed
      SELECT bukrs,
             doctyp,
             docno,
             gjahr,
             ebillno
             FROM j_1ig_ewaybill
             INTO TABLE @DATA(lt_ewaybill_tbl_dup)
             FOR ALL ENTRIES IN @lt_filedata_tmp
             WHERE  bukrs    IN @lr_bukrs
                AND ebillno  EQ @lt_filedata_tmp-ebillno.
      IF sy-subrc EQ 0.
        DATA(lt_ewaybill) = lt_ewaybill_tbl_dup.
        SORT: lt_ewaybill         BY bukrs doctyp docno gjahr ebillno,
              lt_ewaybill_tbl_dup BY ebillno.
      ENDIF.

    ENDIF.

    core_object->prep_valid_file_data( EXPORTING
                            im_t_filedata       = lt_filedata
                            im_t_ewaybill       = lt_ewaybill
                            im_t_ebill_active   = lt_ewaybill_active
                            im_t_ebill_tbl_dup  = lt_ewaybill_tbl_dup
                            im_t_ebill_file_dup = lr_ebillno_dup
                            im_t_vbrk           = lt_vbrk
                            im_t_vbrk_mat       = lt_vbrk_mat
                            im_t_bkpf           = lt_bkpf
                            im_t_bseg           = lt_bseg
                            im_t_bseg1          = lt_bseg1
                            im_t_ind_cc         = lr_ind_cc
                          IMPORTING
                            ex_t_valid_data     = DATA(lt_file_tbl_valid)
                            ex_t_val_file_data  = DATA(lt_file_valid) ).

    IF lt_file_tbl_valid IS NOT INITIAL.
      core_object->db_update( im_t_ewaybill      = lt_file_tbl_valid
                 im_t_val_file_data = lt_file_valid ).
    ENDIF.
  ENDMETHOD.
ENDCLASS.
