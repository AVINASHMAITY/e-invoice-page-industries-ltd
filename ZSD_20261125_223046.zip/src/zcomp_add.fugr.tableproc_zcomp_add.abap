*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCOMP_ADD
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCOMP_ADD           .

  PERFORM TABLEPROC.

ENDFUNCTION.
