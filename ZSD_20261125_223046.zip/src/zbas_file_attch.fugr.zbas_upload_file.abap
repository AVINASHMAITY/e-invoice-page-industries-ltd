FUNCTION ZBAS_UPLOAD_FILE.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(MOD_DESC) TYPE  ZMOD_IMP
*"     REFERENCE(DOCCATEGORY) TYPE  ZIMP_DOCTYP
*"     REFERENCE(DOCNO) TYPE  ZBAS_ATTACHMENT-DOCNO
*"----------------------------------------------------------------------

******Modification Log***********************
*Date       : 17.02.2017
*Programmer : Ravindran/Iteanz
*TR No.     : DR1K931330
*Description: BFN fila attachment
**********************************************

  EXPORT mod_desc TO MEMORY ID 'MD'.
  EXPORT doccategory TO  MEMORY ID 'CG'.
  EXPORT docno TO MEMORY ID 'DN'.


  PERFORM upload_file USING mod_desc
                            doccategory
                            docno.


ENDFUNCTION.

*&---------------------------------------------------------------------*
*&      Form  fetch_file
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
*FORM fetch_file .
*
*  SELECT *
*    FROM /obiz/zfl_attach
*    INTO TABLE it_pic_download .
*
*ENDFORM.                    " fetch_file
*&---------------------------------------------------------------------*
*&      Form  sel_fieldcat
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM sel_fieldcat .
  CLEAR :it_fieldcat,
         wa_fieldcat.

  REFRESH it_fieldcat.
  pos = pos + 1.
  wa_fieldcat-col_pos = pos.
*
*  wa_fieldcat-fieldname = 'PICON'.
*  wa_field-outputlen = 6.
*  wa_fieldcat-tabname = 'IT_PIC_DOWNLOAD'.
*  wa_fieldcat-fieldname = 'PICON'.
*  wa_fieldcat-coltext   = 'File Type'.
*  wa_fieldcat-key = 'X'.
*  wa_fieldcat-icon = 'X'.
*  APPEND wa_fieldcat TO it_fieldcat.

  CLEAR wa_fieldcat.
  pos = pos + 1.
  wa_fieldcat-col_pos = pos.
  wa_fieldcat-fieldname = 'FNAME'.
*  wa_field-outputlen = 6.
  wa_fieldcat-tabname = 'IT_PIC_DOWNLOAD'.
  wa_fieldcat-coltext   = 'Title'(001).
  wa_fieldcat-key = 'X'.
  APPEND wa_fieldcat TO it_fieldcat.

  CLEAR wa_fieldcat.
  pos = pos + 1.
  wa_fieldcat-col_pos = pos.
  wa_fieldcat-fieldname = 'FCNAME'.
*  wa_field-outputlen = 6.
  wa_fieldcat-tabname = 'IT_PIC_DOWNLOAD'.
  wa_fieldcat-coltext   = 'Creator Name'(002).
  wa_fieldcat-key = 'X'.
  APPEND wa_fieldcat TO it_fieldcat.


  CLEAR wa_fieldcat.
  pos = pos + 1.
  wa_fieldcat-col_pos = pos.
  wa_fieldcat-fieldname = 'FDATE'.
*  wa_field-outputlen = 6.
  wa_fieldcat-tabname = 'IT_PIC_DOWNLOAD'.
  wa_fieldcat-coltext   = 'Created On'(003).
  APPEND wa_fieldcat TO it_fieldcat.

*  wa_fieldcat-fieldname = 'FICON'.
*  wa_field-outputlen = 6.
  wa_fieldcat-tabname = 'IT_PIC_DOWNLOAD'.
  wa_fieldcat-fieldname = 'FICON'.
  wa_fieldcat-coltext   = 'File Type'(004).
*  wa_fieldcat-key = 'X'.
  wa_fieldcat-icon = 'X'.
  APPEND wa_fieldcat TO it_fieldcat.

ENDFORM.                    "sel_fieldcat
