FUNCTION-POOL ZCOMP_NAME                 MESSAGE-ID SV.

* INCLUDE LZCOMP_NAMED...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCOMP_NAMET00                          . "view rel. data dcl.
