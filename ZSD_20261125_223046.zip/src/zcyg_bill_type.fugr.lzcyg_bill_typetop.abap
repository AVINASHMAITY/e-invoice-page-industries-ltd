FUNCTION-POOL ZCYG_BILL_TYPE             MESSAGE-ID SV.

* INCLUDE LZCYG_BILL_TYPED...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_BILL_TYPET00                      . "view rel. data dcl.
