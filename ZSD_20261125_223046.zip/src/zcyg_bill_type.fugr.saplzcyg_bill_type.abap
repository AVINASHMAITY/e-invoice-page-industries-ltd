*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_BILL_TYPETOP.                " Global Data
  INCLUDE LZCYG_BILL_TYPEUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_BILL_TYPEF...                " Subroutines
* INCLUDE LZCYG_BILL_TYPEO...                " PBO-Modules
* INCLUDE LZCYG_BILL_TYPEI...                " PAI-Modules
* INCLUDE LZCYG_BILL_TYPEE...                " Events
* INCLUDE LZCYG_BILL_TYPEP...                " Local class implement.
* INCLUDE LZCYG_BILL_TYPET99.                " ABAP Unit tests
  INCLUDE LZCYG_BILL_TYPEF00                      . " subprograms
  INCLUDE LZCYG_BILL_TYPEI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
