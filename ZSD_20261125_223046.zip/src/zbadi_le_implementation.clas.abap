class ZBADI_LE_IMPLEMENTATION definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_BADI_PRICING_DIFF_DET_SCR .
protected section.
private section.
ENDCLASS.



CLASS ZBADI_LE_IMPLEMENTATION IMPLEMENTATION.


  method IF_BADI_PRICING_DIFF_DET_SCR~SET_COND_DETAIL_SCR_DATA.

    break tansar.
  endmethod.
ENDCLASS.
