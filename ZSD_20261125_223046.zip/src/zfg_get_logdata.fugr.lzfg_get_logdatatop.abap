FUNCTION-POOL ZFG_GET_LOGDATA.              "MESSAGE-ID ..

* INCLUDE LZFG_GET_LOGDATAD...               " Local class definition

*"----------------------------------------------------------------------
*"         Declartaion
*"----------------------------------------------------------------------
DATA gt_dbtablog TYPE TABLE OF dbtablog WITH HEADER LINE.

TYPE-POOLS: sydes.


FIELD-SYMBOLS:
<in_content> TYPE ANY,
<field>      TYPE ANY.
DATA:
w_names       TYPE sydes_nameinfo,
w_long_name(75),
w_word_found.

TYPES : BEGIN OF TP_GETDATA,
w_long_name(75) TYPE c,
field(90) TYPE c ,
        END OF TP_GETDATA.


DATA : gt_getdata TYPE TABLE OF TP_GETDATA,
      gs_getdata TYPE TP_GETDATA.

DATA:
fs_td       TYPE sydes_desc.
