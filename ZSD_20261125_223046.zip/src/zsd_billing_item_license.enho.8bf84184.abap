"Name: \PR:SAPMV60A\FO:CUST_ITEM_ACTIVATE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_BILLING_ITEM_LICENSE.
*&--------------------Modification Log---------------------------------*
*Date       : 18.01.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K939109                                               *
*Description: License Tab will display which have maintained in        *
*             ZSD_BILL_LICENSE table                                   *
*&---------------------------------------------------------------------*

  DATA: lv_vbeln type vbrk-vbeln,
        lv_vgbel TYPE vgbel,
        lv_auart TYPE VBAK-AUART,
        ls_license TYPE ZSD_BILL_LICENSE.

 SELECT SINGLE vgbel FROM LIPS
        INTO lv_vgbel
        WHERE vbeln EQ vbrp-vgbel.

 IF lv_vgbel IS NOT INITIAL.

   SELECT SINGLE AUART FROM vbak
          INTO lv_auart
          WHERE vbeln EQ lv_vgbel.

   SELECT SINGLE * FROM ZSD_BILL_LICENSE INTO LS_LICENSE
          WHERE AUART EQ lv_auart.

   IF sy-subrc EQ 0.

      LOOP AT SCREEN.
        IF SCREEN-NAME EQ 'TABSTRIP_TAB07'.
          GS_CUST_TAB-ITEM_CAPTION = 'License'.
          GS_CUST_TAB-ITEM_PROGRAM = 'SAPLZSDF_LICENSE_VALIDATION'.
          GS_CUST_TAB-ITEM_DYNPRO = '9000'.
          IF NOT GS_CUST_TAB-ITEM_DYNPRO IS INITIAL.
           SCREEN-ACTIVE = 1.
           SCREEN-INVISIBLE = 0.
           TABSTRIP_TAB07 = GS_CUST_TAB-ITEM_CAPTION.
           MODIFY SCREEN.
           "Export below Memories to SAPLZSDF_LICENSE_VALIDATION Program
           EXPORT lv_auart = lv_auart TO MEMORY ID 'LIC_AUART'.
           lv_vbeln = lv_vgbel.
           EXPORT lv_vbeln = lv_vbeln TO MEMORY ID 'LIC_VBELN'.
           EXPORT vbrp = vbrp TO MEMORY ID 'LIC_VBRP'.
          ENDIF.
        ENDIF.
      ENDLOOP.
     ENDIF.
    ENDIF.

ENDENHANCEMENT.
