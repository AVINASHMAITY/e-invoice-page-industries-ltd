FUNCTION-POOL ZDLVKORG                   MESSAGE-ID SV.

* INCLUDE LZDLVKORGD...                      " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDLVKORGT00                            . "view rel. data dcl.
