*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCOLL_PRINTOUT..................................*
DATA:  BEGIN OF STATUS_ZCOLL_PRINTOUT                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCOLL_PRINTOUT                .
CONTROLS: TCTRL_ZCOLL_PRINTOUT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCOLL_PRINTOUT                .
TABLES: ZCOLL_PRINTOUT                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
