"Name: \PR:SAPMV50A\FO:USEREXIT_SAVE_DOCUMENT\SE:BEGIN\EN:/PWEAVER/SAVE_DELIVERY\SE:END\EI
ENHANCEMENT 0 ZSD_VLO2N_STRLOC.
************************************************************************
* Object Name             : ZSD_VLO2N_STRLOC
* Author/Company Name     : Magam Sai Sudarshan - SAISMA
* Functional Consultant   : Magam Sai Sudarshan
* Transport Request       : DR1K956378
* Creation Date           : 21 JUN 2021
************************************************************************
* Description: Storage Location Validation for the movement type       *
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date Programmer Client Ref No. Description Correction                *
************************************************************************
IF sy-tcode = 'VL01N' OR sy-tcode = 'VL02N'.

  DATA : ls_ktokd TYPE kna1-ktokd,
         ls_lgort TYPE ztsd_rest_mty-lgort.

  IF xlikp-vkorg = '5100'.
    LOOP AT xlips[] ASSIGNING FIELD-SYMBOL(<ls_lips>).
      CLEAR : ls_ktokd,ls_lgort.
      SELECT SINGLE ktokd FROM kna1 INTO ls_ktokd
                               WHERE kunnr EQ xlikp-kunag.

      IF NOT ls_ktokd IS INITIAL AND ls_ktokd EQ 'Z007'.

        SELECT SINGLE * FROM ztsd_rest_mty INTO @DATA(lw_werks)
                        WHERE werks EQ @<ls_lips>-werks.

        IF sy-subrc EQ 0.
          SELECT SINGLE lgort FROM  ztsd_rest_mty INTO ls_lgort
                              WHERE werks EQ <ls_lips>-werks
                              AND   bwart EQ <ls_lips>-bwart
                              AND   lgort EQ <ls_lips>-lgort
                              AND   mtart EQ <ls_lips>-mtart.

          IF ls_lgort IS INITIAL AND NOT <ls_lips>-lgort IS INITIAL.
            SELECT SINGLE * FROM zsd_ex_mat INTO @DATA(ls_ex)
                            WHERE matnr EQ @<ls_lips>-matnr.

            IF ls_ex IS INITIAL.
              MESSAGE e085(zsd_messages).
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
      CLEAR : ls_ex.
    ENDLOOP.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
