"Name: \PR:SAPLMB_BUS2017\EX:BAPI_GOODSMVT_CREATE_G6\EI
ENHANCEMENT 0 ZSD_GREECE_UOM_ISO.
** Change Greece 3PL UOM from ISO Code
DATA : l_ebeln TYPE ebeln.
CONSTANTS : lc_plant TYPE werks_d VALUE '3553'.

IF goodsmvt_item[] IS NOT INITIAL.
   LOOP AT goodsmvt_item ASSIGNING FIELD-SYMBOL(<fs_item>).
     IF <fs_item> IS ASSIGNED.
       IF <fs_item>-plant = lc_plant.
        l_ebeln = <fs_item>-po_number.
        l_ebeln = |{ l_ebeln ALPHA = IN }|.
        SELECT SINGLE matnr FROM ekpo INTO @DATA(l_matnr) WHERE ebeln = @l_ebeln.
        IF sy-subrc = 0.
          SELECT SINGLE meins FROM mara INTO @DATA(l_meins) WHERE matnr = @l_matnr.
          IF sy-subrc = 0.
            SELECT SINGLE isocode FROM t006 INTO @DATA(l_isocode) WHERE msehi = @l_meins.
            IF sy-subrc = 0.
               <fs_item>-entry_uom_iso = l_isocode.
            ENDIF.
          ENDIF.
        ENDIF.
       ENDIF.
     ENDIF.
   ENDLOOP.
ENDIF.
ENDENHANCEMENT.
