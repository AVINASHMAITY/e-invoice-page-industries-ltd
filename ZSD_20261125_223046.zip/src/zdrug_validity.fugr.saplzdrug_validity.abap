*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDRUG_VALIDITYTOP.                " Global Data
  INCLUDE LZDRUG_VALIDITYUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDRUG_VALIDITYF...                " Subroutines
* INCLUDE LZDRUG_VALIDITYO...                " PBO-Modules
* INCLUDE LZDRUG_VALIDITYI...                " PAI-Modules
* INCLUDE LZDRUG_VALIDITYE...                " Events
* INCLUDE LZDRUG_VALIDITYP...                " Local class implement.
* INCLUDE LZDRUG_VALIDITYT99.                " ABAP Unit tests
  INCLUDE LZDRUG_VALIDITYF00                      . " subprograms
  INCLUDE LZDRUG_VALIDITYI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules

INCLUDE lzdrug_validityf01.

INCLUDE lzdrug_validityf02.
