class ZBIOICL_SI_INVENTORY_IN definition
  public
  create public .

public section.

  interfaces ZBIOIII_SI_INVENTORY_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOICL_SI_INVENTORY_IN IMPLEMENTATION.


  method zbioiii_si_inventory_in~si_inventory_in.
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Object Name : zbioiii_si_inventory_in~si_inventory_in                         *
* Author/Company Name : Arya/ITZ                               *
* Transport Request :  DR1K944102                                      *
* Creation Date : 18.02.2019                                           *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Modification History *
*&---------------------------------------------------------------------*
* Date Programmer Client Ref No. Description Correction *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*TYPES DECLARATION                                                     *
*&---------------------------------------------------------------------*

    types : begin of tp_zmmt,
              mblnr type zmmt_po_cons-mblnr,
              lrnum type zmmt_po_cons-lrnum,
              lrdat type zmmt_po_cons-lrdat,
              trans type zmmt_po_cons-trans,
              mjahr type mseg-mjahr,
              matnr type mseg-matnr,
              werks type mseg-werks,
              lifnr type mseg-lifnr,
              menge type mseg-menge,
            end of tp_zmmt.

    types : begin of tp_makt,
              matnr type matnr,
              maktx type maktx,
            end of tp_makt.

    types : begin of tp_mara,
              matnr type matnr,
              spart type spart,
            end of tp_mara.

    types : begin of tp_t001w,
              werks type werks_d,
              land1 type land1,
              regio type regio,
            end of tp_t001w.

    types : begin of tp_t005u,
              land1 type land1,
              bland type regio,
              bezei type bezei20,
            end of tp_t005u.
**
**    types : begin of tp_final,
**              spart          type spart,
**              spart_desc(30) type c,
**              lifnr          type elifn,
**              bezei          type bezei20,
**              trans          type ztran,
**              lrnum          type zmm_lr_num,
**              lrdat          type zmm_dt_lr,
**              promo(10)      type c,
**              matnr          type matnr,
**              maktx          type maktx,
**              menge          type menge_d,
**              werks          type werks_d,
**            end of tp_final.
**

    data : gt_zmmt_po_cons type table of tp_zmmt,
           gw_zmmt_po_cons type tp_zmmt.

    data : gt_makt type  table of tp_makt,
           gw_makt type tp_makt.

    data : gt_mara type table of tp_mara,
           gw_mara type tp_mara.

    data : gt_t001w type table of tp_t001w,
           gw_t001w type tp_t001w.

    data : gt_t005u type table of tp_t005u,
           gw_t005u type tp_t005u.

    data : gt_final type table of zbioidt_inventory_res_records,
           gw_final type zbioidt_inventory_res_records.


    data : gt_tspat   type table of tspat,
           gw_tspat   type tspat,
           gt_mara_d  type table of tp_mara,
           gw_mara_d  type tp_mara,
           gv_col_pos like sy-cucol.

    types : begin of tp_down,
              spart          type spart,
              spart_desc(30) type c,
              lifnr          type elifn,
              bezei          type bezei20,
              trans          type ztran,
              lrnum          type zmm_lr_num,
              lrdat(10)      type c,
              promo(10)      type c,
              matnr          type matnr,
              maktx          type maktx,
              menge(20)      type c,
              werks          type werks_d,
            end of tp_down.

    data : gt_down type table of tp_down,
           gw_down type tp_down.

    data :
      so_lrdat type range of zmm_dt_lr,
      lw_lrdat like line of so_lrdat.

    data:lv_report  type  rsvar-report value 'ZSD_PROMOTIONAL_ITEM_REP',
         lv_variant type  rsvar-variant value 'INSPIREINV',
         lt_valutab	type table of	rsparams,
         lw_valutab like line of lt_valutab,
         lv_selname type  rsscr_name value 'SO_LRDAT'.
*&---------------------------------------------------------------------*
*END OF DECLARATION                                            ,         *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*GET VARIANT VALUES                                                    *
*&---------------------------------------------------------------------*
    call function 'RS_VARIANT_CONTENTS'
      exporting
        report               = lv_report
        variant              = lv_variant
      tables
        valutab              = lt_valutab
      exceptions
        variant_non_existent = 1
        variant_obsolete     = 2
        others               = 3.
    if sy-subrc = 0.
      read table lt_valutab into lw_valutab with key selname = lv_selname.
      if sy-subrc = 0.
        lw_lrdat-sign   = lw_valutab-sign.
        lw_lrdat-option = lw_valutab-option.
        if lw_valutab-low   is not initial.
          call function 'CONVERT_DATE_TO_INTERNAL'
            exporting
              date_external            = lw_valutab-low
*             ACCEPT_INITIAL_DATE      =
            importing
              date_internal            = lw_valutab-low
            exceptions
              date_external_is_invalid = 1
              others                   = 2.
          if sy-subrc = 0.
            lw_lrdat-low    = lw_valutab-low.
          endif.
        endif.
        if lw_valutab-high   is not initial.
          call function 'CONVERT_DATE_TO_INTERNAL'
            exporting
              date_external            = lw_valutab-high
*             ACCEPT_INITIAL_DATE      =
            importing
              date_internal            = lw_valutab-high
            exceptions
              date_external_is_invalid = 1
              others                   = 2.
          if sy-subrc = 0.
            lw_lrdat-high   = lw_valutab-high.
          endif.

        endif.
        append lw_lrdat to so_lrdat.
        clear lw_lrdat.
      endif.

*&---------------------------------------------------------------------*
*GET VARIANT VALUES   ENDED                                                  *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* FETCH DATA                                                           *
*&---------------------------------------------------------------------*
      select zmmt_po_cons~mblnr
      zmmt_po_cons~lrnum
      zmmt_po_cons~lrdat
      zmmt_po_cons~trans
      mseg~mjahr
      mseg~matnr
      mseg~werks
      mseg~lifnr
      mseg~menge from zmmt_po_cons inner join mseg on zmmt_po_cons~mblnr = mseg~mblnr
      into table  gt_zmmt_po_cons
      where zmmt_po_cons~lrdat in so_lrdat.


      if gt_zmmt_po_cons is not initial.
        select matnr
        spart from mara into  table gt_mara for all entries in gt_zmmt_po_cons
        where matnr = gt_zmmt_po_cons-matnr.
************Begin of Changes by Ravi on 02.05.2017 DR1K932585*****************
        if gt_mara[] is not initial.
          refresh : gt_mara_d.
          gt_mara_d[] = gt_mara[].
          sort gt_mara_d by spart.
          delete adjacent duplicates from gt_mara_d comparing spart.
          if gt_mara_d[] is not initial.
            select * from tspat
            into table gt_tspat
            for all entries in gt_mara_d
            where spras = 'EN'
            and spart = gt_mara_d-spart.
          endif.
        endif.
************End of Changes by Ravi on 02.05.2017 DR1K932585*****************
        select matnr
        maktx from makt into table gt_makt for all entries in gt_zmmt_po_cons
        where matnr = gt_zmmt_po_cons-matnr and
        spras = 'EN'.

        select werks
        land1
        regio from t001w into table gt_t001w for all entries in gt_zmmt_po_cons
        where werks = gt_zmmt_po_cons-werks.
      endif.
      if gt_t001w is not initial.
        select land1
        bland
        bezei from t005u into table gt_t005u for all entries in gt_t001w
        where land1 = gt_t001w-land1 and
        bland = gt_t001w-regio.
      endif.

      loop at gt_zmmt_po_cons into gw_zmmt_po_cons.
        gw_final-lrnum = gw_zmmt_po_cons-lrnum.
        gw_final-lrdat = gw_zmmt_po_cons-lrdat.
        gw_final-trans = gw_zmmt_po_cons-trans.
        gw_final-matnr = gw_zmmt_po_cons-matnr.
        gw_final-werks = gw_zmmt_po_cons-werks.
        gw_final-lifnr = gw_zmmt_po_cons-lifnr.
        gw_final-menge = gw_zmmt_po_cons-menge.
        read table gt_mara into gw_mara with key matnr = gw_zmmt_po_cons-matnr.
        if sy-subrc = 0.
          gw_final-spart = gw_mara-spart.
************Begin of Changes by Ravi on 02.05.2017 DR1K932585*****************
          read table gt_tspat into gw_tspat with key spart = gw_final-spart.
          if sy-subrc eq 0.
            concatenate 'BF' gw_tspat-vtext into gw_final-spart_desc separated by space.
            replace all occurrences of '-' in gw_final-spart_desc with ' '. "Changed by Pushpa DR1K933200
          endif.
************End of Changes by Ravi on 02.05.2017 DR1K932585*****************
        endif.
        read table gt_makt into gw_makt with key matnr = gw_zmmt_po_cons-matnr.
        if sy-subrc = 0.
          gw_final-maktx = gw_makt-maktx.
        endif.
        read table gt_t001w into gw_t001w with key werks = gw_zmmt_po_cons-werks.
        read table gt_t005u into gw_t005u with key land1 = gw_t001w-land1
        bland = gw_t001w-regio.
        if sy-subrc = 0.
          gw_final-bezei = gw_t005u-bezei.
        endif.

        gw_final-promo = 'PROMO'.
        gw_final-status = 'S'.
        gw_final-message = 'Success'.
        gw_final-date = sy-datum.

        append : gw_final  to gt_final.
        clear : gw_final,
        gw_zmmt_po_cons,
*            gw_mseg,
        gw_mara,
        gw_makt,
        gw_t001w,
        gw_t005u.

      endloop.
*&---------------------------------------------------------------------*
* FETCH DATA                                                           *
*&---------------------------------------------------------------------*
      if gt_final[] is not initial .
        move-corresponding gt_final to  output-mt_inventory_res-records.
      endif.
    else.
      gw_final-status = 'E'.
      gw_final-message = 'Error In variant'.
      gw_final-date = sy-datum.
    endif.
  endmethod.
ENDCLASS.
