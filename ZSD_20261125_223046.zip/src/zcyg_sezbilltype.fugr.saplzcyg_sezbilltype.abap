*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_SEZBILLTYPETOP.              " Global Data
  INCLUDE LZCYG_SEZBILLTYPEUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_SEZBILLTYPEF...              " Subroutines
* INCLUDE LZCYG_SEZBILLTYPEO...              " PBO-Modules
* INCLUDE LZCYG_SEZBILLTYPEI...              " PAI-Modules
* INCLUDE LZCYG_SEZBILLTYPEE...              " Events
* INCLUDE LZCYG_SEZBILLTYPEP...              " Local class implement.
* INCLUDE LZCYG_SEZBILLTYPET99.              " ABAP Unit tests
  INCLUDE LZCYG_SEZBILLTYPEF00                    . " subprograms
  INCLUDE LZCYG_SEZBILLTYPEI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
