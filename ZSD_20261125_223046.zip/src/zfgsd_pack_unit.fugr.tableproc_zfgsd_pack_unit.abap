*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFGSD_PACK_UNIT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFGSD_PACK_UNIT     .

  PERFORM TABLEPROC.

ENDFUNCTION.
