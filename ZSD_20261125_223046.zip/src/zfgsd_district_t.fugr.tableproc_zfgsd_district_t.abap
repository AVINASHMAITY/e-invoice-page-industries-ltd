*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFGSD_DISTRICT_T
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFGSD_DISTRICT_T    .

  PERFORM TABLEPROC.

ENDFUNCTION.
