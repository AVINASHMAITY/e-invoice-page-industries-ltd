FUNCTION zfm_sd_routine.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(LV_KBETR) TYPE  KBETR OPTIONAL
*"     REFERENCE(LV_KBETR1) TYPE  KBETR OPTIONAL
*"  EXPORTING
*"     REFERENCE(LV_RESULT) TYPE  KBETR
*"----------------------------------------------------------------------
DATA : lv_temp TYPE p DECIMALS 5.
DATA : lv_char1 TYPE char15,
       lv_char2 TYPE char15,
       lv_char3(6) TYPE P DECIMALS 2,
       lv_char4(6) TYPE P DECIMALS 3,
       lv_char5(6) TYPE P DECIMALS 4.

  DATA: lv_kbetr2 type kbetr,
        lv_kbetr3   TYPE kbetr.
  CLEAR :lv_kbetr2,lv_kbetr3 .
  lv_kbetr2  = lv_kbetr.
  lv_kbetr3    = lv_kbetr1.
  IF lv_kbetr3 IS NOT INITIAL.
    lv_temp =  lv_kbetr / lv_kbetr3.
*   lv_char3 = lv_temp.
   lv_char5 = lv_temp.
   lv_char4 = lv_char5.
   lv_char3 = lv_char4.
*   SPLIT lv_char1 AT '.' INTO lv_char2 lv_char3.
*    CONDENSE : lv_char2, lv_char3.
*    CLEAR lv_char1.
*    lv_char1 = lv_char3(3).
*    CONDENSE lv_char1.
*    CLEAR lv_char3.
*    CONCATENATE lv_char2 lv_char1 INTO lv_char3 SEPARATED BY '.'.
   lv_result = lv_char4 * 10.
  ENDIF.








ENDFUNCTION.
