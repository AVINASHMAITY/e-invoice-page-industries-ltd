class zcl_phy_samp definition
  public
  final
  create public .

  public section.
    interfaces if_amdp_marker_hdb.
    types : begin of tp_final,
              mblnr      type mblnr,
              mjahr      type mjahr,
              matnr      type matnr,
              maktx      type maktx,
              steuc      type steuc,
              bwart      type bwart,
              werks      type werks_d,
              name1      type name1,
              bezei      type bezei20,
              lgort      type lgort_d,
              lgobe      type lgobe,
              charg      type charg_d,
              menge      type menge_d,
              meins      type meins,
              budat_mkpf type budat,
              migon      type mblnr,
              migod      type budat,
              vbeln      type vbeln_vf,
              fkdat      type fkdat,
              kunrg      type kunrg,
              kunrgn     type name1,
              werks1     type werks_d,
              wname      type name1,
              vbtyp_n    type vbtyp_n,
              jassv      type kbetr,
              joigv      type kbetr,
              jocgv      type kbetr,
              josgv      type kbetr,
            end of tp_final,
            begin of tp_1,
              mblnr      type mblnr,
              mjahr      type mjahr,
*            zeile type mblpo,
              bwart      type bwart,
              matnr      type matnr,
              maktx      type maktx,
              werks      type werks_d,
              name1      type name1,
              bezei      type bezei20,
              lgort      type lgort_d,
              lgobe      type lgobe,
              charg      type charg_d,
              menge      type menge_d,
              meins      type meins,
              budat_mkpf type budat,
            end of tp_1,
            begin of tp_2,
              chk   type char26,
              date  type char8,
              werks type werks_d,
              charg type charg_d,
            end of tp_2,
            begin of tp_21,
              chk        type char26,
              charg      type charg_d,
              budat_mkpf type budat,
            end of tp_21,
            begin of tp_3,
              vbelv   type vbeln_von,
              vbeln   type vbeln_nach,
              invoice type vbeln_von,
              vbtyp_n type vbtyp_n,
              charg   type charg_d,
            end of tp_3,
            begin of tp_4,
              migon   type mblnr,
              vbeln   type vbeln_vf,
              vbtyp_n type vbtyp_n,
              knumv   type knumv,
              fkdat   type fkdat,
              kunrg   type kunrg,
              kunrgn  type name1,
              posnr   type posnr_vf,
              charg   type charg_d,
              werks   type werks_d,
              wname   type name1,
              jassv   type kbetr,
              zptsv   type kbetr,
              zp03v   type kbetr,
              joigv   type kbetr,
              jocgv   type kbetr,
              josgv   type kbetr,
            end of tp_4,
            begin of tp_mi_mseg,
              mblnr      type mblnr,
              mjahr      type mjahr,
              charg      type charg_d,
              budat_mkpf type budat,
              val        type dmbtr,
              menge      type menge_d,
            end of tp_mi_mseg,
            begin of tp_bset,
              mblnr      type mblnr,
              charg      type charg_d,
              budat_mkpf type budat,
              val        type dmbtr,
              joigv      type kbetr_tax,
              jocgv      type kbetr_tax,
              josgv      type kbetr_tax,
            end of tp_bset,
            begin of tp_rseg,
              mblnr      type mblnr,
              charg      type charg_d,
              budat_mkpf type budat,
              val        type dmbtr,
              awkey      type awkey,
              buzei      type buzei,
              bukrs      type bukrs,
              belnr      type belnr_d,
              gjahr      type gjahr,
            end of tp_rseg,
            begin of tp_t,
              tes type string,
            end of tp_t,
            tt_final   type table of tp_final with empty key,
            tt_2       type table of tp_2 with empty key,
            tt_21      type table of tp_21 with empty key,
            tt_3       type table of tp_3 with empty key,
            tt_4       type table of tp_4 with empty key,
            tt_mi_mseg type table of tp_mi_mseg with empty key,
            tt_mi_bset type table of tp_bset with empty key,
            tt_rseg    type table of tp_rseg with empty key,
            tt_tes     type table of tp_t with empty key,
            tt_1       type table of tp_1 with empty key.
    class-methods : _instance returning value(r_ref) type ref to zcl_phy_samp.
    methods : _alv importing value(_where) type string,_physamp_data importing value(_where) type string  exporting
*        value(_mseg_f) type tt_1
*        value(_bmigo) type tt_21
*        value(_vbfa) type tt_3
*        value(_bvbfa) type tt_3
*        value(_bsales) type tt_4
*        value(_mi_1) type tt_final
*        value(_mi_bset) type tt_mi_bset
*        value(_mi_rseg) type tt_rseg
        value(_final) type tt_final.
  protected section.
  private section.
    class-data : gr_ref type ref to zcl_phy_samp.
endclass.

class zcl_phy_samp implementation.
  method _instance.
    if gr_ref is not bound.
      gr_ref = new #( ).
    endif.
    r_ref = gr_ref.
  endmethod.
  method _physamp_data by database procedure for hdb language sqlscript options read-only using mseg t001w t005u t001l vbfa vbrk vbrp konv makt marc rseg bkpf bset.
    _mseg = apply_filter ( mseg, :_where);
    _mseg_1 = select mblnr,mjahr,bwart,matnr,werks,lgort,charg,case when shkzg = 'H' then sum(menge) end as mengeh,case when shkzg = 'S' then sum(menge) end as menges,meins,budat_mkpf from :_mseg
               group by mblnr,mjahr,bwart,matnr,werks,lgort,charg,shkzg,meins,budat_mkpf;
    _mseg = select * from :_mseg where 1 = 2;
    _mseg_1 = select mblnr,mjahr,bwart,matnr,werks,lgort,charg,sum(mengeh) as mengeh,sum(menges)as menges,meins,budat_mkpf from :_mseg_1
              group by mblnr,mjahr,bwart,matnr,werks,lgort,charg,meins,budat_mkpf;
    _mseg_1f = select m.mblnr,m.mjahr,m.bwart,m.matnr,t.maktx,m.werks,m.lgort,m.charg,sum( coalesce(m.mengeh,0) - coalesce(m.menges,0) ) as menge,m.meins,m.budat_mkpf from :_mseg_1 as m
                left outer join makt as t
                on t.mandt = session_context('CLIENT') and t.spras = session_context('LOCALE_SAP') and m.matnr = t.matnr
                group by m.mblnr,m.mjahr,m.bwart,m.matnr,t.maktx,m.werks,m.lgort,m.charg,m.meins,m.budat_mkpf;
    _mseg_1 = select * from :_mseg_1 where 1 = 2;
    _mseg_f = select a.mblnr,a.mjahr,a.bwart,a.matnr,a.maktx,null as steuc,a.werks,p.name1,r.bezei,a.lgort,s.lgobe,a.charg,a.menge,a.meins,a.budat_mkpf from :_mseg_1f as a left outer join t001w as p
               on p.mandt = session_context('CLIENT') and
               a.werks = p.werks inner join t005u as r on r.mandt = session_context('CLIENT') and r.spras = session_context('LOCALE_SAP') and p.land1 = r.land1 and p.regio = r.bland
               inner join t001l as s on s.mandt = session_context('CLIENT') and a.werks = s.werks and a.lgort = s.lgort
               group by a.mblnr,a.mjahr,a.bwart,a.matnr,a.maktx,a.werks,p.name1,r.bezei,a.lgort,s.lgobe,a.charg,a.menge,a.meins,a.budat_mkpf;
    _mseg_f1 = select * from :_mseg_f where 1 = 2;
    _mseg_f = select a.mblnr,a.mjahr,a.bwart,a.matnr,a.maktx,m.steuc,a.werks,a.name1,a.bezei,a.lgort,a.lgobe,a.charg,a.menge,a.meins,a.budat_mkpf from :_mseg_f as a left outer join marc as m
               on m.mandt = session_context('CLIENT') and a.matnr = m.matnr and a.werks = m.werks;
    _migo = select max(a.mblnr||a.mjahr||a.zeile||a.budat_mkpf) as chk,a.werks,a.charg from mseg as a inner join :_mseg_f as b on a.bwart = '101' and a.werks = b.werks and a.charg = b.charg
              and a.budat_mkpf <= b.budat_mkpf group by a.werks,a.charg;
    _vbfa = select distinct a.vbelv,a.vbeln,b.vbeln as invoice,b.vbtyp_n,m.charg from :_migo as m
            left outer join vbfa as a on a.mandt = session_context('CLIENT') and substring(m.chk,1,10) = a.vbeln and a.vbtyp_n = 'i'
            inner join vbfa as b on b.mandt = session_context('CLIENT') and a.vbelv = b.vbelv and b.vbtyp_n in ('M','U')
            inner join vbrk as v on v.mandt = session_context('CLIENT') and v.VBELN = b.VBELN and v.fksto != 'X';
   _sales = select x.vbeln as migon,a.vbeln,x.vbtyp_n,a.knumv,a.fkdat,ltrim(a.kunrg,0)as kunrg,pa.name1 as kunrgn,b.posnr,b.charg,b.werks,pb.name1 as wname,
             case when k.kschl = 'JASS' then k.kbetr else null end as jassv,case when k.kschl = 'ZPTS' then k.kbetr else null end as zptsv,case when k.kschl = 'ZP03' then k.kbetr else null end as zp03v,
             case when k.kschl = 'JOIG' then ( k.kbetr / 10 ) else null end as joigv,
             case when k.kschl = 'JOCG' then ( k.kbetr / 10 ) else null end as jocgv,case when k.kschl = 'JOSG' then ( k.kbetr / 10 ) else null end as josgv
             from vbrk as a left outer join vbrp as b on a.mandt = session_context('CLIENT') and a.mandt = b.mandt and a.vbeln = b.vbeln
*             and b.FKIMG > '0.000'
             inner join konv as k on k.mandt = session_context('CLIENT') and k.knumv = a.knumv and k.kposn = b.posnr
             inner join :_vbfa as x on a.vbeln = x.invoice and b.charg = x.charg
             left outer join t001w as pa
             on pa.mandt = session_context('CLIENT') and ltrim(a.kunrg,0) = pa.werks
             left outer join t001w as pb
             on pb.mandt = session_context('CLIENT') and b.werks = pb.werks;
    _sales = select migon,vbeln,vbtyp_n,knumv,fkdat,kunrg,kunrgn,posnr,charg,werks,wname,sum(jassv) as jassv,sum(zptsv) as zptsv,sum(zp03v) as zp03v,sum(joigv) as joigv,sum(jocgv) as jocgv,
                sum(josgv) as josgv from :_sales group by migon,vbeln,vbtyp_n,knumv,fkdat,kunrg,kunrgn,posnr,charg,werks,wname;
    _sales = select migon,vbeln,vbtyp_n,knumv,fkdat,kunrg,kunrgn,posnr,charg,werks,wname,coalesce(jassv,zp03v,zptsv) as jassv,null as zptsv,null as zp03v,joigv,jocgv,josgv from :_sales;
    _final = select m.mblnr,m.mjahr,m.matnr,m.maktx,m.steuc,m.bwart,m.werks,m.name1,m.bezei,m.lgort,m.lgobe,m.charg,m.menge,m.meins,m.budat_mkpf,substring(m1.chk,1,10) as migon,substring(m1.chk,19,8) as migod,
             null as vbeln,null as fkdat,null as kunrg,null as kunrgn,null as werks1,null as wname,null as vbtyp_n,null as jassv,null as joigv,null as jocgv,null as josgv from :_mseg_f as m
             left outer join :_migo as m1 on m.werks = m1.werks and m.charg = m1.charg;
    _bfinal = select * from :_final where migon is NULL;
    _final = select * from :_final where migon is not null;
    _bmigo = select max(a.mblnr||a.mjahr||a.zeile||a.budat_mkpf) as chk,a.charg,m.budat_mkpf from :_bfinal as m left outer join mseg as a on a.mandt = session_context('CLIENT') and a.bwart = '101'
             and a.charg = m.charg and a.budat_mkpf <= m.budat_mkpf
             group by a.charg,m.budat_mkpf;
    _bfinal = select m.mblnr,m.mjahr,m.matnr,m.maktx,m.steuc,m.bwart,m.werks,m.name1,m.bezei,m.lgort,m.lgobe,m.charg,m.menge,m.meins,m.budat_mkpf,substring(m1.chk,1,10) as migon,substring(m1.chk,19,8) as migod,
             null as vbeln,null as fkdat,m.kunrg,m.kunrgn,m.werks1,m.wname,null as vbtyp_n,null as jassv,null as joigv,null as jocgv,null as josgv from :_bfinal as m
             left outer join :_bmigo as m1 on m.charg = m1.charg and m.budat_mkpf = m1.budat_mkpf;
    _final = select * from :_final union select * from :_bfinal;
    _bvbfa = select distinct a.vbelv,a.vbeln,b.vbeln as invoice,b.vbtyp_n,m.charg from :_bmigo as m
            left outer join vbfa as a on a.mandt = session_context('CLIENT') and substring(m.chk,1,10) = a.vbeln and a.vbtyp_n = 'i'
            inner join vbfa as b on b.mandt = session_context('CLIENT') and a.vbelv = b.vbelv and b.vbtyp_n in ('M','U')
            inner join vbrk as v on v.mandt = session_context('CLIENT') and v.VBELN = b.VBELN and v.fksto != 'X';
    _bsales = select x.vbeln as migon,a.vbeln,x.vbtyp_n,a.knumv,a.fkdat,ltrim(a.kunrg,0)as kunrg,pa.name1 as kunrgn,b.posnr,b.charg,b.werks,pb.name1 as wname,
             case when k.kschl = 'JASS' then k.kbetr end as jassv,
             case when k.kschl = 'ZPTS' then k.kbetr else null end as zptsv,
             case when k.kschl = 'ZP03' then k.kbetr else null end as zp03v,
             case when k.kschl = 'JOIG' then ( k.kbetr / 10 ) else null end as joigv,case when k.kschl = 'JOCG' then ( k.kbetr / 10 ) else null end as jocgv,
             case when k.kschl = 'JOSG' then ( k.kbetr / 10 ) else null end as josgv
             from vbrk as a left outer join vbrp as b on a.mandt = session_context('CLIENT') and a.mandt = b.mandt and a.vbeln = b.vbeln
*             and b.FKIMG > '0.000'
             inner join konv as k on k.mandt = session_context('CLIENT') and k.knumv = a.knumv and k.kposn = b.posnr
             inner join :_bvbfa as x on a.vbeln = x.invoice and b.charg = x.charg
             left outer join t001w as pa
             on pa.mandt = session_context('CLIENT') and ltrim(a.kunrg,0) = pa.werks
             left outer join t001w as pb
             on pb.mandt = session_context('CLIENT') and b.werks = pb.werks;
    _bvbfa = select * from :_bvbfa where 1 = 2;
    _bsales = select migon,vbeln,vbtyp_n,knumv,fkdat,kunrg,kunrgn,posnr,charg,werks,wname,sum(jassv) as jassv,sum(zptsv) as zptsv,sum(zp03v) as zp03v,sum(joigv) as joigv,sum(jocgv) as jocgv,
                sum(josgv) as josgv from :_bsales group by migon,vbeln,vbtyp_n,knumv,fkdat,kunrg,kunrgn,posnr,charg,werks,wname;
    _bsales = select migon,vbeln,vbtyp_n,knumv,fkdat,kunrg,kunrgn,posnr,charg,werks,wname,coalesce(jassv,zp03v,zptsv) as jassv,null as zptsv,null as zp03v,joigv,jocgv,josgv from :_bsales;
    _mseg_f = select * from :_mseg_f where 1 = 2;
    _migo = select * from :_migo where 1 = 2;
    _sales = select * from :_sales union select * from :_bsales;
    _final = select m.mblnr,m.mjahr,m.matnr,m.maktx,m.steuc,m.bwart,m.werks,m.name1,m.bezei,m.lgort,m.lgobe,m.charg,m.menge,m.meins,m.budat_mkpf,m.migon,m.migod,
             s.vbeln,s.fkdat,s.kunrg,s.kunrgn,s.werks as werks1,s.wname,s.vbtyp_n,s.jassv,s.joigv,s.jocgv,s.josgv from :_final as m
             left outer join :_sales as s on m.migon = s.migon and m.charg = s.charg
             group by m.mblnr,m.mjahr,m.matnr,m.maktx,m.steuc,m.bwart,m.werks,m.name1,m.bezei,m.lgort,m.lgobe,m.charg,m.menge,m.meins,m.budat_mkpf,m.migon,m.migod,s.vbeln,s.fkdat,
             s.kunrg,s.kunrgn,s.werks,s.wname,s.vbtyp_n,s.jassv,s.joigv,s.jocgv,s.josgv;
*"No Inovice for MIGO
    _mi_1 = select * from :_final where migon is not null and vbeln is null;
    _final = select * from :_final where migon is not null and vbeln is not null;
    _mi_mseg = select max(a.mblnr) as mblnr,max(a.mjahr) as mjahr,max(a.zeile) as zeile,a.charg,a.budat_mkpf,a.menge,a.ebeln,a.ebelp,(coalesce(a.bualt,0)-coalesce(a.bnbtr,0)) as val from mseg as a
                inner join :_mi_1 as mi
                on a.mandt = session_context('CLIENT') and a.mblnr = mi.migon and a.charg = mi.charg and a.budat_mkpf = mi.migod
                group by a.charg,a.budat_mkpf,a.menge,a.ebeln,a.ebelp,a.bualt,a.bnbtr;
    _mi_mseg = select mblnr,mjahr,zeile,charg,budat_mkpf,null as menge,ebeln,ebelp,case when val is not null then (val/menge) else null end as val from :_mi_mseg;
    _mi_rseg = select m.mblnr,m.charg,m.budat_mkpf,m.val,b.awkey,cast(lpad(ltrim(r.buzei,0),3,0) as nvarchar(3) ) as buzei,b.bukrs,b.belnr,b.gjahr from rseg as r
                inner join :_mi_mseg as m
                on r.mandt = session_context('CLIENT') and r.ebeln = m.ebeln and r.ebelp = m.ebelp and r.bwtar = m.charg and r.lfbnr = m.mblnr and r.lfgja = m.mjahr and r.lfpos = m.zeile
                inner join bkpf as b
                on b.mandt = session_context('CLIENT') and b.awkey = (r.belnr||r.gjahr);
    _mi_bset = select r.mblnr,r.charg,r.budat_mkpf,r.val,case when b.kschl = 'JIIG' then (b.kbetr/10) end as joigv,case when b.kschl = 'JICG' then (b.kbetr/10) end as jocgv,
                case when b.kschl = 'JISG' then (b.kbetr/10) end as josgv from :_mi_rseg as r
                left outer join bset as b
                on b.mandt = session_context('CLIENT') and r.bukrs = b.bukrs and r.belnr = b.belnr and r.gjahr = b.gjahr and r.buzei = b.buzei;
    _mi_1 = select m.mblnr,m.mjahr,m.matnr,m.maktx,m.steuc,m.bwart,m.werks,m.name1,m.bezei,m.lgort,m.lgobe,m.charg,m.menge,m.meins,m.budat_mkpf,m.migon,m.migod,m.vbeln,m.fkdat,m.kunrg,m.kunrgn,
                   m.werks1,m.wname,m.vbtyp_n,b.val as jassv,b.joigv,b.jocgv,b.josgv from :_mi_1 as m
                   left outer join :_mi_bset as b on m.charg = b.charg and m.migon = b.mblnr and m.migod = b.budat_mkpf;
    _mi_mseg = select * from :_mi_mseg where 1 = 2;
    _mi_rseg = select * from :_mi_rseg where 1 = 2;
    _mi_bset = select * from :_mi_bset where 1 = 2;
    _sales = select * from :_sales where 1 = 2;
    _final = select * from :_final union select * from :_mi_1;
    _mi_1 = select * from :_mi_1 where 1 = 2;
  endmethod.
  method _alv .
    try.
        _physamp_data( exporting _where = _where importing _final = data(lt_final) ).
      catch cx_amdp_execution_failed.
    endtry.
    try.
        cl_salv_table=>factory( importing r_salv_table = data(lr_alv) changing t_table = lt_final[] ).

        data(disp) = lr_alv->get_display_settings( ).
        disp->set_list_header( conv #( 'Physician Sample'(010) ) ).
        data(tb) = lr_alv->get_functions( ).
        tb->set_all( ).
        data(col) = lr_alv->get_columns( ).
        col->set_optimize( abap_true ).
        try.
            data(lr_cols) = col->get_column( conv #( 'MIGON'(101) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Migo No'(201) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'MIGOD'(102) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Migo Date'(202) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'JASSV'(103) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Price/Unit'(203) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'JOIGV'(104) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'JOIG'(204) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'JOSGV'(105) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'JOSG'(205) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'JOCGV'(106) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'JOCG'(206) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'NAME1'(107) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Plant Description'(207) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'BEZEI'(108) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Plant Region Description'(208) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'LGOBE'(109) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Storage Location Description'(209) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'KUNRG'(110) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Invoice Payer'(210) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'KUNRGN'(111) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Invoice Payer name'(211) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'WERKS1'(112) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Invoice Plant'(212) ) ).
          catch cx_salv_not_found.
        endtry.
        try.
            lr_cols = col->get_column( conv #( 'WNAME'(113) ) ).
            lr_cols->set_short_text( conv #( abap_false ) ).
            lr_cols->set_medium_text( conv #( abap_false ) ).
            lr_cols->set_long_text( conv #( 'Invoice Plant name'(213) ) ).
          catch cx_salv_not_found.
        endtry.
        lr_alv->display( ).
      catch cx_salv_msg.
    endtry.
  endmethod.
endclass.
