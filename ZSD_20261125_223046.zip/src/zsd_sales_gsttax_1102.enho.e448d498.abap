"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:END\EI
ENHANCEMENT 0 ZSD_SALES_GSTTAX_1102.
************************************************************************
*Implementetaion   : ZSD_SALES_GSTTAX_1102                             *
*Created on        : 25.04.2018                                        *
*Developer         : Chaithanya/Iteanz                                 *
*Functional        : Saroj                                             *
*Transport         : DR1K939917                                        *
*Description       : Mandatory tax condition check JOIG, JOCG & JOSG   *
************************************************************************
*                     MOdification Log                                 *
************************************************************************
* Changed On     Developer    Transport        Description             *
* 09.05.2018     Chaithanya   DR1K940131      ZCMAIN Maintians         *
* 16.05.2018     Chaithanya   DR1K940228      Remove  VA02             *
* 16.06.2025     Rajasekhar   DR1K993587      Added new del block Z9   *
************************************************************************
DATA : GV_FLAG TYPE C.
CONSTANTS : LC_VA01     TYPE SYST_TCODE VALUE 'VA01',
            LC_VA02     TYPE SYST_TCODE VALUE 'VA02',
            LC_1102     TYPE VKORG VALUE '1102',
            LC_JOIG     TYPE KSCHL VALUE 'JOIG',
            LC_JOCG     TYPE KSCHL VALUE 'JOCG',
            LC_JOSG     TYPE KSCHL VALUE 'JOSG',
            LC_ZPTS     TYPE KSCHL VALUE 'ZPTS',
            LC_X(1)     VALUE 'X',
            LC_E(1)     VALUE 'E',
            LC_VKORG(5) VALUE 'VKORG',
            LC_AUART(5) VALUE 'AUART',  " Added by Rajasekhar
            lc_2600(4)  VALUE '2600',   " Added by Rajasekhar
            lc_zbta(4)  VALUE 'ZBTA',   " Added by Rajasekhar
            lc_zbmo(4)  VALUE 'ZBMO'.   " Added by Rajasekhar

CONSTANTS : LC_PRG TYPE SOBJ_NAME VALUE 'ZSD_SALES_GSTTAX_1102'.
DATA : LT_CON  TYPE ZTT_ZTABAP_TVARVC,
       LW_CON  TYPE ZTABAP_TVARVC.

** Begin of changes Rajasekhar 16.06.2025 ABAP_LAKSHMI DR1K993587
*IF ( SY-TCODE = LC_VA01 OR SY-TCODE = LC_VA02 or sy-tcode = 'ZSD_SALESORDER' or sy-tcode = 'ZSD_SALESORDER_NEW' ).

if xvbak-vkorg eq lC_2600 or vbak-vkorg eq lc_2600.
  if xvbak-auart eq lc_zbmo or xvbak-auart eq lc_zbta or vbak-auart eq lc_zbmo or vbak-auart eq lc_zbta.
    DATA: lv_cond_val TYPE komv-kwert.
        LOOP AT xvbap INTO gs_vbap.
         READ TABLE xkomv INTO DATA(gs_komv1) WITH KEY kschl  = 'ZBM1'
                                                kposn  = gs_vbap-posnr .


             READ TABLE xkomv INTO DATA(gs_komv2) WITH KEY kschl  = 'EDI1'
                                                kposn  = gs_vbap-posnr .


       lv_cond_val  = gs_komv1-kwert + gs_komv2-kwert.

         if gs_vbap-netwr ne lv_cond_val.
           vbak-lifsk = 'Z9'.
           Xvbak-lifsk = 'Z9'.
           exit.
           else.
             data(lv_flg) = abap_true.
       endif.
       if lv_flg is NOT INITIAL.
         if  xvbak-lifsk eq 'Z9' or vbak-lifsk eq 'Z9'.
         CLEAR : xvbak-lifsk, vbak-lifsk.
         endif.
      endif.

     ENDLOOP.
    endif.
  endif.

*ENDIF.
** End of changes Rajasekhar 16.06.2025 ABAP_LAKSHMI DR1K993587
IF  SY-TCODE = LC_VA01. " Code Added By Chaithanya  DR1K940228
*----------------------------------------------------------------------*
*ZCMAIN PARAMTER  ZSD_EXPORT_INVOICE
*----------------------------------------------------------------------*
  CLEAR : LW_CON.
  CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
    EXPORTING
      IM_OBJNAME = LC_PRG
    IMPORTING
      EX_TAB     = LT_CON.

  READ TABLE LT_CON INTO LW_CON
         WITH KEY   OBJ_NAME = LC_PRG
                    NAME     = LC_VKORG
                    LOW      = VBAK-VKORG.
  IF SY-SUBRC = 0.

    READ TABLE LT_CON INTO LW_CON
           WITH KEY   OBJ_NAME = LC_PRG
                      NAME     = LC_AUART
                      LOW      = VBAK-AUART.
    IF SY-SUBRC = 0.
      LOOP AT XVBAP.
      READ TABLE XKOMV WITH KEY
                                KSCHL = LC_ZPTS
                                KPOSN = XVBAP-POSNR.
        IF SY-SUBRC EQ 0.
        IF XKOMV-KWERT IS INITIAL.
           MESSAGE 'ZPTS Value is Missing’' TYPE LC_E.
        ENDIF.
        ENDIF.
        CLEAR :GV_FLAG.
        READ TABLE XKOMV WITH KEY
                                KSCHL = LC_JOIG
                                KPOSN = XVBAP-POSNR.
        IF SY-SUBRC EQ 0.
          GV_FLAG = LC_X.
        ENDIF.
        READ TABLE XKOMV WITH KEY
                                KSCHL = LC_JOCG
                                KPOSN = XVBAP-POSNR.
        IF SY-SUBRC EQ 0.
          READ TABLE XKOMV WITH KEY
                                  KSCHL = LC_JOSG
                                  KPOSN = XVBAP-POSNR.
          IF SY-SUBRC EQ 0.
            GV_FLAG = LC_X.
          ENDIF.
        ENDIF.

        IF GV_FLAG <> LC_X.
          MESSAGE 'Mandatory tax condition is missing’' TYPE LC_E.
        ENDIF.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDIF.
**
**if xvbak-vkorg eq '2600'.
**  if xvbak-auart eq 'ZBMO' or xvbak-auart eq 'ZBOR'.
**        LOOP AT xvbap INTO gs_vbap.
**         READ TABLE xkomv INTO DATA(gs_komv1) WITH KEY kschl  = 'ZBM1'
**                                                kposn  = gs_vbap-posnr .
**         IF sy-subrc eq 0.
**        DATA(lv_kbetr1) = gs_komv1-kbetr.
**         ENDIF.
**
**             READ TABLE xkomv INTO DATA(gs_komv2) WITH KEY kschl  = 'EDI1'
**                                                kposn  = gs_vbap-posnr .
**         IF sy-subrc eq 0.
**        DATA(lv_kbetr2) = gs_komv2-kbetr.
**         ENDIF.
**
**        DATA(lv_kbetr3) = lv_kbetr1 + lv_kbetr2.
****   READ TABLE komp INTO DATA(gs_xkomp1) with key kposn = gs_vbap-posnr.
****   if sy-subrc eq 0.
****     DATA(lv_netwr_1) = gs_xkomp1-netwr.
****     endif.
**         if gs_vbap-netwr ne lv_kbetr3.
**           xvbak-lifsk = 'ZE'.
**           exit.
**       endif.
**     ENDLOOP.
**    endif.
**  endif.

ENDENHANCEMENT.
