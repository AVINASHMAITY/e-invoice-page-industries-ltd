*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCOLL_PRINTOUTTOP.                " Global Data
  INCLUDE LZCOLL_PRINTOUTUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCOLL_PRINTOUTF...                " Subroutines
* INCLUDE LZCOLL_PRINTOUTO...                " PBO-Modules
* INCLUDE LZCOLL_PRINTOUTI...                " PAI-Modules
* INCLUDE LZCOLL_PRINTOUTE...                " Events
* INCLUDE LZCOLL_PRINTOUTP...                " Local class implement.
* INCLUDE LZCOLL_PRINTOUTT99.                " ABAP Unit tests
  INCLUDE LZCOLL_PRINTOUTF00                      . " subprograms
  INCLUDE LZCOLL_PRINTOUTI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
