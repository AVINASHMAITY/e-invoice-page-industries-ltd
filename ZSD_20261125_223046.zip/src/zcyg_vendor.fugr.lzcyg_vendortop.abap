FUNCTION-POOL ZCYG_VENDOR                MESSAGE-ID SV.

* INCLUDE LZCYG_VENDORD...                   " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_VENDORT00                         . "view rel. data dcl.
