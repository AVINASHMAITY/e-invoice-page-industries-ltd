*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_SEZ_PLANT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_SEZ_PLANT      .

  PERFORM TABLEPROC.

ENDFUNCTION.
