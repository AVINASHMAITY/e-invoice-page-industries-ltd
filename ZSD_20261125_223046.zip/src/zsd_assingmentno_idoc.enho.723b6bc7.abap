"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ASSINGMENTNO_IDOC.
*&-------------------------------------------------------------------
*Date       : 18.07.2023
*Programmer : Sumit
*TR No.     : DR1K976866
*Description: Enhancment for Assingment Number for Credit/Debit Memo
*&-------------------------------------------------------------------
*                  Modification Log                                 *
*&-------------------------------------------------------------------
*Date       : 29.10.2024
*Programmer : Suganya
*TR No.     : DR1K976866
*Description: Enhancment to update Assingment Number for all orders
*&-------------------------------------------------------------------
data:lwa_E1EDK02_temp type E1EDK02.

LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_idoc02>) where segnam = 'E1EDK02' .
lwa_e1edk02_temp  = <fs_idoc02>-sdata.
IF lwa_e1edk02_temp-qualf = '017'.
 DATA(lv_idoc_x) = 'X'.
 EXPORT lv_idoc_x TO MEMORY id 'LV_IDOC_X'.
 DATA(lv_assing) = lwa_e1edk02_temp-belnr.
 EXPORT lv_assing TO MEMORY id 'LV_ASSING'.
ENDIF.
ENDLOOP.

ENDENHANCEMENT.
