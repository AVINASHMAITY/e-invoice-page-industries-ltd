FUNCTION-POOL ZCOLL_PRINTOUT             MESSAGE-ID SV.

* INCLUDE LZCOLL_PRINTOUTD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCOLL_PRINTOUTT00                      . "view rel. data dcl.
