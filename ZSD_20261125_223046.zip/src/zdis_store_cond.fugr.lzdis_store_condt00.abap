*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDIS_STORE_COND.................................*
DATA:  BEGIN OF STATUS_ZDIS_STORE_COND               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDIS_STORE_COND               .
CONTROLS: TCTRL_ZDIS_STORE_COND
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDIS_STORE_COND               .
TABLES: ZDIS_STORE_COND                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
