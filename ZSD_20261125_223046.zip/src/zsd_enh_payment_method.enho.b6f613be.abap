"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBKD\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_PAYMENT_METHOD.
DATA:lw_bukrs TYPE vkbuk,
     lw_zwels TYPE dzwels.


IF sy-tcode = 'VA01' AND vbkd-zlsch IS INITIAL.
 if not ( vbak-auart = 'YBNR' OR vbak-auart = 'YBRE' or vbak-auart = 'YBSC'
    OR vbak-auart = 'YBCR' OR vbak-auart = 'YBDR' )." OR vbak-auart = 'YBSR' ).
  CLEAR:lw_bukrs,lw_zwels.

  SELECT SINGLE bukrs FROM tvko INTO lw_bukrs WHERE vkorg = vbak-vkorg.
  IF sy-subrc = 0.
    SELECT SINGLE zwels  FROM knb1 INTO lw_zwels  WHERE kunnr = vbak-kunnr AND bukrs = lw_bukrs.
    IF sy-subrc = 0.
      vbkd-zlsch = lw_zwels.
    ENDIF.
    ENDIF.
  ENDIF.
ENDIF.

* As per Saroj confirmation on 05.01.2017
  " It has been commented
*
** " Check PO Number either it's existing in VBKD or not
*     " code added by Gokul - 25.11.2016
*        " Sol. ID = 8000002442
*           " TR : DR1K929789
**           Modification :
*          " TR : DR1K929988  -  07.12.2016
**             - Removed BUKRS and check for VKORG in ZCMAIN
*        if sy-tcode = 'VA01'
*          or sy-tcode = 'VA02'.
*
*     DATA : lv_BSTKD TYPE BSTKD,
*           LV_VBELN TYPE VBELN,
*           lv_BSTNK TYPE BSTNK,
*           LV_KUNNR TYPE KUNAG.
*
*DATA : GT_CONSTANTS TYPE ZTT_ZTABAP_TVARVC.
*
*CONSTANTS : GC_PO_COMP VALUE 'ZSD_ENH_PAYMENT_METHOD' TYPE SOBJ_NAME ,
*            LC_AUART(8) VALUE 'SO_AUART' ,
*            LC_VKORG(8) VALUE 'SO_VKORG' .
*if sy-tcode = 'VA02'.
** SELECT SINGLE VKORG FROM tvko INTO lw_VKORG WHERE vkorg = vbak-vkorg.
*ENDIF.
**----------------------------------------------------------------------*
** T_CODE   : ZCMAIN
** PARAMTER : ZSD_ENH_PAYMENT_METHOD
**----------------------------------------------------------------------*
*  CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
*    EXPORTING
*      IM_OBJNAME = GC_PO_COMP
*    IMPORTING
*      EX_TAB     = GT_CONSTANTS.
*
*    READ TABLE GT_CONSTANTS INTO DATA(GW_CONSTANTS)
*         WITH KEY   OBJ_NAME = GC_PO_COMP
*                    NAME     = LC_VKORG
*                    LOW      = vbak-vkorg.
**    IF SY-SUBRC = 0.
**      CLEAR GW_CONSTANTS.
**    READ TABLE GT_CONSTANTS INTO GW_CONSTANTS
**         WITH KEY   OBJ_NAME = GC_PO_COMP
**                    NAME     = LC_AUART
**                    LOW      = VBAK-AUART.
*     IF SY-SUBRC = 0.
*       CLEAR : lv_BSTKD.
*          SELECT single BSTKD
*                 into   lv_BSTKD
*                 from   vbkd
*                 where  BSTKD = VBKD-BSTKD.
*           IF sy-subrc = 0.
*             IF SY-TCODE = 'VA02'.
*              CLEAR : lv_BSTKD,LV_VBELN.
*              SELECT single VBELN
*                            BSTKD
*                 into   (LV_VBELN, lv_BSTKD)
*                 from   vbkd
*                 where  VBELN = VBKD-VBELN
*                   AND  BSTKD = VBKD-BSTKD.
*                IF SY-SUBRC EQ 0.
*                  MESSAGE e003(zsd_ret).
*                ENDIF.
*              ELSEIF SY-TCODE = 'VA01'.
*               SELECT SINGLE BSTNK KUNNR
*               FROM VBAK
*               INTO (lv_BSTNK, LV_KUNNR)
*               WHERE KUNNR = VBAK-KUNNR
*                 AND BSTNK = VBAK-BSTNK.
*              if sy-subrc eq 0.
*              MESSAGE e003(zsd_ret).
*              endif.
*             ENDIF.
*           ENDIF.
*
*      ENDIF.
**      ENDIF.
*        endif.
*
*
*           " TR : DR1K929789
*        " Sol. ID = 8000002442
*     " code added by Gokul - 25.11.2016
** " Check PO Number either it's existing in VBKD or not

  " It has been commented
* As per Saroj confirmation on 05.01.2017


*break Sahoo.
*Break sahoo.
*If sy-tcode = 'VA01' or Sy-tcode = 'VA02'.
*If sy-ucomm = 'SICH'.
*If XVBAK-VKORG = '1102' and XVBAK-LIFSK = 'Z1'.
**Break sahoo.
**Clear XVBBE-OMENG.
**Clear YVBBE-OMENG.
**Clear YVBBS-OMENG.
**Clear XVBBS-OMENG.
**Refresh XVBBE.
**Refresh YVBBE.
**Refresh YVBBS.
**Refresh xVBBS.
* XVBAP-FIXMG = 'X'.
* VBAP-FIXMG = 'X'.
*endif.
*endif.
*endif.
ENDENHANCEMENT.
