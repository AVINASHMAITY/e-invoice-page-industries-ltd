"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_RETURN_ORDER_CHECK.
*
*****************************************************************************
*Implementetaion   : ZSD_RETURN_ORDER_CHECK
*Created on        : 04.04.2016
*Developer         : Lokesh/Iteanz
*Functional        : Sunil/Ravi
*Transaport        : DR1K925616
*Description       : Validating Return order against it's Invoice doc
*                    1. Qty should not exceed  than Inv.qty
*                    2. Materials other than Inv.doc marerials is not allowed
*****************************************************************************
* Modification History                                                      *
*****************************************************************************
*Developer         : Lokesh/Iteanz
*Transport         : DR1K926648
*Created on        : 24.05.2016
*Change Descp      : Ignoring Same SO which is editing in VA02
******************************************************************************




******************************************
* Types Declaration                      *
******************************************
TYPES : BEGIN OF ty_vbak,
        vbeln TYPE vbeln_va,
        vgbel TYPE vgbel,
        END OF ty_vbak,

        BEGIN OF ty_vbap,
        vbeln TYPE vbeln_va,
        posnr TYPE posnr_va,
        matnr TYPE matnr,
        kwmeng TYPE kwmeng,
        END OF ty_vbap,

        BEGIN OF ty_vbrp,
        vbeln TYPE vbeln_vf,
        posnr TYPE posnr_vf,
        fkimg TYPE fkimg,
        matnr TYPE matnr,
        END OF ty_vbrp,

        BEGIN OF ty_xit,
        matnr TYPE matnr,
        kwmeng TYPE kwmeng,
        END OF ty_xit.

******************************************
* Struc & Int.tables                     *
******************************************
data : lt_vbap TYPE TABLE OF ty_vbap,
       lt_vbak TYPE TABLE OF ty_vbak,
       lt_vbrp TYPE TABLE OF ty_vbrp,
       lt_xit  TYPE TABLE OF ty_xit,
       ls_vbap TYPE ty_vbap,
       ls_vbap1 TYPE ty_vbap,
       ls_vbrp TYPE ty_vbrp,
       ls_vbrp1 TYPE ty_vbrp,
       ls_xit TYPE ty_xit,
       ls_chk TYPE ztsd_ret_order.
data : lx TYPE vbapvb,
       lv_kwmeng TYPE kwmeng,
       lv_fkimg TYPE fkimg.
data : ls_ret TYPE bapiret2,
       lt_ret TYPE TABLE OF bapiret2.

if ( sy-tcode = 'VA01' or
     sy-tcode = 'VA02' ).
if ( sy-ucomm eq 'SICH' or
     sy-ucomm eq ''  or
     sy-ucomm eq 'YES').  "=>*DR1K926648 added by lokesh
*** ReTurn OrdeR Only ***
if vbak-vbtyp eq 'H'.

refresh : lt_vbak,
          lt_vbap,
          lt_ret,
          lt_xit.
CLEAR : ls_vbap,
        ls_xit,
        ls_ret,
        lv_kwmeng,
        lv_fkimg.

CLEAR ls_chk.
SELECT SINGLE * FROM ztsd_ret_order INTO ls_chk WHERE vkorg = vbak-vkorg and
                                                      auart = vbak-auart and
                                                      zactiv = 'X'.
if sy-subrc eq 0.
if vbak-vgbel is NOT INITIAL.
if xvbap[] is NOT INITIAL.
  refresh lt_xit.
  loop at xvbap.
  if xvbap-updkz ne 'D'.
  ls_xit-matnr = xvbap-matnr.
  ls_xit-kwmeng = xvbap-kwmeng.
  COLLECT ls_xit INTO lt_xit.
  CLEAR ls_xit.
  endif.
  ENDLOOP.

**Fetch Invoice Details
SELECT vbeln
       posnr
       fkimg
       matnr FROM vbrp INTO TABLE lt_vbrp
             where vbeln = vbak-vgbel." lx-vgbel.
if sy-subrc eq 0.
  sort lt_vbrp by matnr.
**Fetch Existing Sales Order details against Ref.doc(Inv)
SELECT vbeln
       vgbel
       FROM vbak
       INTO TABLE lt_vbak
       where vgbel = vbak-vgbel.
if sy-subrc eq 0.
*Added by lokesh => Not Considering the same SO which is Editing in VA02
*DR1K926648
if sy-tcode = 'VA02'.
  delete lt_vbak where vbeln eq vbak-vbeln.
endif.
*DR1K926648
if lt_vbak is NOT INITIAL.
select vbeln
       posnr
       matnr
       kwmeng
       FROM vbap INTO TABLE lt_vbap
       FOR ALL ENTRIES IN lt_vbak
       WHERE vbeln = lt_vbak-vbeln.
endif.
endif.
*if sy-subrc eq 0.
if lt_vbap is NOT INITIAL.
sort lt_vbap by matnr.

** Checking Invoice Qty & Material with Current Sale Order items
loop at lt_xit INTO ls_xit.
  lv_kwmeng = ls_xit-kwmeng.
CLEAR ls_vbrp.
READ TABLE lt_vbrp INTO ls_vbrp with key matnr = ls_xit-matnr BINARY SEARCH.
if sy-subrc eq 0.
loop at lt_vbrp INTO ls_vbrp1 FROM sy-tabix.
if ls_vbrp1-matnr eq ls_vbrp-matnr.
lv_fkimg = lv_fkimg + ls_vbrp1-fkimg.
else.
  exit.
endif.
CLEAR ls_vbrp1.
endloop.

**Checking Existing Sale Order Qty with Current Sale Order items
CLEAR ls_vbap.
READ TABLE lt_vbap INTO ls_vbap with key matnr = ls_xit-matnr BINARY SEARCH.
if sy-subrc eq 0.
loop at lt_vbap INTO ls_vbap1 FROM sy-tabix.
if ls_vbap1-matnr eq ls_vbap-matnr.
 lv_kwmeng = lv_kwmeng + ls_vbap1-kwmeng.
else.
  exit.
endif.
CLEAR :ls_vbap1.
endloop.
endif.

if lv_kwmeng gt lv_fkimg.
  ls_ret-type = 'E'.
  ls_ret-id = 'ZSD_RET'.
  ls_ret-number = '001'.
  ls_ret-message_v1 = ls_xit-matnr.
  APPEND ls_ret TO lt_ret.
  CLEAR ls_ret.
endif.

else.
** If Material Other than original Invoiced Material
  ls_ret-type = 'E'.
  ls_ret-id = 'ZSD_RET'.
  ls_ret-number = '000'.
  ls_ret-message_v1 = ls_xit-matnr.
  APPEND ls_ret TO lt_ret.
  CLEAR ls_ret.
endif.
CLEAR :lv_kwmeng,lv_fkimg.
CLEAR ls_xit.
ENDLOOP.

else.
*** No Sale order Exisits against Rerfernce.doc(Inv)****

*Checking Invoice Qty and Material with Current Sale order Qty & Matnr
CLEAR :lv_fkimg,lv_kwmeng.
loop at lt_xit INTO ls_xit.
  lv_kwmeng = ls_xit-kwmeng.
  CLEAR ls_vbrp.
** correction
* DR1K925758
*READ TABLE lt_vbap INTO ls_vbap with key matnr = ls_xit-matnr BINARY SEARCH.
READ TABLE lt_vbrp INTO ls_vbrp with key matnr = ls_xit-matnr BINARY SEARCH.
** End of correction
if sy-subrc eq 0.
loop at lt_vbrp INTO ls_vbrp1 FROM sy-tabix.
if ls_vbrp1-matnr eq ls_vbrp-matnr.
lv_fkimg = lv_fkimg + ls_vbrp1-fkimg.
else.
  exit.
endif.
CLEAR ls_vbrp1.
endloop.
endif.

if lv_kwmeng gt lv_fkimg.
  ls_ret-type = 'E'.
  ls_ret-id = 'ZSD_RET'.
  ls_ret-number = '001'.
  ls_ret-message_v1 = ls_xit-matnr.
  APPEND ls_ret TO lt_ret.
  CLEAR ls_ret.
endif.
CLEAR :lv_fkimg,lv_kwmeng.
CLEAR : ls_xit.
ENDLOOP.



endif.
*endif.
endif.
endif.
endif.
endif.

IF lt_ret IS NOT INITIAL.
  CALL FUNCTION 'FINB_BAPIRET2_DISPLAY'
    EXPORTING
      it_message = lt_ret.
  MESSAGE e002(zsd_ret).
ENDIF.

endif.
endif.
endif.
ENDENHANCEMENT.
