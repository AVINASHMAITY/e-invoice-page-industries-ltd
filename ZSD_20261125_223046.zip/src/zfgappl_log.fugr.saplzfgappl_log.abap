*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGAPPL_LOGTOP.                   " Global Data
  INCLUDE LZFGAPPL_LOGUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGAPPL_LOGF...                   " Subroutines
* INCLUDE LZFGAPPL_LOGO...                   " PBO-Modules
* INCLUDE LZFGAPPL_LOGI...                   " PAI-Modules
* INCLUDE LZFGAPPL_LOGE...                   " Events
* INCLUDE LZFGAPPL_LOGP...                   " Local class implement.
* INCLUDE LZFGAPPL_LOGT99.                   " ABAP Unit tests
