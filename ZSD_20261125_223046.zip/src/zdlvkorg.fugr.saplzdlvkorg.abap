*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZDLVKORGTOP.                      " Global Data
  INCLUDE LZDLVKORGUXX.                      " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZDLVKORGF...                      " Subroutines
* INCLUDE LZDLVKORGO...                      " PBO-Modules
* INCLUDE LZDLVKORGI...                      " PAI-Modules
* INCLUDE LZDLVKORGE...                      " Events
* INCLUDE LZDLVKORGP...                      " Local class implement.
* INCLUDE LZDLVKORGT99.                      " ABAP Unit tests
  INCLUDE LZDLVKORGF00                            . " subprograms
  INCLUDE LZDLVKORGI00                            . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
