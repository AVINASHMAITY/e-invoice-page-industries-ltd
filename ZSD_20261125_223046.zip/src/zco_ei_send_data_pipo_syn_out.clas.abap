class ZCO_EI_SEND_DATA_PIPO_SYN_OUT definition
  public
  inheriting from CL_PROXY_CLIENT
  create public .

public section.

  methods CONSTRUCTOR
    importing
      !LOGICAL_PORT_NAME type PRX_LOGICAL_PORT_NAME optional
    raising
      CX_AI_SYSTEM_FAULT .
  methods EI_SEND_DATA_PIPO_SYN_OUT_SI
    importing
      !OUTPUT type ZEI_EINVOICE_SEND_DATA_PIPO_R3
    exporting
      !INPUT type ZEI_SAPEI_SEND_DATA_PIPO_RESP2
    raising
      CX_AI_SYSTEM_FAULT .
protected section.
private section.
ENDCLASS.



CLASS ZCO_EI_SEND_DATA_PIPO_SYN_OUT IMPLEMENTATION.


  method CONSTRUCTOR.

  super->constructor(
    class_name          = 'ZCO_EI_SEND_DATA_PIPO_SYN_OUT'
    logical_port_name   = logical_port_name
  ).

  endmethod.


  method EI_SEND_DATA_PIPO_SYN_OUT_SI.

  data:
    ls_parmbind type abap_parmbind,
    lt_parmbind type abap_parmbind_tab.

  ls_parmbind-name = 'OUTPUT'.
  ls_parmbind-kind = cl_abap_objectdescr=>importing.
  get reference of OUTPUT into ls_parmbind-value.
  insert ls_parmbind into table lt_parmbind.

  ls_parmbind-name = 'INPUT'.
  ls_parmbind-kind = cl_abap_objectdescr=>exporting.
  get reference of INPUT into ls_parmbind-value.
  insert ls_parmbind into table lt_parmbind.

  if_proxy_client~execute(
    exporting
      method_name = 'EI_SEND_DATA_PIPO_SYN_OUT_SI'
    changing
      parmbind_tab = lt_parmbind
  ).

  endmethod.
ENDCLASS.
