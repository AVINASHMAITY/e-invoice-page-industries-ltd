"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:END\EI
ENHANCEMENT 0 ZSD_ENABLE_DEL_BLK.
**********************************************************************
*Created on        : 26.04.2019                                      *
*Developer         : Ravindran                                       *
*Transaport        : DR1K937255                                      *
*Description       : Release Delivery Block for SO                   *
**********************************************************************
  DATA : lv_uname TYPE syst-uname.
  SELECT SINGLE uname FROM ztsd_so_rel_auth
         INTO lv_uname WHERE uname = sy-uname.
  IF sy-subrc EQ 0.
    FIELD-SYMBOLS: <cols> LIKE LINE OF tctrl_u_erf_auftrag-cols.
    IF sy-tcode = 'VA02'.
      IF screen-name EQ 'VBAK-FAKSK' OR
         screen-name EQ 'VBAK-VBELN' OR
         screen-name EQ 'VBAK-LIFSK'.
        screen-input = 1.
        MODIFY SCREEN.
      ELSE.
        screen-input = 0.
        MODIFY SCREEN.
      ENDIF.

      LOOP AT tctrl_u_erf_auftrag-cols ASSIGNING <cols>.
        CASE <cols>-screen-group2.
          WHEN 'LOO'.
            <cols>-screen-input = 0.
            MODIFY tctrl_u_erf_auftrag-cols[] FROM <cols>.
        ENDCASE.
      ENDLOOP.
    ENDIF.
  ENDIF.
ENDENHANCEMENT.
