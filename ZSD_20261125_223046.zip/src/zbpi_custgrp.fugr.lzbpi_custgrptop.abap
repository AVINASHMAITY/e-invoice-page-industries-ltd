FUNCTION-POOL ZBPI_CUSTGRP               MESSAGE-ID SV.

* INCLUDE LZBPI_CUSTGRPD...                  " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBPI_CUSTGRPT00                        . "view rel. data dcl.
