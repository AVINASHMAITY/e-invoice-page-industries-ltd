class ZCL_SI_PROXY_GETEINVRESPONSE_R definition
  public
  create public .

public section.

  interfaces ZII_SI_PROXY_GETEINVRESPONSE_R .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SI_PROXY_GETEINVRESPONSE_R IMPLEMENTATION.


  method ZII_SI_PROXY_GETEINVRESPONSE_R~SI_PROXY_GETEINVRESPONSE_REQ.
*** **** INSERT IMPLEMENTATION HERE **** ***
  endmethod.
ENDCLASS.
