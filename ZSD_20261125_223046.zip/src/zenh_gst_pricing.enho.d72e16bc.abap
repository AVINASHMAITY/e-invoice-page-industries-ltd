"Name: \PR:SAPMV45A\FO:USEREXIT_NEW_PRICING_VBAP\SE:END\EI
ENHANCEMENT 0 ZENH_GST_PRICING.

*&--------------------Modification Log-----------------
*Date       : 05.07.2017
*Programmer : Ravindran
*TR No.     : DR1K933705
*Description: Call Pricing type when changing qty and net value
*&-----------------------------------------------------
DATA : LV_VA01 TYPE SY-TCODE VALUE 'VA01',
       LV_VA02 TYPE SY-TCODE VALUE 'VA02',
       LV_VA03 TYPE SY-TCODE VALUE 'VA03',
       LV_C    TYPE C VALUE 'C',
       gt_constants TYPE ztt_ztabap_tvarvc.

CONSTANTS : gc_po_comp   TYPE sobj_name VALUE 'ZENH_GST_PRICING',
            lc_bukrs(17) VALUE 'GST_VKORG'.

  IF SY-TCODE EQ LV_VA01 OR  SY-TCODE EQ LV_VA02 OR SY-TCODE EQ LV_VA03.

  CALL METHOD zcl_abap_utility=>get_options
    EXPORTING
      im_objname = gc_po_comp
    IMPORTING
      ex_tab     = gt_constants.

    READ TABLE gt_constants INTO DATA(gw_constants)
        WITH KEY   obj_name = gc_po_comp
                   name     = lc_bukrs
                   low      = vbak-vkorg.
   IF SY-SUBRC EQ 0.
     IF VBAP-KWMENG NE *VBAP-KWMENG OR
       VBAP-NETWR NE *VBAP-NETWR.
       NEW_PRICING = LV_C.
     ENDIF.
    ENDIF.
  ENDIF.
ENDENHANCEMENT.
