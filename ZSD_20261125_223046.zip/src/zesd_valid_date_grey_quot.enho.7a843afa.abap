"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:BEGIN\EI
ENHANCEMENT 0 ZESD_VALID_DATE_GREY_QUOT.
 IF sy-tcode EQ 'VA22'.
  DATA: ls_uname TYPE ztsd_quot_date.
  IF vbak-vtweg EQ '50' AND vbak-vkorg EQ '1402'.
   SELECT SINGLE * FROM ztsd_quot_date INTO ls_uname WHERE uname = sy-uname.
   IF sy-subrc IS NOT INITIAL.
    CASE screen-name.
      WHEN 'VBAK-BNDDT'.
        screen-input = 0.
    ENDCASE.
   ENDIF.
  ENDIF.
 ENDIF.
ENDENHANCEMENT.
