/*
----------------------------------------------------------
Object Name           : ZV_MIS
Author/Comapny Name   : Chandra Mohan/ITEANZ
Transport Request     : DR1K938241
Creation Date         : 18.01.2018
----------------------------------------------------------
Description : MIS Report
----------------------------------------------------------
*/

@AbapCatalog.sqlViewName: 'ZSV_MIS'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@ClientDependent: true
@EndUserText.label: 'MIS Report view'
define view ZV_MIS 
with parameters langauage : abap.lang, client : abap.clnt, zspace : abap.char( 3 )
as select from ZV_MIS_IBD( langauage :$parameters.langauage, client :$parameters.client ) as _IBD
//PO Header
left outer join ekko as _ekko 
    on _IBD.vgbel = _ekko.ebeln
left outer join t024 as _t024
    on _ekko.ekgrp = _t024.ekgrp    
left outer join ekpo as _ekpo
    on _ekko.ebeln = _ekpo.ebeln    
//left outer join tinct[ spras = $parameters.langauage ] as _TINCT  //Commented by Bhagavan on 23.05.2022  DR1k965918   
left outer join tinct as _TINCT
    on _ekko.inco1 = _TINCT.inco1 
    and _TINCT.spras = $parameters.langauage  //Added by Bhagavan on 23.05.2022  DR1k965918
//left outer join t161t[spras = $parameters.langauage ] as _T161T   
//    on _ekko.   
//Plant address
left outer join ZV_PLNT_ADR( language : $parameters.langauage ) as _plantadr
    on _IBD.werks = _plantadr.werks
//Vendor    
left outer join lfa1 as _LFA1 
    on _ekko.lifnr = _LFA1.lifnr
//BoE
left outer join ZV_MIS_BOE as _BOE
    on _IBD.vbeln = _BOE.REFDOCNO
    and _IBD.erdat = _BOE.refdocdat  
//Delivery mode desc.
left outer join ztmm_delivery_m as _DMDESC
    on _ekko.delivery_mode = _DMDESC.delivery_type
//NNDO
left outer join ZV_MIS_NNDO(langauage :$parameters.langauage, client :$parameters.client ) as _NNDO 
    on _IBD.vbeln = _NNDO.refdocnr
//    and _IBD.erdat = _NNDO.refdocdt "C_V1
    and _IBD.EBELP1 = _NNDO.EBELP
//CLIN    
left outer join ZV_MIS_CLIN  as _CLIN
    on _NNDO.docnr = _CLIN.refdocnr
    and _NNDO.docdate = _CLIN.refdocdt
{  
    _IBD.vbeln as IBD_No,
    _IBD.ERNAM as ernam,              // Added by Bhagavan on 31/05/2022 "DR1k965918
    _IBD.erdat as IBD_dat,
    _IBD.lfart as IBD_lfart,
    _IBD.werks as Plant,
    _IBD.Matnr as Matnr,
    _IBD.posnr as item,
    
 
    @EndUserText: {label: 'Status of customs clearance'} _IBD.status as status,
//    _ekko.inco1 as Cat_Mat,
   @EndUserText: {label : 'Category of Material',quickInfo: 'Category of Material'} 
//   concat( concat(_TINCT.bezei, cast($parameters.zspace as abap.char( 3 ) )) , _ekko.inco2) as Cat_Mat,
    _IBD.mtbez as Cat_Mat,
//     concat( concat(_TINCT.bezei, '` `') , _ekko.inco2) as Cat_Mat,
//    _IBD.meins as UoM,        
    cast(
    _plantadr.padr as abap.char( 255 ) ) as UoM,
    _ekpo.disub_pspnr as wbs,
    _IBD.vgbel as PO_No,
    _ekko.ekgrp as Purc_Grp,
     _t024.eknam as Purc_Desc ,
    _ekko.inco1 as INCO,
//    _ekko.delivery_mode as MoT,
    _DMDESC.description as MoT,
    _LFA1.name1 as Sup_Nam,
    _NNDO.landx as CoC, 
    _NNDO.coddesc1 as PoLD, 
    _IBD.maktx as Mat_Desc,
    @EndUserText: {label: 'Port of clearance'}
//    _NNDO.portdisc as Poclr,   
    _IBD.eindt as Dev_Dat,
    _IBD.igm_date as IGM_Dat,
    _IBD.igm_no as IGM_No,
    _NNDO.INVOICENR as INV_No,
    _NNDO.INVOICEDT as INV_Dat,
//    _NNDO.EBELP as ItemN,
    _NNDO.INVOICEVAL as INV_val,
    _NNDO.INVOICECUR as INV_Cur,
    @EndUserText: {label: 'Invoice value in INR'}
    _NNDO.totval as INV_valinr, 
    @EndUserText: {label: 'Exchange rate in INR'}
    _NNDO.wkurs1 as INV_erinr, 
//Qty of material
    _NNDO.BTGEW as G_W,
    _NNDO.ERGEI as G_U,
    _NNDO.CHARGEWT as C_W,
    _NNDO.CMEINS as C_U,  
//Packages
    _NNDO.PKGNO as PKG_NO,
    _NNDO.coddesc2 as PKG_DESC,
//Type of cargo
    @EndUserText: {label: 'Type of Cargo'} _IBD.noc as toc,
//Perishable
    _IBD.per as per,
//     @EndUserText: {label: 'Perishable',quickInfo: 'Perishable'}     
//    ' ' as per, 
//Type of parcel
    _NNDO.C_status as ToP,
//Type of Transport Document  
    _NNDO.DELMD  as ToTD,
    _NNDO.HAWBNO as HAWBNO,
    _NNDO.HAWBDT as HAWBDT,
    _NNDO.MAWBNO as MAWBNO,
    _NNDO.MAWBDT as MAWBDT,
    _NNDO.BOLNR as BOLNR,
    _NNDO.BOLDT as BOLDT,
//Shipping documents routed through Bank
    _NNDO.pay_temrs as pay_term,
    _IBD.zdocm  as docm,
    _IBD.bro_ad as BRO_AD,
    _IBD.bro_rd as BRO_RD,
    _IBD.bnk_ad as BNK_AD,
    _IBD.bnk_rd as BNK_RD,    
//Type of Clearance
//   _BOE.DOCNO as BOE_No,
//   _BOE.BOEDATE as BOE_Date
    _IBD.bill_entry_no as BOE_No,
    _IBD.bill_entry_date as BOE_dat,
    _IBD.NETRPR4 as Cus_da, //Customs duty mt
    _IBD.lpci as LPCI, // Late presentation charges incurred
    _IBD.iocd as IOCD, //Interest on customs duty
    _IBD.op as OP, //Other penalties
    _IBD.DATE_CARGO_CLEAR as sc_dat, //Shipment clearence date
//Bonding at  CBW
    _IBD. ztoc as  ztoc,
    _IBD.cbw_bno as cbw_bno, //Bond BOE No
    _IBD.cbw_dat as cbw_dat, //BOE Date    
    _IBD.DATE_CARGO_BOND as bond_dat, //Bonding date
    _IBD.lfimg as cbw_qty, // Quantity
//EX-bond from CBW
    _IBD.xcbw_xbno as xcbw_xbno, //
    _IBD.xcbw_xbn as xcbw_xbn, //
    _IBD.xcbw_scd as xcbw_scd,
    _IBD.xcbw_cd as xcbw_cd,
    _IBD.xcbw_lpci as xcbw_lpci,
    _IBD.xcbw_iocd as xcbw_iocd,
    _IBD.xcbw_op as xcbw_op,
//Clrnce under duty exemption schemes/Licenese
    _IBD.sc_nam as sc_nam, //Scheme name
    _IBD.LS_No as LS_No, //License/Scheme no
    _IBD.val_d2l as val_d2l, //val debited to license/scheme
//Clearnce under various regulatory licenses
    _IBD.zcuvrl as zcuvrl,
    _IBD.CDCSO as CDCSO, //Form 10/Form 11/NOC
    _IBD.cfno as cfno, //Clearance Form No
    _IBD.cqty as cqty, //Clearance Quantity
    _IBD.fssaino as fssaino, //FSSAI  NOC/License No
    _IBD.fssaiqty as fssaiqty, //FSSAI  quantity
    _IBD.aniqno as aniqno, //Animal Quarantine  NOC/License No
    _IBD.aniqty as aniqty, //Animal Quarantine Quantity
    _IBD.PQ_NO as PQ_NO, //Plant Quarantine  NOC/License  No
    _IBD.PQ_qty as PQ_qty, //Plant Quarantine Quantity
    _IBD.nar_no as nar_no, //Narcotics Dept  NOC/ License No.
    _IBD.nar_qty as nar_qty, //Narcotics Qty
    _IBD.adf_no as adf_no, //ADF NOC/License No.
    _IBD.adf_qty as adf_qty, //ADF Qty
    _IBD.pcb_no as pcb_no, //PCB NOC/ License No.
    _IBD.pcb_qty as pcb_qty, //PCB Qty
    _IBD.peso_no as peso_no, // PESO  NOC/License No.
    _IBD.peso_qty as peso_qty, //PESO Qty
// Customs House Agent                
    _IBD.cust_broker_name as cha_nam, //Customs house agent
    ' ' as cha_crg,
    _IBD.CHA_BILL_NO as cha_no, //CHA Bill no
    _IBD.cha_date as cha_dat, //CHA date
    _IBD.cha_rec as cha_rec, //Charges receipted (Amount)
    _IBD.cha_nrec as cha_nrec, //Charges non-receipted (Amount)
    _IBD.zcuscr as zcuscr,
    _IBD.zdelof as zdelof,
    _IBD.netrpr2 as Demurr_amt, //Demurrage amount
    _IBD.zrsdem as r4d, //Reason for demurrage
    _IBD.netrpr3 as tot_cha_amt, // TOtal cha bill amount
// Transporter
//    _CLIN.tname as trans_nam, 
    _IBD.trans_nam as trans_nam,
    ' ' as trans_crg,  
    _IBD.trans_bill_no as trans_no, //Transport bill no
    _IBD.date_trans_bill as trans_date, //Transport bill date
    _IBD.netrpr5 as trans_amt, //Trucking charges
    _IBD.hlc as hlc, //Handling/ Loading Charges (
    _IBD.hatc as hatc, //Halting charges (Amount)
    _IBD.rhat as rhat, //Reason for Halting(Summary)
//Freight Forwarder
    _IBD.ff_nam as ff_nam, 
//    ' ' as ff_crg, 
    _IBD.freight_bill_no as fr_no, //Frieght bill no
    _IBD.date_of_freight as fr_dat, //Frieght date
    _IBD.fr_amt as fr_amt,
    _IBD.final as final ,
    _IBD.intdt as intdt ,
    _IBD.saldt as saldt ,
    _IBD.bondt as bondt ,
    _IBD.augdt as augdt ,
    _IBD.remrk as remrk ,
    _IBD.lsc_no as lsc_no,            //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.vade_sch as vade_sch,        //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.lsc_no1 as lsc_no1,          //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.vade_sch1 as vade_sch1,      //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.hsn_code as hsn_code,        //Added by Bhagavan on 11.09.2020    DR1K952693
    _NNDO.docnr as docnr,             //Added by Bhagavan on 25.05.2022     DR1K965918
    _NNDO.docdate as docdate,         //Added by Bhagavan on 25.05.2022     DR1K965918
    _NNDO.totval as INV_val_inr,       //Added by Bhagavan on 10.06.2022     DR1K966435
    
    _IBD.zlics_date1 as zlics_date1,  // added by kiruba
    
    _IBD.ZLICS_EXPDT1 as ZLICS_EXPDT1,  // added by kiruba DR1K982014
    _IBD.ZLICS_QTY1 as ZLICS_QTY1,      // added by kiruba DR1K982014
    _IBD.ZLICS_DATE2 as ZLICS_DATE2,    // added by kiruba DR1K982014
    _IBD.ZLICS_EXPDT2 as ZLICS_EXPDT2,  // added by kiruba DR1K982014  
    _IBD.ZLICS_QTY2 as ZLICS_QTY2,      // added by kiruba DR1K982014
    _IBD.ZLICS_DATE3 as ZLICS_DATE3,    // added by kiruba DR1K982014
    _IBD.ZLICS_EXPDT3 as ZLICS_EXPDT3,  // added by kiruba DR1K982014
    _IBD.ZLICS_QTY3 as ZLICS_QTY3,      // added by kiruba DR1K982014
    _IBD.ZLICS_DATE4 as ZLICS_DATE4,    // added by kiruba DR1K982014
    _IBD.ZLICS_EXPDT4 as ZLICS_EXPDT4,   // added by kiruba DR1K982014 
    _IBD.z1schn as z1schn               // added by kiruba DR1K982014 
        
//_CLIN.CLIN_No as CLIN_NO,
//_CLIN.refdocdt as REF_No

}
group by  _IBD.vbeln,  _IBD.erdat, _IBD.lfart, _IBD.werks, _IBD.Matnr, _IBD.posnr, _IBD.mtbez, _plantadr.padr, _IBD.vgbel, _ekko.ekgrp,
    _t024.eknam, _ekko.inco1,
    _DMDESC.description, _LFA1.name1,  
    _NNDO.landx, _NNDO.coddesc1, 
    _IBD.maktx, 
    _NNDO.portdisc, 
    _IBD.eindt, _IBD.igm_date, _IBD.igm_no, 
    _NNDO.INVOICENR, _NNDO.INVOICEDT, 
    _NNDO.INVOICEVAL, _NNDO.INVOICECUR, _NNDO.totval, _NNDO.wkurs1 ,_NNDO.BTGEW, _NNDO.ERGEI, _NNDO.CHARGEWT, _NNDO.CMEINS, _NNDO.PKGNO, 
    _NNDO.coddesc2, _NNDO.C_status, _NNDO.DELMD, _NNDO.HAWBNO, _NNDO.HAWBDT, _NNDO.MAWBNO, _NNDO.MAWBDT, _NNDO.BOLNR, _NNDO.BOLDT, _NNDO.pay_temrs, 
    _IBD.bill_entry_no, _IBD.bill_entry_date, _IBD.NETRPR4, _IBD.DATE_CARGO_CLEAR, _IBD.DATE_CARGO_BOND, _IBD.lfimg, _IBD.cust_broker_name,
    _IBD.CHA_BILL_NO, _IBD.cha_date, _IBD.netrpr2, _IBD.reason_delay, _IBD.netrpr3,
    _CLIN.tname, 
    _IBD.trans_bill_no, _IBD.date_trans_bill, _IBD.netrpr5, 
    _IBD.freight_bill_no, _IBD.date_of_freight,
    _IBD.status,_IBD.noc,_IBD.per,_IBD.bro_ad,_IBD.bro_rd,    _IBD.bnk_ad,    _IBD.bnk_rd,    _IBD.lpci,    _IBD.iocd,    _IBD.op,    _IBD.cbw_bno,    _IBD.cbw_dat,    _IBD.xcbw_xbno,
    _IBD.xcbw_xbn,    _IBD.xcbw_scd,    _IBD.xcbw_cd,    _IBD.xcbw_lpci,    _IBD.xcbw_iocd,    _IBD.xcbw_op,    _IBD.sc_nam,    _IBD.LS_No,    _IBD.val_d2l,    _IBD.CDCSO,    _IBD.cfno,
    _IBD.cqty,    _IBD.fssaino,    _IBD.fssaiqty,    _IBD.aniqno,    _IBD.aniqty,    _IBD.PQ_NO,    _IBD.PQ_qty,    _IBD.nar_no,    _IBD.nar_qty,    _IBD.adf_no,    _IBD.adf_qty,    _IBD.pcb_no,
    _IBD.pcb_qty,    _IBD.peso_no,    _IBD.peso_qty,    _IBD.cha_rec,    _IBD.cha_nrec,    _IBD.trans_nam,    _IBD.hlc,    _IBD.hatc,    _IBD.rhat,    _IBD.ff_nam,    _IBD.fr_amt,    _IBD.final,
   _IBD.intdt ,
   _IBD.saldt  , //added by arya on 23.08.2019  DR1K947105
    _IBD.bondt  , //added by arya on 23.08.2019  DR1K947105
    _IBD.augdt  , //added by arya on 23.08.2019  DR1K947105
    _IBD.remrk , //added by arya on 23.08.2019  DR1K94710533
    _IBD.zdocm,
    _IBD. ztoc,
    _IBD.zcuvrl,
    _ekpo.disub_pspnr,
    _IBD.zcuscr,
    _IBD.zdelof,
    _IBD.zrsdem,
    _IBD.lsc_no,       //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.vade_sch,     //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.lsc_no1,      //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.vade_sch1,    //Added by Bhagavan on 11.09.2020    DR1K952693
    _IBD.hsn_code,      //Added by Bhagavan on 11.09.2020    DR1K952693
    _NNDO.docnr,     //Added by Bhagavan on 25.05.2022     DR1K965918
    _NNDO.docdate,       //Added by Bhagavan on 25.05.2022     DR1K965918
    _IBD.ERNAM,           // Added by Bhagavan on 31/05/2022 "DR1k965918   
    _NNDO.totval,         //Added by Bhagavan on 10.06.2022     DR1K966435  
    _IBD.zlics_date1,      // added by kiruba
    
    _IBD.ZLICS_EXPDT1,   // added by kiruba DR1K982014
    _IBD.ZLICS_QTY1 ,  // added by kiruba DR1K982014
    _IBD.ZLICS_DATE2,  // added by kiruba DR1K982014
    _IBD.ZLICS_EXPDT2,  // added by kiruba DR1K982014  
    _IBD.ZLICS_QTY2,  // added by kiruba DR1K982014
    _IBD.ZLICS_DATE3,  // added by kiruba DR1K982014
    _IBD.ZLICS_EXPDT3,  // added by kiruba DR1K982014
    _IBD.ZLICS_QTY3,  // added by kiruba DR1K982014
    _IBD.ZLICS_DATE4,  // added by kiruba DR1K982014
    _IBD.ZLICS_EXPDT4,   // added by kiruba DR1K982014
    _IBD.z1schn          // added by kiruba DR1K982014
    
