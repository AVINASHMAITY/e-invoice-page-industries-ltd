
*$*$ ===================================================================
*$*$ Copyright Optibiz Technologies
*$*$ ===================================================================
*$*$ Author       : OptiBiz Technologies
*$*$ Creation Date:15.12.2006
*$*$ Program ID   : /OBIZ/FG_FILE_ATTCH
*$*$ Description  : File Upload Download Function Module
*$*$
*$*$ Modification History :
*$*$
*$*$ Date        By            Description
*$*$ -------------------------------------------------------------------
*$*$ 15.12.2006  9901381(SKE)  Initial Code
*&*&--------------------------------------------------------------------
*$*$ 11.01.2007     ''         Code commented(checking internal table is
*$*$                           initial and giving error message) under
*$*$                           request TIDK900542
*&*&--------------------------------------------------------------------
*$*$ 11.01.2007      ''        Code Added (Added a new perform free_alv)
*$*$                           under request TIDK900542
*$*$--------------------------------------------------------------------
*$*$ 12.01.2007       "        Code Added for checking the class object
*$*$                           is initial , before creating it.
*$*&                           under request TIDK900542
*$*$ ===================================================================


*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBAS_FILE_ATTCHTOP.           " Global Data
  INCLUDE LZBAS_FILE_ATTCHUXX.           " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE /OBIZ/LFG_FILE_ATTCHF...           " Subprograms
* INCLUDE /OBIZ/LFG_FILE_ATTCHO...           " PBO-Modules
* INCLUDE /OBIZ/LFG_FILE_ATTCHI...           " PAI-Modules

INCLUDE LZBAS_FILE_ATTCHF01.
*INCLUDE LZBFN_FILE_ATTCHF01.
*INCLUDE /OBIZ/LIMP_FILE_ATTCHF01.
*INCLUDE /OBIZ/LFG_FILE_ATTCHF01.

INCLUDE LZBAS_FILE_ATTCHO01.
*INCLUDE LZBFN_FILE_ATTCHO01.
*INCLUDE /OBIZ/LIMP_FILE_ATTCHO01.
*INCLUDE /OBIZ/LFG_FILE_ATTCHO01.

INCLUDE LZBAS_FILE_ATTCHI01.
*INCLUDE LZBFN_FILE_ATTCHI01.
*INCLUDE /OBIZ/LIMP_FILE_ATTCHI01.
*INCLUDE /OBIZ/LFG_FILE_ATTCHI01.
