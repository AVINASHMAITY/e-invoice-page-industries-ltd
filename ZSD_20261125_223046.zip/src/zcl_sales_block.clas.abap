class ZCL_SALES_BLOCK definition
  public
  final
  create public .

public section.

  interfaces BI_OBJECT .
  interfaces BI_PERSISTENT .
  interfaces IF_WORKFLOW .

  class-events CREDIT_CHECK
    exporting
      value(I_VBELN) type VBELN_VA optional .

  class-methods GET_AGENTS
    importing
      value(I_VBELN) type VBELN_VA optional
    exporting
      !EX_AGENT type PDVEMPLOYEE
      !EX_EMAIL type AD_SMTPADR .
  class-methods RELEASE_CREDIT_BLOCK
    importing
      !I_VBELN type VBELN_VA .
  class-methods CHECK
    for event CREDIT_CHECK of ZCL_SALES_BLOCK
    importing
      !I_VBELN .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SALES_BLOCK IMPLEMENTATION.


  METHOD check.

    DATA:lv_vbuk TYPE vbuk.

    break praveens.
    break wf-batch.

    SELECT SINGLE * FROM vbuk INTO lv_vbuk WHERE vbeln = i_vbeln.

    IF lv_vbuk-cmgst = 'B'.
      RAISE EVENT credit_check.
    ENDIF.

  ENDMETHOD.


  METHOD get_agents.

    DATA:li_itab TYPE STANDARD TABLE OF zsdt_crd_mail,
         lw_itab TYPE zsdt_crd_mail.

    DATA:lv_agent TYPE swp_agent.

    SELECT mandt vkorg bname smtp_addr zbname FROM zsdt_crd_mail INTO TABLE li_itab.
    IF sy-subrc = 0.
      LOOP AT li_itab INTO lw_itab.
        CONCATENATE 'US' lw_itab-bname INTO lv_agent.
        APPEND lv_agent TO ex_agent.
        CONCATENATE 'US' lw_itab-zbname INTO lv_agent.
        APPEND lv_agent TO ex_agent.
      ENDLOOP.
    ENDIF.

    IF ex_agent IS INITIAL.
      lv_agent = 'USWF-BATCH'.
      APPEND lv_agent TO ex_agent.
    ENDIF.

  ENDMETHOD.


  METHOD release_credit_block.

    DATA:lv_vbeln TYPE vbeln_va.

    CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
      EXPORTING
        input  = i_vbeln
      IMPORTING
        output = lv_vbeln.

    CALL FUNCTION 'SD_ORDER_CREDIT_RELEASE'
      EXPORTING
        vbeln = lv_vbeln
*       IF_SYNCHRON       = 'X'
      .
  ENDMETHOD.
ENDCLASS.
