FUNCTION zfm_rfc_emp_cocd.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IM_USRID) TYPE  SYSID
*"  EXPORTING
*"     VALUE(EX_BUKRS) TYPE  BUKRS
*"  EXCEPTIONS
*"      POSITION_NOT_FOUND
*"      STRUC_GET_METHOD_ERROR
*"      NO_ENTRY_FOUND
*"      USERID_NOT_MAINTAINED
*"----------------------------------------------------------------------

  SELECT SINGLE pernr
    FROM pa0105
    INTO @DATA(lv_pernr)
    WHERE usrid = @im_usrid.

  IF sy-subrc = 0.
    SELECT SINGLE bukrs
      FROM pa0001
      INTO ex_bukrs
      WHERE pernr = lv_pernr AND
            endda GE sy-datum.
  ENDIF.

ENDFUNCTION.
