*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZACTMLS.........................................*
DATA:  BEGIN OF STATUS_ZACTMLS                       .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZACTMLS                       .
CONTROLS: TCTRL_ZACTMLS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZACTMLS                       .
TABLES: ZACTMLS                        .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
