class ZCL_GST_UTILITIES definition
  public
  final
  create public .

public section.

  class-methods GET_GSTNR_FROM_BILLING_DOC
    importing
      !IV_VBELN type VBELN
      !IV_BUKRS type BUKRS
    returning
      value(RV_GSTNR) type J_1IGSTCD3 .
  class-methods GET_GSTNR_FROM_PO_DOC
    importing
      !IV_EBELN type EBELN
      !IV_BUKRS type BUKRS
    returning
      value(RV_GSTNR) type J_1IGSTCD3 .
  class-methods GET_SD_INVOICE_REFERNCE
    importing
      !IV_VBELN type VBRK-VBELN
    returning
      value(RV_XBLNR) type VBRK-XBLNR .
  class-methods GET_CUSTOMER_GST
    importing
      !IV_VBELN type VBPA-VBELN
    returning
      value(RV_STCD3) type KNA1-STCD3 .
  class-methods GET_BUYER_GST
    importing
      !IV_VBELN type VBPA-VBELN
    returning
      value(RV_STCD3) type KNA1-STCD3 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_GST_UTILITIES IMPLEMENTATION.


  METHOD get_buyer_gst.
************************************************************************
* Object Name             : GST ROLLOUT CHANGES
* Author/Company Name     : Magam Sai Sudarshan
* Functional Consultant   : Naga Ramesh / Rajashekhar
* Transport Request       : DR1K933353
* Creation Date           : 24.06.2017
************************************************************************
* Description: Copied all the Esixting Forms and Enhancemnt Validations*
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date Programmer Client Ref No. Description Correction                *
************************************************************************
    SELECT SINGLE kna1~stcd3 INTO rv_stcd3
    FROM vbpa INNER JOIN kna1
    ON   kna1~kunnr = vbpa~kunnr
    WHERE vbpa~vbeln = iv_vbeln
    AND   vbpa~parvw = 'RE'.
  ENDMETHOD.


  METHOD get_customer_gst.
************************************************************************
* Object Name             : GST ROLLOUT CHANGES
* Author/Company Name     : Magam Sai Sudarshan
* Functional Consultant   : Naga Ramesh / Rajashekhar
* Transport Request       : DR1K933353
* Creation Date           : 24.06.2017
************************************************************************
* Description: Copied all the Esixting Forms and Enhancemnt Validations*
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date Programmer Client Ref No. Description Correction                *
************************************************************************
    SELECT SINGLE kna1~stcd3 INTO rv_stcd3
      FROM vbpa INNER JOIN kna1
      ON   kna1~kunnr = vbpa~kunnr
      WHERE vbpa~vbeln = iv_vbeln
      AND   vbpa~parvw = 'WE'.
  ENDMETHOD.


  METHOD get_gstnr_from_billing_doc.
************************************************************************
* Object Name             : GST ROLLOUT CHANGES
* Author/Company Name     : Magam Sai Sudarshan
* Functional Consultant   : Naga Ramesh / Rajashekhar
* Transport Request       : DR1K933353
* Creation Date           : 24.06.2017
************************************************************************
* Description: Copied all the Esixting Forms and Enhancemnt Validations*
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date Programmer Client Ref No. Description Correction                *
************************************************************************
    SELECT SINGLE werks FROM vbrp INTO @DATA(lv_werks)
      WHERE vbeln = @iv_vbeln.
    IF sy-subrc = 0.
      SELECT SINGLE j_1bbranch FROM t001w INTO @DATA(lv_branch)
        WHERE werks = @lv_werks.
      IF sy-subrc = 0.
        SELECT SINGLE gstin FROM j_1bbranch INTO rv_gstnr
          WHERE bukrs = iv_bukrs
          AND branch = lv_branch.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD get_gstnr_from_po_doc.
************************************************************************
* Object Name             : GST ROLLOUT CHANGES
* Author/Company Name     : Magam Sai Sudarshan
* Functional Consultant   : Naga Ramesh / Rajashekhar
* Transport Request       : DR1K933353
* Creation Date           : 24.06.2017
************************************************************************
* Description: Copied all the Esixting Forms and Enhancemnt Validations*
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date Programmer Client Ref No. Description Correction                *
************************************************************************

    SELECT SINGLE werks FROM ekpo INTO @DATA(lv_werks)
      WHERE ebeln = @iv_ebeln.
    IF sy-subrc = 0.
      SELECT SINGLE j_1bbranch FROM t001w INTO @DATA(lv_branch)
        WHERE werks = @lv_werks.
      IF sy-subrc = 0.
        SELECT SINGLE gstin FROM j_1bbranch INTO rv_gstnr
          WHERE bukrs = iv_bukrs
          AND branch = lv_branch.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD get_sd_invoice_refernce.
************************************************************************
* Object Name             : GST ROLLOUT CHANGES
* Author/Company Name     : Magam Sai Sudarshan
* Functional Consultant   : Naga Ramesh / Rajashekhar
* Transport Request       : DR1K933353
* Creation Date           : 24.06.2017
************************************************************************
* Description: Copied all the Esixting Forms and Enhancemnt Validations*
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date Programmer Client Ref No. Description Correction                *
************************************************************************
    SELECT SINGLE xblnr INTO rv_xblnr FROM vbrk
      WHERE vbeln = iv_vbeln.
  ENDMETHOD.
ENDCLASS.
