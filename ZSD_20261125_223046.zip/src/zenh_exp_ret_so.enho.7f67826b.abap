"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZENH_EXP_RET_SO.
   DATA: gs_vbap TYPE vbap,
         gs_komv TYPE komv,
         lv_error  TYPE c,
         gt_exp TYPE ztt_ztabap_tvarvc.
   CONSTANTS: gc_exp VALUE 'ZENH_EXP_RET_SO' TYPE sobj_name.

   CALL METHOD zcl_abap_utility=>get_options
    EXPORTING
     im_objname = gc_exp
    IMPORTING
     ex_tab     = gt_exp.

   READ TABLE gt_exp INTO DATA(gs_exp) WITH KEY name = 'EXP_BUKRS'
                                                 low = vbak-bukrs_vf.
   IF sy-subrc IS INITIAL.
    READ TABLE gt_exp INTO gs_exp WITH KEY name = 'EXP_AUART'
                                            low = vbak-auart.
    IF sy-subrc IS INITIAL.
     READ TABLE gt_exp INTO gs_exp WITH KEY name = 'EXP_VTWEG'
                                            low = vbak-vtweg.
     IF sy-subrc IS INITIAL.
       IF vbak-vbtyp EQ 'H'.
        LOOP AT xvbap INTO gs_vbap.
         READ TABLE xkomv INTO gs_komv WITH KEY kschl  = 'ZFDB'"'JIDB'
                                                kposn  = gs_vbap-posnr .
         IF sy-subrc NE 0.
          lv_error = 'X'.
         ENDIF.
         READ TABLE xkomv INTO gs_komv WITH KEY kschl  = 'ZFDF'"'JIDF'
                                                kposn  = gs_vbap-posnr .
         IF sy-subrc NE 0.
          lv_error = 'X'.
         ENDIF.
        ENDLOOP.
        IF lv_error IS NOT INITIAL.
*         MESSAGE 'JIDB/JIDF is mandatory!' TYPE 'E'.
         MESSAGE 'ZFDB/ZFDF is mandatory!' TYPE 'E'.
        ENDIF.
       ENDIF.
    ENDIF.
   ENDIF.
  ENDIF.
ENDENHANCEMENT.
