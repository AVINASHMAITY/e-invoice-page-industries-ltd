"Name: \FU:J_1I7_USEREXIT_J1IEX_BEF_SAVE\SE:END\EI
ENHANCEMENT 0 ZSD_CALC_EXC_BASE.
***************************************************************************
* Object              :  ZSD_CALC_EXC_BASE.                                       *
* Developer           :  Kavin/Iteanz                                            *                                    *
* Created on          :  23.09.2016                                       *
* Transport           :  DR1K928720                                       *
* Description         :  Condition Price Should not Exceed Percentage
*                        Maintain in ZCMAIN *
**************************************************************************

DATA :    V_SUM   TYPE J_1IMENGE,
          V_EXBAS TYPE J_1IMENGE,
          LC_W    TYPE BAPI_MTYPE  VALUE 'E',
          LC_ID   TYPE SYMSGID VALUE 'ZSD_J1IAX',
          LC_000  TYPE SYMSGNO VALUE '001',
          LT_RET  TYPE TABLE OF BAPIRET2,
          LW_RET  TYPE BAPIRET2.


DATA : LT_CONSTANT TYPE ZTT_ZTABAP_TVARVC,
       LW_CONSTANT TYPE ZTABAP_TVARVC.

DATA : LC_PARAM    TYPE SOBJ_NAME VALUE 'J_1I7_USEREXIT_J1IEX_BEF_SAVE',
       LT_CONST    TYPE TABLE OF ZTABAP_TVARVC,
       LW_CONST    TYPE ZTABAP_TVARVC,
       LV_PO_DUTY  TYPE STRING,
       LC_EXGRP(8) VALUE 'SO_EXGRP',
       LC_YES(3)   VALUE 'YES',
       LV_SYST     TYPE SY-UCOMM.

CLEAR :V_SUM ,V_EXBAS,LW_CONST,LV_PO_DUTY,LW_CONSTANT.
REFRESH: LT_RET ,LT_CONST,LT_CONSTANT.

****************Excise Percentage
CALL METHOD ZCL_ABAP_UTILITY=>GET_PARAMETERS
  EXPORTING
    IM_OBJNAME = LC_PARAM
  IMPORTING
    EX_TAB     = LT_CONST.

*******************Excise Group
CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
  EXPORTING
    IM_OBJNAME = LC_PARAM
  IMPORTING
    EX_TAB     = LT_CONSTANT.

READ TABLE  LT_CONST INTO  LW_CONST INDEX 1.
IF SY-SUBRC EQ 0.
  LV_PO_DUTY = LW_CONST-LOW.
ENDIF.

LOOP AT T_EXCDTL.

  IF LV_PO_DUTY IS NOT INITIAL.

    V_SUM = T_EXCDTL-EXBED + T_EXCDTL-EXSED + T_EXCDTL-EXAED   + T_EXCDTL-NCCD    + T_EXCDTL-ECS + T_EXCDTL-EXADDTAX1 .

    V_EXBAS = ( T_EXCDTL-EXBAS * LV_PO_DUTY ) / 100 .

    READ TABLE LT_CONSTANT INTO LW_CONSTANT
            WITH KEY   OBJ_NAME = LC_PARAM
                       NAME     = LC_EXGRP
                       LOW      = T_EXCDTL-EXGRP.
    IF SY-SUBRC EQ 0.

      IF V_SUM GT  V_EXBAS.
        LW_RET-TYPE     =  LC_W.
        LW_RET-ID       =  LC_ID.
        LW_RET-NUMBER   =  LC_000.
        LW_RET-MESSAGE  =  T_EXCDTL-ZEILE.
        APPEND LW_RET TO LT_RET.
        CLEAR LW_RET.
      ENDIF.
    ENDIF.
  ENDIF.
ENDLOOP.

IF LT_RET  IS NOT INITIAL.
  LV_SYST = SY-UCOMM.
  CALL FUNCTION 'FINB_BAPIRET2_DISPLAY'
    EXPORTING
      IT_MESSAGE = LT_RET.

  LOOP AT LT_RET INTO LW_RET.
    IF LV_SYST EQ LC_YES.
      MESSAGE A000(ZSD_J1IAX) WITH  LV_PO_DUTY LW_RET-MESSAGE .
    ELSE.
      MESSAGE E000(ZSD_J1IAX) WITH  LV_PO_DUTY LW_RET-MESSAGE .
    ENDIF.
  ENDLOOP.
ENDIF.
CLEAR  LV_SYST.
ENDENHANCEMENT.
