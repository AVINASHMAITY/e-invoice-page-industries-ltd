*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_SD_CVDTOP.                    " Global Data
  INCLUDE LZFG_SD_CVDUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_SD_CVDF...                    " Subroutines
* INCLUDE LZFG_SD_CVDO...                    " PBO-Modules
* INCLUDE LZFG_SD_CVDI...                    " PAI-Modules
* INCLUDE LZFG_SD_CVDE...                    " Events
* INCLUDE LZFG_SD_CVDP...                    " Local class implement.
* INCLUDE LZFG_SD_CVDT99.                    " ABAP Unit tests
