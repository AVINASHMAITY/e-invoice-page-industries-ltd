"Name: \PR:SAPMV50A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_AVLCHK_BATCH.
*&---------------------------------------------------------------------*
*Date       : 10.05.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K945224                                               *
*Description: Validation of Batch quantity and checking Batch approved *
*             or not in VL01N & VL02N                                  *
*&---------------------------------------------------------------------*
READ TABLE xvbap INTO DATA(ls_vbap) WITH KEY bedae = 'ZR'.
IF sy-subrc EQ 0.
  CONSTANTS : lc_vl01n TYPE tcode VALUE 'VL01N',
              lc_vl02n TYPE tcode VALUE 'VL02N'.
  CONSTANTS : lc_prg       TYPE sobj_name VALUE 'ZSD_BATCH_AVAIL_CHECK',
              lc_avail(15) VALUE 'PLANT_BATCH'.
  DATA : lt_con  TYPE ztt_ztabap_tvarvc,
         lw_con  TYPE ztabap_tvarvc,
         gt_lips TYPE TABLE OF lipsvb,
         gs_lips TYPE lipsvb,
         lt_mska TYPE TABLE OF mska,
         ls_mska TYPE mska,
         lv_msg  TYPE string,
         lv_qty  TYPE labst,
         lv_int  TYPE i.

  TYPES : BEGIN OF ty_qals,
            prueflos  TYPE qplos,
            herkunft  TYPE qherk,
            enstehdat TYPE qentst,
            charg     TYPE charg_d,
          END OF ty_qals.

  DATA : lt_qals TYPE TABLE OF ty_qals,
         ls_qals TYPE ty_qals.

  TYPES : BEGIN OF ty_qave,
            prueflos TYPE qplos,
            kzart    TYPE qkzart,
            zaehler  TYPE qvezaehler,
            vcode    TYPE qvcode,
          END OF ty_qave.

  DATA : lt_qave TYPE TABLE OF ty_qave,
         ls_qave TYPE ty_qave.

  IF sy-tcode EQ lc_vl01n OR sy-tcode EQ lc_vl02n.
    "Logic for Availability check:
    CLEAR : lw_con.
    CALL METHOD zcl_abap_utility=>get_options
      EXPORTING
        im_objname = lc_prg
      IMPORTING
        ex_tab     = lt_con.

    gt_lips[] = xlips[].
*    DELETE gt_lips WHERE posnr+0(1) NE '9'.
    IF gt_lips IS NOT INITIAL.
      SELECT * FROM mska INTO TABLE lt_mska
             FOR ALL ENTRIES IN gt_lips
             WHERE vbeln EQ gt_lips-vbelv
               AND posnr EQ gt_lips-posnv.

      SELECT prueflos herkunft enstehdat charg
             FROM qals INTO TABLE lt_qals
             FOR ALL ENTRIES IN gt_lips
             WHERE herkunft EQ '04'
               AND charg EQ gt_lips-charg.
      SORT lt_qals DESCENDING BY enstehdat.
      IF lt_qals IS NOT INITIAL.
        SELECT prueflos kzart zaehler vcode
               FROM qave INTO TABLE lt_qave
               FOR ALL ENTRIES IN lt_qals
               WHERE prueflos EQ lt_qals-prueflos.
      ENDIF.
    ENDIF.
    LOOP AT xvbap INTO ls_vbap WHERE bedae = 'ZR'.
      READ TABLE lt_con INTO lw_con
             WITH KEY   obj_name = lc_prg
                        name     = lc_avail
                        low      = ls_vbap-werks.
      IF sy-subrc = 0.
        CLEAR : lv_qty.
        gt_lips[] = xlips[].
        DELETE gt_lips WHERE posnv NE ls_vbap-posnr.
        DELETE gt_lips WHERE updkz EQ 'D'.
        DESCRIBE TABLE gt_lips LINES lv_int.
        IF lv_int GT 1.
          DELETE gt_lips WHERE posnr EQ ls_vbap-posnr.
        ENDIF.
        LOOP AT gt_lips INTO gs_lips WHERE vbelv = ls_vbap-vbeln
                                       AND posnv = ls_vbap-posnr.
          IF gs_lips-charg IS NOT INITIAL.
            READ TABLE lt_mska INTO ls_mska WITH KEY matnr = gs_lips-matnr
                                                     werks = gs_lips-werks
                                                     lgort = gs_lips-lgort
                                                     charg = gs_lips-charg
                                                     sobkz = 'E'
                                                     vbeln = gs_lips-vbelv
                                                     posnr = gs_lips-posnv.
            IF sy-subrc EQ 0.

              READ TABLE lt_qals INTO ls_qals WITH KEY charg = gs_lips-charg.
              IF sy-subrc EQ 0.
                READ TABLE lt_qave INTO ls_qave WITH KEY prueflos = ls_qals-prueflos.
                IF sy-subrc EQ 0.
                  IF ls_qave-vcode = 'A0' OR ls_qave-vcode = 'A' OR ls_qave-vcode = 'W0'.
                  ELSE.
                    CLEAR : lv_msg.
                    lv_msg = 'Batch' && ` ` && gs_lips-charg && ` ` && 'is not approved'.
                    MESSAGE lv_msg TYPE 'E'.
                  ENDIF.
                ELSE.
                  CLEAR : lv_msg.
                  lv_msg = 'Batch' && ` ` && gs_lips-charg && ` ` && 'is not approved'..
                  MESSAGE lv_msg TYPE 'E'.
                ENDIF.
              ELSE.

              ENDIF.
            ELSE.
              CLEAR : lv_msg.
              lv_msg = 'Line Item' && ` ` && gs_lips-posnr && ` ` && 'are not matching'.
              MESSAGE lv_msg TYPE 'E'.
            ENDIF.
            IF gs_lips-lfimg IS NOT INITIAL.
              lv_qty = lv_qty + gs_lips-lfimg.
            ENDIF.
          ENDIF.
        ENDLOOP.
*        IF lv_qty IS NOT INITIAL.
*          IF ls_vbap-kwmeng GT lv_qty.
*            CLEAR : lv_msg.
*            lv_msg = 'Batch quantity is not sufficient'.
*            MESSAGE lv_msg TYPE 'E'.
*          ENDIF.
*        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
