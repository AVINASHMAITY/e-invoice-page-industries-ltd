*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZACTMLS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZACTMLS             .

  PERFORM TABLEPROC.

ENDFUNCTION.
