*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBPI_CUSTGRP....................................*
DATA:  BEGIN OF STATUS_ZBPI_CUSTGRP                  .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBPI_CUSTGRP                  .
CONTROLS: TCTRL_ZBPI_CUSTGRP
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBPI_CUSTGRP                  .
TABLES: ZBPI_CUSTGRP                   .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
