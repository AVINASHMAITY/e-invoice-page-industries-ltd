class ZCL_IM_CUST_CREDIT_CHANGE definition
  public
  final
  create public .

public section.

  interfaces IF_EX_IDOC_DATA_MAPPER .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_CUST_CREDIT_CHANGE IMPLEMENTATION.


  method if_ex_idoc_data_mapper~process.

*&------------------------------------------------------------------------
* Object Name       : ZCUST_CREDIT_CHANGE
* Author/Company    : Lokesh/iteanz
* Transport Req     : DR1K923623
* Creation date     : 10.12.2015
*---------------------------------------------------------------------
** Description of Development
* Corrections in Customer Credit value while sending from MDG to ECC
*---------------------------------------------------------------------

    data : obj type sobj_name value 'ZCUST_CREDIT_CHANGE'.


    types : begin of st_const,
              c_mestyp    type edi_mestyp,
              c_idoc      type edi_idoctp,
              c_seg_kna1m type edi_segnam,
              c_seg_knvvm type edi_segnam,
              c_stamid    type edi_stamid,
              c_stamno    type edi_stamno,
              c_klimg(16),
              c_klime(16),
              c_waers     type waers,
              c_dlaus     type dlaus,
              c_klimk(16),
              c_seg_knkam type edi_segnam,
              c_seg_knkkm type edi_segnam,
            end of st_const.


    data : lt_global type table of  ztabap_tvarvc,
           ls_global type ztabap_tvarvc.

    data : lt_const type table of st_const,
           ls_const type st_const.


    data : ls_kna1m type e1kna1m,
           ls_knvvm type e1knvvm.

    data : lt_sdt006 type table of zsdt006,
           ls_sdt006 type zsdt006.

    data : ls_knka type knka,
           ls_knkk type knkk.

    data : lt_idoc type tab_edidd,
           ls_idoc type edid4.

    data : ls_zacc type zaccgroup.
    data : ls_change type idoc_chang.

    data :  num  type idocdsgnum,
            num1 type idocdsgnum.

    field-symbols : <lx_const> type any.

    refresh lt_global.
    clear: ls_global,
           ls_const.

    select * from ztabap_tvarvc into table lt_global where obj_name = obj.
    if sy-subrc eq 0.
      sort lt_global by id.

      loop at lt_global into ls_global.
        unassign <lx_const>.
        assign component sy-tabix
               of structure ls_const
                   to <lx_const>.

        if <lx_const> is assigned.
          <lx_const> = ls_global-low.
        endif.
        clear ls_global.
      endloop.

      if control-mestyp = ls_const-c_mestyp and
         control-idoctp = ls_const-c_idoc.


        if data is not initial.

          clear : ls_idoc,
                  ls_knkk,
                  ls_knka,
                  ls_sdt006,
                  ls_zacc,
                  ls_knvvm,
                  ls_kna1m,
                  ls_idoc,
                  num,
                  num1.


          loop at data into ls_idoc.
            case ls_idoc-segnam.
*            when 'E1KNA1M'.
              when ls_const-c_seg_kna1m.
                ls_kna1m = ls_idoc-sdata.
*            when 'E1KNVVM' .
              when ls_const-c_seg_knvvm.
                ls_knvvm = ls_idoc-sdata .
            endcase.
            clear ls_idoc.
          endloop.


          read table data into ls_idoc  with key segnam = ls_const-c_seg_knkam."'E1KNKAM'.
          if sy-subrc eq 0.
            num = ls_idoc-segnum.
          endif.

          clear ls_idoc.
          read table data into ls_idoc  with key segnam = ls_const-c_seg_knkkm.  "'E1KNKKM'.
          if sy-subrc eq 0.
            num1 = ls_idoc-segnum.
          endif.

          clear ls_zacc.
          select single * from zaccgroup into ls_zacc where ktokd = ls_kna1m-ktokd.
          if sy-subrc eq 0.
            clear ls_sdt006.
            select single * from zsdt006 into ls_sdt006
                                     where vkorg = ls_knvvm-vkorg
                                     and vtweg = ls_knvvm-vtweg .
            if sy-subrc eq 0.


              select single * from knkk into ls_knkk where kunnr = ls_kna1m-kunnr and
                                                           kkber = ls_sdt006-kkber.

              select single * from knka into ls_knka where kunnr = ls_kna1m-kunnr.

              if ls_knkk is initial and
                 ls_knka is initial.

                have_to_change = 'X'.

                protocol-stamid = ls_const-c_stamid.
                protocol-stamno = ls_const-c_stamno.



                ls_change-segnum =  num .                   "'000016'.
                ls_change-feldname = ls_const-c_klimg.
                ls_change-value   = ' '.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.

                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_klime.        " 'KLIME'.
                ls_change-value   = ' '.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.


                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_waers.        "'WAERS'.
                ls_change-value   = ' '.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.

                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_dlaus.        "'DLAUS'.
                ls_change-value   = ' '.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.

                ls_change-segnum = num1.                    " '000017'.
                ls_change-feldname = ls_const-c_klimk.        "'KLIMK'.
                ls_change-value   = ls_sdt006-klimk.
                condense ls_change-value.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.

              else.

                have_to_change = 'X'.

                protocol-stamid = ls_const-c_stamid.          "'B1'.
                protocol-stamno = ls_const-c_stamno.          "'005'.

                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_klimg.        "'KLIMG'.
                ls_change-value   = ls_knka-klimg.
                condense ls_change-value.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.

                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_klime.        "'KLIME'.
                ls_change-value   =  ls_knka-klime.
                condense ls_change-value.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.


                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_waers.        "'WAERS'.
                ls_change-value   = ls_knka-waers.
                condense ls_change-value.
                ls_change-save_type = 'X'.


                ls_change-segnum = num.                     "'000016'.
                ls_change-feldname = ls_const-c_dlaus.        "'DLAUS'.
                ls_change-value   = ls_knka-dlaus.
                condense ls_change-value.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.


                ls_change-segnum = num1.                    "'000017'.
                ls_change-feldname = ls_const-c_klimk.        "'KLIMK'.
                ls_change-value   = ls_knkk-klimk.
                condense ls_change-value.
                ls_change-save_type = 'X'.

                append ls_change to mapping_tab.
                clear ls_change.

              endif.
            endif.
          endif.
        endif.
      endif.
    endif.
  endmethod.
ENDCLASS.
