class ZCL_IM_SD_FREIGHT_TAX definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ACC_DOCUMENT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_SD_FREIGHT_TAX IMPLEMENTATION.


  METHOD if_ex_acc_document~change.
    DATA: wa_extension TYPE bapiparex.
    DATA: wa_wtax  TYPE accit_wt,
          ls_accit TYPE accit.
    FIELD-SYMBOLS <fs_accit> TYPE accit.
    DATA:c_ext TYPE TABLE OF bapiparex,
         w_ext TYPE bapiparex.
    DESCRIBE TABLE c_extension2 LINES DATA(lines).
    DATA(lines2) = lines / 2.

    LOOP AT c_extension2 INTO wa_extension.
      IF wa_extension-structure = 'ZBUSSEC'.
        LOOP AT c_accit ASSIGNING <fs_accit>.
          <fs_accit>-bupla = wa_extension-valuepart1.
          <fs_accit>-secco = wa_extension-valuepart2.
        ENDLOOP.
      ENDIF.

      IF wa_extension-structure = 'ZWTAX'.
        wa_wtax-wt_key    = wa_extension-valuepart1.
        wa_wtax-witht     = wa_extension-valuepart2.
        wa_wtax-wt_withcd = wa_extension-valuepart3.
        APPEND wa_wtax TO c_accwt.
        READ TABLE c_accit ASSIGNING <fs_accit> WITH KEY koart = 'K'.
        IF sy-subrc = 0.
          <fs_accit>-wt_key = wa_wtax-wt_key.
        ENDIF.
      ENDIF.
*********Begin of Changes by Ravi on 27.02.2019 DR1K943026***************
      "Below HSN code imported from 'ZFI_PARK_GP Tcode
      IF wa_extension-structure = 'HSN_CODE'.
        READ TABLE c_accit INTO ls_accit INDEX 1.
        IF sy-subrc EQ 0.
          LOOP AT c_accit ASSIGNING <fs_accit> WHERE xblnr EQ ls_accit-xblnr.
            <fs_accit>-hsn_sac = wa_extension-valuepart2.
          ENDLOOP.
        ENDIF.
      ENDIF.

      IF wa_extension-structure = 'TRADING_PARTNER'.
        READ TABLE c_accit INTO ls_accit INDEX 1.
        IF sy-subrc EQ 0.
          LOOP AT c_accit ASSIGNING <fs_accit> WHERE xblnr EQ ls_accit-xblnr.
            <fs_accit>-vbund = wa_extension-valuepart2.
          ENDLOOP.
        ENDIF.
      ENDIF.

      IF wa_extension-structure = 'ORDER'.
        READ TABLE c_accit INTO ls_accit INDEX 1.
        IF sy-subrc EQ 0.
          LOOP AT c_accit ASSIGNING <fs_accit> WHERE xblnr EQ ls_accit-xblnr.
            <fs_accit>-aufnr = wa_extension-valuepart2.
          ENDLOOP.
        ENDIF.
      ENDIF.

      IF wa_extension-structure = 'PROFIT_CENTER'.
        READ TABLE c_accit INTO ls_accit INDEX 1.
        IF sy-subrc EQ 0.
          LOOP AT c_accit ASSIGNING <fs_accit> WHERE xblnr EQ ls_accit-xblnr.
            <fs_accit>-prctr = wa_extension-valuepart2.
          ENDLOOP.
        ENDIF.
      ENDIF.
*      *********End of Changes by Ravi on 27.02.2019 DR1K943026***************
      "Code begin by lakshmi/iteanz "24.06.2021
      DATA:lines1 TYPE char10,
           d1     TYPE char5.
      IF wa_extension-structure = 'POSTING_KEY'.
        CLEAR ls_accit.
        IF d1 < lines2.
          d1 = d1 + 1.
        ENDIF.
        READ TABLE c_accit INTO ls_accit INDEX d1."1.
        IF sy-subrc EQ 0.
          SORT c_accit BY hkont.
          LOOP AT c_accit ASSIGNING <fs_accit> WHERE xblnr EQ ls_accit-xblnr
                                                 AND posnr EQ ls_accit-posnr.
*            IF <fs_accit>-hkont IS NOT INITIAL.
            IF wa_extension-valuepart4  IS NOT INITIAL.
              <fs_accit>-bschl = wa_extension-valuepart2.
              <fs_accit>-shkzg = wa_extension-valuepart3.
            ELSE."IF <fs_accit>-kunnr IS NOT INITIAL..
              <fs_accit>-bschl = wa_extension-valuepart2.
              <fs_accit>-shkzg = wa_extension-valuepart3.
            ENDIF.
*            IF <fs_accit>-koart = 'S'.
*              <fs_accit>-shkzg = 'S'.
*            ELSE.
*              <fs_accit>-shkzg = 'H'.
*            ENDIF.
          ENDLOOP.
          UNASSIGN <fs_accit>.
        ENDIF.
      ENDIF.
      IF wa_extension-structure = 'HOUSE_BANK'.
        SORT c_accit."BY hkont." DESCENDING.
        READ TABLE c_accit INTO ls_accit with key posnr = wa_extension-valuepart4."INDEX  1."sy-tabix.

        IF sy-subrc EQ 0.

          LOOP AT c_accit ASSIGNING <fs_accit> WHERE  xblnr EQ ls_accit-xblnr
            AND posnr EQ ls_accit-posnr.
            <fs_accit>-hbkid = wa_extension-valuepart2.
          ENDLOOP.
        ENDIF.
      ENDIF.
      "Code ended by lakshmi/iteanz "24.06.2021
    ENDLOOP.
  ENDMETHOD.


  METHOD if_ex_acc_document~fill_accit.


ENDMETHOD.
ENDCLASS.
