*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZEM_COUNTRIES
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZEM_COUNTRIES       .

  PERFORM TABLEPROC.

ENDFUNCTION.
