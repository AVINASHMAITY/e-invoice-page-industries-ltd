*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_GET_LOGDATATOP.               " Global Data
  INCLUDE LZFG_GET_LOGDATAUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_GET_LOGDATAF...               " Subroutines
* INCLUDE LZFG_GET_LOGDATAO...               " PBO-Modules
* INCLUDE LZFG_GET_LOGDATAI...               " PAI-Modules
* INCLUDE LZFG_GET_LOGDATAE...               " Events
* INCLUDE LZFG_GET_LOGDATAP...               " Local class implement.
* INCLUDE LZFG_GET_LOGDATAT99.               " ABAP Unit tests
