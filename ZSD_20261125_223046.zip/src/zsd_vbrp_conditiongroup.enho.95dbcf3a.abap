"Name: \PR:SAPMV60A\FO:CUST_ITEM_ACTIVATE\SE:END\EI
ENHANCEMENT 0 ZSD_VBRP_CONDITIONGROUP.
break sahoo.
 if XVBRK-VBTYP = 'U' or XVBRK-VBTYP = '5'.
LOOP AT SCREEN .

  If Screen-Name Eq 'TABSTRIP_TAB07'.
    GS_CUST_TAB-item_Caption = 'Codition Group'.
    GS_CUST_TAB-item_program = 'ZVBRP_CONDITIONGROUP'.
    GS_CUST_TAB-item_Dynpro = '0001'.
    if not GS_CUST_TAB-item_Dynpro  is INITIAL.
      Screen-active = 1.
      screen-invisible = 0.
      modify screen.
      TABSTRIP_TAB07 = GS_CUST_TAB-ITEM_CAPTION.
    endif.
  endif.

endloop.
endif.

ENDENHANCEMENT.
