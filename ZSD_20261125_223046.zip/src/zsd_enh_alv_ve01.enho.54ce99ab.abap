"Name: \PR:SAPLV50G\FO:CREATE_ALV_GRID_2100\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENH_ALV_VE01.
*Enhancement for adding extra fields in VE01 output screen
  IF sy-tcode = 'ZVE01' AND sy-cprog = 'RVEXST00'.
    FIELD-SYMBOLS:<fs_ls_veiav> TYPE veiav.
    ASSIGN ('(RVEXST00)veiav') TO <fs_ls_veiav>.

    LOOP AT selection_log_tab ASSIGNING FIELD-SYMBOL(<fs_log>).
      <fs_log>-werksland = <fs_ls_veiav>-werksland.
      <fs_log>-lieferbed = <fs_ls_veiav>-lieferbed.
      <fs_log>-artgescha = <fs_ls_veiav>-artgescha.
      <fs_log>-verkehrzw = <fs_ls_veiav>-verkehrzw.
      <fs_log>-ursprslnd = <fs_ls_veiav>-ursprslnd.
      <fs_log>-verfahren = <fs_ls_veiav>-verfahren.
    ENDLOOP.
  ENDIF.

ENDENHANCEMENT.
