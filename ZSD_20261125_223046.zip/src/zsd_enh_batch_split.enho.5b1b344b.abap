"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBEP\SE:END\EI
ENHANCEMENT 0 ZSD_ENH_BATCH_SPLIT.
*Break sahoo.
* BREAK pushpa.
****  IF sy-tcode = 'VA01' or sy-tcode = 'VA02'.
****
****
****  IF vbak-auart = 'YBOR'.
****
****BREAK mehar.
**** data : lt_str TYPE TABLE OF string,
****        lw_str TYPE string,
****        lv_temp type SMENG,
****        lv_temp1 type SMENG,
****        lv_index TYPE i,
****        lw_vbap TYPE vbap,
****        lw_vbep TYPE vbep,
****        lw_ivbap like ivbap.
****
****  TYPES : BEGIN OF ty_knvv,
****            KUNNR  TYPE KUNNR,
****            VKORG  TYPE VKORG,
****            VTWEG  TYPE VTWEG,
****            SPART  TYPE SPART,
****            INCO1  TYPE INCO1,
****            INCO2  TYPE INCO2,
****          END OF ty_knvv,
****          BEGIN OF ty_mara,
****            matnr TYPE matnr,
****            MTART  TYPE MTART,
****            MBRSH  TYPE MBRSH,
****            MATKL  TYPE MATKL,
****            MEINS  TYPE MEINS,
****          END OF ty_mara,
****          BEGIN OF ty_marc,
****            MATNR TYPE MATNR,
****            WERKS TYPE WERKS_D,
****            MTVFP TYPE MTVFP,
****          end of ty_marc,
****          BEGIN OF ty_qty1,
****          posnr TYPE posnr,
****          matnr TYPE matnr,
****          WERKS  TYPE WERKS_D,
****          qty TYPE char13,
****        END OF ty_qty1.
****
****
**** data : lt_COLUMNS TYPE TABLE OF HELP_VALUE,
****        lw_columns type HELP_VALUE,
****        lt_qty1 TYPE TABLE OF ty_qty1,
****        lw_qty1 TYPE ty_qty1.
****
**** data : lw_knvv TYPE ty_knvv,
****        lw_mara TYPE ty_mara,
****        lw_T683C TYPE T683C,
****        lw_marc TYPE ty_marc,
****        i_BDBATCH TYPE TABLE OF BDBATCH,
****        w_BDBATCH TYPE BDBATCH.
**** data : w_KOMKH TYPE KOMKH,
****        w_KOMPH TYPE KOMPH,
****        w_BDCOM TYPE BDCOM.
*****
************ determine batch and stock
****SELECT SINGLE KUNNR VKORG VTWEG SPART INCO1 INCO2
****  INTO lw_knvv
****  FROM knvv
****  WHERE KUNNR = xvbak-kunnr
****    and VKORG = xvbak-VKORG
****    and VTWEG = xvbak-VTWEG
****    and SPART = xvbak-SPART.
****
****  SELECT SINGLE matnr MTART MBRSH MATKL MEINS
****    INTO lw_mara
****    FROM mara
****    WHERE matnr = vbap-matnr.
****
****  SELECT SINGLE * INTO lw_T683C
****    FROM T683C
****    WHERE VKORG = xvbak-VKORG
****      and VTWEG = xvbak-vtweg
****      and SPART = xvbak-SPART
****      and AUART = xvbak-auart
****      and KZCHP = 'X'.
****
****  SELECT SINGLE MATNR WERKS MTVFP
****    INTO lw_marc
****    FROM marc
****    WHERE matnr = vbap-matnr
****      and werks = vbap-werks.
****
**** w_KOMKH-mandt = sy-mandt.
**** w_KOMKH-KNDNR = xvbak-kunnr.
**** w_KOMKH-KNRZE = xvbak-kunnr.
**** w_KOMKH-KUNWE = xvbak-kunnr.
**** w_KOMKH-KUNNR = xvbak-kunnr.
**** w_KOMKH-VKORG = xvbak-VKORG.
**** w_KOMKH-VTWEG = xvbak-VTWEG.
**** w_KOMKH-SPART = xvbak-SPART.
**** w_KOMKH-AUART = xvbak-AUART.
**** w_KOMKH-VSBED = xvbak-VSBED.
**** w_KOMKH-AUART_SD = xvbak-AUART.
**** w_KOMKH-inco1 = vbkd-inco1.
**** w_KOMKH-inco2 = vbkd-inco2.
**** w_KOMKH-LAND1 = TVKO_SADR-land1.
**** w_KOMKH-REGIO = TVKO_SADR-REGIO.
****
**** w_KOMPH-MATNR = vbap-matnr.
**** w_KOMPH-WERKS = vbap-werks.
**** w_KOMPH-LGORT = vbap-lgort.
**** w_KOMPH-VSTEL = vbap-vstel.
**** w_KOMPH-KONDM = vbap-KONDM.
**** w_KOMPH-MATKL = vbap-MATKL.
**** w_KOMPH-SPARP = xvbak-SPART.
**** w_KOMPH-MTART = lw_mara-mtart.
**** w_KOMPH-mbrsh = lw_mara-mbrsh.
****
****
**** w_BDCOM-KAPPL = 'V'.
**** w_BDCOM-KALSM = T683C-KALSM.
**** w_BDCOM-MENGE = VBEP-WMENG.
**** w_BDCOM-MEINS = vbap-meins.
**** w_BDCOM-ERFMG = vbap-zmeng.
**** w_BDCOM-ERFME = vbap-meins.
**** w_BDCOM-MBDAT = sy-datum.
**** w_BDCOM-LFDAT = sy-datum.
**** w_BDCOM-UMREZ = vbap-UMVKZ.
**** w_BDCOM-UMREN = vbap-umvkn.
**** w_BDCOM-KZVBP = 'X'.
**** w_BDCOM-MTVFP = lw_marc-MTVFP.
**** w_BDCOM-PRREG = 'A'.
**** w_BDCOM-BEDAR = t459a-BEDAR.
**** w_BDCOM-OBJID = 'VBAP'.
**** w_BDCOM-ATP_TRTYP = 'H'.
**** w_BDCOM-KUND1 = xvbak-kunnr.
**** w_BDCOM-LAND1 = TVKO_SADR-land1.
**** w_bdcom-NODIA = 'X'.
****
****CALL FUNCTION 'VB_BATCH_DETERMINATION'
****  EXPORTING
****   I_KOMKH                       = w_KOMKH
****    i_komph                       = w_KOMPH
****    x_bdcom                       = w_BDCOM
***** IMPORTING
*****   E_PROBLEMS                    =
*****   X_BDCOM                       =
****  TABLES
*****   I_BDBATCH                     =
****    e_bdbatch                     = i_BDBATCH
*****   I_MDVA                        =
*****   E_MDVA                        =
*****   I_CHARA                       =
*****   E_CHARA                       =
*****   I_ATPCSX                      =
*****   E_ATPCSX                      =
*****   E_MDVEX                       =
*****   I_ATPREX                      =
*****   I_ATPFIELD                    =
**** EXCEPTIONS
****   NO_MATERIAL                   = 1
****   NO_PLANT                      = 2
****   NO_APPLICATION                = 3
****   FUNCTION_NOT_POSSIBLE         = 4
****   CONDITION_NOT_FOUND           = 5
****   CLASSTYPE_NOT_FOUND           = 6
****   CLASSTYPE_NOT_ACTIVE          = 7
****   NO_BASE_UNIT                  = 8
****   NO_UNIT                       = 9
****   CONVERSION_NOT_FOUND          = 10
****   CONVERSION_OVERFLOW           = 11
****   MISSING_ENTRY_T156C           = 12
****   CONVERSION_TYPE_INVALID       = 13
****   DIVISION_BY_ZERO              = 14
****   DATA_MISMATCH                 = 15
****   MATERIAL_NOT_FOUND            = 16
****   NO_QUANTITY                   = 17
****   INVALID_DUPLICATE_BATCH       = 18
****   OTHERS                        = 19
****          .
****IF sy-subrc <> 0.
***** Implement suitable error handling here
****ENDIF.
*****delete i_BDBATCH where lgort = '1014'.
****READ TABLE i_BDBATCH INTO w_BDBATCH with key lgort = '1014'.
****if sy-subrc = 0.
****  refresh i_BDBATCH.
****endif.
****if i_BDBATCH is INITIAL.
****      READ TABLE xvbep INTO lw_vbep
****        with key posnr = vbap-posnr.
****      IF ( sy-subrc = 0 and lw_vbep-wmeng > vbep-WMENG )
****         or sy-subrc <> 0.
****
****      lv_temp = vbep-WMENG.
****      CLEAR lv_temp1.
****        READ TABLE i_BDBATCH INTO w_BDBATCH INDEX 1.
****        IF sy-subrc = 0.
*****         if w_BDBATCH-lgort = '1014'.
*****           clear: w_BDBATCH-lgort,w_BDBATCH-CHARG,w_BDBATCH-BWTAR,w_BDBATCH-vrfmg,w_BDBATCH-menge,w_BDBATCH-erfmg.
*****         endif.
****        IF w_BDBATCH-VRFMG < lv_temp.
****            clear lw_qty1.
****             lv_temp = lv_temp - w_BDBATCH-VRFMG.
****
****             IF lv_temp1 is INITIAL.
****               lv_temp1 = w_BDBATCH-VRFMG .
****             ENDIF.
****            vbep-WMENG = w_BDBATCH-VRFMG.
****
****            DESCRIBE TABLE xvbap LINES lv_index.
****            READ TABLE xvbap INTO lw_vbap INDEX lv_index.
****            IF sy-subrc = 0.
****              lw_vbap-POSNR = lw_vbap-POSNR + 10.
****              APPEND lw_vbap to xvbap.
****              lw_qty1-qty = lv_temp.
****              lw_qty1-posnr = lw_vbap-POSNR.
****              lw_qty1-matnr = lw_vbap-matnr.
****              lw_qty1-WERKS = lw_vbap-werks.
****
****              APPEND lw_qty1 to lt_qty1.
****              clear : lw_vbap,lw_qty1.
****              DESCRIBE TABLE lt_qty1 LINES lv_index.
****              lv_index = lv_index - 1.
****              READ TABLE lt_qty1 INTO lw_qty1
****                index lv_index.
****              IF sy-subrc = 0.
****                lw_qty1-qty = vbep-WMENG.
****                MODIFY lt_qty1 FROM lw_qty1 INDEX lv_index.
****              ENDIF.
****            ENDIF.
****            DESCRIBE TABLE ivbap LINES lv_index.
****            READ TABLE ivbap into lw_ivbap INDEX lv_index.
****            IF sy-subrc = 0.
****              lw_ivbap-posnr = lw_ivbap-posnr + 10.
****              lw_ivbap-tabix = lw_ivbap-tabix + 1.
****              APPEND lw_ivbap to ivbap.
****              clear lw_ivbap.
****            ENDIF.
****        ENDIF.
****        ENDIF.
****      IF lv_temp1 is NOT INITIAL.
****         vbep-WMENG = lv_temp1.
****      ENDIF.
****
****      LOOP AT lt_qty1 INTO lw_qty1.
****        lw_str = lw_qty1-qty.
****
****        CONCATENATE lw_qty1-POSNR lw_qty1-matnr
****        lw_qty1-werks lw_str INTO lw_str.
****        APPEND lw_str to lt_str.
****        CLEAR lw_str.
****      ENDLOOP.
****
****      lw_columns-TABNAME = 'VBAP'.
****      lw_columns-FIELDNAME = 'POSNR'.
****      lw_columns-SELECTFLAG = 'X'.
****      APPEND lw_columns to lt_columns.
****      lw_columns-FIELDNAME = 'MATNR'.
****      APPEND lw_columns to lt_columns.
****      lw_columns-FIELDNAME = 'WERKS'.
****      APPEND lw_columns to lt_columns.
****      lw_columns-FIELDNAME = 'SMENG'.
****      APPEND lw_columns to lt_columns.
****      clear lw_columns.
****
****      CALL FUNCTION 'MD_POPUP_SHOW_INTERNAL_TABLE'
****        EXPORTING
****          title         = 'Please Consider Following Quantity'
*****       IMPORTING
*****         INDEX         =
****        tables
****          values        = lt_str
****          columns       = lt_columns
****       EXCEPTIONS
****         LEAVE         = 1
****         OTHERS        = 2
****                .
****      IF sy-subrc <> 0.
***** Implement suitable error handling here
*****          MESSAGE E000(ZPP_MESSAGE) WITH
*****          'Error while popup message'.
****      ENDIF.
****       ELSE.
****   MESSAGE I000(ZPP_MESSAGE) WITH 'Batch Alreday Determine'.
**** ENDIF.
****
****endif.
****ENDIF.
****endif.
ENDENHANCEMENT.
