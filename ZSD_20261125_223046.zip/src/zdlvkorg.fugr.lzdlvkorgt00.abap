*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZDLVKORG........................................*
DATA:  BEGIN OF STATUS_ZDLVKORG                      .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZDLVKORG                      .
CONTROLS: TCTRL_ZDLVKORG
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZDLVKORG                      .
TABLES: ZDLVKORG                       .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
