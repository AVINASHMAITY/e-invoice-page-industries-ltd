"Name: \PR:SAPFV45E\FO:VBEP-WMENG_PRUEFEN_VORGAENGER\SE:END\EI
ENHANCEMENT 0 ZSD_QUOTATION_CHECK_1.

" ADDED BY KIRUBA FOR RESTRICTING THE VALUE IN SO

  DATA : it_zcmain TYPE TABLE OF ztabap_tvarvc.

    SELECT  * FROM ztabap_tvarvc INTO TABLE it_zcmain
        WHERE obj_name = 'ZSD_QUOTATION_CHECK_1'.

          IF it_zcmain IS NOT INITIAL.

      READ TABLE it_zcmain INTO DATA(ls_zcmain) WITH KEY low = vbak-vkorg.
      IF sy-subrc EQ 0.

        IF DA_KRFMNGV > DA_KWMENGV AND
        DA_KWMENGV > 0.

  IF KOPIEREN NE CHARX.

    MESSAGE 'Sales Order value exceeds Quotation value' TYPE 'E'.

    ENDIF.
    ENDIF.
    ENDIF.

    ENDIF.




ENDENHANCEMENT.
