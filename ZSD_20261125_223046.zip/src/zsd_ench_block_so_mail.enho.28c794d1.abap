"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENCH_BLOCK_SO_MAIL.
*&------------------------------------------------------------------------*
* Date        Programmer         TR No.          Description                    *
* 13.02.2022  Samata P/Iteanz    DR1K972180      Automatic mail Sending for a blocked SO  *

*&------------------------------------------------------------------------*

IF SY-TCODE = 'VA01' OR SY-TCODE = 'VA02'.
  DATA: LT_ZTSD_SO_MAIL TYPE TABLE OF ZTSD_SO_MAIL,
        LW_ZTSD_SO_MAIL TYPE ZTSD_SO_MAIL.
  DATA: LV_FLAG_SO_BLOCK TYPE C.
DATA :  LW_DOC_CHNG TYPE SODOCCHGI1,
          I_OBJPACK   LIKE SOPCKLSTI1 OCCURS 0 WITH HEADER LINE,
          I_OBJTXT    LIKE SOLISTI1 OCCURS 0 WITH HEADER LINE,
          I_OBJBIN    LIKE SOLISTI1 OCCURS 0 WITH HEADER LINE,
          I_RECLIST   LIKE SOMLRECI1 OCCURS 0 WITH HEADER LINE,
          V_FORM_NAME TYPE RS38L_FNAM,
          V_LEN_IN    LIKE SOOD-OBJLEN,
          V_LEN_OUT   LIKE SOOD-OBJLEN,
          V_LEN_OUTN  TYPE I,
          V_LINES_TXT TYPE I,
          V_LINES_BIN TYPE I.

  DATA : LT_RECIPIENTS TYPE TABLE OF UIYS_IUSR,
         LW_RECIPIENTS LIKE LINE OF LT_RECIPIENTS,
         LT_RETURN     TYPE TABLE OF RPBENERR,
         LW_OBJHEAD    TYPE SOLI_TAB.

  DATA : LV_UNAME TYPE SY-UNAME,
         LW_VKORG TYPE VBAK-VKORG,
         LV_FLAG  TYPE C.
data: LW_CDPOS type cdpos,
      LT_CDPOS TYPE TABLE OF CDPOS,
      LW_KNVV_Z1 TYPE KNVV,
      VBAK_NETWR_STR TYPE STRING,
      LV_NAME1_KUNNR TYPE KNA1-NAME1,
      katr6 TYPE TVK6T-VTEXT,
      KATR6_1 type KNA1-katr6,
      wa_xvbap_block type vbap,
      lv_werks type vbap-werks. "by Samata P/Iteanz DR1K972966 01.03.2023
clear : lv_werks."by Samata P/Iteanz DR1K972966 01.03.2023
*  SELECT SINGLE * FROM KNA1 INTO @DATA(KNA1) WHERE KUNNR = VBAK-KUNNR.
*SELECT SINGLE NAME1,KATR6 FROM KNA1 INTO (LV_NAME1_KUNNR, KATR6) WHERE KUNNR = VBAK-KUNNR.
SELECT SINGLE NAME1 FROM KNA1 INTO (LV_NAME1_KUNNR) WHERE KUNNR = VBAK-KUNNR.
  SELECT SINGLE KATR6 FROM KNA1 INTO (KATR6_1) WHERE KUNNR = VBAK-KUNNR.

    IF KATR6_1 IS NOT INITIAL.
      SELECT SINGLE VTEXT FROM TVK6T INTO (KATR6) WHERE KATR6 = KATR6_1.
      ENDIF.

LOOP AT xvbap into wa_xvbap_block.
lv_werks = wa_xvbap_block-werks.
exit.
ENDLOOP.
*select single werks from vbap into lv_werks where vbeln = vbak-vbeln. "by Samata P/Iteanz DR1K972966 01.03.2023
*IF VBUK-CMGST = 'B' or VBUK-CMGST = 'C'.
*   LV_FLAG_SO_BLOCK = 'X'.
*ENDIF.
* IF VBAK-LIFSK = 'Z1'.
*   LV_FLAG_SO_BLOCK = 'X'.
* ENDIF.
* LOOP AT XVBEP.
*   IF XVBEP-LIFSP = 'Z2'.
*    LV_FLAG_SO_BLOCK = 'X'.
*    EXIT.
*   ENDIF.
* ENDLOOP.
* IF LV_FLAG_SO_BLOCK = 'X'.
   SELECT * FROM ZTSD_SO_MAIL INTO TABLE LT_ZTSD_SO_MAIL WHERE VKORG = VBAK-VKORG and werks = lv_werks. "'werks' by Samata P/Iteanz DR1K972966 01.03.2023
   LOOP AT LT_ZTSD_SO_MAIL INTO LW_ZTSD_SO_MAIL.
     I_RECLIST-RECEIVER = LW_ZTSD_SO_MAIL-SMTP_ADDR.
     I_RECLIST-REC_TYPE = 'U'.
    APPEND I_RECLIST.
   ENDLOOP.
 IF I_RECLIST IS NOT INITIAL.
   IF XVBEP-LIFSP = 'Z2'.
     CLEAR : V_LINES_TXT,LW_DOC_CHNG.
     refresh : I_objtxt[],I_OBJPACK[].
    CONCATENATE 'SO blocked for Z2:'   VBAK-VBELN INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
    CONCATENATE 'Sold to Party:'   VBAK-KUNNR '-' LV_NAME1_KUNNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
*     SOLD TO PARTY: VBAK-KUNNR
     I_OBJTXT = ' '.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    I_OBJTXT = 'NOTE: THIS IS SYSTEM GENERATED E-MAIL.'.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    DESCRIBE TABLE I_OBJTXT LINES V_LINES_TXT.
    READ TABLE I_OBJTXT INDEX V_LINES_TXT.
      CONCATENATE VBAK-VBELN ':SO BLOCKED FOR Z2' into LW_DOC_CHNG-OBJ_DESCR.
*    LW_DOC_CHNG-OBJ_DESCR = 'SO BLOCKED FOR Z2'.
    LW_DOC_CHNG-DOC_SIZE = V_LINES_TXT * 255.

    CLEAR I_OBJPACK-TRANSF_BIN.
    I_OBJPACK-HEAD_START = 1.
    I_OBJPACK-HEAD_NUM = 0.
    I_OBJPACK-BODY_START = 1.
    I_OBJPACK-BODY_NUM = V_LINES_TXT.
    I_OBJPACK-DOC_TYPE = 'RAW'.
    APPEND I_OBJPACK.
*    IF I_RECLIST IS NOT INITIAL.
*      DELETE ADJACENT DUPLICATES FROM I_RECLIST.
*    ENDIF.

    CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
      EXPORTING
        DOCUMENT_DATA              = LW_DOC_CHNG
        PUT_IN_OUTBOX              = 'X'
        SENDER_ADDRESS             = 'WF-BATCH' "CONV SOEXTRECI1-RECEIVER( SY-UNAME )
*       SENDER_ADDRESS_TYPE        = 'B'
        COMMIT_WORK                = 'X'
*       SENDER_ID                  =
      TABLES
        PACKING_LIST               = I_OBJPACK
        OBJECT_HEADER              = LW_OBJHEAD
        CONTENTS_BIN               = I_OBJBIN
        CONTENTS_TXT               = I_OBJTXT
        RECEIVERS                  = I_RECLIST
      EXCEPTIONS
        TOO_MANY_RECEIVERS         = 1
        DOCUMENT_NOT_SENT          = 2
        DOCUMENT_TYPE_NOT_EXIST    = 3
        OPERATION_NO_AUTHORIZATION = 4
        PARAMETER_ERROR            = 5
        X_ERROR                    = 6
        ENQUEUE_ERROR              = 7
        OTHERS                     = 8.
    IF SY-SUBRC <> 0.
      WRITE:/ 'ERROR WHEN SENDING THE FILE', SY-SUBRC.
    ENDIF.
   ENDIF.
    IF VBAK-LIFSK = 'Z1'.

       CLEAR : V_LINES_TXT,LW_DOC_CHNG.
     refresh : I_objtxt[],I_OBJPACK[].
      CONCATENATE ' SO blocked for Z1: '   VBAK-VBELN INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    if sy-tcode = 'VA01'.

     select single * from KNVV INTO LW_KNVV_Z1 where KUNNR = VBAK-KUNNR
                                               AND VKORG = VBAK-VKORG
                                               AND VTWEG = VBAK-VTWEG
                                               AND SPART = VBAK-SPART.

    IF sy-SUBRC EQ 0.
        CONCATENATE 'Old Payment Terms: '  LW_KNVV_Z1-ZTERM INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
     CONCATENATE 'New Payment Terms: '   VBKD-ZTERM INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    " added by  kiruba/iteanz on DR1K976833
    CONCATENATE 'Plant: '  VBAP-WERKS INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Region: '  katr6 INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    SHIFT VBAK-KUNNR LEFT DELETING LEADING '0'.
    CONCATENATE 'Customer Code: '  VBAK-KUNNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Customer Name: '  LV_NAME1_KUNNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    SHIFT VBAP-MATNR  LEFT DELETING LEADING '0'.
    CONCATENATE 'Material Number: '  VBAP-MATNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Material Description:' VBAP-ARKTX INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

      ENDIF.
     ENDIF.
    if sy-tcode = 'VA02'.
*     select * from CDPOS INTO TABLE LT_CDPOS where OBJECTID = VBAK-VBELN and tabname = 'VBKD' AND FNAME = 'ZTERM'.
*     SORT LT_CDPOS BY OBJECTID DESCENDING.
*     READ TABLE LT_CDPOS INTO LW_CDPOS WITH KEY  OBJECTID = VBAK-VBELN.
*      IF sy-SUBRC EQ 0.
        CONCATENATE 'Old Payment Terms: '   YVBKD-ZTERM INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
     CONCATENATE 'New Payment Terms: '  XVBKD-ZTERM INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Plant: '  VBAP-WERKS INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Region: '  katr6 INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    SHIFT VBAK-KUNNR LEFT DELETING LEADING '0'.
    CONCATENATE 'Customer Code: '  VBAK-KUNNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Customer Name: '  LV_NAME1_KUNNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    SHIFT VBAP-MATNR  LEFT DELETING LEADING '0'.
    CONCATENATE 'Material Number: '  VBAP-MATNR INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    CONCATENATE 'Material Description:' VBAP-ARKTX INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
*      ENDIF.
     ENDIF.


     I_OBJTXT = ' '.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    I_OBJTXT = 'NOTE: THIS IS SYSTEM GENERATED E-MAIL.'.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    DESCRIBE TABLE I_OBJTXT LINES V_LINES_TXT.
    READ TABLE I_OBJTXT INDEX V_LINES_TXT.
    CONCATENATE VBAK-VBELN ':SO BLOCKED FOR Z1' into LW_DOC_CHNG-OBJ_DESCR.
*    LW_DOC_CHNG-OBJ_DESCR = 'SO BLOCKED FOR Z1'.
    LW_DOC_CHNG-DOC_SIZE = V_LINES_TXT * 255.

    CLEAR I_OBJPACK-TRANSF_BIN.
    I_OBJPACK-HEAD_START = 1.
    I_OBJPACK-HEAD_NUM = 0.
    I_OBJPACK-BODY_START = 1.
    I_OBJPACK-BODY_NUM = V_LINES_TXT.
    I_OBJPACK-DOC_TYPE = 'RAW'.
    APPEND I_OBJPACK.
*    IF I_RECLIST IS NOT INITIAL.
*      DELETE ADJACENT DUPLICATES FROM I_RECLIST.
*    ENDIF.

    CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
      EXPORTING
        DOCUMENT_DATA              = LW_DOC_CHNG
        PUT_IN_OUTBOX              = 'X'
        SENDER_ADDRESS             = 'WF-BATCH' "CONV SOEXTRECI1-RECEIVER( SY-UNAME )
*       SENDER_ADDRESS_TYPE        = 'B'
        COMMIT_WORK                = 'X'
*       SENDER_ID                  =
      TABLES
        PACKING_LIST               = I_OBJPACK
        OBJECT_HEADER              = LW_OBJHEAD
        CONTENTS_BIN               = I_OBJBIN
        CONTENTS_TXT               = I_OBJTXT
        RECEIVERS                  = I_RECLIST
      EXCEPTIONS
        TOO_MANY_RECEIVERS         = 1
        DOCUMENT_NOT_SENT          = 2
        DOCUMENT_TYPE_NOT_EXIST    = 3
        OPERATION_NO_AUTHORIZATION = 4
        PARAMETER_ERROR            = 5
        X_ERROR                    = 6
        ENQUEUE_ERROR              = 7
        OTHERS                     = 8.
    IF SY-SUBRC <> 0.
      WRITE:/ 'ERROR WHEN SENDING THE FILE', SY-SUBRC.
    ENDIF.
    ENDIF.
  IF VBUK-CMGST = 'B' or VBUK-CMGST = 'C'.
     CLEAR : V_LINES_TXT,LW_DOC_CHNG.
     refresh : I_objtxt[],I_OBJPACK[].
    CONCATENATE 'SO blocked for Credit: '   VBAK-VBELN INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
    CONCATENATE 'Sold to Party: '  VBAK-KUNNR  '-' LV_NAME1_KUNNR  INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
    VBAK_NETWR_STR = VBAK-NETWR.
    CONCATENATE 'NET Value: '  VBAK_NETWR_STR  ' '  VBAK-WAERK INTO I_OBJTXT.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.
*    SOLD TO PARTY: VBAK-KUNNR
*
*SO NET VALUE & SO CURRENCY: VBAK-NETWR & VBAK-WAERK
     I_OBJTXT = ' '.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    I_OBJTXT = 'NOTE: THIS IS SYSTEM GENERATED E-MAIL.'.
    APPEND I_OBJTXT.
    CLEAR : I_OBJTXT.

    DESCRIBE TABLE I_OBJTXT LINES V_LINES_TXT.
    READ TABLE I_OBJTXT INDEX V_LINES_TXT.
     CONCATENATE VBAK-VBELN ':SO BLOCKED FOR CREDIT' into LW_DOC_CHNG-OBJ_DESCR.
*    LW_DOC_CHNG-OBJ_DESCR = 'SO BLOCKED FOR CREDIT'.
    LW_DOC_CHNG-DOC_SIZE = V_LINES_TXT * 255.

    CLEAR I_OBJPACK-TRANSF_BIN.
    I_OBJPACK-HEAD_START = 1.
    I_OBJPACK-HEAD_NUM = 0.
    I_OBJPACK-BODY_START = 1.
    I_OBJPACK-BODY_NUM = V_LINES_TXT.
    I_OBJPACK-DOC_TYPE = 'RAW'.
    APPEND I_OBJPACK.
*    IF I_RECLIST IS NOT INITIAL.
*      DELETE ADJACENT DUPLICATES FROM I_RECLIST.
*    ENDIF.

    CALL FUNCTION 'SO_DOCUMENT_SEND_API1'
      EXPORTING
        DOCUMENT_DATA              = LW_DOC_CHNG
        PUT_IN_OUTBOX              = 'X'
        SENDER_ADDRESS             = 'WF-BATCH' "CONV SOEXTRECI1-RECEIVER( SY-UNAME )
*       SENDER_ADDRESS_TYPE        = 'B'
        COMMIT_WORK                = 'X'
*       SENDER_ID                  =
      TABLES
        PACKING_LIST               = I_OBJPACK
        OBJECT_HEADER              = LW_OBJHEAD
        CONTENTS_BIN               = I_OBJBIN
        CONTENTS_TXT               = I_OBJTXT
        RECEIVERS                  = I_RECLIST
      EXCEPTIONS
        TOO_MANY_RECEIVERS         = 1
        DOCUMENT_NOT_SENT          = 2
        DOCUMENT_TYPE_NOT_EXIST    = 3
        OPERATION_NO_AUTHORIZATION = 4
        PARAMETER_ERROR            = 5
        X_ERROR                    = 6
        ENQUEUE_ERROR              = 7
        OTHERS                     = 8.
    IF SY-SUBRC <> 0.
      WRITE:/ 'ERROR WHEN SENDING THE FILE', SY-SUBRC.
    ENDIF.
  ENDIF.



ENDIF.
*endif.
ENDIF.
*
*IF SY-TCODE = 'VA01'.
*
*  DATA: lv_so_value     TYPE netwr,
*        lv_quot_value   TYPE vbap-kwmeng,
*        lt_quotations   TYPE TABLE OF vbeln_va,
*        lv_quot_vbeln   TYPE vbeln_va,
*        lv_netwr_quot   TYPE vbap-kwmeng,
*        lv_netwr_quot1  TYPE VBFA-RFMNG.
*
*  CLEAR lv_so_value.
*  CLEAR lv_quot_value.
*
**  TYPES : BEGIN OF TY_STR,
**          VBELV TYPE VBFA-VBELV,
**          POSNV TYPE VBFA-POSNV,
**          VBELN TYPE VBFA-VBELN,
**          POSNN TYPE VBFA-POSNN,
**          VBTYP_N TYPE VBFA-VBTYP_N,
**          RFMNG TYPE VBFA-RFMNG,
**          END OF TY_STR.
**
**          DATA : IT_VB TYPE TABLE OF TY_STR.
*          DATA : IT_VB TYPE TABLE OF VBFA.
*
*  IF XVBAK-VGBEL IS NOT INITIAL .
*
*      SELECT SUM( kwmeng ) INTO lv_netwr_quot
*      FROM vbap
*      WHERE vbeln = XVBAK-VGBEL.
*
*      SELECT SUM( RFMNG ) INTO lv_netwr_quot1
*      FROM vbfa
*      WHERE vbelv = XVBAK-VGBEL AND VBTYP_N = 'C'.
*
*    LOOP AT XVBAP INTO DATA(LS_VB).
*
*      lv_quot_value = lv_quot_value + ls_vb-kwmeng.
*      clear : ls_vb.
*
*      ENDLOOP.
*
*  " Compare total Sales Order value with total Quotation value
*
*  IF lv_netwr_quot1 IS NOT INITIAL.
*     lv_netwr_quot  = lv_netwr_quot - lv_netwr_quot1.
*    ENDIF.
*
*   IF lv_netwr_quot < lv_quot_value.
*     CLEAR : XVBAP, XVBAK,lv_netwr_quot, lv_netwr_quot1.
*      clear : ls_vb.
*    MESSAGE 'Sales Order value exceeds Quotation value' TYPE 'E'.
*  ENDIF.
*
*  ENDIF.
*  ENDIF.
ENDENHANCEMENT.
