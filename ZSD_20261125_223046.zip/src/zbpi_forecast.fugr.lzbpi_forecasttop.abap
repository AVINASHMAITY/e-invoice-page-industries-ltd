FUNCTION-POOL ZBPI_FORECAST              MESSAGE-ID SV.

* INCLUDE LZBPI_FORECASTD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBPI_FORECASTT00                       . "view rel. data dcl.
