"Name: \PR:SAPLV69A\FO:USEREXIT_FIELD_MODIFICATION\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ENHAN_UPDATE_DISABLE.
**&----------------------------------------------------------------------------*
* Date        Programmer Client Ref No.        *
* 04.01.2017  Kavin/Iteanz             Billing Delete Button based on
*                                      in ZCMAIN Parameter  *
*                                      by sales organisation Wise
*Transport Request -  DR1K930165                              *
*&-----------------------------------------------------------------------------*

constants:
  lc_name type rvari_vnam value 'P_COMP',
  lc_tc1  type syst_tcode value 'VF01',
  lc_tc2  type syst_tcode value 'VF02',
  lc_btn  type char3      value 'BTN'.

data: lv_var  type char14,
      gt_cont type ztt_ztabap_tvarvc,
      gw_cont type ztabap_tvarvc.

field-symbols: <fs_vbrk> type vbrk.

if screen-group2 = lc_btn."'BTN'.
  screen-input = 1.

  lv_var = '(SAPMV60A)VBRK'.
  assign (lv_var) to <fs_vbrk>.

  call method zcl_abap_utility=>get_parameters
    exporting
      im_objname = sy-repid
    importing
      ex_tab     = gt_cont.

  if <fs_vbrk> is assigned.

    read table gt_cont into gw_cont with key obj_name = sy-repid
                                             name     = lc_name "'P_COMP'
                                             low      = <fs_vbrk>-bukrs."'5100'.
    if sy-subrc eq 0.

      if sy-tcode eq lc_tc1
      or sy-tcode eq lc_tc2.

        if screen-name = 'BT_KOLO'.
          screen-input = 0.
          modify screen.
        elseif screen-name = 'BT_KONY'.
          screen-input = 0.
          modify screen.
        elseif screen-name = 'BT_KONX'.
          screen-input = 0.
          modify screen.
        endif.

      endif.

    endif.

  endif.

endif.

**************Begin of Addition by Kavin/iteanz On 04/01/2017
**********************************************************************************
**Below Logic is to Disable Delete and Update Button based on Sales Organisation wise
***********************************************************************************
**********************************************************************************
*Decalation Part
***********************************************************************************
constants : gc_zsd_enh       type sobj_name    value 'ZSD_ENH_PRCING_CHECK',
            lc_vkorg_blk(13) value 'SO_VKORG_BLK1'.

refresh : gt_cont.
clear : gw_cont.

if screen-group2 = lc_btn."'BTN'.
  screen-input = 1.

  lv_var = '(SAPMV60A)VBRK'.
  assign (lv_var) to <fs_vbrk>.

  call method zcl_abap_utility=>get_options
    exporting
      im_objname = gc_zsd_enh
    importing
      ex_tab     = gt_cont.

  if <fs_vbrk> is assigned.

    read table gt_cont into gw_cont with key obj_name =  gc_zsd_enh
                                             name     = lc_vkorg_blk
                                             low      = <fs_vbrk>-vkorg.
    if sy-subrc eq 0.

      if sy-tcode eq lc_tc1
      or sy-tcode eq lc_tc2.
**********************************************************************************
*    Disable Buttons
**********************************************************************************
        if screen-name = 'BT_KOLO'.
          screen-input = 0.
          modify screen.
        elseif screen-name = 'BT_KONY'.
          screen-input = 0.
          modify screen.
        elseif screen-name = 'BT_KONX'.
          screen-input = 0.
          modify screen.
        endif.
      endif.
    endif.
  endif.
endif.
****************End of addition by kavin/iteanz on 04/01/2017

ENDENHANCEMENT.
