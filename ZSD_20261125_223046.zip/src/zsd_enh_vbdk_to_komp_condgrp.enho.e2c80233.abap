"Name: \PR:SAPMV45A\FO:USEREXIT_PRICING_PREPARE_TKOMP\SE:END\EI
ENHANCEMENT 0 ZSD_ENH_VBDK_TO_KOMP_CONDGRP.
 "**To Move the values of customer condition group to pricing structure KOMP. "DR1K901482
 tkomp-zzkdkg1 = vbkd-kdkg1.
 tkomp-zzkdkg2 = vbkd-kdkg2.
 tkomp-zzkdkg3 = vbkd-kdkg3.
 tkomp-zzkdkg4 = vbkd-kdkg4.
 tkomp-zzkdkg5 = vbkd-kdkg5.

* " changes added by khurshida 30.10.15
 If Sy-tcode = 'VA01' or Sy-tcode = 'VA02'.
  if vbak-vkorg = '1102' .

    FIELD-SYMBOLS : <lx_werks1> type any.
     ASSIGN ('(SAPMV45A)VBAP-WERKS') TO <lx_WERKS1>.
* if ( vbak-auart = 'YBOR' or vbak-auart = 'YBOI' ).
if <lx_WERKS1> is not INITIAL.
*  AUTHORITY-CHECK OBJECT 'ZOBJ_WERKS'
*             ID 'WERKS' FIELD <lx_WERKS1>
*             ID 'ACTVT' FIELD '01'.
*    IF SY-SUBRC <> 0.
*      MESSAGE 'You do not have authorisation for this plant' type 'E'.
*    ENDIF.
 data: W_ZSDT_PLANT_USER  type ZSDT_PLANT_USER.
 CLEAR w_ZSDT_PLANT_USER.
 select single * From ZSDT_PLANT_USER INTO w_ZSDT_PLANT_USER where vkorg = vbak-vkorg " sold to party
                                and   vwerk = <lx_WERKS1>
                                and   UNAME = sy-uname.
* if sy-subrc eq 0.
 if sy-subrc NE 0.
*  if w_ZSDT_PLANT_USER-uname ne sy-uname.
   MESSAGE 'You do not have authorisation for this plant' type 'E'.
*  endif.
 endif.
types: BEGIN OF t_knvv,
        kunnr type knvv-kunnr,
        vwerk type knvv-vwerk,
       end of t_knvv.
data: i_knvv TYPE TABLE OF t_knvv,
      w_knvv type t_knvv.
CLEAR w_knvv.
REFRESH i_knvv.
 Select kunnr vwerk from knvv INTO TABLE i_knvv where kunnr = vbak-kunnr.
 if i_knvv is NOT INITIAL.
 read TABLE i_knvv INTO w_knvv with key kunnr = vbak-kunnr
                                     vwerk = <lx_WERKS1>.
 if sy-subrc ne 0.

  read TABLE i_knvv INTO w_knvv with key kunnr = vbak-kunnr.
  if w_knvv-vwerk is not INITIAL.
  if w_knvv-vwerk ne <lx_WERKS1>.
   MESSAGE 'Customer does not belongs to your plant' type 'E'.
  endif.
   endif.
 endif.
 endif.

" ship to party
 Select kunnr vwerk from knvv INTO TABLE i_knvv where kunnr = kuwev-kunnr.
 if i_knvv is NOT INITIAL.
 read TABLE i_knvv INTO w_knvv with key kunnr = kuwev-kunnr
                                     vwerk = <lx_WERKS1>.
 if sy-subrc ne 0.

  read TABLE i_knvv INTO w_knvv with key kunnr = kuwev-kunnr.
  if w_knvv-vwerk is not INITIAL.
  if w_knvv-vwerk ne <lx_WERKS1>.
   MESSAGE 'Customer does not belongs to your plant' type 'E'.
  endif.
   endif.
 endif.
 endif.

endif.
*endif.
endif.
endif.
" end of changes

ENDENHANCEMENT.
