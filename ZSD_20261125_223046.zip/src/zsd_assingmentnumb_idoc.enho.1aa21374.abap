"Name: \PR:SAPMV45A\FO:USEREXIT_MOVE_FIELD_TO_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_ASSINGMENTNUMB_IDOC.
**&-------------------------------------------------------------------
**Date       : 18.07.2023
**Programmer : Sumit
**TR No.     : DR1K976866
**Description: Enhancment for Assingment Number for Credit/Debit Memo
**&-------------------------------------------------------------------
*&-------------------------------------------------------------------
*                  Modification Log                                 *
*&-------------------------------------------------------------------
*Date       : 29.10.2024
*Programmer : Suganya
*TR No.     : DR1K976866
*Description: Enhancment to update Assingment Number for all orders
*&-------------------------------------------------------------------
DATA:lv_idoc_x TYPE char1.
DATA:lv_assing TYPE VBAK-ZUONR.

IMPORT lv_idoc_x FROM MEMORY id 'LV_IDOC_X'.
IMPORT lv_assing FROM MEMORY id 'LV_ASSING'.

IF sy-tcode = 'VA01' AND lv_idoc_x = 'X'.
 VBAK-ZUONR = LV_ASSING.
ENDIF.

ENDENHANCEMENT.
