"Name: \PR:SAPLVEDA\FO:INTERPRET_IDOC_ORDERS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_DELIV_BLOCK_UPD.
*&-------------------------------------------------------------------
*Date       : 11.02.2025
*Programmer : Suganya Palanisamy
*TR No.     : DR1K990793
*Description: Enhancment to update Delivery block for duplicate record in ORDERS05
*&-------------------------------------------------------------------
IF idoc_contrl-idoctp = 'ORDERS05'.

SELECT * FROM tvarvc INTO TABLE @DATA(lt_tvarv) WHERE name = 'ZSD_SALESORDER_DUP'.

" Local Declaration
DATA ls_e1edk14 TYPE e1edk14.
DATA ls_e1edk02 TYPE e1edk02.
DATA ls_e1edk01 TYPE e1edk01.
DATA lv_salorg TYPE vkorg.
DATA lv_dispch TYPE vtweg.
DATA lv_divis  TYPE spart.
DATA lv_ordtyp TYPE auart.
DATA lv_assign TYPE ordnr_v.
DATA lv_lifsk_1 TYPE lifsk.

" Sales Area
LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_e1edk14>) where segnam = 'E1EDK14'.
 ls_e1edk14  = <fs_e1edk14>-sdata.
 CASE ls_e1edk14-qualf.
   WHEN '008'.
     lv_salorg = ls_e1edk14-orgid.
   WHEN '007'.
     lv_dispch = ls_e1edk14-orgid.
   WHEN '006'.
     lv_divis  = ls_e1edk14-orgid.
   WHEN '012'.
     lv_ordtyp = ls_e1edk14-orgid.
 ENDCASE.
ENDLOOP.

FREE MEMORY ID 'LV_LIFSK'.

" Filter condition
READ TABLE lt_tvarv INTO DATA(ls_tvarv) WITH KEY low = lv_salorg.
IF sy-subrc = 0.

" Assignment
 LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_e1edk02>) where segnam = 'E1EDK02'.
  ls_e1edk02 = <fs_e1edk02>-sdata.
  IF ls_e1edk02-qualf = '017'.
   lv_assign = ls_e1edk02-belnr.
  ENDIF.
 ENDLOOP.

" Delivery Block
 LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<fs_e1edk01>) where segnam = 'E1EDK01'.
 ls_e1edk01 = <fs_e1edk01>-sdata.

 "Check Duplication and set delivery block as DP for duplicate record
   SELECT auart,
          vkorg,
          vtweg,
          spart,
          zuonr
        FROM vbak
        INTO TABLE @DATA(lt_vbak)
        WHERE auart = @lv_ordtyp
          AND vkorg = @lv_salorg
          AND vtweg = @lv_dispch
          AND spart = @lv_divis
          AND zuonr = @lv_assign.
  IF sy-subrc EQ 0.
   ls_e1edk01-lifsk = 'DP'.
  ENDIF.

  lv_lifsk_1 = ls_e1edk01-lifsk.

  EXPORT lv_lifsk_1 TO MEMORY ID 'LV_LIFSK'.
 ENDLOOP.

 ENDIF.
ENDIF.
ENDENHANCEMENT.
