*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGLIFSP_UPDATETOP.               " Global Data
  INCLUDE LZFGLIFSP_UPDATEUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGLIFSP_UPDATEF...               " Subroutines
* INCLUDE LZFGLIFSP_UPDATEO...               " PBO-Modules
* INCLUDE LZFGLIFSP_UPDATEI...               " PAI-Modules
* INCLUDE LZFGLIFSP_UPDATEE...               " Events
* INCLUDE LZFGLIFSP_UPDATEP...               " Local class implement.
* INCLUDE LZFGLIFSP_UPDATET99.               " ABAP Unit tests
