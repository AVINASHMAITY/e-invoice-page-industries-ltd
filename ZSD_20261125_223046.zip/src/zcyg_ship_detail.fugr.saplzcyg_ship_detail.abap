*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_SHIP_DETAILTOP.              " Global Data
  INCLUDE LZCYG_SHIP_DETAILUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_SHIP_DETAILF...              " Subroutines
* INCLUDE LZCYG_SHIP_DETAILO...              " PBO-Modules
* INCLUDE LZCYG_SHIP_DETAILI...              " PAI-Modules
* INCLUDE LZCYG_SHIP_DETAILE...              " Events
* INCLUDE LZCYG_SHIP_DETAILP...              " Local class implement.
* INCLUDE LZCYG_SHIP_DETAILT99.              " ABAP Unit tests
  INCLUDE LZCYG_SHIP_DETAILF00                    . " subprograms
  INCLUDE LZCYG_SHIP_DETAILI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
