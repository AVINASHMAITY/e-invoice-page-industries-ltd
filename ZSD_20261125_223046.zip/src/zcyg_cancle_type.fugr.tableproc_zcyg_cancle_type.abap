*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_CANCLE_TYPE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_CANCLE_TYPE    .

  PERFORM TABLEPROC.

ENDFUNCTION.
