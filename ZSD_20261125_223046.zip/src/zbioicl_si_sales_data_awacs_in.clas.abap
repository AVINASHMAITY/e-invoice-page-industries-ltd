class ZBIOICL_SI_SALES_DATA_AWACS_IN definition
  public
  create public .

public section.

  interfaces ZBIOIII_SI_SALES_DATA_AWACS_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOICL_SI_SALES_DATA_AWACS_IN IMPLEMENTATION.


  method zbioiii_si_sales_data_awacs_in~si_sales_data_awacs_in.
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Object Name : ~SI_SALES_DATA_AWACS_IN                         *
* Author/Company Name : Arya/ITZ                               *
* Transport Request :  DR1K944205                                      *
* Creation Date : 25.02.2019                                           *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Dependencies *
*&---------------------------------------------------------------------*
* Modification History *
*&---------------------------------------------------------------------*
* Date Programmer Client Ref No. Description Correction *
*                                                                      *
*&---------------------------------------------------------------------*
*                                                                      *
*                                                                      *
*&---------------------------------------------------------------------*


    types: begin of tp_ztsd_invawacs,
             mandt type ztsd_invawacs-mandt,
             vbeln type ztsd_invawacs-vbeln,
             fkdat type ztsd_invawacs-fkdat,
             ftpin type ztsd_invawacs-ftpin,
             ftpdt type ztsd_invawacs-ftpdt,
             ftptm type ztsd_invawacs-ftptm,
           end of tp_ztsd_invawacs.


    types:  begin of tp_vbrp,
              vbeln type vbrp-vbeln,
              posnr type vbrp-posnr,
              werks type vbrp-werks,
              matnr type vbrp-matnr,
              arktx type vbrp-arktx,
              charg type vbrp-charg,
              fkimg type vbrp-fkimg,
              vrkme type vbrp-vrkme,
              prsfd type vbrp-prsfd,
              shkzg type vbrp-shkzg,
            end of  tp_vbrp.

    types:begin of tp_kna1,
            kunnr type  kna1-kunnr,
            name1 type  kna1-name1,
          end of  tp_kna1.

    types:begin of tp_konv,
            knumv type    konv-knumv,
            kposn type    konv-kposn,
            kawrt type    konv-kawrt,
            kbetr type    konv-kbetr,
            kschl type    konv-kschl,
            kwert type    konv-kwert,
          end of  tp_konv.
    data :           lt_update        type table of tp_ztsd_invawacs,
                     gt_ztsd_invawacs type table of tp_ztsd_invawacs,
                     lt_uftp          type table of ztsd_invawacs,
                     ls_uftp          like line of lt_uftp,
                     lw_update        type tp_ztsd_invawacs,
                     lt_ztsd_invawacs type table of tp_ztsd_invawacs,
                     lt_konv          type table of tp_konv,
                     lw_konv          type tp_konv,
                     lw_konv_tmp      type tp_konv,
                     lt_vbrp          type table of tp_vbrp,
                     lw_vbrp          type tp_vbrp,
                     lt_kna1          type table of tp_kna1,
                     lw_kna1          type tp_kna1.

    types: begin of tp_vbrk,
             vbeln type vbrk-vbeln,
             fkdat type vbrk-fkdat,
             kunrg type vbrk-kunrg,
             knumv type vbrk-knumv,
             xblnr type xblnr_v1,
           end of tp_vbrk.

    data : lt_vbrk   type table of tp_vbrk,
           lw_vbrk   type tp_vbrk,
           lt_t0061  type table of t006a,
           lw_t0061  type t006a,
           lv_jivp   type konv-kbetr,
           lv_jocg   type konv-kbetr,
           lv_joig   type konv-kbetr,
           lv_josg   type konv-kbetr,
           lv_taxamt type kawrt,
           lv_zoth   type konv-kbetr,
           lv_zpts   type konv-kbetr,
           lv_flag   type c,
           lv_zpts1  type konv-kbetr,
           lv_zptsc  type konv-kbetr,
           lv_zspl   type konv-kbetr,
           lv_z004   type konv-kbetr,
           lv_z005   type konv-kbetr,
           lv_z007   type konv-kbetr,
           lv_diff   type konv-kbetr.

    constants : gc_1102(4) value '1102',
                gc_60(2)   value '60'.

    types :  begin of tp_mch1,
               matnr type mch1-matnr,
               charg type mch1-charg,
               vfdat type mch1-vfdat,
               licha type mch1-licha,
               lifnr type mch1-lifnr,
             end of tp_mch1.

    types: begin of tp_lfa1,
             lifnr type lfa1-lifnr,
             name1 type lfa1-name1,
           end of tp_lfa1.
    data:  lt_lfa1 type table of tp_lfa1,
           lw_lfa1 type tp_lfa1.

    data : lt_mch1  type table of tp_mch1,
           lw_mch1  type tp_mch1,
           lv_vfdat type   xudatfrmt.

    types : begin of tp_ftp,
              werks                 type  werks_d,
              vbeln                 type  vbeln_vf,
              xblnr                 type  xblnr_v1,
              fkdat                 type   xudatfrmt,
              kunrg                 type  kna1-kunnr,
              name1                 type  kna1-name1,
              uniform               type  string,
              prod_code             type  string,
              matnr                 type  matnr,
              arktx                 type  arktx,
              pack                  type  string,
              mfg_name              type  string,
              batch_no              type  string,
              expiry_dt             type  xudatfrmt,
              vat_app               type  string,
              vat_free              type  string,
              vat_perc              type  string,
              ptr                   type  string,
              pts                   type  string,
              cst_suffered_amt      type  string,
              mrp                   type  string,
              excise_duity          type  string,
              edu_cess              type  string,
              quantity              type  string,
              free_quantity         type  string,
              ptr_disc_perc         type  string,
              pts_disc_amt          type  string,
              sp_disc_perc_pts      type  string,
              sp_disc_amt_pts       type  string,
              taxable_amt           type string,
              cgst_perc             type string,
              cgst_amt              type string,
              igst_perc             type string,
              igst_amt              type string,
              sgst_perc             type string,
              sgst_amt              type string,
              utgst_perc            type string,
              utgst_amt             type string,
              hsn_code              type string,
              documents_through     type  string,
              payment               type  string,
              calc_method_invoice   type  string,
              mrp_incoftaxes_or_lte type  string,
              status                type  string,
              date                  type  string,
              message               type  string,

            end of tp_ftp.

    types : begin of tp_marc,
              matnr type matnr,
              werks type werks_d,
              steuc type steuc,
            end of tp_marc.
    data : lt_marc     type table of tp_marc,
           lw_marc     like line of lt_marc,
           lt_vbrp_tmp type table of tp_vbrp.

    data : pa_fkdat type vbrk-fkdat .
    data : it_mara type table of mara,
           wa_mara type mara.
    data : lt_ftp   type table of tp_ftp,
           lw_ftp   type tp_ftp,
           lv_quan  type string,
           lv_fkimg type string.
    constants : gc_jocg type kscha value 'JOCG',
                gc_joig type kscha value 'JOIG',
                gc_josg type kscha value 'JOSG'.

    data:lv_report  type  rsvar-report value 'ZSD_SHAREPRIMARY_SALE_DATA',
         lv_variant type  rsvar-variant value 'VAR1',
         lt_valutab type table of rsparams,
         lw_valutab like line of lt_valutab,
         lv_selname type  rsscr_name value 'PA_FKDAT'.
*---------------------------------------------------------
*  get_data .
*---------------------------------------------------------
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************
*******************************************************************************
**  Input date  - 1  logic
****************************************************************************
    data : r_fkdat  type range of vbrk-fkdat,
           lw_fkdat like line  of r_fkdat.

    refresh: lt_update,r_fkdat,lt_vbrk,gt_ztsd_invawacs.


    call function 'RS_VARIANT_CONTENTS'
      exporting
        report               = lv_report
        variant              = lv_variant
      tables
        valutab              = lt_valutab
      exceptions
        variant_non_existent = 1
        variant_obsolete     = 2
        others               = 3.
    if sy-subrc = 0.
      read table lt_valutab into lw_valutab with key selname = lv_selname.
      if sy-subrc = 0.
        call function 'CONVERT_DATE_TO_INTERNAL'
          exporting
            date_external            = lw_valutab-low
          importing
            date_internal            = lw_valutab-low
          exceptions
            date_external_is_invalid = 1
            others                   = 2.
        if sy-subrc = 0.
          pa_fkdat = lw_valutab-low.
        endif.


      endif.
    else.
      clear :lw_ftp.
      lw_ftp-message = 'No Variant Found'.
      lw_ftp-status = 'E'.
      lw_ftp-date = sy-datum.
      append lw_ftp to lt_ftp.
      clear:lw_ftp.
      move-corresponding lt_ftp to output-mt_sales_data_awacs_res-records.
      refresh: lt_ftp[].
      exit.
    endif.




    lw_fkdat-sign = 'I'.
    lw_fkdat-option = 'BT'.
    lw_fkdat-low = pa_fkdat - 1 .
    lw_fkdat-high = pa_fkdat.
    append lw_fkdat to r_fkdat.
*    clear: lw_fkdat.
    if lw_fkdat-low is not initial.
      clear lw_fkdat.
*******************************************************************************************
**    Take Billing Record
*******************************************************************************************
      select  vbeln
      fkdat
      kunrg
      knumv
      xblnr
      from vbrk
      into  corresponding fields of table lt_vbrk
      where  fkdat in r_fkdat and
      vkorg in ra_vkorg and      "vkorg eq gc_1102 and             "Added by Ravi on 06.06.2019 DR1K945737
      vtweg ne gc_60.

      select vbeln
      fkdat
      ftpin from ztsd_invawacs
      into  corresponding fields of table gt_ztsd_invawacs
      where fkdat in r_fkdat .

      loop at lt_vbrk into lw_vbrk.
        read table  gt_ztsd_invawacs  transporting no fields with key
                    vbeln = lw_vbrk-vbeln
        ftpin = abap_true.
        if sy-subrc ne 0.
          lw_update-vbeln = lw_vbrk-vbeln.
          lw_update-fkdat = lw_vbrk-fkdat.
          append lw_update to lt_update.
          clear lw_update.
        endif.
      endloop.

      refresh :  lt_ztsd_invawacs,lt_konv,lt_kna1, lt_lfa1 .
      if lt_update[] is not initial.
        if  lt_vbrk[] is not initial .

          select  vbeln
          posnr
          werks
          matnr
          arktx
          charg
          fkimg
          vrkme
          prsfd
          shkzg from vbrp
          into corresponding fields of
          table
          lt_vbrp
          for all entries in lt_vbrk
          where vbeln = lt_vbrk-vbeln .

          move-corresponding lt_vbrp to lt_vbrp_tmp.
          sort lt_vbrp_tmp by vbeln werks ascending.
          delete adjacent duplicates from lt_vbrp_tmp comparing vbeln werks.
          if lt_vbrp_tmp[] is not initial.
            select matnr werks steuc
            from marc
            into table lt_marc
            for all entries in lt_vbrp_tmp
            where matnr eq lt_vbrp_tmp-matnr
            and werks eq lt_vbrp_tmp-werks.
          endif.
          select knumv
          kposn
          kawrt
          kbetr
          kschl
          kwert
          from konv into corresponding fields of
          table lt_konv
          for all entries in lt_vbrk
          where  knumv = lt_vbrk-knumv and
          kschl in ( 'ZVAT','ZVAM','ZPTR','ZPTS','JIVC','ZMRP', 'JIVP', 'ZOTH',
          'ZSPL', 'ZPTS', 'Z004', 'Z005','Z007', 'DIFF', 'JOCG', 'JOIG', 'JOSG' ). "Change by Chandru " DR1K933905

          select kunnr
          name1
          from kna1 into corresponding fields of
          table lt_kna1
          for all entries in lt_vbrk
          where kunnr = lt_vbrk-kunrg.

          if lt_vbrk[] is not initial.

            select matnr
            charg
            vfdat
            licha
            lifnr from mch1
            into table lt_mch1
            for all entries in lt_vbrp
            where  charg = lt_vbrp-charg and
            matnr = lt_vbrp-matnr.

            select   msehi
            mseht
            spras
            from t006a
            into corresponding fields of table lt_t0061
            for all entries in  lt_vbrp
            where spras = 'EN'
            and msehi =  lt_vbrp-vrkme.

            if lt_mch1[] is not initial.

              select lifnr
              name1 from lfa1 into table lt_lfa1
              for all entries in  lt_mch1
              where lifnr = lt_mch1-lifnr.
            endif.
          endif.
        endif.
        sort lt_vbrk by vbeln.
        sort lt_vbrp  by vbeln.
        sort lt_konv by  knumv  kposn.

        loop at   lt_vbrp into lw_vbrp.
          read table lt_vbrk into lw_vbrk with key vbeln = lw_vbrp-vbeln binary search.
          if sy-subrc eq 0.
            read table lt_kna1 into lw_kna1 with key kunnr =  lw_vbrk-kunrg.

            read table lt_mch1 into lw_mch1 with key matnr = lw_vbrp-matnr
            charg =  lw_vbrp-charg.
            lw_ftp-werks       =   lw_vbrp-werks.
            lw_ftp-vbeln        =  lw_vbrp-vbeln.
            lw_ftp-xblnr        =  lw_vbrk-xblnr.
            lw_ftp-fkdat        =  lw_vbrk-fkdat.
**
            call function 'CONVERT_DATE_TO_EXTERNAL'
              exporting
                date_internal            = lw_vbrk-fkdat
              importing
                date_external            = lw_ftp-fkdat
              exceptions
                date_internal_is_invalid = 1
                others                   = 2.
            replace all occurrences of  '-' in lw_ftp-fkdat with '/'. "To show date  with /
            replace all occurrences of  '.' in  lw_ftp-fkdat with '/'. "To show date  with /

            lw_ftp-kunrg        =  lw_kna1-kunnr.
            lw_ftp-name1        =  lw_kna1-name1.
            lw_ftp-uniform      =  abap_false.
            lw_ftp-prod_code    =  abap_false.
            lw_ftp-matnr        = lw_vbrp-matnr.
            lw_ftp-arktx        = lw_vbrp-arktx.
            read table lt_t0061 into lw_t0061 with key   msehi =  lw_vbrp-vrkme.
            if sy-subrc eq 0.
              lw_ftp-pack         = lw_t0061-mseht+0(10).
            endif.
            read table lt_lfa1 into lw_lfa1 with key lifnr = lw_mch1-lifnr.
            if sy-subrc eq 0.

              lw_ftp-mfg_name     = lw_lfa1-name1.
            endif.
            lw_ftp-batch_no     =  lw_mch1-licha.
            clear : lv_vfdat.

            call function 'CONVERT_DATE_TO_EXTERNAL'
              exporting
                date_internal            = lw_mch1-vfdat
              importing
                date_external            = lw_ftp-expiry_dt
              exceptions
                date_internal_is_invalid = 1
                others                   = 2.
            replace all occurrences of  '.' in  lw_ftp-expiry_dt  with '/'.  "To show date  with /
            replace all occurrences of  '-' in  lw_ftp-expiry_dt  with '/'.  "To show date  with /


            lw_ftp-expiry_dt    =   lw_ftp-expiry_dt .
            lw_ftp-vat_free     =  '1'.

            loop at lt_konv into lw_konv  where  knumv = lw_vbrk-knumv and
            kposn =  lw_vbrp-posnr.
              if lw_konv-kschl = 'ZVAT'.
                lw_ftp-vat_app      =  '1'.
              endif.

              if lw_konv-kschl = 'ZVAM'.
                lw_ftp-vat_app      =  '0'.
              endif.

              if lw_konv-kschl = 'JIVP'.
                lw_ftp-vat_perc =   lw_konv-kbetr / 10.
                lv_jivp         =   lw_ftp-vat_perc.
              endif.

              if lw_konv-kschl = 'ZOTH'.
                lw_ftp-vat_perc = ( lw_konv-kbetr / 10 ) .
                lv_zoth         =  lw_ftp-vat_perc .
              endif.
              if lw_konv-kschl = gc_jocg.
                lw_ftp-cgst_perc =   lw_konv-kbetr / 10.
                lv_jocg         =   lw_ftp-cgst_perc.

                lw_ftp-cgst_perc = lv_jocg.
                lw_ftp-cgst_amt = lw_konv-kwert.
              endif.
              if lw_konv-kschl = gc_joig.
                lw_ftp-igst_perc =   lw_konv-kbetr / 10.
                lv_joig         =   lw_ftp-igst_perc.
                lw_ftp-igst_perc = lv_joig.
                lw_ftp-igst_amt = lw_konv-kwert.
              endif.
              if lw_konv-kschl = gc_josg.
                lw_ftp-sgst_perc =   lw_konv-kbetr / 10.
                lv_josg         =   lw_ftp-sgst_perc.
                lw_ftp-sgst_perc = lv_josg.
                lw_ftp-sgst_amt = lw_konv-kwert.
              endif.

*************************PTS LOGIC

              if lw_konv-kschl = 'ZSPL'.
                lv_zspl  = lw_konv-kbetr .
              endif.

              if lw_konv-kschl = 'Z004'.
                lv_z004  = lw_konv-kwert .
              endif.

              if lw_konv-kschl = 'Z005'.
                lv_z005  = lw_konv-kwert .
              endif.

              if lw_konv-kschl = 'ZPTS'.
                lv_zpts  = lw_konv-kwert .

              endif.

              if lw_konv-kschl = 'Z007'.
                lv_z007  = lw_konv-kwert .
              endif.

              if lw_konv-kschl = 'DIFF'.
                lv_diff  = lw_konv-kwert .
              endif.
              if lw_konv-kschl = 'ZPTR'.
                lw_ftp-ptr   = lw_konv-kbetr.
              endif.

              if lw_konv-kschl = 'JIVC'.
                lw_ftp-cst_suffered_amt   = lw_konv-kwert.
              endif.

              if lw_konv-kschl = 'ZMRP'.
                lw_ftp-mrp = lw_konv-kbetr.
              endif.

              lw_ftp-vat_perc =  lv_zoth + lv_jivp .
              at end of kposn.
                if lw_vbrp-fkimg  is not initial.
                  if   lv_z004 is initial or lv_z004 lt 0.
                    lv_zptsc  = ( lv_zspl +  lv_z004  + lv_z005 +  lv_z007 + lv_zpts ) +  lv_diff.
                  else.
                    lv_zptsc  = ( lv_z004  + lv_z005 +  lv_z007 ) +  lv_diff.
                  endif.
                  lv_zpts1 = ( lv_zptsc /  lw_vbrp-fkimg ).
                  lw_ftp-pts =  lv_zpts1.
                endif.
              endat.
            endloop.



            if lw_ftp-cst_suffered_amt  is initial.
              lw_ftp-cst_suffered_amt   = '0'.
            endif.

            if  lw_ftp-ptr is initial.
              lw_ftp-ptr = '0'.
            endif.

            if lw_ftp-mrp is initial.
              lw_ftp-mrp = '0'.
            endif.

            if  lw_ftp-pts  is initial.
              lw_ftp-pts  = '0'.
            endif.

            if lw_ftp-vat_perc  is initial.
              lw_ftp-vat_perc  = '0'.
            endif.

            lw_ftp-excise_duity             = '0' .
            lw_ftp-edu_cess                 = '0'.

            if lw_vbrp-shkzg  is initial.

              lw_ftp-quantity                 = lw_vbrp-fkimg.
            else.
              clear : lv_quan,lv_fkimg.
              lv_fkimg = lw_vbrp-fkimg.
              concatenate '-' lv_fkimg into lv_quan.
              lw_ftp-quantity                 = lv_quan.
            endif.

            if  lw_ftp-quantity  is initial.
              lw_ftp-quantity                 = '0'.
            endif.

            if lw_vbrp-prsfd                = 'B'.
              lw_ftp-free_quantity          = lw_vbrp-fkimg.
              lw_ftp-quantity                 = '0'.
            else.
              lw_ftp-free_quantity          = '0'.
            endif.
            lw_ftp-ptr_disc_perc            = '0'.
            lw_ftp-pts_disc_amt             = '0'.
            lw_ftp-sp_disc_perc_pts         = '0'.
            lw_ftp-sp_disc_amt_pts          = '0' .
            if lw_ftp-cgst_amt gt 0.
              read table lt_konv into lw_konv_tmp
              with key knumv = lw_vbrk-knumv
              kposn = lw_vbrp-posnr
              kschl = gc_jocg.
              if sy-subrc eq 0.
                lw_ftp-taxable_amt = lw_konv_tmp-kawrt.
              endif.
            elseif lw_ftp-igst_amt gt 0.
              read table lt_konv into lw_konv_tmp with key knumv = lw_vbrk-knumv
              kposn = lw_vbrp-posnr
              kschl = gc_joig.
              if sy-subrc eq 0.
                lw_ftp-taxable_amt = lw_konv_tmp-kawrt.
              endif.
            endif.
            lw_ftp-utgst_perc = '0'.
            lw_ftp-utgst_amt  = '0'.
            read table lt_marc into lw_marc with key matnr = lw_ftp-matnr
            werks = lw_ftp-werks.
            if sy-subrc eq 0.
              lw_ftp-hsn_code = lw_marc-steuc.
            endif.

            lw_ftp-documents_through        = 'Direct'.
            lw_ftp-payment                  = '1' .
            lw_ftp-calc_method_invoice      = '0'.
            lw_ftp-mrp_incoftaxes_or_lte    = '0'.

            if lw_ftp-free_quantity  gt 0.
              lw_ftp-ptr = '0'.
              lw_ftp-pts = '0'.
              lw_ftp-mrp = '0'.
            endif.
            data : lc_zero(1) value '0'.
            if lw_ftp-taxable_amt is initial.
              lw_ftp-taxable_amt = lc_zero.
            endif.
            if lw_ftp-cgst_perc is initial.
              lw_ftp-cgst_perc = lc_zero.
            endif.
            if lw_ftp-cgst_amt is initial.
              lw_ftp-cgst_amt = lc_zero.
            endif.
            if lw_ftp-igst_perc is initial.
              lw_ftp-igst_perc = lc_zero.
            endif.
            if lw_ftp-igst_amt is initial.
              lw_ftp-igst_amt = lc_zero.
            endif.
            if lw_ftp-sgst_perc is initial.
              lw_ftp-sgst_perc = lc_zero.
            endif.
            if lw_ftp-sgst_amt is initial.
              lw_ftp-sgst_amt = lc_zero.
            endif.
            if lw_ftp-utgst_perc is initial.
              lw_ftp-utgst_perc = lc_zero.
            endif.
            if lw_ftp-utgst_amt is initial.
              lw_ftp-utgst_amt = lc_zero.
            endif.
            lw_ftp-message = 'Success'.
            lw_ftp-status = 'S'.
            lw_ftp-date = sy-datum.
            append lw_ftp to lt_ftp.
            clear: lw_ftp,lw_vbrk,lw_vbrp,lw_kna1,
            lw_mch1,lw_konv,lw_t0061,lw_lfa1,
            lv_jivp,lv_zoth,lv_zpts , lv_zspl,
            lv_z004,lv_z005,lv_z007,lv_diff ,
            lv_zpts1, lv_zptsc,lv_jocg,
            lv_joig, lv_josg, lw_konv_tmp.
          endif.

        endloop.
        loop at lt_ftp into lw_ftp.
          read table lt_update  into lw_update with key vbeln = lw_ftp-vbeln.
          if sy-subrc ne 0.
            delete table lt_ftp from lw_ftp.
            clear :lw_update,lw_ftp.
            continue.
          else.
            ls_uftp-vbeln = lw_update-vbeln.
            ls_uftp-fkdat = lw_update-fkdat.
            append ls_uftp to lt_uftp.
            clear :ls_uftp.
          endif.
        endloop.

        sort lt_uftp[] by vbeln fkdat.
        delete adjacent duplicates from lt_uftp[] comparing vbeln fkdat.
        data(lt_tmp) = lt_uftp[].
        clear : lt_uftp[].
        lt_uftp = value #( for ls in lt_tmp ( vbeln = ls-vbeln fkdat = ls-fkdat ftpin = abap_true
        ftpdt = sy-datum ftptm = sy-uzeit )
        ).
        clear : lt_tmp[].
        sort  lt_ftp by vbeln  .
        if lt_ftp[] is not initial.
          move-corresponding lt_ftp to output-mt_sales_data_awacs_res-records.
          refresh :lt_ftp[].
        endif.

        if lt_uftp[] is not initial.
          modify ztsd_invawacs from table lt_uftp[].
          if sy-subrc = 0.
            commit work and wait.
          else.
            rollback work.
          endif.
        endif.
        refresh : lt_uftp[].
      endif.
    endif.
  endmethod.
ENDCLASS.
