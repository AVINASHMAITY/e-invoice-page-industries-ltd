*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_RFC_REPORTING_MANAGERTOP.     " Global Data
  INCLUDE LZFG_RFC_REPORTING_MANAGERUXX.     " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_RFC_REPORTING_MANAGERF...     " Subroutines
* INCLUDE LZFG_RFC_REPORTING_MANAGERO...     " PBO-Modules
* INCLUDE LZFG_RFC_REPORTING_MANAGERI...     " PAI-Modules
* INCLUDE LZFG_RFC_REPORTING_MANAGERE...     " Events
* INCLUDE LZFG_RFC_REPORTING_MANAGERP...     " Local class implement.
* INCLUDE LZFG_RFC_REPORTING_MANAGERT99.     " ABAP Unit tests
