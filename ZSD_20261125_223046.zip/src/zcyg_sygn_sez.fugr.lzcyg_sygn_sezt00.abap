*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCYG_SYGN_SEZ...................................*
DATA:  BEGIN OF STATUS_ZCYG_SYGN_SEZ                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCYG_SYGN_SEZ                 .
CONTROLS: TCTRL_ZCYG_SYGN_SEZ
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCYG_SYGN_SEZ                 .
TABLES: ZCYG_SYGN_SEZ                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
