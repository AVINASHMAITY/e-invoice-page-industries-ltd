*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_SD_AGENTTOP.                  " Global Data
  INCLUDE LZFG_SD_AGENTUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_SD_AGENTF...                  " Subroutines
* INCLUDE LZFG_SD_AGENTO...                  " PBO-Modules
* INCLUDE LZFG_SD_AGENTI...                  " PAI-Modules
* INCLUDE LZFG_SD_AGENTE...                  " Events
* INCLUDE LZFG_SD_AGENTP...                  " Local class implement.
* INCLUDE LZFG_SD_AGENTT99.                  " ABAP Unit tests
