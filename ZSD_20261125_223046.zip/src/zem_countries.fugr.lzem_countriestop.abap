FUNCTION-POOL ZEM_COUNTRIES              MESSAGE-ID SV.

* INCLUDE LZEM_COUNTRIESD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZEM_COUNTRIEST00                       . "view rel. data dcl.
