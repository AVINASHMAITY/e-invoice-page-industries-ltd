"Name: \PR:SAPMV45A\EX:BELEG_SICHERN_22\EI
ENHANCEMENT 0 ZSD_QUOTATION_Z6BLOCK.
***********Code Starts by Bhagavan on 10/11/2021 "DR1K961678*******************************
*  if sy-tcode eq 'VA21' or sy-tcode eq 'VA22' .
*      CONSTANTS : GC_Z6BLOCK     VALUE 'ZSD_QUOTE_Z6BLOCK' TYPE SOBJ_NAME,
*      GC_VKORG(15)      VALUE 'Z6_VKORG',
*      GC_AUART(15)      VALUE 'Z6_AUART'.
*      DATA : GT_CONSTANTS TYPE ZTT_ZTABAP_TVARVC.
*      RANGES : RA_VKORG FOR TVKO-VKORG,
*               RA_AUART FOR VBAK-AUART.
*
*      CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
*      EXPORTING
*        IM_OBJNAME = GC_Z6BLOCK
*      IMPORTING
*        EX_TAB     = GT_CONSTANTS.
*
*      LOOP AT GT_CONSTANTS INTO DATA(GW_CONSTANTS)
*            WHERE OBJ_NAME = GC_Z6BLOCK
*            AND NAME     = GC_VKORG.
*        RA_VKORG-SIGN = 'I'.
*        RA_VKORG-OPTION = 'EQ'.
*        RA_VKORG-LOW = GW_CONSTANTS-LOW.
*        APPEND RA_VKORG.
*        CLEAR : RA_VKORG.
*      ENDLOOP.
*
*      LOOP AT GT_CONSTANTS INTO GW_CONSTANTS
*      WHERE OBJ_NAME = GC_Z6BLOCK
*      AND NAME     = GC_AUART.
*        RA_AUART-SIGN = 'I'.
*        RA_AUART-OPTION = 'EQ'.
*        RA_AUART-LOW = GW_CONSTANTS-LOW.
*        APPEND RA_AUART.
*        CLEAR : RA_AUART.
*      ENDLOOP.
* DATA : lv_vbeln TYPE vbak-vbeln,
*        w_vbak type vbak,
*        counter type i.
*     IF  ( xvbak-vkorg IN RA_VKORG     AND  xvbak-auart IN RA_AUART  ) or sy-tcode = 'VA22'.
*      IF ( SY-MSGID = 'V1' AND SY-MSGTY = 'S' AND SY-MSGNO = '311' AND sy-tcode = 'VA21' ) or sy-tcode = 'VA22' .
**
*        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
*          EXPORTING
*            input         = sy-msgv2
*         IMPORTING
*           OUTPUT        = lv_vbeln.
*clear counter.
*        LOOP AT xvbap.
*      if xvbap-posnr is not initial.
*        while counter < 2.
*          call function 'ENQUEUE_EVVBAKE'
*          exporting
*            vbeln          = lv_VBELN
*          exceptions
*            foreign_lock   = 02
*            system_failure = 03.
*          if sy-subrc = 0.
*            UPDATE  vbep SET lifsp = 'Z6'  WHERE vbeln =  lv_vbeln AND posnr  = xvbap-posnr.
*            commit work and wait.
*            call function 'DEQUEUE_EVVBAKE'
*            exporting
*              VBELN = lv_VBELN.
*            counter = 70.
*          else.
*            counter = counter + 1.
*            wait up to 1 SECONDS.
*          endif.
*        endwhile.
*
*      endif.
*        ENDLOOP.
*      ENDIF.
*      ENDIF.
*      ENDIF.
*      BREAK abap_BHAGWAN.
**********Code Ends by Bhagavan on 10/11/2021 "DR1K961678*******************************
ENDENHANCEMENT.
