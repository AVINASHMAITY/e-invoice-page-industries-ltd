*---------------------------------------------------------------------*
*    program for:   TABLEFRAME_ZCYG_SHIP_DETAIL
*---------------------------------------------------------------------*
FUNCTION TABLEFRAME_ZCYG_SHIP_DETAIL   .

  PERFORM TABLEFRAME TABLES X_HEADER X_NAMTAB DBA_SELLIST DPL_SELLIST
                            EXCL_CUA_FUNCT
                     USING  CORR_NUMBER VIEW_ACTION VIEW_NAME.

ENDFUNCTION.
