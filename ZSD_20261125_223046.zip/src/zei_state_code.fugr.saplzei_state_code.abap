*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZEI_STATE_CODETOP.                " Global Data
  INCLUDE LZEI_STATE_CODEUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZEI_STATE_CODEF...                " Subroutines
* INCLUDE LZEI_STATE_CODEO...                " PBO-Modules
* INCLUDE LZEI_STATE_CODEI...                " PAI-Modules
* INCLUDE LZEI_STATE_CODEE...                " Events
* INCLUDE LZEI_STATE_CODEP...                " Local class implement.
* INCLUDE LZEI_STATE_CODET99.                " ABAP Unit tests
  INCLUDE LZEI_STATE_CODEF00                      . " subprograms
  INCLUDE LZEI_STATE_CODEI00                      . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
