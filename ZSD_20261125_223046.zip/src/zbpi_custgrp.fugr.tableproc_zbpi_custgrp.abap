*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBPI_CUSTGRP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBPI_CUSTGRP        .

  PERFORM TABLEPROC.

ENDFUNCTION.
