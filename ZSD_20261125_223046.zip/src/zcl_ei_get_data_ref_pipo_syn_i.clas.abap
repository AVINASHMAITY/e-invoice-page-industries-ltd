class ZCL_EI_GET_DATA_REF_PIPO_SYN_I definition
  public
  create public .

public section.

  interfaces ZII_EI_GET_DATA_REF_PIPO_SYN_I .
protected section.
private section.
ENDCLASS.



CLASS ZCL_EI_GET_DATA_REF_PIPO_SYN_I IMPLEMENTATION.


  method ZII_EI_GET_DATA_REF_PIPO_SYN_I~EI_GET_DATA_REF_PIPO_SYN_IN_SI.
*** **** INSERT IMPLEMENTATION HERE **** ***
  endmethod.
ENDCLASS.
