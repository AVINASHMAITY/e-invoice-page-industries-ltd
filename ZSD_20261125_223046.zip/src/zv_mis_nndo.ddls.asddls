/*
----------------------------------------------------------
Object Name           : ZV_MIS_NNDO
Author/Comapny Name   : Chandra Mohan/ITEANZ
Transport Request     : DR1K938213
Creation Date         : 18.01.2018
----------------------------------------------------------
Description : NNDO
----------------------------------------------------------
*/
@AbapCatalog.sqlViewName: 'ZSV_MIS_NNDO'
@AbapCatalog.compiler.CompareFilter: true
@AccessControl.authorizationCheck: #NOT_REQUIRED
@ClientDependent: true
@EndUserText.label: 'MIS View for NNDO'
define view ZV_MIS_NNDO 
with parameters langauage : abap.lang, client : abap.clnt
as select from /obiz/zbn_dochdr[ doccat = 'NNDO' ] as _NNDO
left outer join /obiz/zbn_bldtl[ doccat = 'NNDO' ] as _NNDOI
    on _NNDO.docnr = _NNDOI.docnr
    and _NNDO.docdate = _NNDOI.docdate
    // Country of cosginment
//left outer join t005t[ spras = $parameters.langauage ] as _T005t
left outer join t005t as _T005t
    on _NNDOI.ctryconsgn = _T005t.land1
    and _T005t.spras = $parameters.langauage 
//Port
left outer join /obiz/zcm_codmas as _port
    on _NNDOI.portload = _port.code
    and _port.codtyp = 'PORT'  
left outer join /obiz/zbn_condtl as _CONT 
    on _NNDO.docnr = _CONT.docnr
    and _NNDO.docdate = _CONT.docdate
left outer join /obiz/zcm_codmas as _DELM
    on _NNDOI.modedel = _DELM.code 
    and _DELM.codtyp = 'DELM'      
left outer join /obiz/zcm_codmas as _PACK
    on _NNDOI.zzpkg_unit = _PACK.code
    and _PACK.codtyp = 'PACK' 
left outer join /obiz/zcm_codmas as _portdisc
    on _NNDOI.portdiscrg = _portdisc.code
    and _portdisc.codtyp = 'PORT'
left outer join /obiz/zbn_invhdr as _NNDOINV
    on _NNDO.docnr = _NNDOINV.docnr
    and _NNDO.docdate = _NNDOINV.docdate
    and _NNDO.refdocnr = _NNDOINV.refdocnr
    and _NNDO.refdocdt = _NNDOINV.refdocdt
    and _NNDOINV.doccat = 'NNDO'
left outer join /obiz/zbn_invitm as _NNDOINVI
    on _NNDOINV.docnr = _NNDOINVI.docnr
    and _NNDOINV.docdate = _NNDOINVI.docdate
    and _NNDOINV.refdocnr = _NNDOINVI.refdocnr
    and _NNDOINVI.doccat = 'NNDO'
left outer join /obiz/zmb_beitm as _BOEITM
    on _NNDOINVI.ebeln = _BOEITM.refdocno
    and _NNDOINVI.ebelp = _BOEITM.refdocitno
    and _NNDOINV.invoicenr = _BOEITM.invno
{
_NNDO.docnr as docnr,
_NNDO.docdate as docdate,
_NNDO.refdocnr as refdocnr,
_NNDO.refdocdt as refdocdt,
_NNDO.hawbno as HAWBNO,
_NNDO.hawbdt as HAWBDT,
_NNDO.mawbno as MAWBNO,
_NNDO.mawbdt as MAWBDT,
_NNDO.bolnr as BOLNR,
_NNDO.boldt as BOLDT,
_NNDOI.ctryconsgn as ctryconsgn,
_NNDOI.ergei as ERGEI,
_NNDOI.btgew as BTGEW,
_NNDOI.chargewt as CHARGEWT,
_NNDOI.meins as CMEINS,
_NNDOI.pkgno as PKGNO,
_T005t.landx as landx,
_port.coddesc as coddesc1,
_PACK.coddesc as coddesc2, 
_NNDOI.portload as portload,
_portdisc.coddesc as portdisc,
_NNDOINV.invoiceval as INVOICEVAL,
_NNDOINV.invoicecur as INVOICECUR,
case 
    when _CONT.status = 'LCL' then 'Low container level'
    when _CONT.status = 'FCL' then 'Full container level'
    else ''
 end as C_status,
 _DELM.coddesc as DELMD, 
//Shipping documents routed through Bank
 case 
    when _NNDOI.zzpayterms = 'DP' then 'Document Presentation'
    when _NNDOI.zzpayterms = 'DA' then 'Delivery against Acceptance'
    when _NNDOI.zzpayterms = 'FC' then 'Free of charge'
    when _NNDOI.zzpayterms = 'LC' then 'Letter of credit'
    when _NNDOI.zzpayterms = 'DP' then 'Document Presentation'
    when _NNDOI.zzpayterms = 'OTH' then 'Others'
    when _NNDOI.zzpayterms = 'SD' then 'Site Draft'
    else ''
  end as pay_temrs,
_NNDOINV.invoicenr as INVOICENR,
_NNDOINV.invoicedt as INVOICEDT, 
//_NNDOINVI.netpr as INVOICEVAL,
//_NNDOINVI.netcur as INVOICECUR,
_BOEITM.netpr as INVOICEVALB,
_BOEITM.wkurs1 as wkurs1,
_BOEITM.totval as totval, 
_NNDOINVI.ebeln as EBELN,
_NNDOINVI.ebelp as EBELP,
_NNDOINVI.menge as MENGE,
_NNDOINVI.meins as MEINS,
_NNDOINVI.netpr as NETPR,
_NNDOINVI.netcur as NETCUR,
_NNDOINVI.refdocnr as REFDOCNRI,
_NNDOINVI.netval as NETVAL,
_port.code as code                          //Added by bhgavan on 26/05/2022 DR1K965918
}
group by _NNDO.docnr, _NNDO.docdate, _NNDO.refdocnr, _NNDO.refdocdt, _NNDO.hawbno, _NNDO.hawbdt, _NNDO.mawbno, _NNDO.mawbdt, _NNDO.bolnr,
         _NNDO.boldt, _NNDOI.ctryconsgn, _NNDOI.btgew, 
         _NNDOI.ergei, 
         _NNDOI.chargewt, _NNDOI.meins, _NNDOI.pkgno, _T005t.landx, _port.coddesc, _PACK.coddesc, _NNDOI.portload,
         _portdisc.coddesc,
         _NNDOINV.invoicenr, _NNDOINV.invoicedt, _NNDOINV.invoiceval, _NNDOINV.invoicecur, _NNDOINVI.ebeln, _NNDOINVI.ebelp, _NNDOINVI.menge,
         _NNDOINVI.meins, _NNDOINVI.netpr, _NNDOINVI.netcur, 
         _BOEITM.netpr, _BOEITM.wkurs1, _BOEITM.totval,
         _NNDOINVI.refdocnr, _NNDOINVI.netval, 
        _CONT.status, _DELM.coddesc, _NNDOI.zzpayterms,
        _port.code                                        //Added by bhgavan on 26/05/2022 DR1K965918
