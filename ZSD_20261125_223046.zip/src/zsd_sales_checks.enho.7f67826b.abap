"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SALES_CHECKS.

*************************************************************
***                 Change Log                             ***
**************************************************************
* Developer         : Lokesh/Iteanz
* Chnages           : Restricting Z2 Block for Return order in
*                     1102 sales.Org
* Transaport        : DR1K925512- subtask under DR1K922860
************************************************************
*****************************************************************
* Developer         : Ravindran/Iteanz
* Changes           : Restricting Z1 Block for Order Type
*                     which maintained in ZSD_RESTRICT_BLK table
* Transaport        : DR1K938680
*****************************************************************
************************************************************
*****************************************************************
* Developer         : Bhagavan/Iteanz
* Changes           : Restricting Z1 Block for Order Type
*                     which maintained in ZSD_RESTRICT_BLK table
*                     for the ZSD_QUOT_SO & YBOT
* Transaport        : DR1K953998
*****************************************************************

TYPES:BEGIN OF ty_mch1,
      matnr	TYPE matnr,  "Material Number
      charg	TYPE charg_d,"Batch Number

      laeda	TYPE laeda,  "Date of Last Change
      vfdat	TYPE vfdat,  "Shelf Life Expiration or Best-Before Date
      END OF ty_mch1.

TYPES:BEGIN OF ty_ztsd_b_so.
        INCLUDE TYPE ztsd_blocked_so.
TYPES:END OF ty_ztsd_b_so.

DATA:li_ztsd_b_so TYPE STANDARD TABLE OF ty_ztsd_b_so,
     li_ztsd_b_so2 TYPE STANDARD TABLE OF ty_ztsd_b_so,
     li_ztsd_b_so3 TYPE STANDARD TABLE OF ty_ztsd_b_so,
     lw_ztsd_b_so TYPE ty_ztsd_b_so,
     lw_yvbap TYPE vbap,
     lw_yvbap1 TYPE vbap,
     lw_xvbap TYPE vbap,
     lw_xvbap1 TYPE vbap,
     lw_yvbkd TYPE vbkd,
     lw_xvbkd TYPE vbkd,
     lw_xkomv TYPE komv,
     lw_knvv  TYPE knvv,
     li_mch1 TYPE STANDARD TABLE OF ty_mch1,
     lw_mch1 TYPE ty_mch1.

DATA:lv_kwmeng_f TYPE flag,
     lv_charg_f TYPE flag,
     lv_blk TYPE c.


FIELD-SYMBOLS:<fs_ztsd_b_so> TYPE ty_ztsd_b_so.

CONSTANTS:c_va01 TYPE syst_tcode VALUE 'VA01',
          c_va02 TYPE syst_tcode VALUE 'VA02',
          c_1102 TYPE vkorg VALUE '1102',
          c_ztnn TYPE pstyv VALUE 'ZTNN',
          c_z004 TYPE kscha VALUE 'Z004',
          c_z005 TYPE kscha VALUE 'Z005',
          c_z007 TYPE kscha VALUE 'Z007',
          c_z1 TYPE lifsk VALUE 'Z1',
          c_0 TYPE i VALUE '0',
          c_x  TYPE flag VALUE 'X'.
*****************Begin of changes by Ravi on 27.12.2018 DR1K939031******************
CONSTANTS : GC_SALES         VALUE 'ZSD_SALES_CHECKS' TYPE SOBJ_NAME,
            GC_1101(15)      VALUE 'SO_VKORG_1101',
            GC_1102(15)      VALUE 'SO_VKORG_1102'.
DATA : GT_CONSTANTS TYPE ZTT_ZTABAP_TVARVC.
RANGES : RA_1101 FOR TVKO-VKORG,
         RA_1102 FOR TVKO-VKORG.

CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
      EXPORTING
        IM_OBJNAME = GC_SALES
      IMPORTING
        EX_TAB     = GT_CONSTANTS.

LOOP AT GT_CONSTANTS INTO DATA(GW_CONSTANTS)
                     WHERE OBJ_NAME = GC_SALES
                       AND NAME     = GC_1101.
  RA_1101-SIGN = 'I'.
  RA_1101-OPTION = 'EQ'.
  RA_1101-LOW = GW_CONSTANTS-LOW.
  APPEND RA_1101." TO RA_1101.
  CLEAR : RA_1101.
ENDLOOP.

LOOP AT GT_CONSTANTS INTO GW_CONSTANTS
                     WHERE OBJ_NAME = GC_SALES
                       AND NAME     = GC_1102.
  RA_1102-SIGN = 'I'.
  RA_1102-OPTION = 'EQ'.
  RA_1102-LOW = GW_CONSTANTS-LOW.
  APPEND RA_1102." TO RA_1101.
  CLEAR : RA_1102.
ENDLOOP.
*****************End of changes by Ravi on 27.12.2018 DR1K939031******************
*-->Check When Create
*IF sy-tcode = c_va01 AND ( vbak-vkorg = c_1102 or vbak-vkorg = '1101' ).       "Commented by Ravi on 27.12.2018 DR1K939031
IF ( sy-tcode = c_va01 OR  sy-tcode = 'ZSD_QUOT_SO' ) AND ( vbak-vkorg IN RA_1102 or vbak-vkorg IN RA_1101 ).     "Added by Ravi on 27.12.2018 DR1K939031" " 'Zsd_quot_so'Added by Bhagavan on 06.11.2020  DR1K953998
  CLEAR:li_ztsd_b_so,lw_ztsd_b_so.

*-->Check Item Category
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
 IF vbak-vkorg IN RA_1101.
  LOOP AT xvbap INTO lw_xvbap WHERE pstyv = c_ztnn.
    vbak-lifsk = c_z1.
  ENDLOOP.
 ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********

*-->Check Item Condition Type.
  SORT li_ztsd_b_so BY vbeln posnr.
  LOOP AT xkomv INTO lw_xkomv WHERE kschl = c_z004 OR kschl = c_z005 OR kschl = c_z007.
    CLEAR:lw_ztsd_b_so.
    IF lw_xkomv-kschl = c_z004 AND lw_xkomv-kbetr ne  c_0.
      vbak-lifsk = c_z1.
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
      IF vbak-vkorg IN RA_1102.
       lv_blk = 'Z'.
      ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
    ENDIF.
    IF lw_xkomv-kschl = c_z005 AND lw_xkomv-kbetr ne  c_0.
      vbak-lifsk = c_z1.
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
      IF vbak-vkorg IN RA_1102.
       lv_blk = 'Z'.
      ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
    ENDIF.
    IF lw_xkomv-kschl = c_z007 AND lw_xkomv-kbetr ne  c_0.
      vbak-lifsk = c_z1.
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
      IF vbak-vkorg IN RA_1102.
       lv_blk = 'Z'.
      ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
    ENDIF.
    ENDLOOP.

*************************************************************************
*-->Batch Number Change
*  IF xvbap IS NOT INITIAL.
*    SELECT matnr charg laeda vfdat FROM mch1
*           INTO TABLE li_mch1
*           FOR ALL ENTRIES IN xvbap
*           WHERE matnr = xvbap-matnr.
*    IF sy-subrc = 0.
*      SORT li_mch1 BY vfdat laeda.
*      DELETE ADJACENT DUPLICATES FROM li_mch1 COMPARING matnr.
*      SORT li_mch1 BY matnr.
*      SORT li_ztsd_b_so BY vbeln posnr.
*      CLEAR:lw_ztsd_b_so.
*      LOOP AT xvbap INTO lw_xvbap.
*        READ TABLE li_mch1 INTO lw_mch1 WITH KEY matnr = lw_xvbap-matnr BINARY SEARCH.
*        IF sy-subrc = 0.
*          IF lw_mch1-charg NE lw_xvbap-charg.
*            vbak-lifsk = c_z1.
*          ENDIF.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*  ENDIF.
************************************************************************
*-->Payment Term
*break sahoo.
ENDIF.
*IF ( sy-tcode = c_va01 or sy-tcode = 'VA02' ) AND ( vbak-vkorg = c_1102 or vbak-vkorg = '1101' ).   "Commented by Ravi on 27.12.2018 DR1K939031
IF ( sy-tcode = c_va01 or sy-tcode = 'VA02' OR  sy-tcode = 'ZSD_QUOT_SO' ) AND ( vbak-vkorg IN RA_1102 or vbak-vkorg IN RA_1101 )."Added by Ravi on 27.12.2018 DR1K939031 " 'Zsd_quot_so'Added by Bhagavan on 06.11.2020  DR1K953998
  SELECT SINGLE * FROM knvv INTO lw_knvv
    WHERE kunnr = vbak-kunnr
      AND vkorg = vbak-vkorg
      AND vtweg = vbak-vtweg
      AND spart = vbak-spart.
  IF sy-subrc = 0.
DATA: w_zsdt012 type zsdt012.
*break sahoo.
    LOOP AT xvbkd INTO lw_xvbkd.
      IF lw_xvbkd-zterm NE lw_knvv-zterm.
*       if vbak-vkorg ne '1101'.           "Commented by Ravi on 27.12.2018 DR1K939031
       if vbak-vkorg NOT IN RA_1101.       "Added by Ravi on 27.12.2018 DR1K939031
        vbak-lifsk = c_z1.
       else.
         CLEAR:w_zsdt012.
         SELECT SINGLE * from zsdt012 INTO w_zsdt012 WHERE vbeln = vbak-vbeln
                                                     and   zterm = lw_xvbkd-zterm.
         if sy-subrc ne 0.
           vbak-lifsk = c_z1.
            CLEAR:w_zsdt012.
         endif.
       endif.
      ENDIF.
*    if vbak-vkorg = '1101' .       "Commented by Ravi on 27.12.2018 DR1K939031
    if vbak-vkorg IN RA_1101 .      "Added by Ravi on 27.12.2018 DR1K939031
      if lw_xvbkd-zterm eq lw_knvv-zterm.
        vbak-lifsk = ''.
      endif.
    endif.
    ENDLOOP.
  ENDIF.
endif.


IF ( sy-tcode = 'VA02' OR sy-tcode = 'VA01' OR  sy-tcode = 'ZSD_QUOT_SO' ) and ( vbak-auart = 'YBOR'or vbak-auart = 'YBOT' OR vbak-auart = 'YBS1' OR "Added 'YBS1' by Ravi on 10.05.2019 " 'Zsd_quot_so' & 'YBOT' Added by Bhagavan on 06.11.2020  DR1K953998
                          vbak-auart = 'YBOI' OR vbak-auart = 'YBFR' OR vbak-auart = 'YBNR' OR vbak-auart = 'YBRE' or  vbak-auart = 'YBSC').
types : begin of lt_mch1,
          MATNR	TYPE MATNR,
          CHARG	TYPE CHARG_D,
          VFDAT	TYPE VFDAT,
          HSDAT	TYPE HSDAT,
        end of lt_mch1,

        begin of lt_mara,
          matnr type matnr,
          MHDRZ	TYPE MHDRZ,
        end of lt_mara.
data : li1_mch1 type table of lt_mch1,
       lw1_mch1 type lt_mch1,
       li_mara type table of lt_mara,
       lw_mara type lt_mara,
       lv_days type numc5.

  select MATNR
          CHARG
          VFDAT
          HSDAT
         into table li1_mch1
         from mch1
         for all entries in xvbap[]
         where matnr = xvbap-matnr
         and charg = xvbap-charg.
    IF sy-subrc = 0.
      sort li1_mch1 by matnr charg.
      select matnr MHDRZ
             into table li_mara
             from mara
             for all entries in li1_mch1
             where matnr = li1_mch1-matnr.
        IF sy-subrc = 0.
         sort li_mara by matnr.
        ENDIF.
    ENDIF.

clear lw_xvbap.
      LOOP AT xvbap INTO lw_xvbap.
        read table YVBAP into LW_YVBAP
                           with  key vbeln = lw_xvbap-vbeln
                                     posnr = lw_xvbap-posnr.
       IF SY-subrc = 0.
         IF lw_Yvbap-charg NE lw_xvbap-charg.
            vbak-lifsk = c_z1.
            unassign <fs_ztsd_b_so>.
            READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so>
                                    WITH KEY vbeln = vbak-vbeln
                                             posnr = lw_xvbap-posnr BINARY SEARCH.
            IF <fs_ztsd_b_so> is assigned.
              <fs_ztsd_b_so>-kwmeng = lw_xvbap-kwmeng.
              <fs_ztsd_b_so>-charg = lw_xvbap-charg.
            ELSE.
              clear lw_ztsd_b_so.
              lw_ztsd_b_so-vbeln = vbak-vbeln.
              lw_ztsd_b_so-posnr = lw_xvbap-posnr.
              lw_ztsd_b_so-zchang = sy-datum.
              lw_ztsd_b_so-charg = lw_xvbap-charg.
              lw_ztsd_b_so-kwmeng = lw_xvbap-kwmeng.
              APPEND lw_ztsd_b_so TO li_ztsd_b_so.
              CLEAR:lw_ztsd_b_so.
              SORT li_ztsd_b_so BY vbeln posnr.
      endif.
         ENDIF.
       endif.
       read table li1_mch1 into lw1_mch1
                          with key matnr = lw_xvbap-matnr
                                   charg = lw_Xvbap-charg.
       IF sy-subrc = 0.
        read table li_mara into lw_mara
                            with key matnr = lw1_mch1-matnr.
        IF sy-subrc = 0.
          lv_days = lw1_mch1-vfdat - lw1_mch1-hsdat.
         IF lv_days < lw_mara-mhdrz or lw_xvbap-pstyv eq 'ZTNN'.
          vbak-lifsk = c_z1.
            unassign <fs_ztsd_b_so>.
       READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = vbak-vbeln
                                                                      posnr = lw_xvbap-posnr BINARY SEARCH.
            IF <fs_ztsd_b_so> is assigned.
              <fs_ztsd_b_so>-kwmeng = lw_xvbap-kwmeng.
              <fs_ztsd_b_so>-charg = lw_xvbap-charg.
            ELSE.
              clear lw_ztsd_b_so.
              lw_ztsd_b_so-vbeln = vbak-vbeln.
              lw_ztsd_b_so-posnr = lw_xvbap-posnr.
              lw_ztsd_b_so-zchang = sy-datum.
              lw_ztsd_b_so-charg = lw_xvbap-charg.
              lw_ztsd_b_so-kwmeng = lw_xvbap-kwmeng.
              APPEND lw_ztsd_b_so TO li_ztsd_b_so.
              CLEAR:lw_ztsd_b_so.
              SORT li_ztsd_b_so BY vbeln posnr.
      endif.
         ENDIF.
       ENDIF.
       endif.
      endloop.
*****

*****************Start of Code on 05.30.2014
       LOOP AT xvbap INTO lw_xvbap.
*        read table YVBAP into LW_YVBAP
*                           with  key vbeln = lw_xvbap-vbeln
*                                     posnr = lw_xvbap-posnr.
*       IF SY-subrc = 0.
*         IF lw_Yvbap-charg NE lw_xvbap-charg.
            unassign <fs_ztsd_b_so>.
            READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so>
                                    WITH KEY vbeln = vbak-vbeln
                                             posnr = lw_xvbap-posnr BINARY SEARCH.
            IF <fs_ztsd_b_so> is assigned.
              <fs_ztsd_b_so>-kwmeng = lw_xvbap-kwmeng.
              <fs_ztsd_b_so>-charg = lw_xvbap-charg.
            ELSE.
              clear lw_ztsd_b_so.
              lw_ztsd_b_so-vbeln = vbak-vbeln.
              lw_ztsd_b_so-posnr = lw_xvbap-posnr.
              lw_ztsd_b_so-zchang = sy-datum.
              lw_ztsd_b_so-charg = lw_xvbap-charg.
              lw_ztsd_b_so-kwmeng = lw_xvbap-kwmeng.
              APPEND lw_ztsd_b_so TO li_ztsd_b_so.
              CLEAR:lw_ztsd_b_so.
              SORT li_ztsd_b_so BY vbeln posnr.
      endif.
*         ENDIF.
*       endif.
       read table li1_mch1 into lw1_mch1
                          with key matnr = lw_xvbap-matnr
                                   charg = lw_Xvbap-charg.
       IF sy-subrc = 0.
        read table li_mara into lw_mara
                            with key matnr = lw1_mch1-matnr.
        IF sy-subrc = 0.
          lv_days = lw1_mch1-vfdat - lw1_mch1-hsdat.
         IF lv_days < lw_mara-mhdrz or lw_xvbap-pstyv eq 'ZTNN'.
          vbak-lifsk = c_z1.
            unassign <fs_ztsd_b_so>.
       READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = vbak-vbeln
                                                                      posnr = lw_xvbap-posnr BINARY SEARCH.
            IF <fs_ztsd_b_so> is assigned.
              <fs_ztsd_b_so>-kwmeng = lw_xvbap-kwmeng.
              <fs_ztsd_b_so>-charg = lw_xvbap-charg.
            ELSE.
              clear lw_ztsd_b_so.
              lw_ztsd_b_so-vbeln = vbak-vbeln.
              lw_ztsd_b_so-posnr = lw_xvbap-posnr.
              lw_ztsd_b_so-zchang = sy-datum.
              lw_ztsd_b_so-charg = lw_xvbap-charg.
              lw_ztsd_b_so-kwmeng = lw_xvbap-kwmeng.
              APPEND lw_ztsd_b_so TO li_ztsd_b_so.
              CLEAR:lw_ztsd_b_so.
              SORT li_ztsd_b_so BY vbeln posnr.
      endif.
         ENDIF.
       ENDIF.
       endif.
      endloop.

*********************End of Code 05.30.2014***********

ENDIF.
*IF ( sy-tcode = 'VA02' OR sy-tcode = 'VA01' ) and ( Vbak-auart = 'YBOI' ) and ( VBAK-VKORG = '1102') and "Commented by Ravi on 27.12.2018 DR1K939031
IF ( sy-tcode = 'VA02' OR sy-tcode = 'VA01' OR  sy-tcode = 'ZSD_QUOT_SO' ) and ( Vbak-auart = 'YBOI' ) and ( VBAK-VKORG IN RA_1102 ) and  "Added by Ravi on 27.12.2018 DR1K939031 " 'Zsd_quot_so' Added by Bhagavan on 06.11.2020  DR1K953998
  ( VBAK-VTWEG = '50') and ( VBAK-SPART = '19')."OR vbak-auart = 'YBFR' OR vbak-auart = 'YBNR' OR vbak-auart = 'YBRE' ).
  vbak-lifsk = c_z1.
endif.
*-->Check When Change.
*IF sy-tcode = c_va02 AND vbak-vkorg = c_1102 ."or vbak-vkorg = '1101' ) . "Commented by Ravi on 27.12.2018 DR1K939031
IF sy-tcode = c_va02 AND vbak-vkorg IN RA_1102 ."or vbak-vkorg = '1101' ) .  "Added by Ravi on 27.12.2018 DR1K939031
  CLEAR:li_ztsd_b_so2,li_ztsd_b_so3,lw_ztsd_b_so.

*-->Check Item Category
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
*  LOOP AT yvbap INTO lw_yvbap WHERE pstyv ne c_ztnn.
*    READ TABLE xvbap INTO lw_xvbap with key vbeln = lw_yvbap-vbeln posnr = lw_yvbap-posnr BINARY SEARCH.
*    IF lw_xvbap-pstyv = c_ztnn.
**    vbak-lifsk = c_z1.      "Commented by Ravi on 19.09.2019 DR1K947547
*    lw_ztsd_b_so-vbeln = vbak-vbeln.
*    lw_ztsd_b_so-posnr = lw_yvbap-posnr.
*
*    lw_ztsd_b_so-pstyv = lw_yvbap-pstyv.
*    APPEND lw_ztsd_b_so TO li_ztsd_b_so.
*    CLEAR:lw_ztsd_b_so.
*    ENDIF.
*  ENDLOOP.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
*-->Check Item Condition Type.
  CLEAR:lw_ztsd_b_so.
  SORT li_ztsd_b_so BY vbeln posnr.
  LOOP AT xkomv INTO lw_xkomv WHERE ( kschl = c_z004 OR kschl = c_z005 OR kschl = c_z007 ) and ( UPDKZ = 'U' ).
    CLEAR:lw_ztsd_b_so.
    IF lw_xkomv-kschl = c_z004 AND lw_xkomv-kbetr ne  c_0.
      vbak-lifsk = c_z1.
      lw_ztsd_b_so-kbetr_4 = lw_xkomv-kbetr.
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
      IF vbak-vkorg IN RA_1102.
       lv_blk = 'Z'.
      ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
    ENDIF.
    IF lw_xkomv-kschl = c_z005 AND lw_xkomv-kbetr ne  c_0.
      vbak-lifsk = c_z1.
      lw_ztsd_b_so-kbetr_5 = lw_xkomv-kbetr.
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
      IF vbak-vkorg IN RA_1102.
       lv_blk = 'Z'.
      ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
    ENDIF.
    IF lw_xkomv-kschl = c_z007 AND lw_xkomv-kbetr ne  c_0.
      vbak-lifsk = c_z1.
      lw_ztsd_b_so-kbetr_7 = lw_xkomv-kbetr.
***Begin of changes by Ravi on 19.09.2019 DR1K947547 **********
      IF vbak-vkorg IN RA_1102.
       lv_blk = 'Z'.
      ENDIF.
***End of changes by Ravi on 19.09.2019 DR1K947547 **********
    ENDIF.
    IF lw_ztsd_b_so-kbetr_4 IS NOT INITIAL OR lw_ztsd_b_so-kbetr_5 IS NOT INITIAL OR lw_ztsd_b_so-kbetr_7 IS NOT INITIAL.
      SORT li_ztsd_b_so BY vbeln posnr.
      READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = vbak-vbeln
                                                                posnr = lw_xkomv-KPOSN BINARY SEARCH.
      IF sy-subrc = 0.
        IF lw_xkomv-kschl = c_z004.
        <fs_ztsd_b_so>-kbetr_4 = lw_ztsd_b_so-kbetr_4.
        ELSEIF lw_xkomv-kschl = c_z005.
        <fs_ztsd_b_so>-kbetr_5 = lw_ztsd_b_so-kbetr_5.
        ELSEIF lw_xkomv-kschl = c_z007.
        <fs_ztsd_b_so>-kbetr_7 = lw_ztsd_b_so-kbetr_7.
        ENDIF.
      ELSE.
          lw_ztsd_b_so-vbeln = vbak-vbeln.
          lw_ztsd_b_so-posnr = lw_xkomv-kposn.

          APPEND lw_ztsd_b_so TO li_ztsd_b_so.
          CLEAR:lw_ztsd_b_so.
        ENDIF.
      ENDIF.
  ENDLOOP.

  types : BEGIN OF t_rele,
          VBELN type VBELN_VA,
          POSNR type POSNR_VA,
          end of t_rele .

 types : BEGIN OF t_block,
         VBELN type VBELN_VA,
         POSNR type POSNR_VA,
         REJECTED type ZREJECTED,
         end of t_block .
data : w_rele type t_rele,
       w_block type t_block.


**-->Quantity & Batch Number Change
  IF yvbap IS NOT INITIAL.
    SORT li_ztsd_b_so BY vbeln posnr.
    CLEAR:lw_ztsd_b_so.

    loop at yvbap INTO lw_yvbap1.

        select single vbeln
                      posnr from ZTSD_RELEASE_SO into w_rele WHERE vbeln = lw_yvbap1-vbeln and
                                                                   posnr = lw_yvbap1-posnr .

        IF sy-subrc = 0.
          READ TABLE xvbap INTO lw_xvbap1 WITH KEY vbeln = lw_yvbap1-vbeln
                                                   posnr = lw_yvbap1-posnr.
        IF lw_xvbap1-kwmeng NE lw_yvbap1-kwmeng .

          vbak-lifsk = c_z1.
          lv_kwmeng_f = c_x.
        ENDIF.
        endif.


       select single vbeln
                     posnr
                     REJECTED  from ZTSD_BLOCKED_SO into w_block WHERE vbeln = lw_yvbap1-vbeln and
                                                                       posnr = lw_yvbap1-posnr and
                                                                       REJECTED = 'X' .
    IF sy-subrc = 0.

       READ TABLE xvbap INTO lw_xvbap1 WITH KEY vbeln = lw_yvbap1-vbeln
                                                posnr = lw_yvbap1-posnr.
        IF lw_xvbap1-kwmeng NE lw_yvbap1-kwmeng .

          vbak-lifsk = c_z1.
          lv_kwmeng_f = c_x.
        ENDIF.
        endif.

    endloop.


    LOOP AT yvbap INTO lw_yvbap.
      CLEAR:lv_kwmeng_f,lv_charg_f.
      READ TABLE xvbap INTO lw_xvbap WITH KEY vbeln = lw_yvbap-vbeln
                                              posnr = lw_yvbap-posnr.
*
      IF sy-subrc = 0.
*        IF lw_xvbap-kwmeng NE lw_yvbap-kwmeng .
*
*          vbak-lifsk = c_z1.
*          lv_kwmeng_f = c_x.
*        ENDIF.
        IF lw_xvbap-charg NE lw_yvbap-charg.
          vbak-lifsk = c_z1.
          lv_charg_f = c_x.
        ENDIF.
      ENDIF.
      IF  lv_kwmeng_f IS NOT INITIAL OR lv_charg_f IS NOT INITIAL.
        READ TABLE li_ztsd_b_so ASSIGNING <fs_ztsd_b_so> WITH KEY vbeln = lw_yvbap-vbeln
                                                                   posnr = lw_yvbap-posnr BINARY SEARCH.
        IF sy-subrc = 0.
          IF lv_kwmeng_f IS NOT INITIAL.
            <fs_ztsd_b_so>-kwmeng = lw_yvbap-kwmeng.
          ENDIF.
*          IF lv_charg_f IS NOT INITIAL.
            <fs_ztsd_b_so>-charg = lw_yvbap-charg.
*          ENDIF.
        ELSE.
          READ TABLE xvbap INTO lw_xvbap WITH KEY vbeln = lw_yvbap-vbeln
                                                  posnr = lw_yvbap-posnr BINARY SEARCH.
          IF sy-subrc = 0.
            lw_ztsd_b_so-vbeln = vbak-vbeln.
            lw_ztsd_b_so-posnr = lw_yvbap-posnr.

            IF lv_kwmeng_f IS NOT INITIAL.
              lw_ztsd_b_so-kwmeng = lw_yvbap-kwmeng.
            ENDIF.
*            IF lv_charg_f IS NOT INITIAL.
              lw_ztsd_b_so-charg = lw_yvbap-charg.
*            ENDIF.
            APPEND lw_ztsd_b_so TO li_ztsd_b_so.
            CLEAR:lw_ztsd_b_so.
            SORT li_ztsd_b_so BY vbeln posnr.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.
  ENDIF.

*-->Payment Term Change
*  IF vbak-lifsk NE 'Z1'.
  IF yvbkd IS NOT INITIAL.
    CLEAR:lw_knvv.
    SELECT SINGLE * FROM knvv INTO lw_knvv
    WHERE kunnr = vbak-kunnr
      AND vkorg = vbak-vkorg
      AND vtweg = vbak-vtweg
      AND spart = vbak-spart.
  IF sy-subrc = 0.
    LOOP AT yvbkd INTO lw_yvbkd where zterm = lw_knvv-zterm.
      READ TABLE xvbkd INTO lw_xvbkd WITH KEY vbeln = lw_yvbkd-vbeln
                                              posnr = lw_yvbkd-posnr.
      IF sy-subrc = 0.
        IF lw_xvbkd-zterm NE lw_knvv-zterm.
          vbak-lifsk = c_z1.
        ENDIF.
      ENDIF.
    ENDLOOP.
   ENDIF.
  ENDIF.


  IF vbak-lifsk = c_z1 AND li_ztsd_b_so IS NOT INITIAL.
    SELECT * FROM ztsd_blocked_so INTO TABLE li_ztsd_b_so2
      FOR ALL ENTRIES IN li_ztsd_b_so
      WHERE vbeln = li_ztsd_b_so-vbeln
      AND   posnr = li_ztsd_b_so-posnr.

    SORT li_ztsd_b_so2 BY vbeln posnr.
    LOOP AT li_ztsd_b_so ASSIGNING <fs_ztsd_b_so>.  "New Values
      READ TABLE li_ztsd_b_so2 INTO lw_ztsd_b_so WITH KEY vbeln = <fs_ztsd_b_so>-vbeln
                                                          posnr = <fs_ztsd_b_so>-posnr BINARY SEARCH.
      IF sy-subrc = 0.
        IF <fs_ztsd_b_so>-charg IS INITIAL.
          <fs_ztsd_b_so>-charg = lw_ztsd_b_so-charg.
        ENDIF.
        IF <fs_ztsd_b_so>-kwmeng IS INITIAL.
          <fs_ztsd_b_so>-kwmeng = lw_ztsd_b_so-kwmeng.
        ENDIF.
        IF <fs_ztsd_b_so>-pstyv IS INITIAL.
          <fs_ztsd_b_so>-pstyv = lw_ztsd_b_so-pstyv.
        ENDIF.
        IF <fs_ztsd_b_so>-kbetr_4 IS INITIAL.
          <fs_ztsd_b_so>-kbetr_4 = lw_ztsd_b_so-kbetr_4.
        ENDIF.
        IF <fs_ztsd_b_so>-kbetr_5 IS INITIAL.
          <fs_ztsd_b_so>-kbetr_5 = lw_ztsd_b_so-kbetr_5.
        ENDIF.
        IF <fs_ztsd_b_so>-kbetr_7 IS INITIAL.
          <fs_ztsd_b_so>-kbetr_7 = lw_ztsd_b_so-kbetr_7.
        ENDIF.
       <fs_ztsd_b_so>-REJECTED = lw_ztsd_b_so-rejected.
       <fs_ztsd_b_so>-REJ_DATE = lw_ztsd_b_so-REJ_DATE.
       <fs_ztsd_b_so>-REJ_BY = lw_ztsd_b_so-REJ_BY.
      ENDIF.

      <fs_ztsd_b_so>-zchang = sy-datum.
      append <fs_ztsd_b_so> TO li_ztsd_b_so3.
    ENDLOOP.
    MODIFY ztsd_blocked_so FROM TABLE li_ztsd_b_so3.
  ENDIF.

ENDIF.

If sy-tcode = 'VA01' or Sy-tcode = 'VA02' OR  sy-tcode = 'ZSD_QUOT_SO' .  " 'Zsd_quot_so' Added by Bhagavan on 06.11.2020  DR1K953998
*Break sahoo.
DATA:    lv_creditlimit TYPE  knkk-klimk,
         lv_delta_to_limit  TYPE  knkk-klimk,
         lv_netwr TYPE netwr_ak,
         lv_perc TYPE numc4,
         lv_kunnr TYPE kunnr,
         lv_sum_open TYPE rf02l-oblig,
         lv_stp TYPE kunnr,
         lv_waerk	TYPE waerk,
         lv_knumv TYPE knumv,
         lv_vkorg TYPE vkorg.
*Break sahoo.
If sy-ucomm = 'SICH'.

*If VBAK-VKORG = '1102' and VBAK-LIFSK = 'Z1'.   "Commented by Ravi on 27.12.2018 DR1K939031
If VBAK-VKORG IN RA_1102 and VBAK-LIFSK = 'Z1'.    "Added by Ravi on 27.12.2018 DR1K939031
   LOOP AT XVBAP.
      XVBAP-fixmg = abap_true.
      MODIFY XVBAP.
    ENDLOOP.
    else.
   LOOP AT XVBAP.
      XVBAP-fixmg = abap_false.
      MODIFY XVBAP.
    ENDLOOP.
endif.
*If VBAK-VKORG = '1101' and VBAK-LIFSK = 'Z1'.
*   LOOP AT XVBAP.
*      XVBAP-fixmg = abap_true.
*      MODIFY XVBAP.
*    ENDLOOP.
*    else.
*   LOOP AT XVBAP.
*      XVBAP-fixmg = abap_false.
*      MODIFY XVBAP.
*    ENDLOOP.
*endif.
*break sahoo.
*If VBAK-AUART = 'YBSC'." and VBAK-LIFSK = 'Z1'.
*   LOOP AT XVBAP.
*      XVBAP-lgort = '1014'.
*      MODIFY XVBAP.
*    ENDLOOP.
*endif.
*If VBAK-AUART ne 'YBSC'." and VBAK-LIFSK = 'Z1'.
**   LOOP AT XVBAP.
**     if  XVBAP-lgort = '1014'.
**      XVBAP-lgort = ''.
**      XVBAP-kbmeng = ''.
**      XVBAP-KLMENG = ''.
**      XVBAP-CHARG = ''.
**      XVBAP-BWTAR = ''.
**      XVBAP-KATPMN = ''.
**      loop at XVBEP where posnr = XVBAP-POSNR.
**        xvbep-bmeng = ''.
**        xvbep-lmeng = ''.
**        xvbep-CMENG = ''.
***        xvbep-bmeng = ''.
**       modify xvbep.
**      endloop.
**      MODIFY XVBAP.
**     endif.
**    ENDLOOP.
*endif.
endif.
*If vbak-vkorg = '1102' and  VBAK-LIFSK eq ''.       "Commented by Ravi on 27.12.2018 DR1K939031
If vbak-vkorg IN RA_1102 and  VBAK-LIFSK eq ''.        "Added by Ravi on 27.12.2018 DR1K939031
  CALL FUNCTION 'CREDIT_EXPOSURE'

             EXPORTING
               kkber                      = '1001'
               kunnr                      = VBAK-kunnr
              date_credit_exposure       = '99991231'
            IMPORTING
              creditlimit                = lv_creditlimit
              delta_to_limit             = lv_delta_to_limit
              sum_opens                  = lv_sum_open .
IF lv_sum_open is not INITIAL .
  LOOP AT XVBAP.
      XVBAP-fixmg = abap_true.
      MODIFY XVBAP.
    ENDLOOP.
ENDIF.
endif.
endif.
If sy-tcode = 'VA01' OR  sy-tcode = 'ZSD_QUOT_SO'. " 'Zsd_quot_so' Added by Bhagavan on 06.11.2020  DR1K953998
if fcode eq 'SICH' OR  sy-tcode = 'ZSD_QUOT_SO'. " 'Zsd_quot_so' Added by Bhagavan on 03.12.2020  DR1K953998

*If sy-ucomm = 'SICH' or sy-ucomm = 'YES'.
*If sy-ucomm = 'SICH' ."or sy-ucomm = 'YES'.
DATA: v_ind type i.
DATA: W_vbap type vbap.
DATA: W_vbapY type vbap.
DATA: w_komv type komv.
DATA: i_cond type TABLE OF ZSDT008,
      w_cond type ZSDT008,
      w_kschl type ZSDT008-kschl.
DATA: v_kbetr type komv-kbetr.
DATA: v_kbetrr type komv-kbetr.
DATA: v_kbetr1 type komv-kbetr.
DATA: v_zfr1 type komv-kbetr.
DATA: v_zfr2 type komv-kbetr.
DATA: v_zbas type komv-kbetr.
DATA: v_Block type vbap-netwr.
DATA: v_Block1 type sTRING.
DATA: v_flag type C.
DATA: i_ZSDT009 type TABLE OF ZSDT009,
      w_zsdt009 type ZSDT009.
data : z2_flag TYPE c. "added by Samata P 08.02.2023 DR1K972180
data : w_temp type zsdt009 .   " Added by raju on 13.10.2015
data : v_rel  ,                " Added by raju on 26.10.2015
      v_date type datum ,      " Added by raju on 26.10.2015
      v_name TYPE syst_uname . " Added by raju on 26.10.2015
data : xvbep1 type TABLE OF vbep ,  " Added by raju on 15.10.2015
      ls_xvbep1 type vbep .            " Added by raju on 15.10.2015
DATA: I_temp type TABLE OF zsdt009.

CONSTANTS : c_x1 type c VALUE 'X' ,  " Added by raju on 13.10.2015
            c_h type c VALUE 'H' .
data:

  ls_xvbep      like xvbep,
  ls_vbepkom    type vbepkom,
  ls_vbepkomx   type vbepkomx.

*if vbak-vkorg = '1101'.       "Commented by Ravi on 27.12.2018 DR1K939031
if vbak-vkorg IN RA_1101.      "Added by Ravi on 27.12.2018 DR1K939031
*break sahoo.

*DATA: v_netwr(18) type N.
*DATA: v_netwr1(18) type N."vbak-netwr.
*DATA: v_netwr2(18) type N." vbak-netwr.

select * from ZSDT008 INTO TABLE i_cond .
*break sahoo.
SELECT * from ZSDT009 INTO TABLE i_temp where vbeln = vbak-vbeln.

*DESCRIBE TABLE xvbap[] lines v_ind.
*if v_ind  = '1'.
loop at xvbap[] INTO W_vbap.
 READ TABLE xkomv[] INTO w_komv with key kschl = 'ZFR1'
                                         kposn = W_vbap-posnr .
if sy-subrc ne 0.
  V_flag = 'X'.
  exit.
endif.
CLEAR: w_vbap,w_komv.
endloop.
Loop at xvbap."[] INTO W_vbap.
*     Begin of code by Samata P 08.02.2023 DR1K972180
clear : z2_flag.
IF xvbap-PSTYV = 'TANN' and ( vbak-vkorg = '1101' or vbak-vkorg = '1301' ) .
  z2_flag = 'X'.
ENDIF.
*end by Samata P 08.02.2023 DR1K972180
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZBAS'
                                        kposn = xvbap-posnr.
if sy-subrc = 0  and z2_flag ne 'X'. "added by Samata P 08.02.2023 DR1K972180
v_zbas = w_komv-kwert.
CLEAR w_komv.
loop at i_cond INTO w_cond .
read TABLE xkomv[] INTO w_komv with key kschl = w_cond-kschl
                                        kposn = xvbap-posnr.

if sy-subrc = 0 and w_komv-stunr = '100' and w_komv-KINAK = ''.
 v_kbetr = w_komv-kwert.
 v_kbetrr = w_komv-kwert.
 CLEAR w_komv.
 Exit.
endif.
endloop.
if v_flag is INITIAL.
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZFR1'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
****************Begin of changes by Ravi on 09.07.2019 DR1K946324*******
*  v_zfr1 = w_komv-kwert.
*  v_zfr2 = w_komv-kwert.
****************End of changes by Ravi on 09.07.2019 DR1K946324**********
*  v_zfr1 = v_zfr1 / 10.
  CLEAR w_komv.
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZFRE'
                                         kposn = xvbap-posnr.
if sy-subrc = 0.
*v_zfr1 = ( w_komv-kbetr * v_zfr1 ) / 10000 .
****************Begin of changes by Ravi on 09.07.2019 DR1K946324*******
*v_zfr1 = w_komv-kwert + v_zfr1.
****************End of changes by Ravi on 09.07.2019 DR1K946324*********
*v_zfr2 = v_zfr1.
*v_zfr1  = w_komv-kbetr + v_zfr1.
CLEAR w_komv.
endif.
endif.
endif.
*READ TABLE xkomv[] INTO w_komv with key kschl = 'ZINS'
*                                        kposn = xvbap-posnr .
*if sy-subrc = 0.
*v_zfr1  = v_zfr1 + w_komv-kbetr.
*CLEAR w_komv.
*endif.
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZMIS'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
v_zfr1  = v_zfr1 + w_komv-kwert.
CLEAR w_komv.
endif.
*perc.
v_kbetr = v_kbetr + v_zfr1.
V_zbas = V_zbas - v_zfr2.
if v_kbetr lt V_zbas.
CLEAR:V_BLOCK1,V_block.
V_BLOCK = V_ZBAS - v_kbetr ."- v_zfr2.
V_BLOCK1 = V_BLOCK.
CONDENSE V_BLOCK1.
*v_netwr1 = V_BLOCK.
*v_netwr2 = v_kbetr .

*
*v_netwr =  v_netwr1 / v_netwr2.
* v_netwr = v_netwr * 100 .
*LOOP AT XVBAP.
*CLEAR: xvbep-LIFSP.
  CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.

      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
*      MODIFY XVBep[] TRANSPORTING LIFSP where posnr = XVBAP-POSNR.
*break sahoo.

loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.

W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetrr."  + v_zfr2 .
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
*READ TABLE i_temp INTO w_zsdt009 with key vbeln = xvbap-vbeln
*                                          posnr = Xvbap-posnr.
*if sy-subrc = 0.
*W_zsdt009-REJECT = w_zsdt009-REJECT.
*W_zsdt009-REJDATE = w_zsdt009-REJECT.
*W_zsdt009-REJNAME = w_zsdt009-REJNAME.
*W_zsdt009-RELEAS  = w_zsdt009-RELEAS.
*W_zsdt009-RELDATE = w_zsdt009-RELDATE.
*W_zsdt009-RELNAME = w_zsdt009-RELNAME.
* CLEAR w_zsdt009.
*endif.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
else.
READ TABLE i_temp INTO w_zsdt009 with key vbeln = xvbap-vbeln
                                          posnr = Xvbap-posnr.
if Sy-subrc = 0.
*CLEAR w_zsdt009.
CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetrr."  + v_zfr2.
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
*W_zsdt009-REJECT = w_zsdt009-REJECT.
*W_zsdt009-REJDATE = w_zsdt009-REJECT.
*W_zsdt009-REJNAME = w_zsdt009-REJNAME.
*W_zsdt009-RELEAS  = w_zsdt009-RELEAS.
*W_zsdt009-RELDATE = w_zsdt009-RELDATE.
*W_zsdt009-RELNAME = w_zsdt009-RELNAME.
*delete zsdt009 from W_zsdt009.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
endif.
endif.
*if v_kbetr lt V_zbas.
*V_BLOCK = V_ZBAS - v_kbetr.
*V_BLOCK1 = V_BLOCK.
*CONDENSE V_BLOCK1.
**v_netwr1 = V_BLOCK.
**v_netwr2 = v_kbetr .
*
**
**v_netwr =  v_netwr1 / v_netwr2.
** v_netwr = v_netwr * 100 .
**LOOP AT XVBAP.
*CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
*      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
*
**    ENDLOOP.
*W_zsdt009-MANDT = Sy-mandt.
*W_zsdt009-VBELN = xvbap-vbeln.
*W_zsdt009-POSNR = xvbap-posnr.
*W_zsdt009-VKORG = VBAK-vkorg.
*W_zsdt009-KUNNR = vbak-kunnr.
*W_zsdt009-MATNR = xvbap-matnr.
*W_zsdt009-ERDAT = vbak-erdat.
*W_zsdt009-ORDER_PRICE = v_kbetr.
*W_zsdt009-BASE_PRICE = V_zbas.
*W_zsdt009-DIFF = V_BLOCK.
*W_zsdt009-WERKS = XVBAP-werks.
*W_zsdt009-DOLC = sy-datum.
*W_zsdt009-CNAME = sy-uname.
*append w_zsdt009 to i_zsdt009.
*CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
*else.
*CLEAR: xvbap-BLOCK_ORDER.
**  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
*      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
*
*W_zsdt009-MANDT = Sy-mandt.
*W_zsdt009-VBELN = xvbap-vbeln.
*W_zsdt009-POSNR = xvbap-posnr.
*W_zsdt009-VKORG = VBAK-vkorg.
*W_zsdt009-KUNNR = vbak-kunnr.
*W_zsdt009-MATNR = xvbap-matnr.
*W_zsdt009-ERDAT = vbak-erdat.
*W_zsdt009-ORDER_PRICE = v_kbetr.
*W_zsdt009-BASE_PRICE = V_zbas.
*W_zsdt009-DIFF = V_BLOCK.
*W_zsdt009-WERKS = XVBAP-werks.
*W_zsdt009-DOLC = sy-datum.
*W_zsdt009-CNAME = sy-uname.
*append w_zsdt009 to i_zsdt009.
*CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
*endif.

endif.
endloop.
*endif.
if i_zsdt009 is not INITIAL.
MODIFY ZSDT009 from table i_zsdt009.
COMMIT WORK AND WAIT.
endif.
endif.
*if vbak-vkorg = '1102'.          "Commented by Ravi on 27.12.2018 DR1K939031
if vbak-vkorg IN RA_1102.         "Added by Ravi on 27.12.2018 DR1K939031
if vbak-vbtyp ne c_h."" Added by lokesh/iteanz on 29.03.2016 " Z2 Block not applicable for Returns DR1K925512 subtask
*  Break sahoo.
  SELECT * from ZSDT009 INTO TABLE i_temp where vbeln = vbak-vbeln.
select * from ZSDT008 INTO TABLE i_cond .
Loop at xvbap."[] INTO W_vbap.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.    "Added by Ravi on 20.07.2022 DR1K967366
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZBAS'
                                        kposn = xvbap-posnr.
if sy-subrc = 0 .
v_zbas = w_komv-kwert.
CLEAR w_komv.
loop at i_cond INTO w_cond .
read TABLE xkomv[] INTO w_komv with key kschl = w_cond-kschl
                                        kposn = xvbap-posnr.

if sy-subrc = '0' and w_komv-KINAK = ''.
 v_kbetr = w_komv-kwert.
 CLEAR w_komv.
 Exit.
endif.
endloop.
READ TABLE xkomv[] INTO w_komv with key kschl = 'Z004'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
v_kbetr = v_kbetr + w_komv-kwert.
 CLEAR w_komv.
endif.
READ TABLE xkomv[] INTO w_komv with key kschl = 'Z005'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
v_kbetr = v_kbetr + w_komv-kwert.
 CLEAR w_komv.
endif.
*READ TABLE xkomv[] INTO w_komv with key kschl = 'R100'
*                                        kposn = xvbap-posnr.
*if sy-subrc = 0.
*v_kbetr = v_kbetr + w_komv-kwert.
* CLEAR w_komv.
*endif.
READ TABLE xkomv[] INTO w_komv with key kschl = 'Z007'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
* w_komv-kbetr = w_komv-kbetr / 10.
* v_kbetr1 = v_kbetr.
* v_kbetr1  = ( v_kbetr1  * w_komv-kbetr  ) / 10000.
** w_komv-kbetr = v_kbetr1 .
** w_komv-kbetr = w_komv-kbetr / 1000.
* v_kbetr = v_kbetr + v_kbetr1 .
 v_kbetr = v_kbetr + w_komv-kwert .
 CLEAR w_komv.
endif.
if v_kbetr lt V_zbas.
CLEAR:V_BLOCK1,V_block.
V_BLOCK = V_ZBAS - v_kbetr.
V_BLOCK1 = V_BLOCK.
CONDENSE V_BLOCK1.
*v_netwr1 = V_BLOCK.
*v_netwr2 = v_kbetr .

*
*v_netwr =  v_netwr1 / v_netwr2.
* v_netwr = v_netwr * 100 .
*LOOP AT XVBAP.
*CLEAR: xvbep-LIFSP.
  CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.

      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
*      MODIFY XVBep[] TRANSPORTING LIFSP where posnr = XVBAP-POSNR.
*break sahoo.

loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.

W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetr.
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
*READ TABLE i_temp INTO w_zsdt009 with key vbeln = xvbap-vbeln
*                                          posnr = Xvbap-posnr.
*if sy-subrc = 0.
*W_zsdt009-REJECT = w_zsdt009-REJECT.
*W_zsdt009-REJDATE = w_zsdt009-REJECT.
*W_zsdt009-REJNAME = w_zsdt009-REJNAME.
*W_zsdt009-RELEAS  = w_zsdt009-RELEAS.
*W_zsdt009-RELDATE = w_zsdt009-RELDATE.
*W_zsdt009-RELNAME = w_zsdt009-RELNAME.
* CLEAR w_zsdt009.
*endif.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
else.
READ TABLE i_temp INTO w_zsdt009 with key vbeln = xvbap-vbeln
                                          posnr = Xvbap-posnr.
if Sy-subrc = 0.
*CLEAR w_zsdt009.
CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetr.
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
*W_zsdt009-REJECT = w_zsdt009-REJECT.
*W_zsdt009-REJDATE = w_zsdt009-REJECT.
*W_zsdt009-REJNAME = w_zsdt009-REJNAME.
*W_zsdt009-RELEAS  = w_zsdt009-RELEAS.
*W_zsdt009-RELDATE = w_zsdt009-RELDATE.
*W_zsdt009-RELNAME = w_zsdt009-RELNAME.
*delete zsdt009 from W_zsdt009.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
endif.
endif.
else.
  CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = ''.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
Endif.
endloop.


if i_zsdt009 is not INITIAL.
MODIFY ZSDT009 from table i_zsdt009.
COMMIT WORK AND WAIT.
endif.
endif.
endif.
endif.
Endif.
If sy-tcode = 'VA02'.
if fcode eq 'SICH'.
If sy-ucomm = 'SICH' or sy-ucomm = 'YES'.
DATA: w_konp TYPE konp.
*if vbak-vkorg = '1101'.               "Commented by Ravi on 27.12.2018 DR1K939031
if vbak-vkorg IN RA_1101.              "Added by Ravi on 27.12.2018 DR1K939031
select * from ZSDT008 INTO TABLE i_cond .
*break sahoo.
SELECT * from ZSDT009 INTO TABLE i_temp where vbeln = vbak-vbeln.

loop at xvbap[] INTO W_vbap where KWMENG is not initial.
*read table YVBAP[] into w_vbapy with key posnr = W_vbap-posnr.
*if sy-subrc ne 0.
 READ TABLE xkomv[] INTO w_komv with key kschl = 'ZFR1'
                                         kposn = W_vbap-posnr .
if sy-subrc ne 0.
*  if w_komv-kwemg is not initial.
  V_flag = 'X'.
  exit.
*  endif.
endif.
*endif.
CLEAR: w_vbap,w_komv,W_vbapy.
endloop.

Loop at xvbap where KWMENG is not initial."[] INTO W_vbap.
*read table YVBAP[] into w_vbapy with key posnr = xvbap-posnr.
*if sy-subrc ne 0.
*    Begin of code by Samata P 08.02.2023 DR1K972180
clear : z2_flag.
IF xvbap-PSTYV = 'TANN' and ( vbak-vkorg = '1101' or vbak-vkorg = '1301' ) .
  z2_flag = 'X'.
ENDIF.
*end by Samata P 08.02.2023 DR1K972180
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZBAS'
                                        kposn = xvbap-posnr.
if sy-subrc = 0 and z2_flag ne 'X'. " 'z2_flag' added by Samata P 08.02.2023 DR1K972180
CLEAR w_konp.
SELECT SINGLE * from konp  INTO w_konp where knumh = w_komv-knumh and loevm_ko = 'X'.
if sy-subrc ne 0 .
v_zbas = w_komv-kwert.
CLEAR w_komv.
loop at i_cond INTO w_cond .
read TABLE xkomv[] INTO w_komv with key kschl = w_cond-kschl
                                        kposn = xvbap-posnr.

if sy-subrc = 0 and w_komv-stunr = '100' and w_komv-KINAK = ''.
 v_kbetr = w_komv-kwert.
 v_kbetrr = w_komv-kwert.
 CLEAR w_komv.
 Exit.
endif.
endloop.
*if v_flag is INITIAL.     " commented by raju on 26.10.2015
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZFR1'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
****************Begin of changes by Ravi on 09.07.2019 DR1K946324*******
*  v_zfr1 = w_komv-kwert.
*  v_zfr2 = w_komv-kwert.
****************End of changes by Ravi on 09.07.2019 DR1K946324*********
*  v_zfr1 = v_zfr1 / 10.
  CLEAR w_komv.
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZFRE'
                                         kposn = xvbap-posnr.
if sy-subrc = 0.
****************Begin of changes by Ravi on 09.07.2019 DR1K946324*******
*v_zfr1 = w_komv-kwert + v_zfr1.
****************End of changes by Ravi on 09.07.2019 DR1K946324*******
CLEAR w_komv.
endif.
endif.
*endif.         " commented by raju on 26.10.2015
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZMIS'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
v_zfr1  = v_zfr1 + w_komv-kwert.
CLEAR w_komv.
endif.
*perc.
v_kbetr = v_kbetr + v_zfr1.
V_zbas = V_zbas - v_zfr2.

clear : v_zfr1 , v_zfr2 .       " added v_zfr1 , v_zfr2 by raju on 26.10.2015
if v_kbetr lt V_zbas.
CLEAR:V_BLOCK1,V_block .
V_BLOCK = V_ZBAS - v_kbetr ."- v_zfr2.
V_BLOCK1 = V_BLOCK.
CONDENSE V_BLOCK1.
" Added by raju
*if i_temp is INITIAL .
*  CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.    " Commented by raju on 15.10.2015
*
*      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.                                    " Commented by raju on 15.10.2015

loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  if vbak-vbtyp ne c_h .

  READ TABLE i_temp INTO w_temp with key posnr = ls_xvbep-posnr  .

  if sy-subrc ne 0 .
   CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.

      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.

     move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.

endif .
endif .
endloop .

* endif .
" end of code
*break sahoo.
BREAK umadevi .
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.
 " Added by raju on 13.10.2015
  if vbak-vbtyp ne c_h .
  READ TABLE i_temp INTO w_temp with key posnr = ls_xvbep-posnr  releas = c_x1 .
  if sy-subrc = 0 .

    if w_temp-order_price = v_kbetr
      and  w_temp-base_price = v_zbas . " and vbak-vbtyp ne c_h.

    continue .

   else .


  CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.

      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.

  endif .
 endif .

READ TABLE i_temp INTO w_temp with key posnr = ls_xvbep-posnr .
 IF sy-subrc eq 0 .

    if w_temp-order_price ne v_kbetr
      or w_temp-base_price ne v_zbas .

  CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.

      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
    clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
  endif .
  endif .
  endif .
" End of code
endloop.

W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetrr."  + v_zfr2 .
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
else.
READ TABLE i_temp INTO w_zsdt009 with key vbeln = xvbap-vbeln
                                          posnr = Xvbap-posnr.
if Sy-subrc = 0.
*CLEAR w_zsdt009.
CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetrr."  + v_zfr2.
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
read TABLE i_temp INTO w_zsdt009 with key vbeln = XVBAP-vbeln
                                   posnr = XVBAP-POSNR.
if sy-subrc = 0.
* w_zsdt009-RELEAS = 'X'.
*w_zsdt009-RELDATE = SY-DATUM.
*w_zsdt009-RELNAME = SY-UNAME.
w_zsdt009-REJECT = w_zsdt009-REJECT.
w_zsdt009-REJDATE = w_zsdt009-REJDATE.
w_zsdt009-REJNAME = w_zsdt009-REJNAME.
endif.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
endif.
endif.

else.
    CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
read TABLE i_temp INTO w_zsdt009 with key vbeln = XVBAP-vbeln
                                   posnr = XVBAP-POSNR.
if sy-subrc = 0.
  w_zsdt009-RELEAS = 'X'.
w_zsdt009-RELDATE = SY-DATUM.
w_zsdt009-RELNAME = SY-UNAME.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
APPEND w_zsdt009 to i_zsdt009.
*      MODIfy i_zsdt009 from w_zsdt009 TRANSPORTING RELEAS RELDATE RELNAME where vbeln = XVBAP-vbeln
*                                 and  posnr = XVBAP-POSNR.
endif.
CLEAR:w_zsdt009.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = ''.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
endif.

else.
  CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
*      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
read TABLE i_temp INTO w_zsdt009 with key vbeln = XVBAP-vbeln
                                   posnr = XVBAP-POSNR.
if sy-subrc = 0.
  w_zsdt009-RELEAS = 'X'.
w_zsdt009-RELDATE = SY-DATUM.
w_zsdt009-RELNAME = SY-UNAME.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
APPEND w_zsdt009 to i_zsdt009.
*      MODIfy i_zsdt009 from w_zsdt009 TRANSPORTING RELEAS RELDATE RELNAME where vbeln = XVBAP-vbeln
*                                 and  posnr = XVBAP-POSNR.
endif.
*      MODIfy i_zsdt009 from w_zsdt009 TRANSPORTING RELEAS RELDATE RELNAME where vbeln = XVBAP-vbeln
*                                 and  posnr = XVBAP-POSNR.
*Begin of code by Samata P 08.02.2023 DR1K972180
IF z2_flag = 'X'.
delete zsdt009 from w_zsdt009.
delete i_zsdt009 where vbeln = XVBAP-vbeln and posnr = XVBAP-POSNR.
ENDIF.
*end by Samata P 08.02.2023 DR1K972180
CLEAR:w_zsdt009.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
endif.

endloop.
*endif.

" added by raju on 15.10.2015 (loop at xvbep)
xvbep1[] = xvbep[] .
loop at xvbep1 into ls_xvbep1 .
*if z2_flag ne 'X'.
 READ TABLE i_zsdt009 into w_zsdt009 with key vbeln = ls_xvbep1-vbeln
                                           posnr = ls_xvbep1-posnr .
  if sy-subrc = 0." and z2_flag ne 'X'.
    if ls_xvbep1-lifsp = 'Z2' .
      w_zsdt009-releas = ' ' .

    elseif ls_xvbep1-lifsp = ' ' .
SELECT single releas reldate relname into (v_rel,v_date,v_name)
                                  from zsdt009 where vbeln = ls_xvbep1-vbeln
                                               and    posnr = ls_xvbep1-posnr .
  if sy-subrc = 0 .
      w_zsdt009-releas = v_rel .
      w_zsdt009-RELDATE = v_date .
      w_zsdt009-RELNAME = v_name.
  endif .
  endif .

 modify i_ZSDT009 from w_zsdt009 INDEX sy-tabix .
  endif .
* endif."Samata
 endloop .

if i_zsdt009 is not INITIAL.
MODIFY ZSDT009 from table i_zsdt009.
COMMIT WORK AND WAIT.
endif.
endif.
*if vbak-vkorg = '1102'.       "Commented by Ravi on 27.12.2018 DR1K939031
if vbak-vkorg IN RA_1102.        "Added by Ravi on 27.12.2018 DR1K939031
*  Break sahoo.
  SELECT * from ZSDT009 INTO TABLE i_temp where vbeln = vbak-vbeln.
select * from ZSDT008 INTO TABLE i_cond .
Loop at xvbap where KWMENG is not initial."[] INTO W_vbap.
CLEAR v_kbetr.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.    "Added by Ravi on 20.07.2022 DR1K967366
*read table YVBAP[] into w_vbapy with key posnr = xvbap-posnr.
*if sy-subrc ne 0.
READ TABLE xkomv[] INTO w_komv with key kschl = 'ZBAS'
                                        kposn = xvbap-posnr.
if sy-subrc = 0 .
  CLEAR w_konp.
SELECT SINGLE * from konp  INTO w_konp where knumh = w_komv-knumh and loevm_ko = 'X'.
if sy-subrc ne 0 .
v_zbas = w_komv-kwert.
CLEAR w_komv.
loop at i_cond INTO w_cond .
read TABLE xkomv[] INTO w_komv with key kschl = w_cond-kschl
                                        kposn = xvbap-posnr.

if sy-subrc = '0' and w_komv-KINAK = ''.
 v_kbetr = w_komv-kwert.
 CLEAR w_komv.
 Exit.
endif.
endloop.
READ TABLE xkomv[] INTO w_komv with key kschl = 'Z004'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
v_kbetr = v_kbetr + w_komv-kwert.
 CLEAR w_komv.
endif.
READ TABLE xkomv[] INTO w_komv with key kschl = 'Z005'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
v_kbetr = v_kbetr + w_komv-kwert.
 CLEAR w_komv.
endif.
READ TABLE xkomv[] INTO w_komv with key kschl = 'Z007'
                                        kposn = xvbap-posnr.
if sy-subrc = 0.
 v_kbetr = v_kbetr + w_komv-kwert .
 CLEAR w_komv.
endif.
if v_kbetr lt V_zbas.
CLEAR:V_BLOCK1,V_block.
V_BLOCK = V_ZBAS - v_kbetr.
V_BLOCK1 = V_BLOCK.
CONDENSE V_BLOCK1.

" Added by raju
*if i_temp is INITIAL .
*  CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.    " Commented by raju on 15.10.2015
*
*      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.                                     " Commented by raju on 15.10.2015


 loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.
     if vbak-vbtyp ne c_h .
     READ TABLE i_temp INTO w_temp with key posnr = ls_xvbep-posnr  .
   if sy-subrc ne 0 .

      CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.

      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.

    move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endif .
endif .

endloop .
*
*endif .



*break sahoo.

loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  " Added by raju on 13.10.2015
  if vbak-vbtyp ne c_h .
  READ TABLE i_temp INTO w_temp with key posnr = ls_xvbep-posnr  releas = c_x1 .

  if sy-subrc = 0 .

    if w_temp-order_price = v_kbetr
      and w_temp-base_price = v_zbas . "and vbak-vbtyp ne c_h.

       continue .

   else .


CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
 MODIFY XVBAP TRANSPORTING BLOCK_ORDER.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.

endif .
endif .
READ TABLE i_temp INTO w_temp with key posnr = ls_xvbep-posnr .
 IF sy-subrc eq 0 .

   if w_temp-order_price ne v_kbetr
      or w_temp-base_price ne v_zbas .

 CONCATENATE 'Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
   MODIFY XVBAP TRANSPORTING BLOCK_ORDER.



   clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = 'Z2'.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endif .
endif .
endif .
 " End of code
endloop.

W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetr.
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
else.
READ TABLE i_temp INTO w_zsdt009 with key vbeln = xvbap-vbeln
                                          posnr = Xvbap-posnr.
if Sy-subrc = 0.
*CLEAR w_zsdt009.
CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
W_zsdt009-MANDT = Sy-mandt.
W_zsdt009-VBELN = xvbap-vbeln.
W_zsdt009-POSNR = xvbap-posnr.
W_zsdt009-VKORG = VBAK-vkorg.
W_zsdt009-KUNNR = vbak-kunnr.
W_zsdt009-MATNR = xvbap-matnr.
W_zsdt009-ERDAT = vbak-erdat.
W_zsdt009-ORDER_PRICE = v_kbetr.
W_zsdt009-BASE_PRICE = V_zbas.
W_zsdt009-DIFF = V_BLOCK.
W_zsdt009-WERKS = XVBAP-werks.
W_zsdt009-DOLC = sy-datum.
W_zsdt009-CNAME = sy-uname.
append w_zsdt009 to i_zsdt009.
CLEAR:v_kbetr,V_zbas,V_BLOCK,W_zsdt009.
endif.
endif.
else.
  CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
read TABLE i_temp INTO w_zsdt009 with key vbeln = XVBAP-vbeln
                                   posnr = XVBAP-POSNR.
if sy-subrc = 0.
  w_zsdt009-RELEAS = 'X'.
w_zsdt009-RELDATE = SY-DATUM.
w_zsdt009-RELNAME = SY-UNAME.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
APPEND w_zsdt009 to i_zsdt009.
*      MODIfy i_zsdt009 from w_zsdt009 TRANSPORTING RELEAS RELDATE RELNAME where vbeln = XVBAP-vbeln
*                                 and  posnr = XVBAP-POSNR.
endif.
CLEAR:w_zsdt009.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = ''.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.

endif.
else.
  CLEAR: xvbap-BLOCK_ORDER.
*  CONCATENATE ' Block Due to Base Price - ' V_BLOCK1 INTO  xvbap-BLOCK_ORDER.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
read TABLE i_temp INTO w_zsdt009 with key vbeln = XVBAP-vbeln
                                   posnr = XVBAP-POSNR.
if sy-subrc = 0.
  w_zsdt009-RELEAS = 'X'.
w_zsdt009-RELDATE = SY-DATUM.
w_zsdt009-RELNAME = SY-UNAME.
      MODIFY XVBAP TRANSPORTING BLOCK_ORDER.
APPEND w_zsdt009 to i_zsdt009.
*      MODIfy i_zsdt009 from w_zsdt009 TRANSPORTING RELEAS RELDATE RELNAME where vbeln = XVBAP-vbeln
*                                 and  posnr = XVBAP-POSNR.
endif.
CLEAR:w_zsdt009.
loop at xvbep into ls_xvbep where posnr = XVBAP-POSNR.

  clear: ls_vbepkom, ls_vbepkomx.
  move-corresponding ls_xvbep to ls_vbepkom.
  ls_vbepkom-LIFSP  = ''.
  ls_vbepkomx-posnr = ls_xvbep-posnr.
  ls_vbepkomx-etenr = ls_xvbep-etenr.

ls_vbepkomx-LIFSP = 'X'.

call function 'SD_SALES_SCHEDULE_MAINTAIN'
  exporting
    fvbepkom     = ls_vbepkom
    fvbepkomx    = ls_vbepkomx.
endloop.
Endif.
*endif.
endloop.

" added by raju on 15.10.2015 (loop at xvbep)
xvbep1[] = xvbep[] .
loop at xvbep1 into ls_xvbep1 .

 READ TABLE i_zsdt009 into w_zsdt009 with key vbeln = ls_xvbep1-vbeln
                                           posnr = ls_xvbep1-posnr .
  if sy-subrc = 0 .
    if ls_xvbep1-lifsp = 'Z2' .
      w_zsdt009-releas = ' ' .

    elseif ls_xvbep1-lifsp = ' ' .
      SELECT single releas reldate relname into (v_rel,v_date,v_name)
                                  from zsdt009 where vbeln = ls_xvbep1-vbeln
                                               and    posnr = ls_xvbep1-posnr .
     if sy-subrc = 0 .
      w_zsdt009-releas = v_rel .
      w_zsdt009-RELDATE = v_date .
      w_zsdt009-RELNAME = v_name.
     endif .
  endif .

 modify i_ZSDT009 from w_zsdt009 INDEX sy-tabix .
  endif .
 endloop .

if i_zsdt009 is not INITIAL.
MODIFY ZSDT009 from table i_zsdt009.
COMMIT WORK AND WAIT.
endif.

endif.
endif.
endif.
Endif.
DATA: I_plant type TABLE OF ZSDT004,
      W_plant type  ZSDT004.
IF sy-ucomm = 'SICH' or  sy-ucomm = 'YES' or sy-ucomm = 'TEIL' or sy-ucomm = 'WEIT' or sy-ucomm = 'OPT1' or sy-ucomm = 'NO' or sy-ucomm = 'CANC' or sy-ucomm = ''.
*IF ( sy-tcode = 'VA02' or sy-tcode = 'VA01' ) and ( vbak-vkorg = '1101'  )."or vbak-vkorg = '1102' ).  "Commented by Ravi on 27.12.2018 DR1K939031
IF ( sy-tcode = 'VA02' or sy-tcode = 'VA01' OR  sy-tcode = 'ZSD_QUOT_SO' ) and ( vbak-vkorg IN RA_1101  )."or vbak-vkorg = '1102' ). "Added by Ravi on 27.12.2018 DR1K939031 " 'Zsd_quot_so' Added by Bhagavan on 06.11.2020  DR1K953998
  select * from ZSDT004 INTO TABLE i_plant.
FIELD-SYMBOLS: <LX_werks> type any,
      <LX_auart> type any.
*ASSIGN ('(SAPMV45A)VBAP-WERKS') TO <lx_WERKS>.
*ASSIGN ('(SAPMV45A)VBAK-') TO <lx_WERKS>.
*  LOOP AT xvbap[] INTO xvbap.
    READ TABLE i_plant INTO w_plant with key  auart = vbak-auart
                                              werks = XVBAP-werks."<lx_WERKS>."xvbap-werks.
    if sy-subrc ne 0.
*    if sy-subrc eq 0.
*    if w_plant-CHP_ID is INITIAL.
      MESSAGE e000(8I) with 'Selected Doc type' VBAK-AUART  'not pertaining to' XVBAP-werks.
*    endif.

    endif.
*  ENDLOOP.
endif.
endif.
*if ( sy-tcode = 'VA01' )  or ( sy-tcode = 'VA02' ).
**BREAK sahoo.
*if vbak-vkorg = '1102'.
*DATA: L_yvbap type vbap,
*      l_xvbap type vbap.
*data: v_vfdat type mch1-vfdat.
*loop at yvbap INTO l_yvbap.
* read TABLE xvbap INTO l_xvbap with key posnr = l_yvbap-posnr.
* if sy-subrc = 0.
*   if l_xvbap-charg ne l_yvbap-charg.
*     select SINGLE vfdat from mch1 INTO v_vfdat where matnr = l_xvbap-matnr
*                                                and   charg = l_xvbap-charg.
*      if v_vfdat is not INITIAL.
*        if  v_vfdat(6) le sy-datum(6).
*          MESSAGE e000(8i) with l_xvbap-charg 'Batch is expired'.
*        endif.
*      endif.
*   endif.
* endif.
* CLEAR : L_yvbap,L_yvbap,v_vfdat.
*endloop.
*endif.
*endif.
*********Begin of Changes by Ravi on 13.02.2018 DR1K938680****************************
IF sy-tcode EQ c_va01 OR  sy-tcode = 'ZSD_QUOT_SO' . " 'Zsd_quot_so' Added by Bhagavan on 06.11.2020  DR1K953998
 DATA : ls_blk TYPE zsd_restrict_blk.
 CLEAR : ls_blk.
 SELECT SINGLE * FROM zsd_restrict_blk
        INTO ls_blk
        WHERE vkorg EQ vbak-vkorg
          AND auart EQ vbak-auart.
 IF ls_blk IS NOT INITIAL.
  IF vbak-lifsk EQ 'Z1'.
   CLEAR : vbak-lifsk.
  ENDIF.
 ENDIF.
ENDIF.
*********End of Changes by Ravi on 13.02.2018 DR1K938680******************************
*********Begin of Changes by Ravi on 23.08.2019 DR1K947155******************************
DATA : lt_blk TYPE TABLE OF zsd_remove_blk,
       lw_blk TYPE zsd_remove_blk,
       lv_chk TYPE c,
       lv_chk1 TYPE c.
IF sy-tcode EQ c_va01 OR sy-tcode EQ c_va02  OR  sy-tcode = 'ZSD_QUOT_SO'." OR sy-tcode EQ c_va03. " 'Zsd_quot_so' Added by Bhagavan on 06.11.2020  DR1K953998
 IF vbak-vkorg IN ra_1102.                  "Added by Ravi on 19.09.2019 DR1K947547
  IF xvbap[] IS NOT INITIAL.

    SELECT * FROM zsd_remove_blk INTO TABLE lt_blk
             FOR ALL ENTRIES IN XVBAP
             WHERE matnr EQ xvbap-matnr.
    IF SY-subrc IS INITIAL.
     LOOP AT xvbap INTO lw_xvbap.
      READ TABLE lt_blk INTO lw_blk WITH KEY matnr = lw_xvbap-matnr
                                             pstyv = lw_xvbap-pstyv.
      IF sy-subrc IS NOT INITIAL.
       lv_chk = 'Y'.
      ELSE.
       lv_chk1 = 'X'.
      ENDIF.
     ENDLOOP.

     IF lv_chk NE 'Y' AND lv_chk1 EQ 'X' AND lv_blk IS INITIAL. "Added by Ravi on 19.09.2019 DR1K947547
      IF vbak-lifsk EQ 'Z1'.
       CLEAR : vbak-lifsk.
      ENDIF.
     ENDIF.
    ENDIF.
   ENDIF.
  ENDIF.
ENDIF.
*********End of Changes by Ravi on 23.08.2019 DR1K947155********************************

*********Begin of Changes by Akshay on 17/11/2026 in DR1K9A032X ******************************
    DATA: lv_knvv_zterm    TYPE knvv-zterm,
          lv_valid_vkorg   TYPE ztabap_tvarvc-low,
          lv_zterm_changed TYPE abap_bool.
    TYPES: BEGIN OF ty_tvarvc_low,
             low TYPE ztabap_tvarvc-low,
           END OF ty_tvarvc_low.

    DATA: lt_itemcat TYPE STANDARD TABLE OF ty_tvarvc_low.

    IF ( sy-tcode = 'VA01' OR sy-tcode = 'VA02' ) AND vbak-faksk IS INITIAL.
      SELECT SINGLE zterm FROM knvv INTO lv_knvv_zterm
      WHERE kunnr = vbak-kunnr
      AND vkorg = vbak-vkorg
      AND vtweg = vbak-vtweg
      AND spart = vbak-spart.
      IF sy-subrc = 0.
        IF tkomk-zterm IS NOT INITIAL AND tkomk-zterm NE lv_knvv_zterm.
          lv_zterm_changed = abap_true.
        ENDIF.
      ENDIF.
      IF lv_zterm_changed = abap_true.
        SELECT SINGLE low FROM ztabap_tvarvc INTO lv_valid_vkorg
        WHERE obj_name = 'ZSD_BILL_BLOCK_SO_REPORT'
        AND name     = 'ZSALESORG'
        AND type     = 'S'
        AND sign     = 'I'
        AND opti     = 'EQ'
        AND low      = vbak-vkorg.
        IF sy-subrc = 0.
          SELECT low FROM ztabap_tvarvc INTO TABLE lt_itemcat
          WHERE obj_name = 'ZSD_BILL_BLOCK_SO_REPORT'
          AND name     = 'ZITEMCAT'
          AND type     = 'S'
          AND sign     = 'I'
          AND opti     = 'EQ'.
          IF sy-subrc = 0.
            LOOP AT xvbap ASSIGNING FIELD-SYMBOL(<fs_xvbap>) WHERE updkz <> 'D'.
              READ TABLE lt_itemcat TRANSPORTING NO FIELDS WITH KEY low = <fs_xvbap>-pstyv.
              IF sy-subrc = 0.
                vbak-faksk = 'Z1'.
                EXIT.
              ENDIF.
            ENDLOOP.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
*********End of Changes by Akshay on 17/11/2026 in DR1K9A032X ******************************

ENDENHANCEMENT.
