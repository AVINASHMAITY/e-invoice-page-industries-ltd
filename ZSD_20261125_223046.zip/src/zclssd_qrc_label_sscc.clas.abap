class ZCLSSD_QRC_LABEL_SSCC definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ty_sccc_r,
        sign   TYPE ddsign,
        option TYPE ddoption,
        low    TYPE zsscc,
        high   TYPE zsscc,
      END OF ty_sccc_r .
  types:
    tt_sccc_r TYPE STANDARD TABLE OF ty_sccc_r .
  types:
    BEGIN OF ty_vbeln_r,
        sign   TYPE ddsign,
        option TYPE ddoption,
        low    TYPE vbeln_vl,
        high   TYPE vbeln_vl,
      END OF ty_vbeln_r .
  types:
    tt_vbeln_r TYPE STANDARD TABLE OF ty_vbeln_r .
  types:
    BEGIN OF ty_posnr_r,
        sign   TYPE ddsign,
        option TYPE ddoption,
        low    TYPE posnr_vl,
        high   TYPE posnr_vl,
      END OF ty_posnr_r .
  types:
    tt_posnr_r TYPE STANDARD TABLE OF ty_posnr_r .
  types:
    BEGIN OF ty_sscc_details,
        zsscc	         TYPE zsscc,
        gtin           TYPE zgtin,
        matnr	         TYPE matnr,
        maktx	         TYPE maktx,
*        charg           TYPE charg_d,
        charg1         TYPE charg_d,
        charg2         TYPE charg_d,
*        lfimg          TYPE char20,
        lfimg1         TYPE char20,
        lfimg2         TYPE char20,
*        hsdat           TYPE char20,
        hsdat1         TYPE char20,
        hsdat2         TYPE char20,
        vfdat	         TYPE char20,
*        qndat           TYPE char20,
        qndat1         TYPE char20,
        qndat2         TYPE char20,
        vbeln	         TYPE vbeln_vl,
        posnr	         TYPE posnr_vl,
        quantity       TYPE kwmeng,
        meins          TYPE meins,
        no_of_child(5) TYPE c,
        status         TYPE char40,
        mfg_by         TYPE string,
        mfg_lic        TYPE zmmlicencenr1,
        spl_storage    TYPE zdesc,
      END OF ty_sscc_details .
  types:
    tt_sscc_details TYPE STANDARD TABLE OF ty_sscc_details .

  constants C_S_Q type C value '`' ##NO_TEXT.
  constants C_D_Q type C value '"' ##NO_TEXT.

  class-methods FORM_SSCC_CODE
    importing
      !IV_BUKRS type BUKRS
    exporting
      value(EV_SSCC_URL) type CHAR200
    returning
      value(RV_SSCC) type AIN_SSCC .
  class-methods DESTROY_LABELS
    importing
      !IV_SSCC type ZSSCC optional
    returning
      value(RV_ERROR_F) type XFLD .
  class-methods GET_ANNEXURE
    importing
      !IT_SSCC type TT_SCCC_R optional
      !IT_VBELN type TT_VBELN_R optional
      !IT_POSNR type TT_POSNR_R optional
      !IV_PRINT_PDF_F type C default ABAP_TRUE
    exporting
      value(ET_SSCC_DATA) type ZCLSSD_QRC_LABEL_SSCC=>TT_SSCC_DETAILS .
  class-methods PUSH_PGI_DATA
    importing
      !IT_SSCC type TT_SCCC_R optional
      !IT_VBELN type TT_VBELN_R optional
      !IT_POSNR type TT_POSNR_R optional .
protected section.
private section.

  class-methods GENERATE_PDF
    importing
      !IT_SSCC_DATA type ZCLSD_QRC_LABEL_SSCC=>TT_SSCC_DETAILS .
  class-methods REPLACE_SP_CHARS_API_NAME
    changing
      !CV_API_NAME type STRING .
ENDCLASS.



CLASS ZCLSSD_QRC_LABEL_SSCC IMPLEMENTATION.


  METHOD DESTROY_LABELS.

*----------------------------------------------------------------------*
*      Modification Log                                                *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Date        Programmer Client Ref No.   TR  No.         Description  *
* 01.12.2022  Proventech 3000001887       DR1K970065      PGI Data     *
* To destroy the unwanted labels during scrap or rejection of the      *
* delivery
* All inter related labels will be determined and will be updated with *
* status as "DESTROYED" (Pallet--> Outer--> Inner)                     *
* The same details will be sent to VRS for data sync using proxy       *
* service                                                              *
*&---------------------------------------------------------------------*

**********************************************************************
* Data Declarations
**********************************************************************
    DATA lt_qr_sscc TYPE STANDARD TABLE OF zsd_qr_sscc.
    DATA lt_sscc    TYPE tt_sccc_r.

**********************************************************************
* Business Logic Processing
**********************************************************************
    SELECT SINGLE * FROM zsd_qr_sscc INTO @DATA(ls_qr_sscc)
      WHERE zsscc = @iv_sscc.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
    APPEND ls_qr_sscc TO lt_qr_sscc.

* Get the children details
    SELECT * FROM zsd_qr_sscc INTO TABLE @DATA(lt_qr_sscc_chd)
      WHERE zsscc_r = @ls_qr_sscc-zsscc.
    IF sy-subrc = 0.
      SORT lt_qr_sscc_chd BY zsscc ASCENDING.
      APPEND LINES OF lt_qr_sscc_chd TO lt_qr_sscc.
    ENDIF.

    IF lt_qr_sscc_chd IS NOT INITIAL.
      SELECT * FROM zsd_qr_sscc INTO TABLE @DATA(lt_qr_sscc_chd_x)
        FOR ALL ENTRIES IN @lt_qr_sscc_chd
        WHERE zsscc_r = @lt_qr_sscc_chd-zsscc.
      IF sy-subrc = 0.
        SORT lt_qr_sscc_chd_x BY zsscc ASCENDING.
        APPEND LINES OF lt_qr_sscc_chd_x TO lt_qr_sscc.
      ENDIF.
    ENDIF.

* To update the status as Destroyed
    LOOP AT lt_qr_sscc ASSIGNING FIELD-SYMBOL(<ls_qr_sscc>).
      <ls_qr_sscc>-aenam       = sy-uname.
      <ls_qr_sscc>-laeda       = sy-datum.
      <ls_qr_sscc>-change_time = sy-uzeit.
      <ls_qr_sscc>-status      = 'DESTROYED'.

* For VRS update
      APPEND VALUE #( sign = 'I' option = 'EQ'
                      low = <ls_qr_sscc>-zsscc ) TO lt_sscc.
    ENDLOOP.

    IF lt_qr_sscc[] IS NOT INITIAL.
      UPDATE zsd_qr_sscc FROM TABLE lt_qr_sscc.
      IF sy-subrc = 0.
        rv_error_f = abap_false.
      ELSE.
        rv_error_f = abap_true.
      ENDIF.
    ENDIF.

* To send the Data to VRS
    zclsd_qrc_label_sscc=>push_pgi_data(
        it_sscc  = lt_sscc
           ).
* To commit Proxy call
    COMMIT WORK.

  ENDMETHOD.


  METHOD FORM_SSCC_CODE.

*----------------------------------------------------------------------*
*      Modification Log                                                *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Date        Programmer Client Ref No.   TR  No.         Description  *
* 01.12.2022  Proventech 3000001887       DR1K970065      PGI Data     *
* To form SSCC number from GCP and dedicated number range              *
* Check digit logic has been applied for last digit of the SSCC        *
*&---------------------------------------------------------------------*

**********************************************************************
* Data Declarations
**********************************************************************
    DATA lv_next_number    TYPE char9.
    DATA lv_nr_range_nr    TYPE nrnr.
    DATA lv_nr_object      TYPE nrobj.
    DATA lv_sum            TYPE i.

**********************************************************************
* Main Business Logic
**********************************************************************
    FREE: rv_sscc.

* Get GCP code against Company code
    SELECT SINGLE gcp FROM zsd_bukrs_gcp INTO @DATA(lv_gcp)
      WHERE bukrs = @iv_bukrs.
    IF sy-subrc <> 0.
* Error message

    ENDIF.
* Label indicator
    rv_sscc+0(1) = 0.

* GCP number range is different for different Company Codes
    DATA(lv_gcp_len) = strlen( lv_gcp ).

* Company Code GCP value
    rv_sscc+1(lv_gcp_len) = lv_gcp.

* To determine the number range based on GCP length
    CASE lv_gcp_len.
      WHEN 7.
        lv_nr_object = 'ZSSCC_9'.
      WHEN 8.
        lv_nr_object = 'ZSSCC_8'.
      WHEN 10.
        lv_nr_object = 'ZSSCC_6'.
    ENDCASE.

* To get next available number

    lv_nr_range_nr = '01'.
    CALL FUNCTION 'NUMBER_GET_NEXT'
      EXPORTING
        nr_range_nr             = lv_nr_range_nr
        object                  = lv_nr_object
      IMPORTING
        number                  = lv_next_number
      EXCEPTIONS
        interval_not_found      = 1
        number_range_not_intern = 2
        object_not_found        = 3
        quantity_is_0           = 4
        quantity_is_not_1       = 5
        interval_overflow       = 6
        buffer_overflow         = 7
        OTHERS                  = 8.
    IF sy-subrc <> 0.
* Error message
    ENDIF.

    CONDENSE lv_next_number.
    DATA(lv_sscc_len) = strlen( rv_sscc ).
    DATA(lv_num_len) = strlen( lv_next_number ).
*    lv_sscc_len = lv_sscc_len - 1.

    rv_sscc+lv_sscc_len(lv_num_len) = lv_next_number.

* To determine the Check Digit - 18 char
    DO 17 TIMES.
      DATA(lv_index) = sy-index.
      DATA(lv_mod) = lv_index MOD 2.
      lv_index = lv_index - 1.

      IF lv_mod = 0. "Even position
        DATA(lv_value) = ( rv_sscc+lv_index(1) * 1 ).
      ELSE. "Odd position
        lv_value = ( rv_sscc+lv_index(1) * 3 ).
      ENDIF.
      lv_sum = lv_sum + lv_value.
    ENDDO.

    FREE: lv_mod.
    lv_mod = lv_sum MOD 10.

* Last Digit - Check digit
    lv_mod = 10 - lv_mod.
    IF lv_mod = 0 OR lv_mod = 10.
      rv_sscc+17(1) = 0.
    ELSE.
      DATA(lv_sum_x) = lv_sum.
      lv_sum_x = lv_sum_x + lv_mod.
      rv_sscc+17(1) = lv_sum_x - lv_sum.
    ENDIF.

    IF iv_bukrs EQ '5100' OR iv_bukrs EQ '5500' OR iv_bukrs EQ '5600'.
      IF sy-sysid EQ 'PR1'.
        CONCATENATE 'https://vrs.syngeneintl.com/00/' rv_sscc '/' INTO ev_sscc_url.
      ELSE.
        CONCATENATE 'https://vrsq.syngeneintl.com/00/' rv_sscc '/' INTO ev_sscc_url.
      ENDIF.
    ELSE.
      IF sy-sysid EQ 'PR1'.
        CONCATENATE 'https://vrs.biocon.com/00/' rv_sscc '/' INTO ev_sscc_url.
      ELSE.
        CONCATENATE 'https://vrsq.biocon.com/00/' rv_sscc '/' INTO ev_sscc_url.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  METHOD GENERATE_PDF.

*----------------------------------------------------------------------*
*      Modification Log                                                *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Date        Programmer Client Ref No.   TR  No.         Description  *
* 01.12.2022  Proventech 3000001887       DR1K970065      PGI Data     *
* To generate cummulative PDF with all the selected SSCC labels        *
*&---------------------------------------------------------------------*

**********************************************************************
* Data Declarations
**********************************************************************
    DATA lt_binary_tab    TYPE tsfixml.
    DATA lt_pdf_table     TYPE tfpcontent.

    DATA ls_outputparams  TYPE  sfpoutputparams.
    DATA lv_funcname      TYPE funcname.
    DATA ls_docparams     TYPE sfpdocparams.
    DATA ls_joboutput     TYPE sfpjoboutput.

    DATA lv_temp_dir      TYPE string.
    DATA lv_separator     TYPE c.
    DATA lv_rc            TYPE sysubrc.
    DATA lv_synchronous   TYPE string.
    DATA lv_file_name     TYPE filename VALUE 'QR_LABELS'.

    FIELD-SYMBOLS: <ls_pdf_table> LIKE LINE OF lt_pdf_table.

**********************************************************************
* Business Logic Processing
**********************************************************************
    INCLUDE fp_spool_constants.

* To open a new job for PDF printing
* Set PDF output parameters
    ls_outputparams-nodialog   = 'X'.
    ls_outputparams-getpdf     = 'M'.
    ls_outputparams-connection = 'ADS'.
    ls_outputparams-bumode     = 'M'.
    ls_outputparams-assemble   = 'M'.

* Sets the output parameters and opens the spool job
    CALL FUNCTION 'FP_JOB_OPEN'
      CHANGING
        ie_outputparams = ls_outputparams
      EXCEPTIONS
        cancel          = 1
        usage_error     = 2
        system_error    = 3
        internal_error  = 4
        OTHERS          = 5.
    IF sy-subrc <> 0.
* Error message
      RETURN.
    ENDIF.

* To generate runtime function module
    TRY.
        CALL FUNCTION 'FP_FUNCTION_MODULE_NAME'
          EXPORTING
            i_name     = 'ZSD_QR_CODE_ANNX'
          IMPORTING
            e_funcname = lv_funcname.
        IF sy-subrc <> 0.
* Error message
          RETURN.
        ENDIF.
      CATCH cx_fp_api_repository.
      CATCH cx_fp_api_usage.
      CATCH cx_fp_api_internal.
    ENDTRY.

    LOOP AT it_sscc_data INTO DATA(ls_sscc_data).
      CALL FUNCTION lv_funcname
        EXPORTING
          /1bcdwb/docparams = ls_docparams
          is_sscc_details   = ls_sscc_data
*      IMPORTING
*         /1bcdwb/formoutput = ls_formoutput
        EXCEPTIONS
          usage_error       = 1
          system_error      = 2
          internal_error    = 3.
    ENDLOOP.

* To clsoe job of PDF printing
    CALL FUNCTION 'FP_JOB_CLOSE'
      IMPORTING
        e_result       = ls_joboutput
      EXCEPTIONS
        usage_error    = 1
        system_error   = 2
        internal_error = 3
        OTHERS         = 4.
    IF sy-subrc <> 0.
* Error message
      RETURN.
    ENDIF.

* Read and delete PDF documents from bundle
    CALL FUNCTION 'FP_GET_PDF_TABLE'
      IMPORTING
        e_pdf_table = lt_pdf_table.

**********************************************************************
* Download to PC
**********************************************************************
    cl_gui_frontend_services=>get_temp_directory(
      CHANGING
        temp_dir             = lv_temp_dir
      EXCEPTIONS
        cntl_error           = 1
        error_no_gui         = 2
        not_supported_by_gui = 3
        OTHERS               = 4
           ).
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    cl_gui_cfw=>flush(
      EXCEPTIONS
        cntl_system_error = 1
        cntl_error        = 2
        OTHERS            = 3
           ).
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    cl_gui_frontend_services=>get_file_separator(
      CHANGING
        file_separator       = lv_separator
      EXCEPTIONS
        not_supported_by_gui = 1
        error_no_gui         = 2
        cntl_error           = 3
        OTHERS               = 4
           ).
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

* Form the file name
    CONCATENATE lv_temp_dir lv_separator lv_file_name c_file_ext_pdf INTO lv_temp_dir.

* Convert PDF content to Binary format for printing
    LOOP AT lt_pdf_table ASSIGNING <ls_pdf_table>.
      CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
        EXPORTING
          buffer     = <ls_pdf_table>
        TABLES
          binary_tab = lt_binary_tab.
    ENDLOOP.

    CHECK <ls_pdf_table> IS ASSIGNED.
* To download the PDF file in TEMP folder
    cl_gui_frontend_services=>gui_download(
      EXPORTING
        bin_filesize              = xstrlen( <ls_pdf_table> )
        filename                  = lv_temp_dir
        filetype                  = 'BIN'
      CHANGING
        data_tab                  = lt_binary_tab
      EXCEPTIONS
        file_write_error          = 1
        no_batch                  = 2
        gui_refuse_filetransfer   = 3
        invalid_type              = 4
        no_authority              = 5
        unknown_error             = 6
        header_not_allowed        = 7
        separator_not_allowed     = 8
        filesize_not_allowed      = 9
        header_too_long           = 10
        dp_error_create           = 11
        dp_error_send             = 12
        dp_error_write            = 13
        unknown_dp_error          = 14
        access_denied             = 15
        dp_out_of_memory          = 16
        disk_full                 = 17
        dp_timeout                = 18
        file_not_found            = 19
        dataprovider_exception    = 20
        control_flush_error       = 21
        not_supported_by_gui      = 22
        error_no_gui              = 23
        OTHERS                    = 24
           ).
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.

    lv_synchronous = abap_true.
* To open the PDF file in front end
    CALL METHOD cl_gui_frontend_services=>execute
      EXPORTING
        document               = lv_temp_dir
        synchronous            = lv_synchronous
      EXCEPTIONS
        cntl_error             = 1
        error_no_gui           = 2
        bad_parameter          = 3
        file_not_found         = 4
        path_not_found         = 5
        file_extension_unknown = 6
        error_execute_failed   = 7
        synchronous_failed     = 8
        not_supported_by_gui   = 9
        OTHERS                 = 10.
    IF sy-subrc <> 0.
    ENDIF.

  ENDMETHOD.


  METHOD get_annexure.

*----------------------------------------------------------------------*
*      Modification Log                                                *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Date        Programmer Client Ref No.   TR  No.         Description  *
* 01.12.2022  Proventech 3000001887       DR1K970065      PGI Data     *
* To Print SSCC label details in PDF                                   *
* The data contains details about SSCC code and associated API details *
*&---------------------------------------------------------------------*

**********************************************************************
* Data Declarations
**********************************************************************
    DATA lv_matnr_x          TYPE matnr.
    DATA lv_id               TYPE thead-tdid.
    DATA lv_name             TYPE thead-tdname.
    DATA lv_object           TYPE thead-tdobject.
    DATA lt_lines            TYPE STANDARD TABLE OF tline.
    DATA lt_month_names      TYPE STANDARD TABLE OF t247.

**********************************************************************
* Business Logic Processing
**********************************************************************
    SELECT * FROM zsd_qr_sscc INTO TABLE @DATA(lt_qr_sscc)
      WHERE zsscc IN @it_sscc  AND
            vbeln IN @it_vbeln AND
            posnr IN @it_posnr.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
    SORT lt_qr_sscc BY zsscc ASCENDING.
    DELETE lt_qr_sscc WHERE status = 'DELETED'.

* Get the children details
    SELECT * FROM zsd_qr_sscc INTO TABLE @DATA(lt_qr_sscc_chd)
      FOR ALL ENTRIES IN @lt_qr_sscc
      WHERE zsscc_r = @lt_qr_sscc-zsscc.
    IF sy-subrc <> 0.
      SORT lt_qr_sscc BY zsscc ASCENDING.
    ENDIF.

** To get the Quantity and UOM details
** Inner
*    SELECT vbeln_d, posnr, label_i, in_kwmeng, vrkme
*      FROM ztsd_label INTO TABLE @DATA(lt_inner_label)
*        FOR ALL ENTRIES IN @lt_qr_sscc
*          WHERE vbeln_d = @lt_qr_sscc-vbeln AND
*                vbeln_d = @lt_qr_sscc-vbeln AND
*                label_i = @lt_qr_sscc-label_n.
*    IF sy-subrc = 0.
*      SORT lt_inner_label BY vbeln_d ASCENDING posnr ASCENDING
*                             label_i ASCENDING.
*    ENDIF.
*
** Outer
*    SELECT vbeln_d, posnr, label_o, label_i, in_kwmeng, vrkme
*       FROM ztsd_outer INTO TABLE @DATA(lt_outer_label)
*        FOR ALL ENTRIES IN @lt_qr_sscc
*          WHERE vbeln_d = @lt_qr_sscc-vbeln AND
*                vbeln_d = @lt_qr_sscc-vbeln AND
*                label_o = @lt_qr_sscc-label_n.
*    IF sy-subrc = 0.
*      SORT lt_outer_label BY vbeln_d ASCENDING posnr ASCENDING
*                             label_o ASCENDING.
*    ENDIF.
*
** Pallet
*    SELECT vbeln_d, posnr, label_p, label_o, qty, vrkme
*      FROM ztsd_pallet INTO TABLE @DATA(lt_pallet_label)
*        FOR ALL ENTRIES IN @lt_qr_sscc
*          WHERE vbeln_d = @lt_qr_sscc-vbeln AND
*                vbeln_d = @lt_qr_sscc-vbeln AND
*                label_p = @lt_qr_sscc-label_n.
*    IF sy-subrc = 0.
*      SORT lt_pallet_label BY vbeln_d ASCENDING posnr ASCENDING
*                             label_p ASCENDING.
*      IF lt_pallet_label[] IS NOT INITIAL.
*        SELECT vbeln_d, posnr, label_o, label_i, in_kwmeng, qty, vrkme
*          FROM ztsd_outer INTO TABLE @DATA(lt_pouter)
*                          FOR ALL ENTRIES IN @lt_pallet_label
*                               WHERE label_o = @lt_pallet_label-label_o.
*
*      ENDIF.
*    ENDIF.

* To get the Quantity and UOM details
* Inner
    SELECT vbeln_d, posnr, label_i, in_kwmeng, vrkme, zzlicencenr1, store_desc, sfg_batch
      FROM zssd_label INTO TABLE @DATA(lt_sinner_label)
        FOR ALL ENTRIES IN @lt_qr_sscc
          WHERE vbeln_d = @lt_qr_sscc-vbeln AND
                vbeln_d = @lt_qr_sscc-vbeln AND
                label_i = @lt_qr_sscc-label_n.
    IF sy-subrc = 0.
      SORT lt_sinner_label BY vbeln_d ASCENDING posnr ASCENDING
                             label_i ASCENDING.
    ENDIF.

* Outer
    SELECT vbeln_d, posnr, label_o, label_i, in_kwmeng, vrkme, zzlicencenr1, store_desc, sfg_batch
       FROM zssd_outer INTO TABLE @DATA(lt_souter_label)
        FOR ALL ENTRIES IN @lt_qr_sscc
          WHERE vbeln_d = @lt_qr_sscc-vbeln AND
                vbeln_d = @lt_qr_sscc-vbeln AND
                label_o = @lt_qr_sscc-label_n.
    IF sy-subrc = 0.
      SORT lt_souter_label BY vbeln_d ASCENDING posnr ASCENDING
                             label_o ASCENDING.
    ENDIF.

* Pallet
    SELECT vbeln_d, posnr, label_p, label_o, qty, vrkme, zzlicencenr1, store_desc, sfg_batch
      FROM zssd_pallet INTO TABLE @DATA(lt_spallet_label)
        FOR ALL ENTRIES IN @lt_qr_sscc
          WHERE vbeln_d = @lt_qr_sscc-vbeln AND
                vbeln_d = @lt_qr_sscc-vbeln AND
                label_p = @lt_qr_sscc-label_n.
    IF sy-subrc = 0.
      SORT lt_spallet_label BY vbeln_d ASCENDING posnr ASCENDING
                             label_p ASCENDING.
      IF lt_spallet_label[] IS NOT INITIAL.
        SELECT vbeln_d, posnr, label_o, label_i, in_kwmeng, qty, vrkme
          FROM zssd_outer INTO TABLE @DATA(lt_spouter)
                          FOR ALL ENTRIES IN @lt_spallet_label
                               WHERE label_o = @lt_spallet_label-label_o.

      ENDIF.
    ENDIF.


* To get the plant details
    DATA(lt_matnr_werks) = lt_qr_sscc[].
    SORT lt_matnr_werks BY werks ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_matnr_werks COMPARING werks.
    SELECT werks, adrnr FROM t001w INTO TABLE @DATA(lt_t001w)
      FOR ALL ENTRIES IN @lt_matnr_werks
      WHERE werks = @lt_matnr_werks-werks.
    IF sy-subrc = 0.
      SORT lt_t001w BY werks ASCENDING adrnr ASCENDING.
    ENDIF.
    SELECT * FROM zssd_plant_addr INTO TABLE @DATA(lt_zplant)
                      FOR ALL ENTRIES IN @lt_matnr_werks
                         WHERE werks = @lt_matnr_werks-werks.

* To get Company code from Plant
    SELECT bwkey, bukrs FROM t001k INTO TABLE @DATA(lt_t001k)
      FOR ALL ENTRIES IN @lt_t001w
      WHERE bwkey = @lt_t001w-werks.
    IF sy-subrc = 0.
      SORT lt_t001k BY bukrs ASCENDING.
      SELECT bukrs, butxt FROM t001 INTO TABLE @DATA(lt_t001)
        FOR ALL ENTRIES IN @lt_t001k
        WHERE bukrs = @lt_t001k-bukrs.
      IF sy-subrc = 0.
        SORT lt_t001 BY bukrs ASCENDING.
      ENDIF.
    ENDIF.

* To get Storage Conditions
    LOOP AT lt_matnr_werks ASSIGNING FIELD-SYMBOL(<ls_matnr_werks>).
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = <ls_matnr_werks>-matnr
        IMPORTING
          output       = <ls_matnr_werks>-matnr
        EXCEPTIONS
          length_error = 1.
    ENDLOOP.
*    SELECT * FROM zqmstorcond INTO TABLE @DATA(lt_storcond)
*      FOR ALL ENTRIES IN @lt_matnr_werks
*        WHERE zmatnr = @lt_matnr_werks-matnr AND
*              zplant = @lt_matnr_werks-werks.
*    IF sy-subrc = 0.
*      SORT lt_storcond BY zmatnr ASCENDING zplant ASCENDING.
*    ENDIF.
*    FREE: lt_matnr_werks.
    SELECT * FROM zssd_store_cond INTO TABLE @DATA(lt_storcond)
      FOR ALL ENTRIES IN @lt_matnr_werks
        WHERE zmatnr = @lt_matnr_werks-matnr AND
              zplant = @lt_matnr_werks-werks.
    IF sy-subrc = 0.
      SORT lt_storcond BY zmatnr ASCENDING zplant ASCENDING.
    ENDIF.
    FREE: lt_matnr_werks.


* To get Plant address details
    DATA(lt_werks) = lt_t001w.
    SORT lt_t001w BY adrnr ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_t001w COMPARING adrnr.
    SELECT * FROM adrc INTO TABLE @DATA(lt_adrc)
      FOR ALL ENTRIES IN @lt_werks
      WHERE addrnumber = @lt_werks-adrnr.
    IF sy-subrc = 0.
      SORT lt_adrc BY addrnumber ASCENDING.
    ENDIF.

* Material Manufactring details
    DATA(lt_matnr) = lt_qr_sscc.
    SORT lt_matnr BY matnr ASCENDING werks ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_matnr COMPARING matnr werks.
    LOOP AT lt_matnr ASSIGNING FIELD-SYMBOL(<ls_matnr>).
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = <ls_matnr>-matnr
        IMPORTING
          output       = <ls_matnr>-matnr
        EXCEPTIONS
          length_error = 1.
    ENDLOOP.
    SELECT matnr, werks, zzlicencenr1
      FROM marc INTO TABLE @DATA(lt_marc)
      FOR ALL ENTRIES IN @lt_matnr
      WHERE matnr = @lt_matnr-matnr AND
            werks = @lt_matnr-werks.
    IF sy-subrc = 0.
      SORT lt_marc BY matnr ASCENDING werks ASCENDING.
    ENDIF.
    FREE: lt_matnr.

* To get Plant details from Delviery line item
    DATA(lt_vbeln) = lt_qr_sscc.
    SORT lt_vbeln BY vbeln ASCENDING.
    SELECT vbeln, posnr, matnr, werks, charg, lfimg
      FROM lips INTO TABLE @DATA(lt_lips)
      FOR ALL ENTRIES IN @lt_vbeln
      WHERE vbeln = @lt_vbeln-vbeln.
    IF sy-subrc = 0.
      SORT lt_lips BY vbeln ASCENDING posnr ASCENDING matnr ASCENDING.
    ENDIF.
    FREE: lt_vbeln.

* To get month names
    CALL FUNCTION 'MONTH_NAMES_GET'
      TABLES
        month_names           = lt_month_names
      EXCEPTIONS
        month_names_not_found = 1.

    DATA(lv_lines) = 0.
* Prepare data for Annexure display
    lv_id = 'BEST'.
    lv_object = 'MATERIAL'.

    LOOP AT lt_qr_sscc INTO DATA(ls_qr_sscc).
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = ls_qr_sscc-matnr
        IMPORTING
          output       = lv_matnr_x
        EXCEPTIONS
          length_error = 1.

* Count no. of children
      LOOP AT lt_qr_sscc_chd INTO DATA(ls_qr_sscc_chd)
        WHERE zsscc_r = ls_qr_sscc-zsscc.
        lv_lines = lv_lines + 1.
      ENDLOOP.

      APPEND INITIAL LINE TO et_sscc_data ASSIGNING FIELD-SYMBOL(<fs_sscc_data>).
      MOVE-CORRESPONDING ls_qr_sscc TO <fs_sscc_data>.
* Company Name
      DATA(lv_bukrs) = VALUE #( lt_t001k[ bwkey = ls_qr_sscc-werks ]-bukrs OPTIONAL ).

* Dates
*      IF ls_qr_sscc-qndat <> '00000000'.
*        IF ls_qr_sscc-hsdat+6(2) NE '01' AND ( lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600')..
*          CALL FUNCTION 'BKK_ADD_MONTH_TO_DATE'
*            EXPORTING
*              months  = '-1'
*              olddate = ls_qr_sscc-qndat
*            IMPORTING
*              newdate = ls_qr_sscc-qndat.
*        ENDIF.
*        <fs_sscc_data>-qndat =
*          VALUE #( lt_month_names[ mnr = ls_qr_sscc-qndat+4(2) ]-ktx OPTIONAL ).
*        IF  lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600'.
*          CONCATENATE <fs_sscc_data>-qndat ls_qr_sscc-qndat+0(4)
*            INTO <fs_sscc_data>-qndat SEPARATED BY space.
*        ELSE.
*          CONCATENATE ls_qr_sscc-qndat+6(2) <fs_sscc_data>-qndat ls_qr_sscc-qndat+0(4)
*           INTO <fs_sscc_data>-qndat SEPARATED BY space.
*        ENDIF.
*      ELSE.
*        FREE: <fs_sscc_data>-qndat.
*      ENDIF.
*
*      IF ls_qr_sscc-hsdat <> '00000000'.
*        <fs_sscc_data>-hsdat =
*          VALUE #( lt_month_names[ mnr = ls_qr_sscc-hsdat+4(2) ]-ktx OPTIONAL ).
*        IF lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600'.
*          CONCATENATE <fs_sscc_data>-hsdat ls_qr_sscc-hsdat+0(4)
*            INTO <fs_sscc_data>-hsdat SEPARATED BY space.
*        ELSE.
*          CONCATENATE ls_qr_sscc-hsdat+6(2) <fs_sscc_data>-hsdat ls_qr_sscc-hsdat+0(4)
*          INTO <fs_sscc_data>-hsdat SEPARATED BY space.
*        ENDIF.
*
*      ELSE.
*        FREE: <fs_sscc_data>-hsdat.
*      ENDIF.

      IF ls_qr_sscc-vfdat <> '00000000'.
        IF ls_qr_sscc-hsdat+6(2) NE '01' AND ( lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600')..
          CALL FUNCTION 'BKK_ADD_MONTH_TO_DATE'
            EXPORTING
              months  = '-1'
              olddate = ls_qr_sscc-vfdat
            IMPORTING
              newdate = ls_qr_sscc-vfdat.
        ENDIF.
        <fs_sscc_data>-vfdat =
          VALUE #( lt_month_names[ mnr = ls_qr_sscc-vfdat+4(2) ]-ktx OPTIONAL ).
        IF  lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600'.
          CONCATENATE <fs_sscc_data>-vfdat ls_qr_sscc-vfdat+0(4)
            INTO <fs_sscc_data>-vfdat SEPARATED BY space.
        ELSE.
          CONCATENATE ls_qr_sscc-vfdat+6(2) <fs_sscc_data>-vfdat ls_qr_sscc-vfdat+0(4)
          INTO <fs_sscc_data>-vfdat SEPARATED BY space.
        ENDIF.
      ELSE.
        FREE: <fs_sscc_data>-vfdat.
      ENDIF.

      FREE: lv_name, lt_lines.
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = ls_qr_sscc-matnr
        IMPORTING
          output       = lv_name
        EXCEPTIONS
          length_error = 1.

* To get Product Item text
      CALL FUNCTION 'READ_TEXT'
        EXPORTING
          id                      = lv_id
          language                = sy-langu
          name                    = lv_name
          object                  = lv_object
        TABLES
          lines                   = lt_lines
        EXCEPTIONS
          id                      = 1
          language                = 2
          name                    = 3
          not_found               = 4
          object                  = 5
          reference_check         = 6
          wrong_access_to_archive = 7.

      DATA(lv_text) = VALUE #( lt_lines[ 1 ]-tdline OPTIONAL ).
      IF lv_text IS NOT INITIAL.
        <fs_sscc_data>-maktx = lv_text.
      ENDIF.

* Manufactured by
      IF  lv_bukrs+0(1) EQ '5'. "'5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
        READ TABLE lt_zplant INTO DATA(ls_zplant) WITH KEY werks = ls_qr_sscc-werks.
        IF sy-subrc IS INITIAL.
          CONCATENATE ls_zplant-company ls_zplant-address INTO <fs_sscc_data>-mfg_by SEPARATED BY ','.
        ENDIF.
*      ELSE.
*        DATA(ls_t001w) = VALUE #( lt_t001w[ werks = ls_qr_sscc-werks ] OPTIONAL ).
*        DATA(ls_adrc) = VALUE #( lt_adrc[ addrnumber = ls_t001w-adrnr ] OPTIONAL ).
*        IF ls_adrc-name1 IS NOT INITIAL.
*          CONCATENATE ls_adrc-name1 ls_adrc-str_suppl1 ls_adrc-str_suppl2 ls_adrc-city1
*                      ls_adrc-post_code1 ls_adrc-country
*                      INTO <fs_sscc_data>-mfg_by SEPARATED BY space.
*        ENDIF.
      ENDIF.
* License No.
      DATA(ls_marc) = VALUE #( lt_marc[ matnr = lv_matnr_x
                                        werks = ls_qr_sscc-werks ] OPTIONAL ).
      <fs_sscc_data>-mfg_lic = ls_marc-zzlicencenr1.

* Storage condition
      <fs_sscc_data>-spl_storage =
        VALUE #( lt_storcond[ zmatnr = lv_matnr_x
                              zplant = ls_qr_sscc-werks ]-zdesc OPTIONAL ).

* Batch size / Delivery line item quantity
*      DATA(ls_lips) = VALUE #( lt_lips[ vbeln = ls_qr_sscc-vbeln
*                                        posnr = ls_qr_sscc-posnr
*                                        matnr = lv_name ] OPTIONAL ).
*      <fs_sscc_data>-lfimg = ls_lips-lfimg.

      IF lv_bukrs(1) EQ '5'. "'5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
        IF ls_qr_sscc-ltype EQ 'I'.
          DATA(ls_sinner_label) =
           VALUE #( lt_sinner_label[ vbeln_d = ls_qr_sscc-vbeln
                                    posnr   = ls_qr_sscc-posnr
                                    label_i = ls_qr_sscc-label_n ] OPTIONAL ).
* License No.
          <fs_sscc_data>-mfg_lic = ls_sinner_label-zzlicencenr1.
*Storage condition
          <fs_sscc_data>-spl_storage = ls_sinner_label-store_desc.
* Batch size / Delivery line item quantity
*          <fs_sscc_data>-lfimg = ls_sinner_label-sfg_batch.
        ELSEIF ls_qr_sscc-ltype EQ 'O'.
          DATA(ls_souter_label) =
         VALUE #( lt_souter_label[ vbeln_d = ls_qr_sscc-vbeln
                                  posnr   = ls_qr_sscc-posnr
                                  label_o = ls_qr_sscc-label_n ] OPTIONAL ).
* License No.
          <fs_sscc_data>-mfg_lic = ls_souter_label-zzlicencenr1.
*Storage condition
          <fs_sscc_data>-spl_storage = ls_souter_label-store_desc.
* Batch size / Delivery line item quantity
*          <fs_sscc_data>-lfimg = ls_souter_label-sfg_batch.
        ELSEIF ls_qr_sscc-ltype EQ 'P'.
          DATA(ls_spallet_label) =
     VALUE #( lt_spallet_label[ vbeln_d = ls_qr_sscc-vbeln
                              posnr   = ls_qr_sscc-posnr
                              label_p = ls_qr_sscc-label_n ] OPTIONAL ).
* License No.
          <fs_sscc_data>-mfg_lic = ls_spallet_label-zzlicencenr1.
* License No.
          <fs_sscc_data>-spl_storage = ls_spallet_label-store_desc.
* Batch size / Delivery line item quantity
*          <fs_sscc_data>-lfimg = ls_spallet_label-sfg_batch.
        ENDIF.
      ENDIF.

* Quantity
      CASE ls_qr_sscc-ltype.
        WHEN 'I'.
          IF lv_bukrs+0(1) EQ '5'. "'5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
            ls_sinner_label =
            VALUE #( lt_sinner_label[ vbeln_d = ls_qr_sscc-vbeln
                                     posnr   = ls_qr_sscc-posnr
                                     label_i = ls_qr_sscc-label_n ] OPTIONAL ).
            <fs_sscc_data>-quantity = ls_sinner_label-in_kwmeng.
            <fs_sscc_data>-meins    = ls_sinner_label-vrkme.
*          ELSE.
*            DATA(ls_inner_label) =
*              VALUE #( lt_inner_label[ vbeln_d = ls_qr_sscc-vbeln
*                                       posnr   = ls_qr_sscc-posnr
*                                       label_i = ls_qr_sscc-label_n ] OPTIONAL ).
*            <fs_sscc_data>-quantity = ls_inner_label-in_kwmeng.
*            <fs_sscc_data>-meins    = ls_inner_label-vrkme.
          ENDIF.
        WHEN 'O'.
*          DATA(ls_outer_label) =
*            VALUE #( lt_outer_label[ vbeln_d = ls_qr_sscc-vbeln
*                                     posnr   =  ls_qr_sscc-posnr
*                                     label_o =  ls_qr_sscc-label_n ] OPTIONAL ).
          IF lv_bukrs+0(1) EQ '5'. "'5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
            LOOP AT lt_souter_label INTO ls_souter_label
         WHERE vbeln_d = ls_qr_sscc-vbeln   AND
               posnr   =  ls_qr_sscc-posnr  AND
               label_o =  ls_qr_sscc-label_n.
              <fs_sscc_data>-quantity = <fs_sscc_data>-quantity + ls_souter_label-in_kwmeng.
            ENDLOOP.
            <fs_sscc_data>-meins    = ls_souter_label-vrkme.
*          ELSE.
*            LOOP AT lt_outer_label INTO DATA(ls_outer_label)
*              WHERE vbeln_d = ls_qr_sscc-vbeln   AND
*                    posnr   =  ls_qr_sscc-posnr  AND
*                    label_o =  ls_qr_sscc-label_n.
*              <fs_sscc_data>-quantity = <fs_sscc_data>-quantity + ls_outer_label-in_kwmeng.
*            ENDLOOP.
*            <fs_sscc_data>-meins    = ls_outer_label-vrkme.
          ENDIF.
        WHEN 'P'.
*          DATA(ls_pallet_label) =
*            VALUE #( lt_pallet_label[ vbeln_d = ls_qr_sscc-vbeln
*                                      posnr   = ls_qr_sscc-posnr
*                                      label_p = ls_qr_sscc-label_n ] OPTIONAL ).
          IF lv_bukrs+0(1) EQ '5'. "'5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
            LOOP AT lt_spallet_label INTO ls_spallet_label
           WHERE vbeln_d = ls_qr_sscc-vbeln AND
                 posnr   = ls_qr_sscc-posnr AND
                 label_p = ls_qr_sscc-label_n.
*            <fs_sscc_data>-quantity = <fs_sscc_data>-quantity + ls_pallet_label-qty. "in_kwmeng.
              LOOP AT lt_spouter INTO DATA(ls_spouter)
                          WHERE label_o = ls_spallet_label-label_o.
                <fs_sscc_data>-quantity = <fs_sscc_data>-quantity + ls_spouter-in_kwmeng.
              ENDLOOP.
            ENDLOOP.
            <fs_sscc_data>-meins    = ls_spallet_label-vrkme.
*          ELSE.
*            LOOP AT lt_pallet_label INTO DATA(ls_pallet_label)
*              WHERE vbeln_d = ls_qr_sscc-vbeln AND
*                    posnr   = ls_qr_sscc-posnr AND
*                    label_p = ls_qr_sscc-label_n.
**            <fs_sscc_data>-quantity = <fs_sscc_data>-quantity + ls_pallet_label-qty. "in_kwmeng.
*              LOOP AT lt_pouter INTO DATA(ls_pouter)
*                          WHERE label_o = ls_pallet_label-label_o.
*                <fs_sscc_data>-quantity = <fs_sscc_data>-quantity + ls_pouter-in_kwmeng.
*              ENDLOOP.
*            ENDLOOP.
*            <fs_sscc_data>-meins    = ls_pallet_label-vrkme.
          ENDIF.
      ENDCASE.

      <fs_sscc_data>-no_of_child = lv_lines.
      FREE: lv_lines.
    ENDLOOP.

    IF iv_print_pdf_f = abap_false.
      RETURN.
    ENDIF.

**********************************************************************
* PDF display
**********************************************************************
* To open a new job for PDF printing
*    zclssd_qrc_label_sscc=>generate_pdf( et_sscc_data ).

  ENDMETHOD.


  METHOD PUSH_PGI_DATA.
*----------------------------------------------------------------------*
*      Modification Log                                                *
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Date        Programmer Client Ref No.   TR  No.         Description  *
* 01.12.2022  Proventech 3000001887       DR1K970065      PGI Data     *
* To push Delivery data to VRS system during PGI of the delivery       *
* The data contains details about SSCC code and associated API details *
*&---------------------------------------------------------------------*

**********************************************************************
* Data Declarations
**********************************************************************
    DATA lo_proxy     TYPE REF TO zco_si_api_qrcode_out.
    DATA ls_output    TYPE zmt_api_qrcode_req.
    DATA lt_lines     TYPE STANDARD TABLE OF tline.
    DATA lt_month_names TYPE STANDARD TABLE OF t247.

    DATA lv_id               TYPE thead-tdid.
    DATA lv_name             TYPE thead-tdname.
    DATA lv_object           TYPE thead-tdobject.
    TYPES: BEGIN OF tp_mfdate,
             date TYPE char8,
           END OF tp_mfdate.
    DATA: ls_mfdate TYPE tp_mfdate,
          lt_mfdate TYPE STANDARD TABLE OF tp_mfdate,
          ls_retest TYPE tp_mfdate,
          lt_retest TYPE STANDARD TABLE OF tp_mfdate,
          lv_datest TYPE string,
          lv_coma   TYPE char1.
**********************************************************************
* Business Logic Processing
**********************************************************************
* To get the Label data
    SELECT * FROM zsd_qr_sscc INTO TABLE @DATA(lt_qr_sscc)
      WHERE zsscc IN @it_sscc AND
            vbeln IN @it_vbeln AND
            posnr IN @it_posnr.
    IF sy-subrc <> 0.
      RETURN.
    ENDIF.
    SORT lt_qr_sscc BY matnr ASCENDING.
    DELETE lt_qr_sscc WHERE status = 'Deleted'.
    IF lt_qr_sscc[] IS NOT INITIAL.
      SELECT * FROM zssd_label INTO TABLE @DATA(lt_zssd_label)
                         FOR ALL ENTRIES IN @lt_qr_sscc
                      WHERE label_i = @lt_qr_sscc-label_n.
      SELECT * FROM zssd_outer INTO TABLE @DATA(lt_zssd_outer)
                         FOR ALL ENTRIES IN @lt_qr_sscc
                      WHERE label_o = @lt_qr_sscc-label_n.
      SELECT * FROM zssd_pallet INTO TABLE @DATA(lt_zssd_pallet)
                         FOR ALL ENTRIES IN @lt_qr_sscc
                      WHERE label_p = @lt_qr_sscc-label_n.
      SELECT * FROM ztsd_label INTO TABLE @DATA(lt_ztsd_label)
                         FOR ALL ENTRIES IN @lt_qr_sscc
                      WHERE label_i = @lt_qr_sscc-label_n.
      SELECT * FROM ztsd_outer INTO TABLE @DATA(lt_ztsd_outer)
                         FOR ALL ENTRIES IN @lt_qr_sscc
                      WHERE label_o = @lt_qr_sscc-label_n.
      SELECT * FROM ztsd_pallet INTO TABLE @DATA(lt_ztsd_pallet)
                         FOR ALL ENTRIES IN @lt_qr_sscc
                      WHERE label_p = @lt_qr_sscc-label_n.

    ENDIF.

* Material descriptions and Storage conditions
    DATA(lt_matnr) = lt_qr_sscc.
    SORT lt_matnr BY matnr ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_matnr COMPARING matnr.
    LOOP AT lt_matnr ASSIGNING FIELD-SYMBOL(<ls_matnr>).
* Material input format
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = <ls_matnr>-matnr
        IMPORTING
          output       = <ls_matnr>-matnr
        EXCEPTIONS
          length_error = 1.
    ENDLOOP.

    SELECT matnr, maktx FROM makt INTO TABLE @DATA(lt_makt)
      FOR ALL ENTRIES IN @lt_matnr
      WHERE matnr = @lt_matnr-matnr AND
            spras = @sy-langu.
    IF sy-subrc = 0.
      SORT lt_makt BY matnr ASCENDING.
    ENDIF.

    SELECT matnr, raube FROM mara INTO TABLE @DATA(lt_mara)
      FOR ALL ENTRIES IN @lt_matnr
      WHERE matnr = @lt_matnr-matnr.
    IF sy-subrc = 0.
      SORT lt_matnr BY matnr ASCENDING.
    ENDIF.
    FREE: lt_matnr.

* Material Manufactring details
    lt_matnr = lt_qr_sscc.
    SORT lt_matnr BY matnr ASCENDING werks ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_matnr COMPARING matnr werks.
    LOOP AT lt_matnr ASSIGNING FIELD-SYMBOL(<ls_matnr_y>).
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = <ls_matnr_y>-matnr
        IMPORTING
          output       = <ls_matnr_y>-matnr
        EXCEPTIONS
          length_error = 1.
    ENDLOOP.
    SELECT matnr, werks, zzlicencenr1
      FROM marc INTO TABLE @DATA(lt_marc)
      FOR ALL ENTRIES IN @lt_matnr
      WHERE matnr = @lt_matnr-matnr AND
            werks = @lt_matnr-werks.
    IF sy-subrc = 0.
      SORT lt_marc BY matnr ASCENDING werks ASCENDING.
    ENDIF.

* To get Storage Conditions description
*    SELECT * FROM t142t INTO TABLE @DATA(lt_t142t)
*      WHERE spras = @sy-langu.
*    IF sy-subrc = 0.
*      SORT lt_t142t BY raube ASCENDING.
*    ENDIF.
* To get Storage Conditions
    LOOP AT lt_matnr ASSIGNING FIELD-SYMBOL(<ls_matnr_x>).
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = <ls_matnr_x>-matnr
        IMPORTING
          output       = <ls_matnr_x>-matnr
        EXCEPTIONS
          length_error = 1.
    ENDLOOP.
    SELECT * FROM zqmstorcond INTO TABLE @DATA(lt_storcond)
      FOR ALL ENTRIES IN @lt_matnr
        WHERE zmatnr = @lt_matnr-matnr AND
              zplant = @lt_matnr-werks.
    IF sy-subrc = 0.
      SORT lt_storcond BY zmatnr ASCENDING zplant ASCENDING.
    ENDIF.

    SELECT * FROM zssd_store_cond INTO TABLE @DATA(lt_storcond_sen)
     FOR ALL ENTRIES IN @lt_matnr
       WHERE zmatnr = @lt_matnr-matnr AND
             zplant = @lt_matnr-werks.
    IF sy-subrc = 0.
      SORT lt_storcond_sen BY zmatnr ASCENDING zplant ASCENDING.
    ENDIF.

    FREE: lt_matnr.

* To get the plant details
    lt_matnr[] = lt_qr_sscc[].
    SORT lt_matnr BY werks ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_matnr COMPARING werks.
    SELECT werks, adrnr FROM t001w INTO TABLE @DATA(lt_t001w)
      FOR ALL ENTRIES IN @lt_matnr
      WHERE werks = @lt_matnr-werks.
    IF sy-subrc = 0.
      SORT lt_t001w BY werks ASCENDING adrnr ASCENDING.
    ENDIF.
    SELECT * FROM zssd_plant_addr INTO TABLE @DATA(lt_zplant)
                      FOR ALL ENTRIES IN @lt_matnr
                         WHERE werks = @lt_matnr-werks.
    FREE: lt_matnr.

* To get Company code from Plant
    SELECT bwkey, bukrs FROM t001k INTO TABLE @DATA(lt_t001k)
      FOR ALL ENTRIES IN @lt_t001w
      WHERE bwkey = @lt_t001w-werks.
    IF sy-subrc = 0.
      SORT lt_t001k BY bukrs ASCENDING.

      SELECT bukrs, butxt FROM t001 INTO TABLE @DATA(lt_t001)
        FOR ALL ENTRIES IN @lt_t001k
        WHERE bukrs = @lt_t001k-bukrs.
      IF sy-subrc = 0.
        SORT lt_t001 BY bukrs ASCENDING.
      ENDIF.
    ENDIF.

* To get Plant address details
    DATA(lt_werks) = lt_t001w.
    SORT lt_t001w BY adrnr ASCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_t001w COMPARING adrnr.
    SELECT * FROM adrc INTO TABLE @DATA(lt_adrc)
      FOR ALL ENTRIES IN @lt_werks
      WHERE addrnumber = @lt_werks-adrnr.
    IF sy-subrc = 0.
      SORT lt_adrc BY addrnumber ASCENDING.
    ENDIF.
* To get country name
    IF lt_adrc[] IS NOT INITIAL.
      SELECT * FROM t005t INTO TABLE @DATA(lt_t005t)
                    FOR ALL ENTRIES IN @lt_adrc
                        WHERE spras = @sy-langu
                          AND land1 = @lt_adrc-country.
    ENDIF.
* To get Plant details from Delviery line item
    DATA(lt_vbeln) = lt_qr_sscc.
    SORT lt_vbeln BY vbeln ASCENDING.
    SELECT vbeln, posnr, matnr, werks, charg, lfimg
      FROM lips INTO TABLE @DATA(lt_lips)
      FOR ALL ENTRIES IN @lt_vbeln
      WHERE vbeln = @lt_vbeln-vbeln.
    IF sy-subrc = 0.
      SORT lt_lips BY vbeln ASCENDING posnr ASCENDING matnr ASCENDING.
    ENDIF.
    FREE: lt_vbeln.

* To get month names
    CALL FUNCTION 'MONTH_NAMES_GET'
      TABLES
        month_names           = lt_month_names
      EXCEPTIONS
        month_names_not_found = 1.

    DATA lt_data TYPE STANDARD TABLE OF zdt_api_qrcode_req_items.
    LOOP AT lt_qr_sscc INTO DATA(ls_qr_sscc).
      FREE: lv_name, lt_lines.
      REFRESH:lt_mfdate.
      APPEND INITIAL LINE TO lt_data ASSIGNING FIELD-SYMBOL(<ls_data>).
      <ls_data>-delivery_id = ls_qr_sscc-vbeln.

      CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
        EXPORTING
          input  = ls_qr_sscc-posnr
        IMPORTING
          output = <ls_data>-delivery_item_number.
      IF ls_qr_sscc-ltype EQ 'I'.
        READ TABLE lt_ztsd_label INTO DATA(ls_ztsd_label) WITH KEY label_i = ls_qr_sscc-label_n.
        IF sy-subrc IS INITIAL.
          DATA(lv_expflag) = ls_ztsd_label-c_edate.
        ELSE.
          lv_expflag = 'X'.
        ENDIF.
      ELSEIF ls_qr_sscc-ltype EQ 'O'.
        READ TABLE lt_ztsd_outer INTO DATA(ls_ztsd_outer) WITH KEY label_o = ls_qr_sscc-label_n.
        IF sy-subrc IS INITIAL.
          lv_expflag = ls_ztsd_outer-c_edate.
        ELSE.
          lv_expflag = 'X'.
        ENDIF.
      ELSEIF ls_qr_sscc-ltype EQ 'P'.
        READ TABLE lt_ztsd_pallet INTO DATA(ls_ztsd_pallet) WITH KEY label_p = ls_qr_sscc-label_n.
        IF sy-subrc IS INITIAL.
          lv_expflag = ls_ztsd_pallet-c_edate.
        ELSE.
          lv_expflag = 'X'.
        ENDIF.
      ENDIF.
* Company Name
      DATA(lv_bukrs) = VALUE #( lt_t001k[ bwkey = ls_qr_sscc-werks ]-bukrs OPTIONAL ).
      DATA(lv_butxt) = VALUE #( lt_t001[ bukrs = lv_bukrs ]-butxt OPTIONAL ).
      <ls_data>-gtin = ls_qr_sscc-gtin.
      <ls_data>-sscc = ls_qr_sscc-zsscc.
      <ls_data>-sscc_status = ls_qr_sscc-status.
      <ls_data>-batch_number = ls_qr_sscc-charg.
* License No.
      DATA(ls_marc) = VALUE #( lt_marc[ matnr = ls_qr_sscc-matnr
                                        werks = ls_qr_sscc-werks ] OPTIONAL ).
      <ls_data>-mfg_license_no = ls_marc-zzlicencenr1.

* Storage condition
      <ls_data>-storage_conditions =
       VALUE #( lt_storcond[ zmatnr = ls_qr_sscc-matnr
                             zplant = ls_qr_sscc-werks ]-zdesc OPTIONAL ).
* Delivery line item quantity
      DATA(ls_lips) = VALUE #( lt_lips[ vbeln = ls_qr_sscc-vbeln
                                        posnr = ls_qr_sscc-posnr
                                        matnr = ls_qr_sscc-matnr ] OPTIONAL ).
      <ls_data>-batch_size = ls_lips-lfimg.

      IF lv_bukrs EQ '5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
        IF ls_qr_sscc-ltype EQ 'I'.
          READ TABLE lt_zssd_label INTO DATA(ls_zssd_label) WITH KEY label_i = ls_qr_sscc-label_n.
          IF sy-subrc IS INITIAL.
            <ls_data>-batch_size = ls_zssd_label-sfg_batch.
* Storage condition
*            <ls_data>-storage_conditions = ls_zssd_label-store_desc.
* Storage condition
      <ls_data>-storage_conditions =
       VALUE #( lt_storcond_sen[ zmatnr = ls_qr_sscc-matnr
                             zplant = ls_qr_sscc-werks ]-zdesc OPTIONAL ).
                  <ls_data>-storage_conditions = ls_zssd_label-store_desc.
* License No.
            <ls_data>-mfg_license_no = ls_zssd_label-zzlicencenr1.
          ENDIF.
        ELSEIF ls_qr_sscc-ltype EQ 'O'.
          READ TABLE lt_zssd_outer INTO DATA(ls_zssd_outer) WITH KEY label_o = ls_qr_sscc-label_n.
          IF sy-subrc IS INITIAL.
            <ls_data>-batch_size = ls_zssd_outer-sfg_batch.
* Storage condition
            <ls_data>-storage_conditions = ls_zssd_outer-store_desc.
* License No.
            <ls_data>-mfg_license_no = ls_zssd_outer-zzlicencenr1.
          ENDIF.
        ELSEIF ls_qr_sscc-ltype EQ 'P'.
          READ TABLE lt_zssd_pallet INTO DATA(ls_zssd_pallet) WITH KEY label_p = ls_qr_sscc-label_n.
          IF sy-subrc IS INITIAL.
            <ls_data>-batch_size = ls_zssd_pallet-sfg_batch.
            if ls_zssd_pallet-zcharg is NOT INITIAL.
            <ls_data>-batch_number = ls_zssd_pallet-zcharg.
            endif.
* Storage condition
            <ls_data>-storage_conditions = ls_zssd_pallet-store_desc.
* License No.
            <ls_data>-mfg_license_no = ls_zssd_pallet-zzlicencenr1.
            IF ls_zssd_pallet-zbatch IS NOT INITIAL.
              <ls_data>-batch_size = ls_zssd_pallet-zbatch.
            ENDIF.
            CLEAR:ls_mfdate.
            SPLIT ls_zssd_pallet-manif AT ',' INTO DATA(l_date1) DATA(l_date2).
            IF l_date1 IS   NOT INITIAL.
              ls_mfdate-date = l_date1.
              APPEND ls_mfdate TO lt_mfdate.
            ENDIF.
            IF l_date2 IS NOT INITIAL.
              ls_mfdate-date = l_date2.
              APPEND ls_mfdate TO lt_mfdate.
            ENDIF.
            CLEAR:ls_retest,l_date1,l_date2.
            SPLIT ls_zssd_pallet-retest AT ',' INTO l_date1 l_date2.
            IF l_date1 IS   NOT INITIAL.
              ls_retest-date = l_date1.
              APPEND ls_retest TO lt_retest.
            ENDIF.
            IF l_date2 IS NOT INITIAL.
              ls_retest-date = l_date2.
              APPEND ls_retest TO lt_retest.
            ENDIF.
          ENDIF.
        ENDIF.

      ENDIF.
      IF ls_qr_sscc-hsdat <> '00000000'.
        <ls_data>-manufacture_date =
          VALUE #( lt_month_names[ mnr = ls_qr_sscc-hsdat+4(2) ]-ktx OPTIONAL ).
        IF lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600'.
          CONCATENATE <ls_data>-manufacture_date ls_qr_sscc-hsdat+0(4)
            INTO <ls_data>-manufacture_date SEPARATED BY space.
        ELSE.
          CONCATENATE ls_qr_sscc-hsdat+6(2) <ls_data>-manufacture_date ls_qr_sscc-hsdat+0(4)
          INTO <ls_data>-manufacture_date SEPARATED BY space.
        ENDIF.
      ELSE.
        FREE: <ls_data>-manufacture_date.
      ENDIF.

      IF ls_qr_sscc-vfdat <> '00000000' AND lv_expflag IS NOT INITIAL.
        IF ls_qr_sscc-hsdat+6(2) NE '01' AND ( lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600').
          CALL FUNCTION 'BKK_ADD_MONTH_TO_DATE'
            EXPORTING
              months  = '-1'
              olddate = ls_qr_sscc-vfdat
            IMPORTING
              newdate = ls_qr_sscc-vfdat.
        ENDIF.
        <ls_data>-expiry_date =
          VALUE #( lt_month_names[ mnr = ls_qr_sscc-vfdat+4(2) ]-ktx OPTIONAL ).
        IF  lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600'.
          CONCATENATE <ls_data>-expiry_date ls_qr_sscc-vfdat+0(4)
            INTO <ls_data>-expiry_date SEPARATED BY space.
        ELSE.
          CONCATENATE ls_qr_sscc-vfdat+6(2) <ls_data>-expiry_date ls_qr_sscc-vfdat+0(4)
            INTO <ls_data>-expiry_date SEPARATED BY space.
        ENDIF.
      ELSE.
        FREE: <ls_data>-expiry_date.
      ENDIF.

      IF ls_qr_sscc-qndat <> '00000000'.
        IF ls_qr_sscc-hsdat+6(2) NE '01' AND ( lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600').
          CALL FUNCTION 'BKK_ADD_MONTH_TO_DATE'
            EXPORTING
              months  = '-1'
              olddate = ls_qr_sscc-qndat
            IMPORTING
              newdate = ls_qr_sscc-qndat.
        ENDIF.
        <ls_data>-retest_date =
          VALUE #( lt_month_names[ mnr = ls_qr_sscc-qndat+4(2) ]-ktx OPTIONAL ).
        IF  lv_bukrs NE '5100' AND lv_bukrs NE '5500' AND lv_bukrs NE '5600'.
          CONCATENATE <ls_data>-retest_date ls_qr_sscc-qndat+0(4)
            INTO <ls_data>-retest_date SEPARATED BY space.
        ELSE.
          CONCATENATE ls_qr_sscc-qndat+6(2) <ls_data>-retest_date ls_qr_sscc-qndat+0(4)
            INTO <ls_data>-retest_date SEPARATED BY space.
        ENDIF.
      ELSE.
        FREE: <ls_data>-retest_date.
      ENDIF.
      IF ( lv_bukrs EQ '5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600') AND ls_qr_sscc-ltype = 'P'.
** Manufacture date.
        if lt_mfdate[] is NOT INITIAL.
        CLEAR :<ls_data>-manufacture_date,lv_coma.
        endif.
        clear:lv_coma.
        LOOP AT lt_mfdate INTO ls_mfdate.

          IF ls_mfdate-date <> '00000000'.
            lv_datest =
               VALUE #( lt_month_names[ mnr = ls_mfdate-date+4(2) ]-ktx OPTIONAL ).
            CONCATENATE <ls_data>-manufacture_date lv_coma ls_mfdate-date+6(2) lv_datest ls_mfdate-date+0(4)
               INTO <ls_data>-manufacture_date SEPARATED BY space.
            lv_coma = ','.
          ENDIF.
        ENDLOOP.
        CONDENSE <ls_data>-manufacture_date.
** retest date
        if lt_retest[] is NOT INITIAL.
        CLEAR :lv_datest,<ls_data>-retest_date,lv_coma.
        endif.
        LOOP AT lt_retest INTO ls_retest.
          IF ls_retest-date <> '00000000'.
            lv_datest =
               VALUE #( lt_month_names[ mnr = ls_retest-date+4(2) ]-ktx OPTIONAL ).
            CONCATENATE <ls_data>-retest_date lv_coma ls_retest-date+6(2) lv_datest ls_retest-date+0(4)
               INTO <ls_data>-retest_date SEPARATED BY space.
            lv_coma = ','.
          ENDIF.
        ENDLOOP.
        CONDENSE <ls_data>-retest_date.
      ENDIF.
* Material input format
      CALL FUNCTION 'CONVERSION_EXIT_MATN1_INPUT'
        EXPORTING
          input        = ls_qr_sscc-matnr
        IMPORTING
          output       = ls_qr_sscc-matnr
        EXCEPTIONS
          length_error = 1.

* Material description
*      DATA(ls_makt) = VALUE #( lt_makt[ matnr = ls_qr_sscc-matnr ] OPTIONAL ).
*      <ls_data>-api_name = ls_makt-maktx.
      lv_id = 'BEST'.
      lv_object = 'MATERIAL'.
      lv_name = ls_qr_sscc-matnr.
* To get Product Item text
      CALL FUNCTION 'READ_TEXT'
        EXPORTING
          id                      = lv_id
          language                = sy-langu
          name                    = lv_name
          object                  = lv_object
        TABLES
          lines                   = lt_lines
        EXCEPTIONS
          id                      = 1
          language                = 2
          name                    = 3
          not_found               = 4
          object                  = 5
          reference_check         = 6
          wrong_access_to_archive = 7.

      DATA(lv_text) = VALUE #( lt_lines[ 1 ]-tdline OPTIONAL ).
      IF lv_text IS NOT INITIAL.
        <ls_data>-api_name = lv_text.
        replace_sp_chars_api_name( CHANGING cv_api_name = <ls_data>-api_name  ).
      ENDIF.


* Manufactured by
      IF  lv_bukrs EQ '5100' OR lv_bukrs EQ '5500' OR lv_bukrs EQ '5600'.
        READ TABLE lt_zplant INTO DATA(ls_zplant) WITH KEY werks = ls_qr_sscc-werks.
        IF sy-subrc IS INITIAL.
          CONCATENATE ls_zplant-company ls_zplant-address INTO <ls_data>-manufactured_by SEPARATED BY ','.
        ENDIF.
      ELSE.
        DATA(ls_t001w) = VALUE #( lt_t001w[ werks = ls_qr_sscc-werks ] OPTIONAL ).
        DATA(ls_adrc) = VALUE #( lt_adrc[ addrnumber = ls_t001w-adrnr ] OPTIONAL ).
        IF ls_adrc-name1 IS NOT INITIAL.
          READ TABLE lt_t005t INTO DATA(ls_t005t) WITH KEY land1 = ls_adrc-country.
          CONCATENATE ls_adrc-name1 ls_adrc-str_suppl1 ls_adrc-str_suppl2 ls_adrc-city1
                      ls_adrc-post_code1 ls_t005t-landx "ls_adrc-country
                      INTO <ls_data>-manufactured_by SEPARATED BY ', '.
        ENDIF.
      ENDIF.


    ENDLOOP.

* To call proxy for data push to VRS
    TRY.
        CREATE OBJECT lo_proxy.

        ls_output-mt_api_qrcode_req-items[] = lt_data[].
        lo_proxy->si_api_qrcode_out(
          EXPORTING
            output = ls_output
               ).
*        COMMIT WORK.
      CATCH cx_ai_system_fault.
    ENDTRY.

  ENDMETHOD.


  METHOD REPLACE_SP_CHARS_API_NAME.


    REPLACE ALL OCCURRENCES OF '&lt;' IN cv_api_name WITH '<'.
    REPLACE ALL OCCURRENCES OF '&gt;' IN cv_api_name WITH '>'.
    REPLACE ALL OCCURRENCES OF '&amp;' IN cv_api_name WITH '&'.
    REPLACE ALL OCCURRENCES OF '&apos' IN cv_api_name WITH c_s_q.
    REPLACE ALL OCCURRENCES OF '&quot' IN cv_api_name WITH c_d_q.


  ENDMETHOD.
ENDCLASS.
