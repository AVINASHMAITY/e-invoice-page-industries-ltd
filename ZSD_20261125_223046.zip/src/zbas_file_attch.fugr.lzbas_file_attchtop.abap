*$*$-----------------------------------------------------------------$*$
*$*$ Author       : Collabera                                        $*$
*$*$ Creation Date: 02.08.2011                                       $*$
*$*$ Funtion group: /OBIZ/IMP_FILE_ATTCH                             $*$
*$*$ Description  : To upload and download documents                 $*$
*$*$                                                                 $*$
*$*$                                                                 $*$
*$*$-----------------------------------------------------------------$*$
*=================================================================*
*   FUNCTION POOL /obiz/fg_file_attch
*=================================================================*
FUNCTION-POOL ZBAS_FILE_ATTCH.          "MESSAGE-ID .


*=================================================================*
*Types Declaration
*=================================================================*
TYPES pict_line(256) TYPE c.


*=================================================================*
* Data Declaration
*=================================================================*
DATA : ok_code     TYPE sy-ucomm,
       sav_okcode  TYPE sy-ucomm,
       pos         TYPE i,
       pic_id      TYPE n LENGTH 13,
       rc          TYPE i,
       action      TYPE i,
       wrk_pic_no  TYPE n LENGTH 13,
       count2      TYPE i,
       count3      TYPE i,
       fnam        TYPE string,
       file_length TYPE i,
       name        TYPE string,
       count       TYPE i,
       wrk_disp    TYPE c.




*================================================================*
*  Internal table Declaration
*================================================================*
DATA : it_pic_upload   TYPE TABLE OF zbas_attachment,
       it_pic_download TYPE TABLE OF zbas_attachment,
       it_pic_tab_down TYPE TABLE OF pict_line,
       it_pic_tab      TYPE TABLE OF file_table,
       it_pic_tab_up   TYPE TABLE OF pict_line,
       it_fieldcat     TYPE lvc_t_fcat,
       it_lay          TYPE lvc_s_layo.

DATA : BEGIN OF it_nam2 OCCURS 0,
         ptype(100),
       END OF it_nam2.

DATA : BEGIN OF it_nam3 OCCURS 0,
         ptype(100),
       END OF it_nam3.



*================================================================*
*Work Area Declaration
*================================================================*
DATA: wa_pic_upload   LIKE LINE OF it_pic_upload,
      wa_pic_download LIKE LINE OF it_pic_download,
      wa_nam2         LIKE LINE OF it_nam2,
      wa_nam3         LIKE LINE OF it_nam3,
      wa_pic_tab      LIKE LINE OF it_pic_tab,
      wa_fieldcat     LIKE LINE OF it_fieldcat.


*===============================================================*
*  Controls Declaration
*===============================================================*

DATA:
*g_container TYPE scrfname VALUE 'CONTAINER',
  grid1         TYPE REF TO cl_gui_alv_grid,
  g_c_container TYPE REF TO cl_gui_custom_container,
  gs_toolbar    TYPE stb_button.


*===============================================================*
*  Ranges Declaration
*===============================================================*
DATA: r_fid           TYPE RANGE OF zbas_attachment-fid.
DATA: r_mod_desc      TYPE RANGE OF zbas_attachment-mod_desc.
DATA: r_doccategory   TYPE RANGE OF zbas_attachment-doccategory.
DATA: r_docno         TYPE RANGE OF zbas_attachment-docno.
*---------------------------------------------------------------------*
*       CLASS lcl_event_receiver DEFINITION
*---------------------------------------------------------------------*
*
*---------------------------------------------------------------------*
CLASS lcl_event_receiver DEFINITION.
  INCLUDE <icon>.
  PUBLIC SECTION.
    DATA : mod_desc    TYPE zbas_attachment-mod_desc,
           doccategory TYPE zimp_doctyp,
           docno       TYPE zbas_attachment-docno.

    METHODS:

      handle_double_click
                    FOR EVENT double_click OF cl_gui_alv_grid
        IMPORTING e_row e_column,

      handle_toolbar
                    FOR EVENT toolbar OF cl_gui_alv_grid
        IMPORTING e_object e_interactive,

      handle_menu_button
                    FOR EVENT menu_button OF cl_gui_alv_grid
        IMPORTING e_object e_ucomm,

      handle_user_command
                    FOR EVENT user_command OF cl_gui_alv_grid
        IMPORTING e_ucomm.

  PRIVATE SECTION.

ENDCLASS.                    "lcl_event_receiver DEFINITION
*-----------------------------------------------------------------

CLASS lcl_event_receiver IMPLEMENTATION.

*===================================================================*
*Method Handle_double_click
*===================================================================*

  METHOD handle_double_click.

    READ TABLE it_pic_download INDEX e_row-index INTO wa_pic_download.

    MOVE wa_pic_download-fid TO pic_id.

    IMPORT it_pict_tab = it_pic_tab_down FROM DATABASE abtree(iv)
            ID pic_id .
    fnam = wa_pic_download-fname.


    CALL METHOD cl_gui_frontend_services=>gui_download
      EXPORTING
        filename                = fnam
        filetype                = 'BIN'
      IMPORTING
        filelength              = file_length
      CHANGING
        data_tab                = it_pic_tab_down
      EXCEPTIONS
        file_write_error        = 1
        no_batch                = 2
        gui_refuse_filetransfer = 3
        invalid_type            = 4
        no_authority            = 5
        unknown_error           = 6
        header_not_allowed      = 7
        separator_not_allowed   = 8
        filesize_not_allowed    = 9
        header_too_long         = 10
        dp_error_create         = 11
        dp_error_send           = 12
        dp_error_write          = 13
        unknown_dp_error        = 14
        access_denied           = 15
        dp_out_of_memory        = 16
        disk_full               = 17
        dp_timeout              = 18
        file_not_found          = 19
        dataprovider_exception  = 20
        control_flush_error     = 21
        not_supported_by_gui    = 22
        error_no_gui            = 23
        OTHERS                  = 24.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.


    CALL METHOD cl_gui_cfw=>flush
      EXCEPTIONS
        cntl_system_error = 1
        cntl_error        = 2
        OTHERS            = 3.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

    CALL METHOD cl_gui_frontend_services=>execute
      EXPORTING
        document               = fnam
        operation              = 'OPEN'
      EXCEPTIONS
        cntl_error             = 1
        error_no_gui           = 2
        bad_parameter          = 3
        file_not_found         = 4
        path_not_found         = 5
        file_extension_unknown = 6
        error_execute_failed   = 7
        synchronous_failed     = 8
        not_supported_by_gui   = 9
        OTHERS                 = 10.
    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.


  ENDMETHOD.                           "handle_double_click
*==============================================================*
* Method Handle ToolBar
*==============================================================*

  METHOD handle_toolbar.

    CLEAR gs_toolbar.
    MOVE 3 TO gs_toolbar-butn_type.
    APPEND gs_toolbar TO e_object->mt_toolbar.

    CLEAR gs_toolbar.
* To hide attach and delete in display mode
    IF wrk_disp IS INITIAL.
      MOVE 'DELETE' TO gs_toolbar-function.
      MOVE icon_delete TO gs_toolbar-icon.
      MOVE 'Delete'(200) TO gs_toolbar-quickinfo.

      APPEND gs_toolbar TO e_object->mt_toolbar.

      MOVE 'ATTACH' TO gs_toolbar-function.
      MOVE icon_aggregate TO gs_toolbar-icon.
      MOVE 'Attach File'(201) TO gs_toolbar-quickinfo.

      APPEND gs_toolbar TO e_object->mt_toolbar.
    ENDIF.
    MOVE 'EXPORT' TO gs_toolbar-function.
    MOVE icon_export TO gs_toolbar-icon.
    MOVE 'Export'(202) TO gs_toolbar-quickinfo.

    APPEND gs_toolbar TO e_object->mt_toolbar.

    MOVE 'REFRESH' TO gs_toolbar-function.
    MOVE icon_refresh TO gs_toolbar-icon.
    MOVE 'Refresh'(203) TO gs_toolbar-quickinfo.

    APPEND gs_toolbar TO e_object->mt_toolbar.


  ENDMETHOD.                    "handle_toolbar

  METHOD handle_menu_button.


  ENDMETHOD.                    "handle_menu_button
*========================================================================*
* Mehod User Command
*========================================================================*

  METHOD handle_user_command.

    DATA: lt_rows TYPE lvc_t_row,
          wa_rows LIKE LINE OF lt_rows.

    CALL METHOD grid1->get_selected_rows
      IMPORTING
        et_index_rows = lt_rows.


    LOOP AT lt_rows INTO wa_rows.

    ENDLOOP.

    READ TABLE it_pic_download INDEX wa_rows-index INTO wa_pic_download.
    MOVE wa_pic_download-fid TO pic_id.

    CASE e_ucomm.

      WHEN 'DELETE'.

        DELETE TABLE it_pic_download FROM wa_pic_download.
        DELETE zbas_attachment FROM wa_pic_download.
        DELETE FROM abtree  WHERE relid = 'IV' AND name = pic_id.

        CALL METHOD grid1->refresh_table_display
          EXCEPTIONS
            finished = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                     WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ENDIF.


      WHEN 'EXPORT'.

        DATA: fpath    TYPE string,
              fullpath TYPE string.

        IMPORT it_pict_tab = it_pic_tab_down FROM DATABASE abtree(iv)
                    ID pic_id .
        fnam = wa_pic_download-fname.

        CALL METHOD cl_gui_frontend_services=>file_save_dialog
          EXPORTING
            prompt_on_overwrite  = 'X'
          CHANGING
            filename             = fnam
            path                 = fpath
            fullpath             = fullpath
            user_action          = action
          EXCEPTIONS
            cntl_error           = 1
            error_no_gui         = 2
            not_supported_by_gui = 3
            OTHERS               = 4.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                     WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ELSEIF action = 9.
*          MESSAGE s002(/obiz/file).
          MESSAGE  s002(zbfn_file_imp).
        ELSE.


          CALL METHOD cl_gui_cfw=>flush
            EXCEPTIONS
              cntl_system_error = 1
              cntl_error        = 2
              OTHERS            = 3.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                       WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
          ENDIF.


          CALL METHOD cl_gui_frontend_services=>gui_download
            EXPORTING
              filename                = fullpath
              filetype                = 'BIN'
            CHANGING
              data_tab                = it_pic_tab_down
            EXCEPTIONS
              file_write_error        = 1
              no_batch                = 2
              gui_refuse_filetransfer = 3
              invalid_type            = 4
              no_authority            = 5
              unknown_error           = 6
              header_not_allowed      = 7
              separator_not_allowed   = 8
              filesize_not_allowed    = 9
              header_too_long         = 10
              dp_error_create         = 11
              dp_error_send           = 12
              dp_error_write          = 13
              unknown_dp_error        = 14
              access_denied           = 15
              dp_out_of_memory        = 16
              disk_full               = 17
              dp_timeout              = 18
              file_not_found          = 19
              dataprovider_exception  = 20
              control_flush_error     = 21
              not_supported_by_gui    = 22
              error_no_gui            = 23
              OTHERS                  = 24.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                       WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
          ENDIF.

          CALL METHOD cl_gui_cfw=>flush
            EXCEPTIONS
              cntl_system_error = 1
              cntl_error        = 2
              OTHERS            = 3.
          IF sy-subrc <> 0.
            MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                       WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
          ENDIF.

        ENDIF.
      WHEN 'ATTACH'.
        IMPORT mod_desc TO mod_desc FROM MEMORY ID 'MD'.
        IMPORT doccategory TO doccategory FROM MEMORY ID 'CG'.
        IMPORT docno TO docno FROM MEMORY ID 'DN'.

        PERFORM upload_file USING mod_desc
                           doccategory
                           docno.

        PERFORM fetch_file USING  mod_desc
                           doccategory
                           docno.

        CALL METHOD grid1->refresh_table_display
          EXCEPTIONS
            finished = 1
            OTHERS   = 2.
        IF sy-subrc <> 0.
*             MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*                        WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
        ENDIF.



    ENDCASE.

  ENDMETHOD.                           "handle_user_command



ENDCLASS.                    "lcl_event_receiver IMPLEMENTATION

DATA event_receiver TYPE REF TO lcl_event_receiver.
