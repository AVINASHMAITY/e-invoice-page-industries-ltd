FUNCTION-POOL ZEI_PAYEE                  MESSAGE-ID SV.

* INCLUDE LZEI_PAYEED...                     " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZEI_PAYEET00                           . "view rel. data dcl.
