*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFGSD_FNOTE_TEXT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFGSD_FNOTE_TEXT    .

  PERFORM TABLEPROC.

ENDFUNCTION.
