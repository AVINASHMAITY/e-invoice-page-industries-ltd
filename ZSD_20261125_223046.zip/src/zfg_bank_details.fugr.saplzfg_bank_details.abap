*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_BANK_DETAILSTOP.              " Global Data
  INCLUDE LZFG_BANK_DETAILSUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_BANK_DETAILSF...              " Subroutines
* INCLUDE LZFG_BANK_DETAILSO...              " PBO-Modules
* INCLUDE LZFG_BANK_DETAILSI...              " PAI-Modules
* INCLUDE LZFG_BANK_DETAILSE...              " Events
* INCLUDE LZFG_BANK_DETAILSP...              " Local class implement.
* INCLUDE LZFG_BANK_DETAILST99.              " ABAP Unit tests
  INCLUDE LZFG_BANK_DETAILSF00                    . " subprograms
  INCLUDE LZFG_BANK_DETAILSI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
