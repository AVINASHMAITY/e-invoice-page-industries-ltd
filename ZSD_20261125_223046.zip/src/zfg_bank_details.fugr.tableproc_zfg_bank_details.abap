*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_BANK_DETAILS
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_BANK_DETAILS    .

  PERFORM TABLEPROC.

ENDFUNCTION.
