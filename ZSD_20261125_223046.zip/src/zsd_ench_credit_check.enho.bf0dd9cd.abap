"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT\SE:END\EI
ENHANCEMENT 0 ZSD_ENCH_CREDIT_CHECK.

Data : lw_komv type komv,
       lv_kwert_cred type KOMV-KWERT,
       lv_kbetr_cred TYPE konp-KBETR,
       lv_flag_cred type c,
       lv_cred type c,
       lv_mail_cred type AD_SMTPADR,
       lw_kna1_cred type kna1,
       lv_tot_cred type string,
       lv_25k(13) type p decimals 2 value 2500000.
DATA: LV_XVBAP TYPE I,
      LV_YVBAP TYPE I.
data:   lt_ZTSD_SAMPLE25K type TABLE OF ZTSD_SAMPLE25K,
         lw_ZTSD_SAMPLE25K type ZTSD_SAMPLE25K,
         lt_A850 TYPE TABLE OF a850,
         lw_a850 type a850,
         lt_konp TYPE TABLE OF konp,
         lw_konp TYPE konp,
         lw_xvbap_cred type vbap,
         lt_zsd_cust_mails type TABLE OF zsd_cust_mails,
         lw_zsd_cust_mails TYPE zsd_cust_mails.
DATA: lt_objtxt       TYPE bcsy_text,
      ls_objtxt       LIKE LINE OF lt_objtxt, "lt_objtxt       LIKE solisti1 OCCURS 10 WITH HEADER LINE,
      doc_chng        LIKE sodocchgi1,
      tab_lines       LIKE sy-tabix,
      w_longtext(255) TYPE c,
      lt_objbin       LIKE solisti1 OCCURS 10 WITH HEADER LINE,
      lv_string       TYPE string,
      lt_reclist      LIKE somlreci1 OCCURS 5 WITH HEADER LINE,
      lt_objpack      LIKE sopcklsti1 OCCURS 2 WITH HEADER LINE.
DATA : "lv_string      TYPE string,
  lv_long_sub    TYPE string,
  lv_data_string TYPE string,
  lv_xstring     TYPE xstring.


DATA:     lv_sub        TYPE so_obj_des.
DATA : lv_system(25) TYPE c,
       lt_text       TYPE bcsy_text,
       ls_text       LIKE LINE OF lt_text.
DATA : lo_bcs       TYPE REF TO cl_bcs,
       lo_doc       TYPE REF TO cl_document_bcs,
       lo_sender    TYPE REF TO if_sender_bcs VALUE IS INITIAL,
       lo_recipient TYPE REF TO if_recipient_bcs VALUE IS INITIAL,
       lv_string1   TYPE string.
DATA: l_num_rows    TYPE i,
      l_text_length TYPE so_obj_len,
      l_num_line    TYPE i.
DATA: LW_XVBAK_CRED TYPE VBAK.
*if sy-tcode = 'VA01' or sy-tcode = 'VA02'.
*
*  select * from ZTSD_SAMPLE25K into TABLE lt_ZTSD_SAMPLE25K.
*  READ TABLE lt_ZTSD_SAMPLE25K into lw_ZTSD_SAMPLE25K with key vkorg = vbak-vkorg auart = vbak-auart.
*  IF sy-subrc eq 0.
*    IF sy-tcode = 'VA01'.
*     lv_cred = 'X'.
*    ENDIF.
*    IF sy-tcode = 'VA02'.
*      DESCRIBE TABLE xvbap LINES lv_xvbap.
*      DESCRIBE TABLE yvbap LINES lv_yvbap.
**      if lv_xvbap = 1.
*      IF lv_xvbap NE lv_yvbap and lv_xvbap LT lv_yvbap .
*        lv_cred = 'X'.
**      endif.
*      else.
*        LOOP AT xvbap.
*          READ TABLE yvbap into lw_yvbap with key posnr = xvbap-posnr.
*          IF sy-subrc = 0.
*             if xvbap-kwmeng ne yvbap-kwmeng.
*               lv_cred = 'X'.
*               exit.
*             endif.
*          ENDIF.
*
*        ENDLOOP.
*      ENDIF.
*    ENDIF.
*
*  IF LV_CRED = 'X'.
*
**    DOMESTIC SAMPLE SALES ORDER
*    if vbak-vtweg = '10'.
**    if vbak-auart = 'ZBFD' or vbak-auart = 'ZBFG' or vbak-auart = 'ZBFS' or vbak-auart = 'ZPFD' or vbak-auart = 'ZPFS'.
*    clear :lv_flag_cred,lv_kwert_cred.
*    READ TABLE xkomv into lw_komv with key kschl = 'JASS'.
*    IF sy-subrc = 0.
*     lv_kwert_cred =  lw_komv-KWERT.
*     IF lv_kwert_cred GE lv_25k.
*       lv_tot_cred = lv_kwert_cred.
*      lv_flag_cred = 'X'.
*     ENDIF.
*    ENDIF.
*   endif.
**    EXPORT SAMPLE SALES ORDER
*   if vbak-vtweg = '20'.
**   IF vbak-auart = 'ZBF1' or vbak-auart = 'ZBFZ' or vbak-auart = 'ZPFZ'.
*     clear :lv_flag_cred,lv_kbetr_cred.
*     IF xvbap is not INITIAL.
*         select * from A850 into TABLE lt_A850 FOR ALL ENTRIES IN xvbap where matnr = xvbap-matnr.
*         IF lt_a850 is not INITIAL.
*           select * from konp into table lt_konp FOR ALL ENTRIES IN lt_a850 where KNUMH = lt_a850-KNUMH.
*         ENDIF.
*     ENDIF.
*
*     LOOP AT xvbap INTO lw_xvbap_cred .
*       READ TABLE lt_a850 into lw_a850 with key matnr = lw_xvbap_cred-matnr.
*       IF sy-subrc = 0.
*         READ TABLE lt_konp into lw_konp with key knumh = lw_a850-knumh.
*         IF sy-subrc = 0.
*           lw_konp-KBETR = lw_konp-KBETR / 100.
*           lw_xvbap_cred-KWMENG = lw_xvbap_cred-KWMENG / 10.
*          lv_KBETR_cred = lv_KBETR_cred + ( lw_konp-KBETR * lw_xvbap_cred-KWMENG ).
*         ENDIF.
*       ENDIF.
*     endloop.
*     IF lv_kbetr_cred GE lv_25k.
*       lv_tot_cred = lv_kbetr_cred.
*       lv_flag_cred = 'X'.
*     ENDIF.
*   ENDIF.
*  ENDIF.
*  ENDIF.
*DATA : lv_flag_cred.
IMPORT lv_flag_cred FROM MEMORY ID 'LV_25K'.

  IF lv_flag_cred = 'X'.
*   VBAK-AUGRU = 'ZC3'.
*   MODIFY vbak."from vbak TRANSPORTING augru.
*   XVBAK-AUGRU = 'ZC3'.
*   MODIFY XVBAK.
*   MODIFY vbak FROM LW_XVBAK_CRED TRANSPORTING AUGRU..
   select SINGLE * from kna1 into lw_kna1_cred where kunnr = vbak-kunnr.
 SELECT * FROM zsd_cust_mails INTO  table lt_zsd_cust_mails WHERE katr6 = lw_kna1_cred-katr6.
loop at lt_zsd_cust_mails into  lw_zsd_cust_mails.
 lv_mail_cred = lw_zsd_cust_mails-smtp_addr.
  IF lv_mail_cred IS NOT INITIAL.

    CONCATENATE 'Dear Team' ',' INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

    CONCATENATE 'Following sample order value is exceeded 25K, Hence SO is closed.' '' INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.


    CONCATENATE 'SO Date: ' VBAK-ERDAT+6(2) '.' VBAK-ERDAT+4(2) '.' VBAK-ERDAT(4)
                INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.
    CONCATENATE 'SO Number:' VBAK-VBELN INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.
    CONCATENATE 'Sold To party :' VBAK-KUNNR '-' lw_kna1_cred-name1 INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.
    CONCATENATE 'Total Value:' lv_tot_cred INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

    "ADDED BY KIRUBA/ITEANZ ON 12/7/2023 DR1K976833
    CONCATENATE 'Plant:' VBAP-WERKS INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

     SHIFT VBAP-MATNR LEFT DELETING LEADING '0'.

    CONCATENATE 'Material Number:' VBAP-MATNR INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

    CONCATENATE 'Material Description:' VBAP-ARKTX INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

"ENDED BY KIRUBA


    CONCATENATE '' '' INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

    CONCATENATE 'Regards' '' INTO ls_objtxt-line SEPARATED BY space.
    APPEND ls_objtxt TO lt_objtxt.
    CLEAR ls_objtxt.

     CONCATENATE VBAK-VBELN ':Sample Order Value exceeded 25K' INTO lv_sub.
    DESCRIBE TABLE lt_objtxt LINES tab_lines.


    DESCRIBE TABLE lt_objtxt LINES l_num_rows.
    l_num_rows = l_num_rows * 255.
    MOVE l_num_rows TO l_text_length.
    TRY.
        lo_doc = cl_document_bcs=>create_document(
                              i_type = 'RAW'
                              i_length  = l_text_length
                              i_text =  lt_objtxt
                              i_subject = lv_sub ).

*      * Set Sender
        lo_bcs = cl_bcs=>create_persistent( ).

        CALL METHOD lo_bcs->set_document( lo_doc ).

        lo_sender = cl_sapuser_bcs=>create( 'WF-BATCH' ).

        lo_bcs->set_sender(
        EXPORTING
        i_sender = lo_sender ).


        lo_recipient = cl_cam_address_bcs=>create_internet_address( lv_mail_cred ).
        lo_bcs->add_recipient(
            EXPORTING
            i_recipient = lo_recipient
            i_express = 'X' ).

        CALL METHOD lo_bcs->set_send_immediately
          EXPORTING
            i_send_immediately = 'X'.
*    * Send email

        lo_bcs->send(
        EXPORTING
        i_with_error_screen = 'X' ).
*        COMMIT WORK.             "Committed by Ravi on 15.06.2023
      CATCH cx_send_req_bcs.
    ENDTRY.

    REFRESH :  lt_objtxt.


  ENDIF.
 ENDLOOP.
  ENDIF.
*ENDIF.
"SOC by Madhur on 110824
*  BREAK SAP_PWCFICO.
IF sy-ucomm = 'SICH' AND VBAK-faksk = 'Z9'.
  "Sending Email to respective Users
  DATA SEND_REQUEST   TYPE REF TO CL_BCS.
  DATA DOCUMENT       TYPE REF TO CL_DOCUMENT_BCS.
  DATA RECIPIENT      TYPE REF TO IF_RECIPIENT_BCS.
  DATA BCS_EXCEPTION  TYPE REF TO CX_BCS.

  DATA : MAIN_TEXT      TYPE BCSY_TEXT,
          LV_CONTENT       TYPE STRING,
          LV_BODY_LINE1    TYPE STRING,
          LV_BODY_LINE2    TYPE STRING,
          LV_BODY_LINE3    TYPE STRING.
  DATA BINARY_CONTENT TYPE SOLIX_TAB.
  DATA SIZE           TYPE SO_OBJ_LEN.
  DATA SENT_TO_ALL    TYPE OS_BOOLEAN.
  DATA :   lv_sodate TYPE CHAR10,
           lv_podate TYPE CHAR10,
           lv_quantity TYPE CHAR10.
  DATA GC_HTM TYPE CHAR3 VALUE 'HTM'.
  DATA: lv_kunnr TYPE kunnr.
* for POP-UP
  DATA WF_ANS TYPE CHAR1.

  DATA : LW_DOCDATA TYPE SODOCCHGI1,
        IT_OBJPACK TYPE TABLE OF SOPCKLSTI1,
        LW_OBJPACK TYPE SOPCKLSTI1,
        IT_OBJHEAD TYPE TABLE OF SOLISTI1,
        LW_OBJHEAD1 TYPE SOLISTI1,
        IT_OBJTXT TYPE TABLE OF SOLISTI1,
        LW_OBJTXT TYPE SOLISTI1,
        LW_LINES TYPE I,
        IT_RECLIST TYPE TABLE OF SOMLRECI1,
        LW_RECLIST TYPE      SOMLRECI1 .
DATA: lt_ZTEXPNOC_EMAIL TYPE TABLE OF ZTEXPNOC_EMAIL,
      ls_ZTEXPNOC_EMAIL TYPE ZTEXPNOC_EMAIL.
        TYPES: BEGIN OF ty_kna1,
                  kunnr TYPE kunnr,
                  name1 TYPE name1,
                END OF ty_kna1.
DATA: lt_kna1_name TYPE TABLE OF ty_kna1,
      ls_kna1_name TYPE ty_kna1.
*DATA INPUT  TYPE CLIKE.
*DATA OUTPUT TYPE CLIKE.
          IF vbak-kunnr IS NOT INITIAL.
            CLEAR lv_kunnr.
            CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
              EXPORTING
                input         = vbak-kunnr
             IMPORTING
               OUTPUT        = lv_kunnr                      .

          SELECT SINGLE kunnr name1 FROM kna1 INTO ls_kna1_name WHERE kunnr = lv_kunnr.
          ENDIF.
        CONCATENATE '<P>' 'Dear Team,' '</P>' INTO LW_OBJTXT-LINE.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        CONCATENATE '<P>' 'Please find the Details' '</P>' INTO LW_OBJTXT-LINE.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<html> <body>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<table style="MARGIN: 20px" bordercolor="black" '.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = 'cellspacing="0" cellpadding="5" width="1000"'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = 'border="1"><tbody><tr>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
*   table header
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">SO Number</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">SO Date</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Customer</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Customer Name</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Customer PO No</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Customer PO Date</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Material Code</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Material Description</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<th bgcolor="DarkGray">Quantity</th>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
*Item Data
        DATA: LT_ZTEXPNOC_LIC TYPE TABLE OF ZTEXPNOC_LIC.
        SELECT * FROM ZTEXPNOC_LIC INTO CORRESPONDING FIELDS OF TABLE LT_ZTEXPNOC_LIC.
        LOOP AT xvbap INTO DATA(vbap_tmp).
          CONCATENATE '<tr>' '<td>' vbak-vbeln '</td>' INTO LW_OBJTXT-LINE.
          READ TABLE LT_ZTEXPNOC_LIC INTO DATA(LS_ZTEXPNOC_LIC) WITH KEY prod_code = VBAP_TMP-matnr.
          IF SY-SUBRC EQ 0.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          CONCATENATE VBAK-ERDAT+6(2) '.'
                      VBAK-ERDAT+4(2) '.'
                      VBAK-ERDAT+0(4)
                      INTO lv_sodate .
          CONCATENATE '<td>' lv_sodate '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          CONCATENATE '<td>' vbak-kunnr '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          CONCATENATE '<td>' ls_kna1_name-name1 '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          CONCATENATE '<td>' vbak-bstnk '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          IF VBAK-bstdk NE '00000000'.
          CONCATENATE VBAK-bstdk+6(2) '.'
                      VBAK-bstdk+4(2) '.'
                      VBAK-bstdk+0(4)
                      INTO lv_podate .
          ENDIF.
          CONCATENATE '<td>' lv_podate '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          SHIFT vbap_tmp-matnr LEFT DELETING LEADING '0'.
          CONCATENATE '<td>' vbap_tmp-matnr '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          CONCATENATE '<td>' vbap_tmp-arktx '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          lv_quantity = vbap_tmp-KWMENG.
          CONCATENATE '<td>' lv_quantity '</td>' INTO LW_OBJTXT-LINE.
          APPEND LW_OBJTXT TO IT_OBJTXT.
          CLEAR: lv_sodate,lv_podate,lv_quantity,lv_kunnr.
          ENDIF.
        ENDLOOP.

        LW_OBJTXT-LINE = '</tbody> </table>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<br><br>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '<br><br>'.
        APPEND LW_OBJTXT TO IT_OBJTXT.
        LW_OBJTXT-LINE = '                 ** This is an Auto-generated mail. Please do not reply **'.
        APPEND LW_OBJTXT TO IT_OBJTXT.

        DESCRIBE TABLE IT_OBJTXT LINES LW_LINES.
        READ TABLE IT_OBJTXT      INTO LW_OBJTXT INDEX LW_LINES.
        LW_DOCDATA-DOC_SIZE =
            ( LW_LINES - 1 ) * 255 + STRLEN( LW_OBJTXT ).

        CLEAR LW_OBJPACK-TRANSF_BIN.
        LW_OBJPACK-HEAD_START = 1.
        LW_OBJPACK-HEAD_NUM   = 0.
        LW_OBJPACK-BODY_START = 1.
        LW_OBJPACK-BODY_NUM   = LW_LINES.
        LW_OBJPACK-DOC_TYPE   = GC_HTM.
        APPEND LW_OBJPACK TO IT_OBJPACK.

        SELECT * FROM ZTEXPNOC_EMAIL INTO TABLE lt_ZTEXPNOC_EMAIL.
          LOOP AT lt_ZTEXPNOC_EMAIL INTO ls_ZTEXPNOC_EMAIL.
            LW_RECLIST-RECEIVER = ls_ZTEXPNOC_EMAIL-smtp_addr.
            LW_RECLIST-REC_TYPE = 'U'.
            APPEND LW_RECLIST TO IT_RECLIST.
            CLEAR  LW_RECLIST.
          ENDLOOP.

*         LW_DOCDATA-OBJ_DESCR = 'Export NOC'.
         LW_DOCDATA-OBJ_DESCR = 'Export NOC Manufacturing License- To be Process'.  "New Subjectline added by Madhur on 190924


        CALL FUNCTION 'SO_NEW_DOCUMENT_ATT_SEND_API1'
          EXPORTING
            DOCUMENT_DATA                    = LW_DOCDATA
            PUT_IN_OUTBOX                    = 'X'
            COMMIT_WORK                      = 'X'
*         IMPORTING
*           SENT_TO_ALL                      =
*           NEW_OBJECT_ID                    =
          TABLES
            PACKING_LIST                     = IT_OBJPACK
            OBJECT_HEADER                    = IT_OBJHEAD
*           CONTENTS_BIN                     =
            CONTENTS_TXT                     = IT_OBJTXT
*           CONTENTS_HEX                     =
*           OBJECT_PARA                      =
*           OBJECT_PARB                      =
            RECEIVERS                        = IT_RECLIST
         EXCEPTIONS
            TOO_MANY_RECEIVERS               = 1
            DOCUMENT_NOT_SENT                = 2
            DOCUMENT_TYPE_NOT_EXIST          = 3
            OPERATION_NO_AUTHORIZATION       = 4
            PARAMETER_ERROR                  = 5
            X_ERROR                          = 6
            ENQUEUE_ERROR                    = 7
            OTHERS                           = 8
                  .
        IF SY-SUBRC <> 0.
* MESSAGE ID SY-MSGID TYPE SY-MSGTY NUMBER SY-MSGNO
*         WITH SY-MSGV1 SY-MSGV2 SY-MSGV3 SY-MSGV4.
        ELSE.
          REFRESH: IT_RECLIST,IT_OBJTXT,IT_OBJPACK,IT_OBJHEAD.
          CLEAR: LW_DOCDATA,ls_kna1_name.
        ENDIF.
ENDIF.
"SOC by Madhur on 110824
ENDENHANCEMENT.
