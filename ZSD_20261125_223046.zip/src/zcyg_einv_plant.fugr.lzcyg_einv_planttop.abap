FUNCTION-POOL ZCYG_EINV_PLANT            MESSAGE-ID SV.

* INCLUDE LZCYG_EINV_PLANTD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_EINV_PLANTT00                     . "view rel. data dcl.
