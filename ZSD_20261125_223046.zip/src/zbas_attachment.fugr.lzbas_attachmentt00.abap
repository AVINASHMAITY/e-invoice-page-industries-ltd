*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBAS_ATTACHMENT.................................*
DATA:  BEGIN OF STATUS_ZBAS_ATTACHMENT               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBAS_ATTACHMENT               .
CONTROLS: TCTRL_ZBAS_ATTACHMENT
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBAS_ATTACHMENT               .
TABLES: ZBAS_ATTACHMENT                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
