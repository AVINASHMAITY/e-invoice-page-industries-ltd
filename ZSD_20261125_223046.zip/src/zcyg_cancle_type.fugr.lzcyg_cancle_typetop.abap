FUNCTION-POOL ZCYG_CANCLE_TYPE           MESSAGE-ID SV.

* INCLUDE LZCYG_CANCLE_TYPED...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_CANCLE_TYPET00                    . "view rel. data dcl.
