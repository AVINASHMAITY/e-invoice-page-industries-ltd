class ZBIOICL_SI_CUSTOMER_IN definition
  public
  create public .

public section.

  interfaces ZBIOIII_SI_CUSTOMER_IN .
protected section.
private section.
ENDCLASS.



CLASS ZBIOICL_SI_CUSTOMER_IN IMPLEMENTATION.


    method zbioiii_si_customer_in~si_customer_in.

*  *&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
* Object Name : ZBIOIII_SI_CUSTOMER_IN~SI_CUSTOMER_IN.                         *
* Author/Company Name : Arya/ITZ                               *
* Transport Request :  DR1K944102                                      *
* Creation Date : 15.02.2019                                           *
*&---------------------------------------------------------------------*
*
*&---------------------------------------------------------------------*
* Dependencies *
*&---------------------------------------------------------------------*
* Modification History *
*&---------------------------------------------------------------------*
* Date Programmer Client Ref No. Description Correction *
*                                                                      *
*&---------------------------------------------------------------------*
*                                                                      *
*                                                                      *
*&---------------------------------------------------------------------*

      constants: gc_three type string          value '3',
                 gc_1102  type string          value '1102'.
      types:begin of tp_kna1,
              kunnr type kunnr,
              land1 type land1_gp,
              name1 type name1_gp,
              name2 type name2_gp,
              regio type regio,
              telf1 type telf1,
              adrnr type adrnr,
              erdat type erdat_rf,
            end of tp_kna1,

            begin of tp_knvv,
              kunnr type kunnr,
              vkorg type vkorg,
              spart type spart,
              erdat type erdat,
              bzirk type bzirk,
            end of tp_knvv,

            begin of tp_j_1imocust,
              kunnr     type kunnr,
              j_1ilstno type j_1ilstno,
            end of tp_j_1imocust,

            begin of tp_adrc,
              addrnumber type ad_addrnum,
              street     type ad_street,
              str_suppl1 type ad_strspp1,
              str_suppl2 type ad_strspp2,
              str_suppl3 type ad_strspp3,
              city1      type ad_city1,
              post_code1 type ad_pstcd1,
            end of tp_adrc,

            begin of tp_t005u,
              land1 type land1,
              bland type regio,
              bezei type bezei20,
            end of tp_t005u,
            begin of tp_adr2,
              addrnumber type ad_addrnum,
              persnumber type ad_persnum,
              telnr_long type ad_telnrlg,
              r3_user    type ad_flgmob,
            end of tp_adr2,

            begin of tp_knvk,
              kunnr type kunnr,
              prsnr type ad_persnum,
            end of tp_knvk,

            begin of tp_adr6,
              addrnumber type ad_addrnum,
              persnumber type ad_persnum,
              smtp_addr  type ad_smtpadr,
            end of tp_adr6,

            begin of tp_tspat,
              spart type spart,
              vtext type vtxtk,
            end of tp_tspat,
            begin of tp_t171,
              bzirk type bzirk,
              bztxt type bztxt,
            end of tp_t171.

      data : gt_kna1       type standard table of tp_kna1,
             gt_knvv       type standard table of tp_knvv,
             gt_j_1imocust type standard table of tp_j_1imocust,
             gt_adrc       type standard table of tp_adrc,
             gt_adr2       type standard table of tp_adr2,
             gt_knvk       type standard table of tp_knvk,
             gt_adr6       type standard table of tp_adr6,
             gt_final      type standard table of zbioidt_customer_data_res_reco,
             gt_t005u      type standard table of tp_t005u,
             gt_tspat      type standard table of tp_tspat,
             gt_t171       type standard table of tp_t171.
      data : lv_space(2)      type c value '``'.
      data : gw_kna1       type tp_kna1,
             gw_knvv       type tp_knvv,
             gw_j_1imocust type tp_j_1imocust,
             gw_adrc       type tp_adrc,
             gw_adr2       type tp_adr2,
             gw_knvk       type tp_knvk,
             gw_adr6       type tp_adr6,
             gw_final      like line of gt_final,
             gw_t005u      type tp_t005u,
             gw_tspat      type tp_tspat,
             gw_t171       type tp_t171.

      data: gv_email    type ad_smtpadr,
            gv_name     type char75,
            gv_address  type char120,
            gv_sy_datum type sy-datum,
            gv_sy_date  type sy-datum
            .

      gv_sy_datum       = sy-datum.
      gv_sy_date        = gv_sy_datum - 1.

      select kunnr                         " Get customer, customer name
      land1                                "  land, region, telephone
      name1                                " address number based on yesterdays date
      name2
      regio
      telf1
      adrnr
      erdat
      from kna1 into table
      gt_kna1 where erdat = gv_sy_date.

      if gt_kna1[] is not initial.

        select kunnr                             " Get division and sales distribution
        vkorg                             " based on compay code as 1102 and customer number
        spart
        erdat
        bzirk
        from knvv into table
        gt_knvv for all entries in gt_kna1
        where kunnr = gt_kna1-kunnr
        and   vkorg = gc_1102
        and   erdat = gt_kna1-erdat.

        if gt_knvv[] is not initial.               " Added by khurshida on 5/26/2016 DR1K926686

          select spart                            " Get Division description based on division
          vtext
          from tspat into table
          gt_tspat for all entries in
          gt_knvv where spart = gt_knvv-spart.
          select bzirk
          bztxt
          from t171t into table
          gt_t171 for all entries in
          gt_knvv where bzirk = gt_knvv-bzirk.
        endif.

        select kunnr                             " get registration number based on customeer number
        j_1ilstno
        from j_1imocust into table
        gt_j_1imocust for all entries in gt_kna1
        where kunnr = gt_kna1-kunnr.

        select addrnumber                        " get address,city and pin based on address number
        street
        str_suppl1
        str_suppl2
        str_suppl3
        city1
        post_code1
        from adrc into table
        gt_adrc for all entries in gt_kna1
        where addrnumber = gt_kna1-adrnr.

        select kunnr                            " get person number based on customer number
        prsnr
        from knvk into table
        gt_knvk for all entries in gt_kna1
        where kunnr = gt_kna1-kunnr.

        if gt_knvk[] is not initial.

          select addrnumber                     " get mobile number based on indicator as 3
          persnumber                     " and person number
          telnr_long
          r3_user
          from adr2 into table
          gt_adr2 for all entries in gt_knvk
          where persnumber = gt_knvk-prsnr
          and   r3_user    = gc_three.

          select addrnumber                     " get email id based on person number
          persnumber
          smtp_addr
          from adr6 into table
          gt_adr6 for all entries in gt_knvk
          where persnumber = gt_knvk-prsnr.

        endif.

        select land1                                 " get state name based on land and regio
        bland
        bezei
        from t005u into table gt_t005u
        for all entries in gt_kna1
        where land1 = gt_kna1-land1
        and   bland = gt_kna1-regio.

        sort gt_knvv by kunnr.
        sort gt_j_1imocust by kunnr.
        sort gt_adrc by addrnumber.
        sort gt_knvk by kunnr.
        sort gt_t005u by land1.
        sort gt_adr2 by persnumber.
        sort gt_adr6 by persnumber.
      endif.
      loop at gt_kna1 into gw_kna1.

        read table gt_knvv into gw_knvv
        with key kunnr = gw_kna1-kunnr
        vkorg = gc_1102
        erdat = gw_kna1-erdat.

        if gw_knvv-vkorg = gc_1102.
          if gw_knvv is not initial.
            read table gt_t171 into gw_t171 with key bzirk = gw_knvv-bzirk.
*      gw_final-bzirk = gw_knvv-bzirk.                  " Biocon HQ (sales distribution)
            gw_final-bztxt = gw_t171-bztxt. " Biocon HQ (sales distribution)

            read table gt_tspat into gw_tspat
            with key spart = gw_knvv-spart.

            if gw_tspat is not initial.

              gw_final-spart = gw_tspat-vtext.                    " BU (Division)
              translate  gw_final-spart to upper case.

              concatenate 'BF' gw_final-spart into
              gw_final-spart separated by ''.

              translate gw_final-spart using ', '.
            endif.
          endif.

          gw_final-kunnr = gw_kna1-kunnr.                    " Legacy code(customer number)

          concatenate gw_kna1-name1 gw_kna1-name2 into
          gv_name separated by space.

          replace all occurrences of ',' in gv_name with space.

          gw_final-name  = gv_name.  " Stokist name(customer name)

          gw_final-telf1 = gw_kna1-telf1.                    " Telephone number

          read table gt_j_1imocust into gw_j_1imocust
          with key  kunnr = gw_kna1-kunnr.

          if gw_j_1imocust is not initial.

            gw_final-j_1ilstno = gw_j_1imocust-j_1ilstno.   " Registration number

          endif.

          read table gt_t005u into gw_t005u
          with key land1 = gw_kna1-land1
          bland = gw_kna1-regio.
          if gw_t005u is not initial.

            gw_final-state = gw_t005u-bezei.               " State

          endif.

          read table gt_adrc into gw_adrc
          with key addrnumber = gw_kna1-adrnr.

          if gw_adrc is not initial.

            replace all occurrences of ',' in gw_adrc-street with space.
            replace all occurrences of ',' in gw_adrc-str_suppl1 with space.
            replace all occurrences of ',' in gw_adrc-str_suppl2 with space.
            replace all occurrences of ',' in gw_adrc-str_suppl3 with space.

            concatenate  gw_adrc-street
            gw_adrc-str_suppl1
            gw_adrc-str_suppl2
            gw_adrc-str_suppl3
            into gv_address separated by space.
            gw_final-address = gv_address.                   " Address

            gw_final-city    = gw_adrc-city1.                " City

            gw_final-pin     = gw_adrc-post_code1.           " State

          endif.

          read table gt_knvk into gw_knvk
          with key kunnr = gw_kna1-kunnr.

          if gw_knvk is not initial.

            read table gt_adr2 into gw_adr2
            with key persnumber = gw_knvk-prsnr
            r3_user    = gc_three.
            if gw_adr2 is not initial.

              gw_final-mobile = gw_adr2-telnr_long.

            endif.

            read table gt_adr6 into gw_adr6
            with key persnumber = gw_knvk-prsnr.

            if gw_adr6 is not initial.

              gw_final-email = gw_adr6-smtp_addr.
              " Email address
            endif.
          endif.
**        if gw_final-bztxt = ''.
**          gw_final-bztxt = lv_space.
**        endif.
**        if gw_final-kunnr = ''.
**          gw_final-kunnr = ' '.
**        endif.
**        if  gw_final-name = ''.
**          gw_final-name = ' '.
**        endif.
**        if  gw_final-telf1 = ''.
**          gw_final-telf1 = ' '.
**        endif.
**        if gw_final-j_1ilstno = ''.
**          gw_final-j_1ilstno = ' '.
**        endif.
**        if gw_final-state = ''.
**          gw_final-state = ' '.
**        endif.
**        if gw_final-address = ''.
**          gw_final-address = ' '.
**        endif.
**        if gw_final-city is initial.
**          gw_final-city = '``'.
**        endif.
**        if gw_final-pin = ''.
**          gw_final-pin = '  '.
**        endif.
**        if gw_final-mobile = ''.
**          gw_final-mobile = '  '.
**        endif.
**        if gw_final-email = ''.
**          gw_final-email = '  '.
**        endif.
**        if gw_final-spart = ''.
**          gw_final-spart = '  '.
**        endif.
****        if gw_final-class is initial.
****          gw_final-class = lv_space."'``'.
****        endif.
**        if gw_final-contactperson  = ''.
**          gw_final-contactperson = '  '.
**        endif.

          gw_final-date = sy-datum.
          gw_final-status =  'S'.
          gw_final-message = 'Success'.
          append gw_final to gt_final.
          clear:gw_final,gw_knvv,gw_j_1imocust,
          gw_adrc,gw_adr2,gw_adr6,gw_knvk,
          gw_t005u,gv_email,gv_address,gv_name,
          gw_tspat.
        endif.

      endloop.
      if gt_final[] is not initial.
        sort gt_final by spart  bztxt  kunnr.
        move-corresponding gt_final to  output-mt_customer_res-records.
      endif.

    endmethod.
ENDCLASS.
