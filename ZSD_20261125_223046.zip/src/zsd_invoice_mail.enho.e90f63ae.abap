"Name: \PR:SAPLV60A\EX:RV_INVOICE_DOCUMENT_ADD_32\EN:OIC_SDP_SAPLV60A\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_INVOICE_MAIL.
*
*  DATA: wa_versions TYPE bapimedcm.
*DATA: t_objpack       TYPE STANDARD TABLE OF sopcklsti1,
*      w_objpack       TYPE sopcklsti1,
*      t_objhead       TYPE STANDARD TABLE OF solisti1,
*      w_objhead       TYPE solisti1,
*      t_objbin        TYPE STANDARD TABLE OF solisti1,
*      w_objbin        TYPE solisti1,
*      t_objtxt        TYPE STANDARD TABLE OF solisti1,
*      w_objtxt        TYPE solisti1,
*      t_reclist       TYPE STANDARD TABLE OF somlreci1,
*      w_reclist       TYPE somlreci1,
*      doc_chng        TYPE sodocchgi1,
*      tab_lines       TYPE sy-tabix,
*      wa_TVSBT        TYPE TVSBT,
*      it_mail         TYPE STANDARD TABLE OF zinv_mail,
*      wa_mail         TYPE zinv_mail.
*
* TYPES : BEGIN OF ty_mara,
*         matnr TYPE mara-matnr,
*         raube TYPE mara-raube,
*         tempb TYPE mara-tempb,
*   END OF ty_mara.
*
*   data: wa_mara TYPE ty_mara.
*
* w_objtxt-line = '<HTML><BODY>'.
*    APPEND w_objtxt TO t_objtxt.
*    CLEAR:w_objtxt.
*    CONCATENATE 'Dear Sir/Madam' ','
*    INTO w_objtxt SEPARATED BY ' '.
*    APPEND w_objtxt TO t_objtxt.
*    CLEAR:w_objtxt.
*    w_objtxt = '<br>  <br/>'.
*    APPEND w_objtxt TO t_objtxt.
*    CLEAR:w_objtxt.
*    CONCATENATE 'The invoice number' xvbrk-vbeln 'is created with below parameters'
*    INTO w_objtxt-line SEPARATED BY ' '.
*    APPEND w_objtxt TO t_objtxt.
*    CLEAR:w_objtxt.
*    w_objtxt = '<br>  <br/>'.
*    APPEND w_objtxt TO t_objtxt.
*    CLEAR:w_objtxt.
*    w_objtxt = 'This is system-generated mail. Kindly do not reply.'.
*    APPEND w_objtxt TO t_objtxt.
*
*    CLEAR:w_objtxt.
*    w_objtxt = '<p>  </p>'.
*    APPEND w_objtxt TO t_objtxt.
*    CLEAR:w_objtxt.
*    w_objtxt = '<table border=1 cellspacing=0 cellpadding=0>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<tr>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<th>Item Number</th>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<th>Material code</th>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<th>Material Description</th>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<th>Shipping condition description</th>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<th>Temperature Conditions</th>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '<th>Storage Conditions</th>'.
*    APPEND w_objtxt TO t_objtxt.
*    w_objtxt-line = '</tr>'.
*    APPEND w_objtxt TO t_objtxt.
*
*    SELECT SINGLE * FROM TVSBT INTO wa_TVSBT WHERE vsbed = xvbrk-vsbed.
*    LOOP at xvbrp .
*
*      SELECT SINGLE
*             matnr
*             raube
*             tempb
*         from mara
*         INTO wa_mara
*         WHERE matnr = xvbrp-matnr.
*
*      CLEAR: w_objtxt.
*      w_objtxt-line = '<tr>'.
*      APPEND w_objtxt TO t_objtxt.
**     Item no
*
*     CONCATENATE '<td align="center">' xvbrp-posnr '</td>' INTO w_objtxt-line.
*     APPEND w_objtxt TO t_objtxt.
*
*      CONCATENATE '<td align="center">' xvbrp-matnr '</td>' INTO w_objtxt-line.
*      APPEND w_objtxt TO t_objtxt.
*
*    CONCATENATE '<td align="center">' xvbrp-arktx '</td>' INTO w_objtxt-line.
*    APPEND w_objtxt TO t_objtxt.
*
*      CONCATENATE '<td align="center">' wa_tvsbt-vtext '</td>' INTO w_objtxt-line.
*      APPEND w_objtxt TO t_objtxt.
*
*if wa_mara-raube is not INITIAL.
*
*       CONCATENATE '<td align="center">' wa_mara-raube '</td>' INTO w_objtxt-line.
*      APPEND w_objtxt TO t_objtxt.
*
*      else.
*      CONCATENATE '<td align="center">' '' '</td>' INTO w_objtxt-line.
*      APPEND w_objtxt TO t_objtxt.
*       endif.
*
*if wa_mara-tempb is not INITIAL.
*       CONCATENATE '<td align="center">' wa_mara-tempb '</td>' INTO w_objtxt-line.
*      APPEND w_objtxt TO t_objtxt.
*
*      else.
*CONCATENATE '<td align="center">' '' '</td>' INTO w_objtxt-line.
*      APPEND w_objtxt TO t_objtxt.
*       endif.
*    ENDLOOP.
*
*           IF sy-subrc EQ 0.
*      CLEAR:w_objtxt.
*      w_objtxt = '</table>'.
*      APPEND w_objtxt TO t_objtxt.
***********************************************************************
*      w_objtxt-line = '</BODY></HTML>'.
*      APPEND w_objtxt TO t_objtxt.
*
*      DESCRIBE TABLE t_objtxt LINES tab_lines.
*      CLEAR:w_objtxt.
*      READ TABLE t_objtxt INTO w_objtxt INDEX tab_lines.
*      doc_chng-doc_size = ( tab_lines - 1 ) * 255 + strlen( w_objtxt ).
** Creating the entry for the compressed document
*      CLEAR w_objpack-transf_bin.
*      w_objpack-head_start = 1.
*      w_objpack-head_num   = 0.
*      w_objpack-body_start = 1.
*      w_objpack-body_num   = tab_lines.
*      w_objpack-doc_type   = 'HTML'.
*      APPEND w_objpack TO t_objpack.
*
*  doc_chng-obj_name = 'Invoicemail'.
*      CONCATENATE 'Invoice line item mail' ''
*      INTO doc_chng-obj_descr .
*
*  SELECT * FROM zinv_mail INTO TABLE it_mail.
*
*    LOOP at it_mail INTO wa_mail.
*      w_reclist-receiver =  wa_mail-email.
*      w_reclist-rec_type =  'U'.
*      APPEND w_reclist TO t_reclist.
*      CLEAR  w_reclist.
*ENDLOOP.
*
* IF t_reclist[] IS NOT INITIAL.
*        CALL FUNCTION 'SO_NEW_DOCUMENT_ATT_SEND_API1'
*          EXPORTING
*            document_data              = doc_chng
*            put_in_outbox              = 'X'
*            commit_work                = 'X'
*          TABLES
*            packing_list               = t_objpack
*            object_header              = t_objhead
*            contents_bin               = t_objbin
*            contents_txt               = t_objtxt
*            receivers                  = t_reclist
*          EXCEPTIONS
*            too_many_receivers         = 1
*            document_not_sent          = 2
*            document_type_not_exist    = 3
*            operation_no_authorization = 4
*            parameter_error            = 5
*            x_error                    = 6
*            enqueue_error              = 7
*            OTHERS                     = 8.
*        IF sy-subrc NE 0.
**    MESSAGE 'Error while mailing' TYPE 'E'.
*        ENDIF.
**    SUBMIT rsconn01 USING SELECTION-SET 'SAP&CONNECTINT'  AND RETURN.
*      ENDIF.
*    ENDIF.
*    CLEAR : doc_chng.
*    REFRESH : t_objpack, t_objhead, t_objbin, t_objtxt, t_reclist.
ENDENHANCEMENT.
