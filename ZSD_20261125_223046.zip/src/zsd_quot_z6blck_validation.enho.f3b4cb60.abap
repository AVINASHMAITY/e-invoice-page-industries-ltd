"Name: \PR:SAPMV45A\EX:FCODE_BEARBEITEN_01\EI
ENHANCEMENT 0 ZSD_QUOT_Z6BLCK_VALIDATION.
***********Code Starts by Bhagavan on 10/11/2021 "DR1K961678*******************************
*    BREAK Abap_bhagwan.
    DATA : lv_lifsp TYPE vbep-lifsp,
          lv_vbak TYPE vbak.
*    SELECT SINGLE * FROM vbak INTO lv_vbak WHERE vbeln = CVBPA-vbeln AND ERNAM = sy-uname.
*    IF sy-subrc = 0 .
*      MESSAGE 'Creator cannot Authorized to SO ' TYPE 'E'.
*    ENDIF.
    CLEAR :lv_lifsp.
    SELECT SINGLE lifsp FROM VBEP INTO lv_lifsp  WHERE vbeln = CVBPA-vbeln.
    IF sy-subrc = 0  AND lv_lifsp = 'Z6'.
      MESSAGE 'Quotation Z6 Block ' TYPE 'E'." DISPLAY LIKE 'E'.
    ENDIF.
*     *********Added by Megha on 02.24.2025
DATA : LT_DATA TYPE TABLE OF ZTABAP_TVARVC,
*       LR_OBJ  TYPE RANGE OF STRING,
*       LW_OBJ LIKE LINE OF LR_OBJ,
       lv_line TYPE i.


*LW_OBJ-low = 'ZSD_COMMIT_DATE'.
*LW_OBJ-option = 'EQ'.
*LW_OBJ-SIGN = 'I'.
*APPEND LW_OBJ TO LR_OBJ.


IF sy-ucomm EQ 'SICH' OR sy-ucomm EQ 'YES' AND sy-tcode eq 'VA01'.

  SELECT obj_name
       low
  FROM ZTABAP_TVARVC
  INTO CORRESPONDING FIELDS OF TABLE lt_data
  WHERE OBJ_NAME EQ 'ZSD_COMMIT_DATE'
  AND low IN ( VBAK-VKORG, VBAK-AUART ).

 IF sy-subrc eq 0.
  DESCRIBE TABLE lt_data LINES lv_line.

IF lv_line GT 1.
LOOP AT  XVBAP INTO DATA(WA_WVBAP).
          IF WA_WVBAP-COMMIT_DATE IS INITIAL.
            MESSAGE 'Please Enter Committed Date' TYPE 'E'.
            ELSEIF WA_WVBAP-COMMIT_DATE LT VBAK-ERDAT.
       MESSAGE 'Committed date is less than SO creation date' TYPE 'E'.
          ENDIF.
        ENDLOOP.
ENDIF.
ENDIF.

data: lt_tline type table of tline.

if vbkd-bstdk is not INITIAL.

**FIELD-SYMBOLS: <ltfs_tline> TYPE ANY table.
**
**DATA: lv_fs_name(30) VALUE '(SAPLV70T)TLINETAB[]'.
**
**ASSIGN (lv_fs_name) TO <ltfs_tline>.
**
**if <ltfs_tline> is ASSIGNED.
**  lt_tline = <ltfs_tline>.
**endif.

*DATA CLIENT           TYPE SY-MANDT.
*DATA ID               TYPE THEAD-TDID.
*DATA LANGUAGE         TYPE THEAD-TDSPRAS.
*DATA NAME             TYPE THEAD-TDNAME.
*DATA OBJECT           TYPE THEAD-TDOBJECT.
*DATA ARCHIVE_HANDLE   TYPE SY-TABIX.
*DATA HEADER           TYPE THEAD.
*DATA OLD_LINE_COUNTER TYPE THEAD-TDTXTLINES.
*DATA LINES            TYPE STANDARD TABLE OF TLINE.


 data: lt_tlines type table of TLINE.

**
**CALL FUNCTION 'READ_TEXT'
**    EXPORTING
***     CLIENT                        = SY-MANDT
**      id                            = 'Z002'
**      language                      = sy-langu
**      name                          = 'XXXXXXXXXX'
**      object                        = 'VBBK'
***     ARCHIVE_HANDLE                = 0
***     LOCAL_CAT                     = ' '
***   IMPORTING
***     HEADER                        = HEADER
***     OLD_LINE_COUNTER              = OLD_LINE_COUNTER
**    TABLES
**      lines                         = lt_tlines
**   EXCEPTIONS
**     ID                            = 1
**     LANGUAGE                      = 2
**     NAME                          = 3
**     NOT_FOUND                     = 4
**     OBJECT                        = 5
**     REFERENCE_CHECK               = 6
**     WRONG_ACCESS_TO_ARCHIVE       = 7
**            .
**
**IF lt_tlines IS NOT INITIAL.
SELECT obj_name
       low
  FROM ZTABAP_TVARVC
  INTO CORRESPONDING FIELDS OF TABLE lt_data
  WHERE OBJ_NAME EQ 'ZSD_PO_DATE'
  AND low EQ VBAK-VKORG.

    IF sy-subrc eq 0.
     DATA(LV_PO_DATE_CHECK) = SY-DATUM - VBKD-BSTDK.
     IF LV_PO_DATE_CHECK GT 2.
      MESSAGE 'Creation date is more than the PO date' TYPE 'I'.
     ENDIF.
    ENDIF.

    endif.
**  endif.

ENDIF.

*********Added by Megha on 02.24.2025
*



**********Code Ends by Bhagavan on 10/11/2021 "DR1K961678*******************************
ENDENHANCEMENT.
