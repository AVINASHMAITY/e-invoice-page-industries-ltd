FUNCTION-POOL ZCYG_UNIT_MASTER           MESSAGE-ID SV.

* INCLUDE LZCYG_UNIT_MASTERD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_UNIT_MASTERT00                    . "view rel. data dcl.
