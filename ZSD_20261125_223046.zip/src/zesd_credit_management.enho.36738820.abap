"Name: \PR:SAPLVKMP\FO:SYSTEM_REACTION\SE:END\EI
ENHANCEMENT 0 ZESD_CREDIT_MANAGEMENT.
*&---------------------------------------------------------------------*
*& Implicit Enhancement
************************************************************************
* Object Name             : ZESD_CREDIT_MANAGEMENT
* Author/Company Name     : Magam Sai Sudarshan
* Functional Consultant   : Ramesh
* Transport Request       : DR1K937380, DR1K938518
* Creation Date           : 06 DEC 2017
************************************************************************
* Description: Validation should Trigger if the Credit limit Exceeds while
*              creating SO / Changing SO                              *
************************************************************************
* Dependencies *
************************************************************************
* Modification History *
************************************************************************
* Date       Programmer           Correction                           *
* Description:
************************************************************************

**CONSTANTS: lc_5001 TYPE kkber VALUE '5001'.
**DATA lv_per TYPE vbkred-klprz. " DR1K938518
**
**IF t691f-kkber EQ lc_5001.
**IF t691f-strea CA con_warning     AND us_warning_to_error EQ space
**OR   ( t691f-strea CA con_error   AND us_error_to_warning EQ true )
**OR   ( rc_check    NE con_rc_ok   AND us_error_to_warning EQ true )
**OR   ( t691f-kkber EQ lc_5001     AND t691f-cmpaa EQ true ).
**
*** Begin of Code Added by SAISMA on 05 FEB 2018 TR DR1K938518
**  CLEAR lv_per.
**  CALL FUNCTION 'CREDIT_LIMIT_USED_PRECENTAGE'
**    EXPORTING
**      kkber = knkk-kkber
**      knkli = knkk-knkli
**    IMPORTING
**      klprz = lv_per.
**
**  IF lv_per GE '100' AND lv_per NE '999'.
*** End of Code Added by SAISMA on 05 FEB 2018 TR DR1K938518
***     warning static credit check
**    CLEAR reaction_warning.
**    IF reaction_warning NE true.
**      reaction_warning = true.
**
**      IF us_no_warning NE true.
**        IF t691f-strea CA con_message_without.
**
**          IF da_no_dialog IS INITIAL OR
**             call_activity EQ gc_activity_lord.
**            MESSAGE e150 WITH space space credit_check
**                         RAISING error.
**
**            message_collect_lord.
**          ENDIF.
**
**        ELSE.
**          IF da_no_dialog IS INITIAL OR
**             call_activity EQ gc_activity_lord.
**            MESSAGE e150 WITH space space credit_check
**                         RAISING error.
**
**            message_collect_lord.
**          ENDIF.
**        ENDIF.
**      ENDIF.
**    ENDIF.
**  ENDIF. " DR1K938518
**ENDIF.
**ENDIF.
ENDENHANCEMENT.
