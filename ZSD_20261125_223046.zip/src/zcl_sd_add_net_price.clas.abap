class ZCL_SD_ADD_NET_PRICE definition
  public
  final
  create public .

public section.

  class-data NETWR type NETWR .
protected section.
private section.
ENDCLASS.



CLASS ZCL_SD_ADD_NET_PRICE IMPLEMENTATION.
ENDCLASS.
