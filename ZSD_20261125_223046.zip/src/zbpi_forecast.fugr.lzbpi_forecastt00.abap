*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBPI_FORECAST...................................*
DATA:  BEGIN OF STATUS_ZBPI_FORECAST                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBPI_FORECAST                 .
CONTROLS: TCTRL_ZBPI_FORECAST
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBPI_FORECAST                 .
TABLES: ZBPI_FORECAST                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
