*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZEM_COUNTRIESTOP.                 " Global Data
  INCLUDE LZEM_COUNTRIESUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZEM_COUNTRIESF...                 " Subroutines
* INCLUDE LZEM_COUNTRIESO...                 " PBO-Modules
* INCLUDE LZEM_COUNTRIESI...                 " PAI-Modules
* INCLUDE LZEM_COUNTRIESE...                 " Events
* INCLUDE LZEM_COUNTRIESP...                 " Local class implement.
* INCLUDE LZEM_COUNTRIEST99.                 " ABAP Unit tests
  INCLUDE LZEM_COUNTRIESF00                       . " subprograms
  INCLUDE LZEM_COUNTRIESI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
