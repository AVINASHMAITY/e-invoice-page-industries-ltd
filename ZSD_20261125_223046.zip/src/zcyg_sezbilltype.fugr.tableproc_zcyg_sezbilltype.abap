*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZCYG_SEZBILLTYPE
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZCYG_SEZBILLTYPE    .

  PERFORM TABLEPROC.

ENDFUNCTION.
