*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZEI_NEW_APITOP.                   " Global Data
  INCLUDE LZEI_NEW_APIUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZEI_NEW_APIF...                   " Subroutines
* INCLUDE LZEI_NEW_APIO...                   " PBO-Modules
* INCLUDE LZEI_NEW_APII...                   " PAI-Modules
* INCLUDE LZEI_NEW_APIE...                   " Events
* INCLUDE LZEI_NEW_APIP...                   " Local class implement.
* INCLUDE LZEI_NEW_APIT99.                   " ABAP Unit tests
  INCLUDE LZEI_NEW_APIF00                         . " subprograms
  INCLUDE LZEI_NEW_APII00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
