FUNCTION-POOL ZFGSD_FNOTE_TEXT           MESSAGE-ID SV.

* INCLUDE LZFGSD_FNOTE_TEXTD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFGSD_FNOTE_TEXTT00                    . "view rel. data dcl.
