class ZCO_EI_GET_DATA_REF_PIPO_SYN_O definition
  public
  inheriting from CL_PROXY_CLIENT
  create public .

public section.

  methods CONSTRUCTOR
    importing
      !LOGICAL_PORT_NAME type PRX_LOGICAL_PORT_NAME optional
    raising
      CX_AI_SYSTEM_FAULT .
  methods EI_GET_DATA_REF_PIPO_SYN_OUT_S
    importing
      !OUTPUT type ZEI_GET_DATA_REF_PIPO_REQ_MT
    exporting
      !INPUT type ZEI_SAPGET_DATA_REF_PIPO_RES12
    raising
      CX_AI_SYSTEM_FAULT .
protected section.
private section.
ENDCLASS.



CLASS ZCO_EI_GET_DATA_REF_PIPO_SYN_O IMPLEMENTATION.


  method CONSTRUCTOR.

  super->constructor(
    class_name          = 'ZCO_EI_GET_DATA_REF_PIPO_SYN_O'
    logical_port_name   = logical_port_name
  ).

  endmethod.


  method EI_GET_DATA_REF_PIPO_SYN_OUT_S.

  data:
    ls_parmbind type abap_parmbind,
    lt_parmbind type abap_parmbind_tab.

  ls_parmbind-name = 'OUTPUT'.
  ls_parmbind-kind = cl_abap_objectdescr=>importing.
  get reference of OUTPUT into ls_parmbind-value.
  insert ls_parmbind into table lt_parmbind.

  ls_parmbind-name = 'INPUT'.
  ls_parmbind-kind = cl_abap_objectdescr=>exporting.
  get reference of INPUT into ls_parmbind-value.
  insert ls_parmbind into table lt_parmbind.

  if_proxy_client~execute(
    exporting
      method_name = 'EI_GET_DATA_REF_PIPO_SYN_OUT_S'
    changing
      parmbind_tab = lt_parmbind
  ).

  endmethod.
ENDCLASS.
