*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_EINV_PLANTTOP.               " Global Data
  INCLUDE LZCYG_EINV_PLANTUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_EINV_PLANTF...               " Subroutines
* INCLUDE LZCYG_EINV_PLANTO...               " PBO-Modules
* INCLUDE LZCYG_EINV_PLANTI...               " PAI-Modules
* INCLUDE LZCYG_EINV_PLANTE...               " Events
* INCLUDE LZCYG_EINV_PLANTP...               " Local class implement.
* INCLUDE LZCYG_EINV_PLANTT99.               " ABAP Unit tests
  INCLUDE LZCYG_EINV_PLANTF00                     . " subprograms
  INCLUDE LZCYG_EINV_PLANTI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
