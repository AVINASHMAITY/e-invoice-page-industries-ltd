"Name: \PR:SAPLV05H\FO:READ_VKDFS_VKDFI_VF_01\SE:END\EI
ENHANCEMENT 0 ZIUT_INVOICE1.

types: BEGIN OF ty_lut,
      vbeln type VBELN_VL,
      vkorg type vkorg, " 'vkorg' added by Samata P/Iteanz 07.03.2022
      lland type lland, " 'lland' added by Samata P/Iteanz 09.03.2022
      lfart type lfart,
      frm_plnt type werks_d,
      to_plnt type werks_d,
      kunnr type kunnr,
      matnr type matnr,
      fkdat type fkdat,
       end of ty_lut,
       tt_lut type STANDARD TABLE OF ty_lut with EMPTY KEY,
       BEGIN OF ty_lut_check,
       vbeln type VBELN_VL,
       vkorg type vkorg, " 'vkorg' added by Samata P/Iteanz 07.03.2022
       lland type lland, " 'lland' added by Samata P/Iteanz 09.03.2022
       lfart type lfart,
       from_plant type AD_SORT2,
       to_plant type AD_SORT2,
       biz_pl type char10,
       end of ty_lut_check.
       data: lt_lut_check type TABLE OF ty_lut_check,
             LT_PLANT TYPE TABLE OF ZTSD_PLANT.
       SELECT * FROM ZTSD_PLANT INTO TABLE LT_PLANT.
if not LVKDFI is initial.
SELECT a~vbeln, a~vkorg, a~fkdat, a~lland, b~lfart, c~werks, c~matnr, d~kunnr from VKDFS as a
  INNER JOIN likp as b
  on a~vbeln eq b~vbeln
  INNER JOIN lips as c
  on a~vbeln eq c~vbeln
  INNER JOIN likp as d
  on a~vbeln eq d~vbeln

  INTO TABLE @DATA(lt_vbeln)
  FOR ALL ENTRIES IN @LVKDFI
  WHERE a~VBELN eq @LVKDFI-VBELN
    and ( a~VKORG eq '1401' or a~VKORG eq '1101' or a~VKORG eq '1301')  " added 1301 by kiruba DR1K985038
    and a~vtweg eq '60'
    and a~vbtyp eq 'J'
    and ( b~lfart eq 'NL' or b~lfart eq 'NCC3' ). "'NCC3' added by Samata P/Iteanz 07.03.2022
endif.
  IF lt_vbeln is not INITIAL.
    DATA(lt_lut) = VALUE tt_lut( for ls in lt_vbeln ( vbeln = ls-vbeln
                                                       vkorg = ls-vkorg
                                                      lfart = ls-lfart
                                                      lland = ls-lland
                                                       frm_plnt = ls-werks
                                                       to_plnt =  ls-kunnr+6(4)
                                                       kunnr = ls-kunnr
                                                       matnr = ls-matnr
                                                       fkdat = ls-fkdat ) ).
    "'vkorg' , 'lfart' , 'matnr' ,' fkdat' added by Samata P/Iteanz 10.02.2022.
    " 'lland' added by Samata P/Iteanz 09.03.2022
    SELECT a~werks, a~adrnr as frm_addr, a~J_1BBRANCH as frm_bp, c~sort2 as from_plant
  from  ( t001w as a INNER JOIN adrc as c
      on c~ADDRNUMBER  eq a~adrnr )
      into TABLE @data(gt_frm_plnt)
      FOR ALL ENTRIES IN @lt_lut
      where a~werks eq @lt_lut-frm_plnt.
      SELECT b~werks, b~adrnr as to_addr, b~J_1BBRANCH as to_bp, d~sort2 as to_plant
  from  ( t001w as b INNER JOIN adrc as d
      on d~ADDRNUMBER  eq b~adrnr )
      into TABLE @data(gt_to_plnt)
      FOR ALL ENTRIES IN @lt_lut
      where b~werks eq @lt_lut-to_plnt.

   select * from kna1 into table @data(gt_kna1)
    FOR ALL ENTRIES IN @lt_lut
    where kunnr eq @lt_lut-kunnr.
"added by Samata P/Iteanz 10.02.2022

  SELECT * from marc into table @data(gt_marc)
    FOR ALL ENTRIES IN @lt_lut
    WHERE matnr eq @lt_lut-matnr and werks eq @lt_lut-frm_plnt.


 SELECT * from a524 INTO table @data(gt_a524)    "added by kiruba
 FOR ALL ENTRIES IN @lt_lut
   where werks eq @lt_lut-frm_plnt
   and datbi GE @lt_lut-fkdat AND datab LE @lt_lut-fkdat.

*    SELECT * from a524 APPENDING table gt_a524


* BREAK PUSHPA.
"added by kiruba

   SELECT * FROM A610 INTO TABLE @DATA(GT_A610)
      FOR ALL ENTRIES IN @lt_lut
       where werks eq @lt_lut-frm_plnt AND datbi GE @lt_lut-fkdat AND datab LE @lt_lut-fkdat.

        IF  GT_A610 is not INITIAL.
     SELECT * from konp into table @data(gt_konp_1)
       FOR ALL ENTRIES IN @GT_A610
       where knumh eq @GT_A610-knumh.
   ENDIF.
   delete gt_konp_1 where loevm_ko eq 'X'.

        SELECT * FROM A357 INTO TABLE @DATA(GT_A357)
      FOR ALL ENTRIES IN @lt_lut
       where werks eq @lt_lut-frm_plnt AND datbi GE @lt_lut-fkdat AND datab LE @lt_lut-fkdat.

      IF GT_A357 is not INITIAL.
     SELECT * from konp into table @data(gt_konp_2)
       FOR ALL ENTRIES IN @GT_A357
       where knumh eq @GT_A357-knumh.
      ENDIF.
      delete gt_konp_2 where loevm_ko eq 'X'.

" ended by kiruba


   IF  gt_a524 is not INITIAL.
     SELECT * from konp into table @data(gt_konp)
       FOR ALL ENTRIES IN @gt_a524
       where knumh eq @gt_a524-knumh.
   ENDIF.
   delete gt_konp where loevm_ko eq 'X'.
   "ended by Samata P/Iteanz 10.02.2022
  ENDIF.

IF lt_lut IS NOT INITIAL. " ADDED BY KIRUBA

        SELECT VBELN,VGBEL,VGPOS FROM LIPS INTO TABLE @DATA(LT_LIPS_K)
          FOR ALL ENTRIES IN @lt_lut WHERE VBELN = @lt_lut-VBELN.

        IF LT_LIPS_K IS NOT INITIAL.

          SELECT EBELN,EBELP,INCO1,INCO2 FROM EKPO INTO TABLE @DATA(LT_EKPO_K)
            FOR ALL ENTRIES IN @LT_LIPS_K  WHERE EBELN = @LT_LIPS_K-VGBEL. "AND EBELP = @LT_LIPS_K-VGPOS.

          ENDIF.

  ENDIF.

  " CHANGES ENDED BY KIRUBA

*BREAK PUSHPA.
  LOOP AT lt_lut ASSIGNING FIELD-SYMBOL(<fs_lut>).
APPEND INITIAL LINE TO lt_lut_check ASSIGNING FIELD-SYMBOL(<fs_lut_check>).
IF <fs_lut_check> is ASSIGNED .
  <fs_lut_check> = CORRESPONDING #( <fs_lut> ).
  <fs_lut_check>-from_plant = value #( gt_frm_plnt[ werks = <fs_lut>-frm_plnt ]-from_plant OPTIONAL ).
  <fs_lut_check>-to_plant = value #( gt_to_plnt[ werks = <fs_lut>-to_plnt ]-to_plant OPTIONAL ).
* code added by Samata P/Iteanz 09.03.2022
   IF <fs_lut_check>-to_plant is INITIAL.
     <fs_lut_check>-to_plant = <fs_lut>-lland .
  ENDIF.

    DATA(gw_kna1) = VALUE #( gt_kna1[ kunnr = <fs_lut>-kunnr ] OPTIONAL ).
    DATA(gw_marc) = VALUE #( gt_marc[ matnr = <fs_lut>-matnr werks = <fs_lut>-frm_plnt ] OPTIONAL ).
    DATA(gw_a524) = VALUE #( gt_a524[ kappl = 'V' kschl = 'JOI2' aland = 'IN' werks = <fs_lut>-frm_plnt taxk8 = '0'taxm8 ='0' brsch = gw_kna1-brsch steuc = gw_marc-steuc ] OPTIONAL ).
    data(gw_konp) = VALUE #( gt_konp[ knumh = gw_a524-knumh ] OPTIONAL ).

"ADDED BY KIRUBA

    DATA(GW_A610) = VALUE #( GT_A610[ kappl = 'V' kschl = 'ZBCD'  werks = <fs_lut>-frm_plnt brsch = gw_kna1-brsch steuc = gw_marc-steuc ] OPTIONAL ).
    DATA(GW_A610_1) = VALUE #( GT_A610[ kappl = 'V' kschl = 'ZHEA'  werks = <fs_lut>-frm_plnt brsch = gw_kna1-brsch steuc = gw_marc-steuc ] OPTIONAL ).
    DATA(GW_A357) = VALUE #( GT_A357[ kappl = 'V' kschl = 'ZBCD'  werks = <fs_lut>-frm_plnt aland = 'IN' steuc = gw_marc-steuc ] OPTIONAL ).

 data(gw_konp_1) = VALUE #( gt_konp_1[ knumh = GW_A610-knumh ] OPTIONAL ).
 data(gw_konp_2) = VALUE #( gt_konp_1[ knumh = GW_A610_1-knumh ] OPTIONAL ).
 data(gw_konp_3) = VALUE #( gt_konp_2[ knumh = GW_A357-knumh ] OPTIONAL ).

"ENDED BY KIRUBA

*ended by Samata P/Iteanz 09.03.2022
  "'NCC3' added by Samata P/Iteanz 07.03.2022
  if <fs_lut_check>-lfart = 'NCC3'.
    <fs_lut_check>-biz_pl = ' '.
  endif.
   "ended by Samata P/Iteanz 07.03.2022
*  code added by Samata P/Iteanz 09.03.2022
  if <fs_lut_check>-lfart = 'NCC3' and <fs_lut_check>-from_plant eq 'DTA' AND <fs_lut_check>-to_plant EQ 'MY'.
    IF gw_KONP-knumh is not initial and gw_konp-kbetr GT 0 .
 <fs_lut_check>-biz_pl = 'REBATE'.
    ELSEIF gw_konp-knumh is INITIAL .
      <fs_lut_check>-biz_pl = 'LUT'.
  endif.
   endif.

  " ADDED BY KIRUBA DR1K985038

*  BREAK PUSHPA.

    if <fs_lut_check>-lfart = 'NCC3'.

    IF <fs_lut_check>-from_plant eq 'DTA' AND <fs_lut_check>-to_plant EQ 'DTA'.

    DATA(LW_TT_D) = ( gw_konp_1-kbetr + gw_konp_2-kbetr + gw_konp_3-kbetr ).

    IF LW_TT_D GT 0.
      <fs_lut_check>-biz_pl = 'WITH DUTY'.
      ELSE.
        <fs_lut_check>-biz_pl = 'WITH OUT DUTY'.
        ENDIF.

*        endif.

  ELSEIF <fs_lut_check>-from_plant eq 'SEZ' AND <fs_lut_check>-to_plant EQ 'DTA'.

*      if gw_konp_1 is NOT INITIAL or gw_konp_2 is NOT INITIAL or gw_konp_3 is NOT INITIAL.

    DATA(LW_TT_2) = ( gw_konp_1-kbetr + gw_konp_2-kbetr + gw_konp_3-kbetr ).

    IF LW_TT_2 GT 0.
      <fs_lut_check>-biz_pl = 'WITH DUTY'.
      ELSE.
        <fs_lut_check>-biz_pl = 'WITH OUT DUTY'.
        ENDIF.

*        endif.

  ELSEIF <fs_lut_check>-from_plant eq 'DTA' AND <fs_lut_check>-to_plant EQ 'SEZ'.

    IF gw_KONP-knumh is not initial and gw_konp-kbetr GT 0 .
    <fs_lut_check>-biz_pl = 'REBATE'.
    ELSEIF gw_konp-knumh is INITIAL OR gw_konp-kbetr is initial. " added by kiruba

    READ TABLE lt_lut_check into data(ls_che)  WITH KEY vbeln = <FS_LUT>-vbeln.
    IF SY-subrc EQ 0.

        READ TABLE LT_LIPS_K INTO DATA(LS_CK_1) WITH KEY vbeln = <FS_LUT>-vbeln.  " ADDED BY KIRUBA
        IF SY-SUBRC EQ 0.

          READ TABLE LT_EKPO_K INTO DATA(LS_PK_1) WITH KEY EBELN = LS_CK_1-VGBEL EBELP = LS_CK_1-VGPOS.
          IF SY-SUBRC EQ 0.

            IF <fs_lut_check>-LFART EQ 'NCC3'.
              IF ( LS_PK_1-INCO1 EQ 'DAP' OR LS_PK_1-INCO1 EQ 'DAT' ) AND  LS_PK_1-INCO2 EQ 'Bangalore (Free sample)'.
*                   lvkdfi-fkart = 'ZBJS'.
                  <fs_lut_check>-biz_pl = 'LUT'.
                   ELSE.
*                      lvkdfi-fkart = 'ZBWR'.
                      <fs_lut_check>-biz_pl = 'LUT SAMPLE'.
                      ENDIF.

    ENDIF.
    ENDIF.
    ENDIF.
    ENDIF.
    ENDIF.


  ELSEIF <fs_lut_check>-from_plant eq 'SEZ' AND <fs_lut_check>-to_plant EQ 'SEZ'.

*if gw_konp_1 is NOT INITIAL or gw_konp_2 is NOT INITIAL or gw_konp_3 is NOT INITIAL.

    DATA(LW_TT_3) = ( gw_konp_1-kbetr + gw_konp_2-kbetr + gw_konp_3-kbetr ).

    IF LW_TT_3 GT 0.
      <fs_lut_check>-biz_pl = 'WITH DUTY'.
      ELSE.
        <fs_lut_check>-biz_pl = 'WITH OUT DUTY'.
        ENDIF.

*        endif.


  ENDIF.

  endif.

  CLEAR : ls_che,LS_CK_1,LS_PK_1.



  " ENDED BY KIRUBA DR1K985038




  if <fs_lut_check>-lfart = 'NL'.
*     ended by Samata P/Iteanz 09.03.2022
    IF <fs_lut_check>-from_plant eq 'DTA' AND <fs_lut_check>-to_plant EQ 'DTA'.

  <fs_lut_check>-biz_pl = cond #( when VALUE #( gt_frm_plnt[ werks = <fs_lut>-frm_plnt ]-frm_bp OPTIONAL ) eq VALUE #( gt_to_plnt[ werks = <fs_lut>-to_plnt ]-to_Bp OPTIONAL ) then 'SAME' else 'DIFF' ).
  ELSEIF <fs_lut_check>-from_plant eq 'SEZ' AND <fs_lut_check>-to_plant EQ 'DTA'.
    <fs_lut_check>-biz_pl = 'STATE'.
    "added by Samata P/Iteanz 10.02.2022
  ELSEIF <fs_lut_check>-from_plant eq 'DTA' AND <fs_lut_check>-to_plant EQ 'SEZ'. "OR <fs_lut_check>-to_plant EQ 'MY' ).

*commented by  Samata P/Iteanz 09.03.2022
*    DATA(gw_kna1) = VALUE #( gt_kna1[ kunnr = <fs_lut>-kunnr ] OPTIONAL ).
*    DATA(gw_marc) = VALUE #( gt_marc[ matnr = <fs_lut>-matnr werks = <fs_lut>-frm_plnt ] OPTIONAL ).
*    DATA(gw_a524) = VALUE #( gt_a524[ kappl = 'V' kschl = 'JOI2' aland = 'IN' werks = <fs_lut>-frm_plnt taxk8 = '0'taxm8 ='0' brsch = gw_kna1-brsch steuc = gw_marc-steuc ] OPTIONAL ).
*    data(gw_konp) = VALUE #( gt_konp[ knumh = gw_a524-knumh ] OPTIONAL ).

*ended by  Samata P/Iteanz 09.03.2022
    IF gw_KONP-knumh is not initial and gw_konp-kbetr GT 0 .
    <fs_lut_check>-biz_pl = 'REBATE'.
    ELSEIF gw_konp-knumh is INITIAL.
    <fs_lut_check>-biz_pl = 'LUT'.
    ENDIF.
" ended by Samata P/Iteanz 10.02.2022
* Begin of code added by Samata P/Iteanz 19.09.2022 DR1K968659
  ELSEIF <fs_lut_check>-from_plant eq 'SEZ' AND <fs_lut_check>-to_plant EQ 'SEZ'.
   <fs_lut_check>-biz_pl = 'SAME'.
  ENDIF.
*   ended by Samata P/Iteanz 19.09.2022 DR1K968659
  endif.
  UNASSIGN <fs_lut_check>.

ENDIF.
  ENDLOOP.

  LOOP AT LVKDFI.
    READ TABLE lt_lut_check ASSIGNING <fs_lut_check> WITH KEY vbeln = lvkdfi-vbeln.
    IF SY-subrc EQ 0.
      READ TABLE lt_plant ASSIGNING FIELD-SYMBOL(<fs_plant>) with key vkorg = <fs_lut_check>-vkorg
                                                                      LFART = <fs_lut_check>-lfart
                                                                      FROM_PLANT = <fs_lut_check>-from_plant
                                                                      TO_PLANT = <fs_lut_check>-to_plant
                                                                      J_1BBRANCH = <fs_lut_check>-biz_pl. "'vkorg','lfart' added by Samata P/Iteanz 10.02.2022
      IF sy-subrc eq 0.

        READ TABLE LT_LIPS_K INTO DATA(LS_CK) WITH KEY vbeln = lvkdfi-vbeln.  " ADDED BY KIRUBA
        IF SY-SUBRC EQ 0.

          READ TABLE LT_EKPO_K INTO DATA(LS_PK) WITH KEY EBELN = LS_CK-VGBEL EBELP = LS_CK-VGPOS.
          IF SY-SUBRC EQ 0.

           IF LS_PK-INCO2 EQ 'Biocon BL(Free sample)'.
             lvkdfi-fkart = 'YGSS'.
             ELSE.
              lvkdfi-fkart = <fs_plant>-fkart.
            ENDIF.

          ENDIF.

            MODIFY lvkdfi TRANSPORTING fkart.  " CHANGES ENDED BY KIRUBA


*        lvkdfi-fkart = <fs_plant>-fkart.   " COMMENTED BY KIRUBA
*        MODIFY lvkdfi TRANSPORTING fkart.

        "added by Samata P/Iteanz 07.03.2022
      else.
        lvkdfi-fkart = ' ' .
        MODIFY lvkdfi TRANSPORTING fkart.
*
        "ended by Samata P/Iteanz 07.03.2022
      ENDIF.
    ENDIF.
    ENDIF.


    CLEAR : LS_CK,LS_PK. " ADDED BY KIRUBA
  ENDLOOP.
*added by Samata P/Iteanz 09.03.2022
 IF LVKDFI is not initial.
  sort LVKDFI by vbeln fkart DESCENDING.
  delete LVKDFI[] WHERE  fkart = ' ' .
 ENDIF.
* ended by Samata P/Iteanz 09.03.2022
*    LOOP AT LVKDFI INTO DATA(LS_LVKDFI).
*
*      LS_LVKDFI-FKART = 'YBSL'.
*      MODIFY LVKDFI FROM LS_LVKDFI INDEX SY-TABIX TRANSPORTING FKART .
*
*    ENDLOOP.
ENDENHANCEMENT.
