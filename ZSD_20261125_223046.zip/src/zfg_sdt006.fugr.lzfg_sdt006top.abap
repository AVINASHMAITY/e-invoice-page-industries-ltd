FUNCTION-POOL ZFG_SDT006                 MESSAGE-ID SV.

* INCLUDE LZFG_SDT006D...                    " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_SDT006T00                          . "view rel. data dcl.
