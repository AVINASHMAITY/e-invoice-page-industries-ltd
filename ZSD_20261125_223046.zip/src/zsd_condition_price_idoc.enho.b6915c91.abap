"Name: \PR:SAPLVEDA\FO:CHECK_IDOC_SEGMENTS\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_CONDITION_PRICE_IDOC.
*&----------------------------------------------------------------
*Date       : 16.05.2023
*Programmer : Sumit
*TR No.     : DR1K975923
*Description: Enhancment for Populate amount in condition types
*&----------------------------------------------------------------
DATA:lwa_e1edp05 TYPE e1edp05.
DATA:lwa_E1EDP01 TYPE E1EDP01,
     lv_tabix    TYPE sy-tabix.
FIELD-SYMBOLS : <fs_e1edp05> TYPE e1edp05.
*Format issue
DATA : lv_kobtr TYPE kobtr,
       lv_dec  TYPE char16,
       lv_sep  TYPE char1.
WRITE lv_kobtr To  lv_dec.
IF lv_dec cs ','.
lv_sep = ','.
ELSE.
  lv_sep = '.'.
ENDIF.
LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<idoc_data1>) WHERE segnam = 'E1EDP05'.
lwa_e1edp05 = <idoc_data1>-sdata.
IF lwa_e1edp05-kobtr cs ','.
 REPLACE ',' WITH lv_sep INTO lwa_e1edp05-kobtr .
ELSE.
  REPLACE '.' WITH lv_sep INTO lwa_e1edp05-kobtr .
ENDIF.
CONDENSE lwa_e1edp05-kobtr.
<idoc_data1>-sdata = lwa_e1edp05.
CLEAR : lwa_e1edp05.
ENDLOOP.

data(LIT_IDoc) = idoc_data[].
CLEAR Lv_tabix.
LOOP AT idoc_data[] ASSIGNING FIELD-SYMBOL(<idoc_data>) WHERE segnam = 'E1EDP01'.
   lv_tabix = lv_tabix + 1.
  lwa_E1EDP01 = <idoc_data>-sdata.
  data(lv_position_temp) = lwa_E1EDP01-posex.
  data(lv_position) = lv_position_temp / 10.


      Loop at xkomv[] ASSIGNING FIELD-SYMBOL(<Fs_xkomv>) where posnr = lv_tabix.      "lv_position.
        LOOP AT LIT_IDoc ASSIGNING FIELD-SYMBOL(<idoc_data05>) WHERE segnam = 'E1EDP05'.
             lwa_e1edp05 = <idoc_data05>-sdata.
                 if lwa_e1edp05-kschl = <Fs_xkomv>-kschl.
                    <Fs_xkomv>-kbetr = lwa_e1edp05-kobtr.
                    xkomv-kbetr = <Fs_xkomv>-kbetr.
                    delete LIT_IDoc INDEX sy-tabix.
                    exit.
                 ENDIF.
        ENDLOOP.
      clear:lwa_e1edp05.
      ENDLOOP.
ENDLOOP.

ENDENHANCEMENT.
