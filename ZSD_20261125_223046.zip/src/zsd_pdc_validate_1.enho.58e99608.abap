"Name: \PR:SAPLV60A\EX:RV_INVOICE_DOCUMENT_ADD_14\EN:EI_EDOCUMENT_PREPARATION\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_PDC_VALIDATE_1.
  DATA : ls_struc TYPE zsd_pdc_block.
  CLEAR : ls_struc.
*  CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
*    EXPORTING
*      input         = xvbrk-kunag
*   IMPORTING
*     OUTPUT        = xvbrk-kunag.

  SELECT SINGLE * FROM zsd_pdc_block INTO ls_struc
           WHERE kunnr = xvbrk-kunag.
    IF sy-subrc = 0.
      MESSAGE 'Customer blocked since more than 3 bounced cheques found' TYPE 'E'.
      ELSE.
        CALL FUNCTION 'CONVERSION_EXIT_ALPHA_INPUT'
          EXPORTING
            input         = xvbrk-kunag
         IMPORTING
           OUTPUT        = xvbrk-kunag.
    ENDIF.
ENDENHANCEMENT.
