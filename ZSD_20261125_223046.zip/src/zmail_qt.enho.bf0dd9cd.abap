"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT\SE:END\EI
ENHANCEMENT 0 ZMAIL_QT.
*
  data: wa_auart_s TYPE ZTSD_QUOTAT_DOC,
        it_rec TYPE STANDARD TABLE OF ZTSD_QUOTAT_APP,
        wa_rec TYPE ZTSD_QUOTAT_APP.

  if sy-tcode = 'VA21'.

   SELECT SINGLE * FROM ZTSD_QUOTAT_DOC INTO wa_auart_s WHERE auart = vbak-auart.
     if sy-subrc = 0.
    SELECT * FROM ZTSD_QUOTAT_APP INTO TABLE it_rec WHERE APPLEV = '1'.

  DATA: lt_mailsubject     TYPE sodocchgi1.
  DATA: lt_mailrecipients  TYPE STANDARD TABLE OF somlrec90 WITH HEADER LINE.
  DATA: lt_mailtxt         TYPE STANDARD TABLE OF soli      WITH HEADER LINE.

  TYPES: BEGIN OF lty_cc,
          email_id TYPE ad_smtpadr,
         END OF lty_cc.
  DATA: lt_cc_id TYPE STANDARD TABLE OF lty_cc,
        lw_cc_id TYPE lty_cc,
        lv_char(10) TYPE c,
        lw_address TYPE bapiaddr3,
        lt_return2 TYPE STANDARD TABLE OF bapiret2,
        lv_qstn(255) TYPE c,
        lv_answer TYPE c.



  CLEAR: lt_mailsubject, lt_mailrecipients[], lt_mailrecipients,
         lt_mailtxt[], lt_mailtxt, lt_cc_id[],lw_address,lt_return2,
         lt_return2[].

LOOP at it_rec INTO wa_rec.

  CALL FUNCTION 'BAPI_USER_GET_DETAIL'
    EXPORTING
      username      = wa_rec-appid
      cache_results = 'X'
    IMPORTING
      address       = lw_address
    TABLES
      return        = lt_return2.

  lt_mailrecipients-rec_type  = 'U'.
  lt_mailrecipients-receiver = lw_address-e_mail.
*  lt_mailrecipients-copy = 'X'.
  APPEND lt_mailrecipients .
  CLEAR lt_mailrecipients .

ENDLOOP.

* Subject.
  lt_mailsubject-obj_name = 'Request for Quotation Approval/Rejection'.
  lt_mailsubject-obj_langu = sy-langu.
  CONCATENATE 'Quotation' vbak-vbeln 'Approval/Rejection Request'
  INTO lt_mailsubject-obj_descr SEPARATED BY ' '.


  lt_mailtxt = 'Dear Sir / Madam,'.
  APPEND lt_mailtxt. CLEAR lt_mailtxt.
  CONCATENATE 'Please login to the system to approve/reject the quotation number' vbak-vbeln 'for first level.'
  INTO lt_mailtxt SEPARATED BY ' '.

  APPEND lt_mailtxt. CLEAR lt_mailtxt.
  CONCATENATE '' ''
  INTO lt_mailtxt SEPARATED BY ' '.
  APPEND lt_mailtxt. CLEAR lt_mailtxt.
  lt_mailtxt = 'This is system generated mail please do not reply.'.
  APPEND lt_mailtxt. CLEAR lt_mailtxt.

sy-uname = 'WF-BATCH'.
* Send Mail
  CALL FUNCTION 'SO_NEW_DOCUMENT_SEND_API1'
    EXPORTING
      document_data              = lt_mailsubject
    TABLES
      object_content             = lt_mailtxt
      receivers                  = lt_mailrecipients
    EXCEPTIONS
      too_many_receivers         = 1
      document_not_sent          = 2
      document_type_not_exist    = 3
      operation_no_authorization = 4
      parameter_error            = 5
      x_error                    = 6
      enqueue_error              = 7
      OTHERS                     = 8.
  IF sy-subrc EQ 0.
    COMMIT WORK.
    MESSAGE s398(00) WITH 'Workflow initiated successfully'.
  ENDIF.

     endif.
endif.

ENDENHANCEMENT.
