"Name: \PR:SAPMV45A\FO:USEREXIT_NEW_PRICING_VBKD\SE:BEGIN\EI
ENHANCEMENT 0 ZENH_RET_PRICING.
*&--------------------Modification Log-----------------
*Date       : 11.07.2017
*Programmer : Ravindran
*TR No.     : DR1K933615
*Description: Call Pricing type when executing ZSD_SALE_RETURN

* 11.01.2021  Bhagavan     DR1K955427      Added Committed Date mandat Code      *
*&-----------------------------------------------------
 "Memory ID is exported from program ZSD_SALE_RETURN
    DATA : lv_reprice TYPE knprs.
    IMPORT lv_reprice FROM MEMORY ID 'LV_REPRICE'.
    IF NOT lv_reprice IS INITIAL
       AND sy-subrc IS INITIAL.
       new_pricing = lv_reprice.
    ENDIF.

*&---------------------------------------------------------------------*
*& Developer                   : Ravindran
*& Created On                  : 12.07.2017
*& Title                       : Pass batch for Free Goods
*& Request Key to Prod         : DR1K934232
*&---------------------------------------------------------------------*
DATA : LV_VA01 TYPE SYST_TCODE VALUE 'VA01',
       LV_VA02 TYPE SYST_TCODE VALUE 'VA02',
       LV_VA03 TYPE SYST_TCODE VALUE 'VA03'.

IF SY-TCODE EQ LV_VA01 OR SY-TCODE EQ LV_VA02 OR SY-TCODE EQ LV_VA03.

DATA : LT_VBAP TYPE TABLE OF vbapvb,
       LS_VBAP TYPE vbapvb,
       lt_bdbatch TYPE TABLE OF bdbatch,
       lw_bdbatch TYPE bdbatch,
       lt_mdva  TYPE TABLE OF mdva,
       lw_komkh TYPE komkh,
       lw_komph TYPE komph,
       lw_bdcom TYPE BDCOM,
       lv_meins TYPE meins,
       lw_t683c TYPE t683c,
       lv_mtvfp TYPE mtvfp,
       lv_kwmeng TYPE KWMENG,
       LT_MCHB TYPE TABLE OF MCHB,
       LS_MCHB TYPE MCHB,
       LV_POSNR TYPE POSNR_VA,
       LV_POSNR1 TYPE POSNR_VA.

  CONSTANTS : c_1 TYPE c VALUE 1.
  LT_VBAP[] = XVBAP[].
  LV_POSNR1 = 000010.
  LOOP AT XVBAP.
   IF XVBAP-PSTYV EQ 'TANN'.
     CLEAR : LV_POSNR.
     LV_POSNR = XVBAP-POSNR - LV_POSNR1.
     READ TABLE LT_VBAP INTO LS_VBAP WITH KEY MATNR = XVBAP-MATNR
                                              PSTYV = 'YTAN'
                                              POSNR = LV_POSNR.
     IF SY-SUBRC EQ 0.
      XVBAP-CHARG = LS_VBAP-CHARG.
      MODIFY XVBAP.
      new_pricing = 'B'.
     ENDIF.
   ENDIF.
  ENDLOOP.

ENDIF.

*****************Begin of changes by Bhagavan on 05/1/2021 DR1K955427******************

    IF ( SY-TCODE = 'VA01') AND ( SY-UCOMM = 'SICH' OR SY-UCOMM = 'OPT1' ) .
      CONSTANTS : GC_SALES1  VALUE 'ZSD_SALES_KPI' TYPE SOBJ_NAME.
      DATA : GT_CONSTANTS1 TYPE ZTT_ZTABAP_TVARVC,
            LV_FLAGC TYPE CHAR1,
            LV_FLAGC1 TYPE CHAR1.
      CALL METHOD ZCL_ABAP_UTILITY=>GET_OPTIONS
      EXPORTING
        IM_OBJNAME = GC_SALES1
      IMPORTING
        EX_TAB     = GT_CONSTANTS1.
      LOOP AT GT_CONSTANTS1 INTO DATA(GS_CONSTANTS1).
        IF  VBAK-VKORG EQ  GS_CONSTANTS1-LOW .
          LV_FLAGC = 'X'.
        ENDIF.
        IF  VBAK-AUART EQ  GS_CONSTANTS1-LOW .
          LV_FLAGC1 = 'X'.
        ENDIF.
      ENDLOOP.
      IF LV_FLAGC = 'X' AND LV_FLAGC1 = 'X' .
        DATA : LV_MESSAGE TYPE CHAR30.
        LOOP AT  XVBAP INTO DATA(WA_XVBAP).

          IF WA_XVBAP-COMMIT_DATE IS INITIAL.
            MESSAGE E005(zsd_messages) WITH 'Please Enter Committed Date' && ` ` && 'in Additional Data B'.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.
*****************End of changes by Bhagavan on 05/1/2021 DR1K955427******************


ENDENHANCEMENT.
