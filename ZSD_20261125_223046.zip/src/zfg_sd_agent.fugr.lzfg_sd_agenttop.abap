FUNCTION-POOL ZFG_SD_AGENT.                 "MESSAGE-ID ..

* INCLUDE LZFG_SD_AGENTD...                  " Local class definition
