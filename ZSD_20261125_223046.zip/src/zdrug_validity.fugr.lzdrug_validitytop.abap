FUNCTION-POOL ZDRUG_VALIDITY             MESSAGE-ID SV.

* INCLUDE LZDRUG_VALIDITYD...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDRUG_VALIDITYT00                      . "view rel. data dcl.
