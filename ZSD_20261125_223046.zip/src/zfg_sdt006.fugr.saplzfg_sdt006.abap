*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_SDT006TOP.                    " Global Data
  INCLUDE LZFG_SDT006UXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_SDT006F...                    " Subroutines
* INCLUDE LZFG_SDT006O...                    " PBO-Modules
* INCLUDE LZFG_SDT006I...                    " PAI-Modules
* INCLUDE LZFG_SDT006E...                    " Events
* INCLUDE LZFG_SDT006P...                    " Local class implement.
* INCLUDE LZFG_SDT006T99.                    " ABAP Unit tests
  INCLUDE LZFG_SDT006F00                          . " subprograms
  INCLUDE LZFG_SDT006I00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
