*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZDIS_STORE_COND
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZDIS_STORE_COND     .

  PERFORM TABLEPROC.

ENDFUNCTION.
