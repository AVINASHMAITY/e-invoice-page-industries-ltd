"Name: \PR:SAPLV60A\FO:BEDINGUNG_PRUEFEN_003\SE:END\EI
ENHANCEMENT 0 ZSD_DEPOT_INVOICE.
If LIKP-VKORG =  '1101'.
DATA: V_WERKS type LIPS-WERKS .
DATA: V_werks1 type J_1IWRKCUS-J_1IWERKS.
DATA: V_vbeln type likp-vbeln.
select single werks from lips INto v_werks where VBELN = likp-vbeln.
if sy-subrc = 0.
 select single J_1IWERKS from J_1IWRKCUS INTO V_WERKS1 where J_1IWERKS = V_WERKS
                                                   and   J_1IDEPOT  = 'X'.
 if sy-subrc = 0.
   select single VBELN  from J_1IRG23D INTO v_vbeln where vbeln = likp-vbeln.
   if sy-subrc ne 0.
     MESSAGE 'Invoice cannot be created as Depot excise invoice is not created' type 'E'.
   endif.
  else.
    clear sy-subrc.
 endif.
endif.
endif.
ENDENHANCEMENT.
