FUNCTION-POOL ZCYG_SYGN_SEZ              MESSAGE-ID SV.

* INCLUDE LZCYG_SYGN_SEZD...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZCYG_SYGN_SEZT00                       . "view rel. data dcl.
