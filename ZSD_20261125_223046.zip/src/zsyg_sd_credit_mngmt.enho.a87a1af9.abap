"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSYG_SD_CREDIT_MNGMT.
*& Begin of code 20-Nov-2017
*& SAP_KARTHM / JKT
*& DR1K937121
*&  Credit Management
CALL METHOD zcl_syg_sd_implicit_eh=>check_credit_management
  EXPORTING
    iv_vbak = vbak.
*& End of code 20-Nov-2017.
ENDENHANCEMENT.
