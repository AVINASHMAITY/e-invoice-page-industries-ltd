*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZBAS_ATTACHMENT
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZBAS_ATTACHMENT     .

  PERFORM TABLEPROC.

ENDFUNCTION.
