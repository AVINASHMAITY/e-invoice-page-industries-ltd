"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAK\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_VBAK.
*----------------------------------------------------------------------*
*Implementetaion   : ZSD_VBAK                                          *
*Created on        : 29.11.2021                                        *
*Developer         : Sudhakar.C/Iteanz                                 *
*Functional        : Rajasekar                                         *
*Transport         : DR1K962228                                        *
*Description       : Validation in VA01 VA02 for sales order currency  *
*                    Based on customer                                 *
*----------------------------------------------------------------------*
constants : lc__va01  type syst_tcode value 'VA01',
            lc__va02  type syst_tcode value 'VA02'.
IF sy-tcode eq lc__va01 OR sy-tcode eq lc__va02.

  constants : lc_prog      type sobj_name value 'ZSYG_SD_SO_VALID',
              lc_name  TYPE SOBJ_NAME value 'S_SO_VKORG_SYG',
              lc_ecx_name  TYPE SOBJ_NAME value 'S_SO_EXC_AUART_SYG'.
  data : lt_cons type ztt_ztabap_tvarvc,
         lw_cons type ztabap_tvarvc,
         waers TYPE knvv-waers.

  clear : lw_cons.
  call method zcl_abap_utility=>get_options
    exporting
      im_objname = lc_prog
    importing
      ex_tab     = lt_cons.

  IF lt_cons[] IS NOT INITIAL.
   IF sy-tcode eq lc__va01.
    READ TABLE lt_cons INTO lw_cons with KEY name = lc_name LOW = vbak-vkorg.
      IF sy-subrc = 0.
      SELECT SINGLE waers FROM knvv INTO waers WHERE kunnr = vbak-kunnr AND vkorg = vbak-vkorg
        AND vtweg = vbak-vtweg AND spart = vbak-spart.
        IF sy-subrc = 0 and waers IS NOT INITIAL.
          CLEAR lw_cons.
          READ TABLE lt_cons INTO lw_cons WITH KEY name = lc_ecx_name low = vbak-auart.
          IF sy-subrc = 4.
            IF vbak-waerk ne waers.
               MESSAGE e087(zsd_messages).
            ENDIF.
          endif.
        ENDIF.
      ENDIF.
    ELSEIF sy-tcode eq lc__va02.
      READ TABLE lt_cons INTO lw_cons with KEY name = lc_name LOW = vbak-vkorg.
      IF sy-subrc = 0.
      SELECT SINGLE waers FROM knvv INTO waers WHERE kunnr = vbak-kunnr AND vkorg = vbak-vkorg
        AND vtweg = vbak-vtweg AND spart = vbak-spart.
        IF sy-subrc = 0 and waers IS NOT INITIAL.
          IF *vbak-waerk NE vbak-waerk.
            CLEAR lw_cons.
            READ TABLE lt_cons INTO lw_cons WITH KEY name = lc_ecx_name low = vbak-auart.
            IF sy-subrc = 4.
              IF vbak-waerk ne waers.
                MESSAGE e087(zsd_messages).
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.
   ENDIF.
  CLEAR: lw_cons, waers.
ENDIF.
ENDENHANCEMENT.
