*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZBBL_CONUM......................................*
DATA:  BEGIN OF STATUS_ZBBL_CONUM                    .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZBBL_CONUM                    .
CONTROLS: TCTRL_ZBBL_CONUM
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZBBL_CONUM                    .
TABLES: ZBBL_CONUM                     .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
