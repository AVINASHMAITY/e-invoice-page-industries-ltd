"Name: \PR:SAPMV45A\FO:USEREXIT_COBL_SEND_ITEM\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_WBS_VALIDATE.
************************************************************************
*   Date       Programmer  Client Ref No.     Correction               *
*   26.10.2016  SAISMA                        DR1K929275
* Description   Changing of WBS element Restriction if the Sales order *
*               is Completely Delivered / Partially Processed
************************************************************************
CONSTANTS: lc_va02 TYPE char30 VALUE 'VA02',
           lc_x    TYPE c VALUE 'X',
           lc_b    TYPE fksta VALUE 'B',
           lc_c    TYPE fksta VALUE 'C',
           lc_obj  TYPE char40 VALUE 'MV45AFZZ_SORG'.

DATA: lw_vbfa TYPE vbfa,
      lv_flag TYPE c,
      lw_vbup TYPE vbup,
      lt_cons TYPE ztt_ztabap_tvarvc,
      lw_cons TYPE ztabap_tvarvc.

FIELD-SYMBOLS <lfs_cobl> TYPE coblf.

IF  sy-tcode = lc_va02.

  IF lt_cons[] IS INITIAL.
    REFRESH lt_cons[].
    CALL METHOD zcl_abap_utility=>get_options
      EXPORTING
        im_objname = lc_obj
      IMPORTING
        ex_tab     = lt_cons.
  ENDIF.

  CLEAR lw_cons.
  READ TABLE lt_cons INTO lw_cons WITH KEY low = vbak-vkorg.

  IF sy-subrc EQ 0.
    CLEAR: lw_vbfa, lv_flag, lw_vbup.
    SELECT SINGLE * FROM vbfa INTO lw_vbfa WHERE vbelv EQ vbap-vbeln
                                           AND   posnv EQ vbap-posnr.

    IF sy-subrc EQ 0.

      SELECT SINGLE * FROM vbup INTO lw_vbup WHERE vbeln EQ vbap-vbeln
                                             AND   posnr EQ vbap-posnr.

      IF lw_vbup-fksta EQ lc_b OR lw_vbup-fksta EQ lc_c.
        lv_flag = lc_x.
      ENDIF.

      IF lw_vbup-fksaa EQ lc_b OR lw_vbup-fksaa EQ lc_c.
        lv_flag = lc_x.
      ENDIF.

      IF lw_vbup-lfsta EQ lc_b OR lw_vbup-lfsta EQ lc_c.
        lv_flag = lc_x.
      ENDIF.

      IF lv_flag EQ lc_x.
        LOOP AT int_coblf ASSIGNING <lfs_cobl> WHERE fdnam EQ 'PS_PSP_PNR'.
          <lfs_cobl>-input = '0'.
        ENDLOOP.

      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
