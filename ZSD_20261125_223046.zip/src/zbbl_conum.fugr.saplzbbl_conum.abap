*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBBL_CONUMTOP.                    " Global Data
  INCLUDE LZBBL_CONUMUXX.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBBL_CONUMF...                    " Subroutines
* INCLUDE LZBBL_CONUMO...                    " PBO-Modules
* INCLUDE LZBBL_CONUMI...                    " PAI-Modules
* INCLUDE LZBBL_CONUME...                    " Events
* INCLUDE LZBBL_CONUMP...                    " Local class implement.
* INCLUDE LZBBL_CONUMT99.                    " ABAP Unit tests
  INCLUDE LZBBL_CONUMF00                          . " subprograms
  INCLUDE LZBBL_CONUMI00                          . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
