*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_VENDORTOP.                   " Global Data
  INCLUDE LZCYG_VENDORUXX.                   " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_VENDORF...                   " Subroutines
* INCLUDE LZCYG_VENDORO...                   " PBO-Modules
* INCLUDE LZCYG_VENDORI...                   " PAI-Modules
* INCLUDE LZCYG_VENDORE...                   " Events
* INCLUDE LZCYG_VENDORP...                   " Local class implement.
* INCLUDE LZCYG_VENDORT99.                   " ABAP Unit tests
  INCLUDE LZCYG_VENDORF00                         . " subprograms
  INCLUDE LZCYG_VENDORI00                         . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
