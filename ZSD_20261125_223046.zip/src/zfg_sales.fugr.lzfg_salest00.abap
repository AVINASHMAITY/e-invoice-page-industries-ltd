*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZSD_APPROVERS...................................*
DATA:  BEGIN OF STATUS_ZSD_APPROVERS                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZSD_APPROVERS                 .
CONTROLS: TCTRL_ZSD_APPROVERS
            TYPE TABLEVIEW USING SCREEN '0005'.
*.........table declarations:.................................*
TABLES: *ZSD_APPROVERS                 .
TABLES: ZSD_APPROVERS                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
