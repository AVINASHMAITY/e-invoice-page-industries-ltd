*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTSD_QUOTAPPROVL................................*
DATA:  BEGIN OF STATUS_ZTSD_QUOTAPPROVL              .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTSD_QUOTAPPROVL              .
CONTROLS: TCTRL_ZTSD_QUOTAPPROVL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZTSD_QUOTAPPROVL              .
TABLES: ZTSD_QUOTAPPROVL               .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
