*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZBPI_CUSTGRPTOP.                  " Global Data
  INCLUDE LZBPI_CUSTGRPUXX.                  " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZBPI_CUSTGRPF...                  " Subroutines
* INCLUDE LZBPI_CUSTGRPO...                  " PBO-Modules
* INCLUDE LZBPI_CUSTGRPI...                  " PAI-Modules
* INCLUDE LZBPI_CUSTGRPE...                  " Events
* INCLUDE LZBPI_CUSTGRPP...                  " Local class implement.
* INCLUDE LZBPI_CUSTGRPT99.                  " ABAP Unit tests
  INCLUDE LZBPI_CUSTGRPF00                        . " subprograms
  INCLUDE LZBPI_CUSTGRPI00                        . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
