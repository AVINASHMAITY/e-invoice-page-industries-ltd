"Name: \PR:SAPLV60A\EX:RV_INVOICE_DOCUMENT_ADD_14\EI
ENHANCEMENT 0 ZSD_PDC_VALIDATE.
*  DATA : ls_zsd_pdc_block TYPE zsd_pdc_block.
*  CLEAR : ls_zsd_pdc_block.
*  SELECT * FROM zsd_pdc_block INTO ls_zsd_pdc_block
*           WHERE kunnr = vbrk-KUNAG.
*    IF ls_zsd_pdc_block IS NOT INITIAL.
*      MESSAGE 'Customer blocked since more than 3 bounced cheques found' TYPE 'E'.
*    ENDIF.
ENDENHANCEMENT.
