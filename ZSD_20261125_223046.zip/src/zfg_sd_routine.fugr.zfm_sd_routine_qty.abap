FUNCTION ZFM_SD_ROUTINE_QTY.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(LV_KWERT) TYPE  KWERT OPTIONAL
*"     REFERENCE(LV_KWMENG) TYPE  KWMENG OPTIONAL
*"  EXPORTING
*"     REFERENCE(LV_RESULT) TYPE  KBETR
*"----------------------------------------------------------------------
DATA : lv_temp TYPE p DECIMALS 5.
  DATA : lv_char1 TYPE char15,
         lv_char2 TYPE char15,
         lv_char3(6) type P DECIMALS 2,"char15,
         lv_char5(6) type P DECIMALS 3,"char15,
         lv_char6(6) type P DECIMALS 4,"char15,
*         lv_char3(6) type P DECIMALS 2,"char15,
         lv_char4 TYPE KBETR ."P DECIMALS 0.
break sahoo.
data : lv_kwert1  type kwert,
       lv_kwmeng1 type kwmeng .

       lv_kwert1 = lv_kwert.
       lv_kwmeng1 = lv_kwmeng.

       if lv_kwmeng1  is not INITIAL.
       lv_temp =   lv_kwert1 / lv_kwmeng1.
*       lv_char3 = lv_temp.
       lv_char6 = lv_temp.
       lv_char5 = lv_char6.
       lv_char3 = lv_char5.
*   SPLIT lv_char1 AT '.' INTO lv_char2 lv_char3.
*    CONDENSE : lv_char2, lv_char3.
*    CLEAR lv_char1.
*    lv_char1 = lv_char3(2).
*    CONDENSE lv_char1.
*    CLEAR lv_char3.
*    CONCATENATE lv_char2 lv_char1 INTO lv_char3 SEPARATED BY '.'.

   LV_RESULT  =  lv_char3.
    endif.

ENDFUNCTION.
