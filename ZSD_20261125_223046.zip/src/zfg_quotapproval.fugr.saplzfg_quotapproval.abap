*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFG_QUOTAPPROVALTOP.              " Global Data
  INCLUDE LZFG_QUOTAPPROVALUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_QUOTAPPROVALF...              " Subroutines
* INCLUDE LZFG_QUOTAPPROVALO...              " PBO-Modules
* INCLUDE LZFG_QUOTAPPROVALI...              " PAI-Modules
* INCLUDE LZFG_QUOTAPPROVALE...              " Events
* INCLUDE LZFG_QUOTAPPROVALP...              " Local class implement.
* INCLUDE LZFG_QUOTAPPROVALT99.              " ABAP Unit tests
  INCLUDE LZFG_QUOTAPPROVALF00                    . " subprograms
  INCLUDE LZFG_QUOTAPPROVALI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
