*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZEI_STATE_CODE..................................*
DATA:  BEGIN OF STATUS_ZEI_STATE_CODE                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZEI_STATE_CODE                .
CONTROLS: TCTRL_ZEI_STATE_CODE
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZEI_STATE_CODE                .
TABLES: ZEI_STATE_CODE                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
