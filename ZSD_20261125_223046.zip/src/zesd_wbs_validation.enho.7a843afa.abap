"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:BEGIN\EI
ENHANCEMENT 0 ZESD_WBS_VALIDATION.
************************************************************************
*   Date       Programmer  Client Ref No.     Correction               *
*   26.10.2016  SAISMA                        DR1K929275
* Description   Changing of WBS element Restriction if the Sales order *
*               is Completely Delivered / Partially Processed
************************************************************************
DATA: lw_vbfa TYPE vbfa,
      lv_flag TYPE c,
      lt_cons TYPE ztt_ztabap_tvarvc,
      lw_cons TYPE ztabap_tvarvc.

CONSTANTS: lc_va02 TYPE char30 VALUE 'VA02',
           lc_x    TYPE c      VALUE 'X',
           lc_b    TYPE fksta  VALUE 'B',
           lc_c    TYPE fksta  VALUE 'C',
           lc_obj  TYPE char40 VALUE 'MV45AFZZ_SORG'.

IF  sy-tcode = lc_va02.

  IF lt_cons[] IS INITIAL.
    REFRESH lt_cons[].
    CALL METHOD zcl_abap_utility=>get_options
      EXPORTING
        im_objname = lc_obj
      IMPORTING
        ex_tab     = lt_cons.
  ENDIF.

  CLEAR lw_cons.
  READ TABLE lt_cons INTO lw_cons WITH KEY low = vbak-vkorg.

  IF sy-subrc EQ 0.
    CLEAR: lw_vbfa, lv_flag.
    SELECT SINGLE * FROM vbfa INTO lw_vbfa WHERE vbelv = vbap-vbeln
                                           AND   posnv = vbap-posnr.

    IF sy-subrc EQ 0 AND screen-name = 'VBAP-PS_PSP_PNR'.

      IF vbup-fksta EQ lc_b OR vbup-fksta EQ lc_c.
        lv_flag = lc_x.
      ENDIF.

      IF vbup-fksaa EQ lc_b OR vbup-fksaa EQ lc_c.
        lv_flag = lc_x.
      ENDIF.

      IF vbup-lfsta EQ lc_b OR vbup-lfsta EQ lc_c.
        lv_flag = lc_x.
      ENDIF.

      IF lv_flag EQ lc_x.
        screen-input = '0' . "WILL DISPLAY ONLY
        MODIFY SCREEN.
      ENDIF.
    ENDIF.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
