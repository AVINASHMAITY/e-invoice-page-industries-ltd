FUNCTION zfm_sd_interger_round_to_pack.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_KWERT1) TYPE  KWERT OPTIONAL
*"     REFERENCE(I_KWERT2) TYPE  KWERT OPTIONAL
*"  EXPORTING
*"     REFERENCE(E_KWERT) TYPE  KWERT
*"----------------------------------------------------------------------
  DATA : lv_temp TYPE p DECIMALS 5.
  DATA : lv_char1 TYPE char15,
         lv_char2 TYPE char15,
         lv_char3(7) TYPE P DECIMALS 2,
         lv_char4(7) TYPE P DECIMALS 3,
         lv_char5(7) TYPE P DECIMALS 4.
*  break sahoo.
  IF i_kwert2 IS NOT INITIAL.
*    e_kwert  = i_kwert1 / i_kwert2.
    lv_temp = i_kwert1 / i_kwert2.
    lv_char5 = lv_temp.  "lv_char1
    lv_char4 = lv_char5.  "lv_char1
    lv_char3 = lv_char4.  "lv_char1
*    lv_char3 = lv_temp.  "lv_char1
*    SPLIT lv_char1 AT '.' INTO lv_char2 lv_char3.
*    CONDENSE : lv_char2, lv_char3.
*    CLEAR lv_char1.
*    lv_char1 = lv_char3(2).
*    CONDENSE lv_char1.
*    CLEAR lv_char3.
*    CONCATENATE lv_char2 lv_char1 INTO lv_char3 SEPARATED BY '.'.

    e_kwert = lv_char3.


  ENDIF.


ENDFUNCTION.
