"Name: \PR:SAPMV45A\FO:USEREXIT_FIELD_MODIFICATION\SE:BEGIN\EI
ENHANCEMENT 0 ZVA02.
*&--------------------Modification Log---------------------------------*
*Date       : 06.06.2019                                               *
*Programmer : Ravindran                                                *
*TR No.     : DR1K945737                                               *
*Description: Remove Sales Org. 1102 and Add ZCMAIN for BFI            *
*&---------------------------------------------------------------------*
*****************************************************************
* Developer         : Bhagavan/Iteanz
* Changes           : Company code 1400 add For SO block
*
* Transaport        : DR1K955054
*****************************************************************
**********Begin of changes by Ravi on 06.06.2019 DR1K945737*************

CONSTANTS : gc_bfi       VALUE 'ZSD_BFI_VKORG' TYPE sobj_name,
            gc_vkorg(15) VALUE 'BFI_VKORG'.

DATA : gt_vkorg TYPE ztt_ztabap_tvarvc.
TYPES : tt_vkorg TYPE RANGE OF tvko-vkorg.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_bfi
  IMPORTING
    ex_tab     = gt_vkorg.

DATA(ra_vkorg) = VALUE tt_vkorg( FOR gs_vkorg IN gt_vkorg
                  ( sign = 'I'
                    option = 'EQ'
                    low = gs_vkorg-low ) ).
************End of changes by Ravi on 06.06.2019 DR1K945737*************


TABLES : ZAUTH.
*BREAK SAHOO.
DATA   : WA_ZAUTH TYPE ZAUTH,
         IT_ZAUTH LIKE ZAUTH OCCURS 0 WITH HEADER LINE .
DATA   : V_ERNAM TYPE CHAR10.

*IF SY-TCODE = 'VA02' and vbak-bukrs_vf = '1100'.
*If ( SY-TCODE = 'VA01') and ( VBAK-VKORG = '1101' or VBAK-VKORG = '1102').
If ( SY-TCODE = 'VA01') and ( VBAK-VKORG = '1101' or VBAK-VKORG IN ra_vkorg ).   "Added by Ravi on 06.06.2019 DR1K945737 "  OR  sy-tcode = 'ZSD_QUOT_SO' ) 'Zsd_quot_so'Added by Bhagavan on 18.11.2020  DR1K953998
  DATA : i_tab TYPE TABLE OF ZTAB_Va01BLOCK,
       w_tab TYPE          ZTAB_Va01BLOCK,
       i_vbap TYPE TABLE OF vbap,
       v_line_vbap TYPE i,
       v_count     TYPE i.
*  BREAK-POINT.
*  break sahoo.
If VBAK-VBTYP = 'C'.
IF VBAK-SPART is not INITIAL.
  SELECT SINGLE * FROM  ZTAB_Va01BLOCK INTO w_tab WHERE    ZSALES_ORG = vbak-VKORG
                                                    and    ZDIVISION =  vbak-SPART
                                                    and    ZFISCAL_YEAR = SY-datum+0(4)
                                                    and    ZMONTH = SY-DATUM+4(2).
 If sy-subrc ne 0 .
  SELECT SINGLE * FROM  ZTAB_Va01BLOCK INTO w_tab WHERE    ZSALES_ORG = vbak-VKORG
*                                                    and    ZDIVISION =  vbak-VTWEG
                                                    and    ZFISCAL_YEAR = SY-datum+0(4)
                                                    and     ZMONTH = SY-DATUM+4(2).
If sy-subrc = 0.
if w_tab-ZDIVISION is INITIAL.
  if Sy-datum eq w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
  endif.
   if VBak-AUDAT eq w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
   endif.
   if Sy-datum gt w_tab-ZDATE ." and SY-UZEIT ge w_tab-ZTIME.
    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
  endif.
   if VBak-AUDAT gt w_tab-ZDATE ." and SY-UZEIT ge w_tab-ZTIME.
     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
   endif.
endif.
endif.
endif.
else.
  SELECT SINGLE * FROM  ZTAB_Va01BLOCK INTO w_tab WHERE    ZSALES_ORG = vbak-VKORG
*                                                    and    ZDIVISION =  vbak-VTWEG
                                                    and    ZFISCAL_YEAR = SY-datum+0(4)
                                                    and     ZMONTH = SY-DATUM+4(2).
If sy-subrc = 0.
if w_tab-ZDIVISION is INITIAL.
*  if Sy-datum ge w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
*    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
*  endif.
*   if VBak-AUDAT ge w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
*     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
*   endif.
  if Sy-datum eq w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
  endif.
   if VBak-AUDAT eq w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
   endif.
   if Sy-datum gt w_tab-ZDATE ." and SY-UZEIT ge w_tab-ZTIME.
    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
  endif.
   if VBak-AUDAT gt w_tab-ZDATE ." and SY-UZEIT ge w_tab-ZTIME.
     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
   endif.
endif.
endif.
endif.
endif.
if VBAP-VGBEL is not INITIAL.
  SELECT SINGLE * FROM  ZTAB_Va01BLOCK INTO w_tab WHERE    ZSALES_ORG = vbak-VKORG
*                                                    and    ZDIVISION =  vbak-VTWEG
                                                    and    ZFISCAL_YEAR = SY-datum+0(4)
                                                    and     ZMONTH = SY-DATUM+4(2).
if sy-subrc = 0.
if w_tab-ZDIVISION is INITIAL.
*  if Sy-datum ge w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
*    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
*  endif.
*   if VBak-AUDAT ge w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
*     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
*   endif.
  if Sy-datum eq w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
  endif.
   if VBak-AUDAT eq w_tab-ZDATE  and SY-UZEIT ge w_tab-ZTIME.
     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
   endif.
   if Sy-datum gt w_tab-ZDATE ." and SY-UZEIT ge w_tab-ZTIME.
    MESSAGE 'Sales order creation closed for the current period' Type 'E'.
  endif.
   if VBak-AUDAT gt w_tab-ZDATE ." and SY-UZEIT ge w_tab-ZTIME.
     MESSAGE 'Sales order creation closed for the current period' Type 'E'.
   endif.
endif.
endif.
endif.
endif.
IF  ( SY-TCODE = 'VA02' or sy-TCODE = 'VA01')"  OR  sy-tcode = 'ZSD_QUOT_SO' ) " 'Zsd_quot_so'Added by Bhagavan on 18.11.2020  DR1K953998
  and ( vbak-bukrs_vf = '1100'  or vbak-bukrs_vf = '1400' ).                 " '1400'Added by Bhagavan on 14.12.2020  DR1K955054
  IF SCREEN-NAME = 'VBAK-FAKSK' and ( VBAK-FAKSK = '08' or  VBAK-FAKSK = '09' )
    or ( SCREEN-NAME = 'VBAK-LIFSK' AND VBAK-LIFSK = 'Z1' ).
      SELECT SNO
             VKORG
             VTWEG
             AUART
             USERID
             UNAME
        FROM ZAUTH
        INTO TABLE IT_ZAUTH
        WHERE USERID = SY-UNAME
        AND  VKORG = VBAK-VKORG
        AND  VTWEG = VBAK-VTWEG
        AND  AUART = VBAK-AUART.
        IF sy-subrc = 0.
          SCREEN-INPUT = '1' .
          MODIFY SCREEN.
       ELSE.
          SCREEN-INPUT = '0' . "WILL DISPLAY ONLY
          MODIFY SCREEN.
       ENDIF.
        ENDIF.
endif.
 IF T180-TRTYP EQ 'A' .
 if screen-name eq 'VBAP-COMMIT_DATE' .
  SCREEN-input = '0'.
  MODIFY SCREEN .
 ENDIF.
 ENDIF.
ENDENHANCEMENT.
