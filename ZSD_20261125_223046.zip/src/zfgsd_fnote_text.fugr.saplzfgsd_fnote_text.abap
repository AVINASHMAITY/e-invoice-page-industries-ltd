*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGSD_FNOTE_TEXTTOP.              " Global Data
  INCLUDE LZFGSD_FNOTE_TEXTUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGSD_FNOTE_TEXTF...              " Subroutines
* INCLUDE LZFGSD_FNOTE_TEXTO...              " PBO-Modules
* INCLUDE LZFGSD_FNOTE_TEXTI...              " PAI-Modules
* INCLUDE LZFGSD_FNOTE_TEXTE...              " Events
* INCLUDE LZFGSD_FNOTE_TEXTP...              " Local class implement.
* INCLUDE LZFGSD_FNOTE_TEXTT99.              " ABAP Unit tests
  INCLUDE LZFGSD_FNOTE_TEXTF00                    . " subprograms
  INCLUDE LZFGSD_FNOTE_TEXTI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
