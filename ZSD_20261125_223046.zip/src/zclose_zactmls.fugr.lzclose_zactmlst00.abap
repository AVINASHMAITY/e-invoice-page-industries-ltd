*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZCLOSE_ZACTMLS..................................*
DATA:  BEGIN OF STATUS_ZCLOSE_ZACTMLS                .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZCLOSE_ZACTMLS                .
CONTROLS: TCTRL_ZCLOSE_ZACTMLS
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZCLOSE_ZACTMLS                .
TABLES: ZCLOSE_ZACTMLS                 .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
