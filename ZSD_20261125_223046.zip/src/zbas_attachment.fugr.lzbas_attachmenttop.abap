FUNCTION-POOL ZBAS_ATTACHMENT            MESSAGE-ID SV.

* INCLUDE LZBAS_ATTACHMENTD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZBAS_ATTACHMENTT00                     . "view rel. data dcl.
