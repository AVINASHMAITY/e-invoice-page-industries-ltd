FUNCTION zfm_sd_cvd_round.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IM_PER) TYPE  KWERT OPTIONAL
*"     REFERENCE(IM_BASE) TYPE  KWERT OPTIONAL
*"  EXPORTING
*"     REFERENCE(EX_CVD) TYPE  KWERT
*"----------------------------------------------------------------------
data : lv_per TYPE kbetr.

 lv_per = ( im_per / 10 ).
 ex_cvd = ( ( lv_per * im_base ) / 100 ).


ENDFUNCTION.
