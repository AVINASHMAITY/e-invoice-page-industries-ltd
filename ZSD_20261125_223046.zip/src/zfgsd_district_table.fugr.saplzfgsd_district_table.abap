*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFGSD_DISTRICT_TABLETOP.          " Global Data
  INCLUDE LZFGSD_DISTRICT_TABLEUXX.          " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFGSD_DISTRICT_TABLEF...          " Subroutines
* INCLUDE LZFGSD_DISTRICT_TABLEO...          " PBO-Modules
* INCLUDE LZFGSD_DISTRICT_TABLEI...          " PAI-Modules
* INCLUDE LZFGSD_DISTRICT_TABLEE...          " Events
* INCLUDE LZFGSD_DISTRICT_TABLEP...          " Local class implement.
* INCLUDE LZFGSD_DISTRICT_TABLET99.          " ABAP Unit tests
