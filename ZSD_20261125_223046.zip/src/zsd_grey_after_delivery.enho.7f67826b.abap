"Name: \PR:SAPMV45A\FO:USEREXIT_SAVE_DOCUMENT_PREPARE\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_GREY_AFTER_DELIVERY.
*****************************************************************************
*Created on        : 21.02.2019
*Developer         : Ravindran
*Functional        : Ravi
*Transaport        : DR1K944054
*Description       : Price should not allow after delivery creation
*****************************************************************************
CONSTANTS : gc_checks         VALUE 'ZSD_SALES_CHECKS' TYPE sobj_name,
            gc_vkorg_1101(15) VALUE 'SO_VKORG_1101',
            gc_vkorg_1102(15) VALUE 'SO_VKORG_1102'.
DATA : gt_constant TYPE ztt_ztabap_tvarvc.
RANGES : ra_vkorg_1101 FOR tvko-vkorg,
         ra_vkorg_1102 FOR tvko-vkorg.

TYPES : BEGIN OF ty_vbuk,
          vbeln TYPE vbeln,
          lfstk TYPE lfstk,
        END OF ty_vbuk.

TYPES: BEGIN OF ty_vbup,
         vbeln TYPE vbeln,
         posnr  TYPE posnr,
         lfsta TYPE lfsta,
        END OF ty_vbup.

DATA : ls_vbuk  TYPE ty_vbuk,
       lt_vbup TYPE STANDARD TABLE OF ty_vbup,
       ls_vbup TYPE ty_vbup,
       gt_konv  TYPE TABLE OF konv,
       gs_konv  TYPE konv,
       ls_komv  TYPE komv,
       lt_cond  TYPE TABLE OF zsdt008,
       ls_cond  TYPE zsdt008,
       lv_kbetr TYPE komv-kbetr,
       lv_zfr1  TYPE komv-kbetr,
       lv_zfr2  TYPE komv-kbetr,
       lv_zbas  TYPE komv-kbetr,
       lx_vbap  TYPE vbap,
       lv_err   TYPE c.

CALL METHOD zcl_abap_utility=>get_options
  EXPORTING
    im_objname = gc_checks
  IMPORTING
    ex_tab     = gt_constant.

LOOP AT gt_constant INTO DATA(gw_constant)
                     WHERE obj_name = gc_checks
                       AND name     = gc_vkorg_1101.
  ra_vkorg_1101-sign = 'I'.
  ra_vkorg_1101-option = 'EQ'.
  ra_vkorg_1101-low = gw_constant-low.
  APPEND ra_vkorg_1101." TO RA_1101.
  CLEAR : ra_vkorg_1101.
ENDLOOP.

LOOP AT gt_constant INTO gw_constant
                     WHERE obj_name = gc_checks
                       AND name     = gc_vkorg_1102.
  ra_vkorg_1102-sign = 'I'.
  ra_vkorg_1102-option = 'EQ'.
  ra_vkorg_1102-low = gw_constant-low.
  APPEND ra_vkorg_1102.
  CLEAR : ra_vkorg_1102.
ENDLOOP.

IF sy-tcode EQ 'VA02' OR sy-tcode EQ 'VA03'.
  IF vbak-vbtyp NE 'H'.
*    SELECT SINGLE vbeln lfstk FROM vbuk INTO ls_vbuk WHERE vbeln EQ vbak-vbeln.
    SELECT vbeln posnr lfsta FROM vbup INTO TABLE lt_vbup WHERE vbeln eq vbak-vbeln.
      IF sy-subrc eq 0.
LOOP AT lt_vbup INTO ls_vbup.
    IF ls_vbup-lfsta EQ 'C' AND ls_vbup-posnr = vbap-posnr.
      SELECT * FROM zsdt008 INTO TABLE lt_cond.
      IF vbak-vkorg IN ra_vkorg_1101.
        IF vbak-knumv IS NOT INITIAL.
          SELECT * FROM konv INTO TABLE gt_konv
                   WHERE knumv EQ vbak-knumv.
          IF gt_konv IS NOT INITIAL.
            CLEAR : lv_err.
            LOOP AT xvbap INTO lx_vbap WHERE kwmeng IS NOT INITIAL.
              CLEAR : lv_zbas, lv_kbetr, lv_zfr1, lv_zfr2.
              READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'ZBAS'
                                                      kposn = lx_vbap-posnr.
              IF sy-subrc = 0 .
                lv_zbas = ls_komv-kwert.
                LOOP AT lt_cond INTO ls_cond .
                  READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = ls_cond-kschl
                                                           kposn = lx_vbap-posnr.

                  IF sy-subrc = 0 AND ls_komv-stunr = '100' AND ls_komv-kinak = ''.
                    lv_kbetr = ls_komv-kwert.
                    CLEAR ls_komv.
                    EXIT.
                  ENDIF.
                ENDLOOP.
                READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'ZFR1'
                                                         kposn = lx_vbap-posnr.
                IF sy-subrc = 0.
****************Begin of changes by Ravi on 09.07.2019 DR1K946324*******
*                  lv_zfr1 = ls_komv-kwert.
*                  lv_zfr2 = ls_komv-kwert.
****************End of changes by Ravi on 09.07.2019 DR1K946324*********
                  CLEAR ls_komv.
                  READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'ZFRE'
                                                           kposn = lx_vbap-posnr.
                  IF sy-subrc = 0.
****************Begin of changes by Ravi on 09.07.2019 DR1K946324*******
*                    lv_zfr1 = ls_komv-kwert + lv_zfr1.
****************End of changes by Ravi on 09.07.2019 DR1K946324*********
                    CLEAR ls_komv.
                  ENDIF.
                ENDIF.
                READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'ZMIS'
                                                         kposn = lx_vbap-posnr.
                IF sy-subrc = 0.
                  lv_zfr1  = lv_zfr1 + ls_komv-kwert.
                  CLEAR ls_komv.
                ENDIF.
                lv_kbetr = lv_kbetr + lv_zfr1.
                lv_zbas = lv_zbas - lv_zfr2.
                IF lv_kbetr IS NOT INITIAL AND
                   lv_zbas IS NOT INITIAL.
                  IF lv_kbetr LT lv_zbas.
                    lv_err = 'X'.
                    EXIT.
                  ENDIF.
                ENDIF.
              ENDIF.
              CLEAR : lx_vbap.
            ENDLOOP.
            IF lv_err IS NOT INITIAL.
              CLEAR : lv_err.
              MESSAGE 'Price should not change after delivery creation' TYPE 'E'.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
      IF vbak-vkorg IN ra_vkorg_1102.
        IF vbak-knumv IS NOT INITIAL.
          SELECT * FROM konv INTO TABLE gt_konv
                   WHERE knumv EQ vbak-knumv.
          IF gt_konv IS NOT INITIAL.
            CLEAR : lv_err.
            LOOP AT xvbap INTO lx_vbap WHERE kwmeng IS NOT INITIAL.
              CLEAR : lv_zbas, lv_kbetr, lv_zfr1, lv_zfr2.
              READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'ZBAS'
                                                      kposn = lx_vbap-posnr.
              IF sy-subrc = 0 .
                lv_zbas = ls_komv-kwert.
                LOOP AT lt_cond INTO ls_cond .
                  READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = ls_cond-kschl
                                                           kposn = lx_vbap-posnr.

                  IF sy-subrc = 0 AND ls_komv-kinak = ''.
                    lv_kbetr = ls_komv-kwert.
                    CLEAR ls_komv.
                    EXIT.
                  ENDIF.
                ENDLOOP.
                READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'Z004'
                                          kposn = lx_vbap-posnr.
                IF sy-subrc = 0.
                  lv_kbetr = lv_kbetr + ls_komv-kwert.
                  CLEAR ls_komv.
                ENDIF.
                READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'Z005'
                                                        kposn = lx_vbap-posnr.
                IF sy-subrc = 0.
                  lv_kbetr = lv_kbetr + ls_komv-kwert.
                  CLEAR ls_komv.
                ENDIF.

                READ TABLE xkomv[] INTO ls_komv WITH KEY kschl = 'Z007'
                                                        kposn = lx_vbap-posnr.
                IF sy-subrc = 0.
                  lv_kbetr = lv_kbetr + ls_komv-kwert .
                  CLEAR ls_komv.
                ENDIF.
                IF lv_kbetr IS NOT INITIAL AND
                   lv_zbas IS NOT INITIAL.
                  IF lv_kbetr LT lv_zbas.
                    lv_err = 'X'.
                    EXIT.
                  ENDIF.
                ENDIF.
              ENDIF.
            ENDLOOP.
            IF lv_err IS NOT INITIAL.
              CLEAR : lv_err.
              MESSAGE 'Price should not change after delivery creation' TYPE 'E'.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
       ENDIF.
       ENDLOOP.
    ENDIF.
  ENDIF.
ENDIF.
ENDENHANCEMENT.
