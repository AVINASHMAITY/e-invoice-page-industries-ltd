FUNCTION-POOL ZFG_BANK_DETAILS           MESSAGE-ID SV.

* INCLUDE LZFG_BANK_DETAILSD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_BANK_DETAILST00                    . "view rel. data dcl.
