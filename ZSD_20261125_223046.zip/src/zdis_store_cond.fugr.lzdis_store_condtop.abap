FUNCTION-POOL ZDIS_STORE_COND            MESSAGE-ID SV.

* INCLUDE LZDIS_STORE_CONDD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZDIS_STORE_CONDT00                     . "view rel. data dcl.
