FUNCTION-POOL ZFG_QUOTAPPROVAL           MESSAGE-ID SV.

* INCLUDE LZFG_QUOTAPPROVALD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFG_QUOTAPPROVALT00                    . "view rel. data dcl.
