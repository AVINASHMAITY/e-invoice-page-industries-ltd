class ZCL_IM_SD_LE_SHP_DELI_PROC definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_LE_SHP_DELIVERY_PROC .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_SD_LE_SHP_DELI_PROC IMPLEMENTATION.


  METHOD if_ex_le_shp_delivery_proc~change_delivery_header.
*&------------------------------------------------------------------------------
*Date       : 23.01.2025
*Programmer : Suganya
*TR No.     : DR1K990472
*Description: Enhancment for updating Actual PGI date in Delivery when PGI posted via Job
*             Program: WS_MONITOR_OUTB_DEL_GDSI in backround processing
*&------------------------------------------------------------------------------
    IF sy-cprog = 'WS_MONITOR_OUTB_DEL_GDSI'.
      SELECT SINGLE *
        FROM tvarvc
        INTO @DATA(ls_tvarvc)
       WHERE name = 'ZSD_UPDATE_PGIDATE'
         AND low  = @cs_likp-lfart              "Delivery Type
         AND high = @cs_likp-vstel.             "Shipping Point
      IF sy-subrc = 0.
        SELECT SINGLE vbelv                     "Sales Order
          FROM vbfa
          INTO @DATA(lv_vbelv)
         WHERE vbeln = @cs_likp-vbeln.          "Delivery Number
        IF sy-subrc = 0.
          SELECT SINGLE fkdat                   "Billing Date
            FROM vbkd
            INTO @DATA(lv_fkdat)
           WHERE vbeln = @lv_vbelv.
          IF sy-subrc = 0.
            cs_likp-wadat_ist = lv_fkdat.       "Actual PGI Date
          ENDIF.
        ENDIF.
      ENDIF.
    ENDIF.

    DATA: lt_tline  TYPE STANDARD TABLE OF  tline,
          ls_tline  TYPE tline,
          lv_tdname TYPE thead-tdname,
          lv_date   TYPE sy-datum.

    READ TABLE it_xlips INTO DATA(wa_lips) INDEX 1.
    IF sy-subrc EQ 0 .
      lv_tdname = wa_lips-vgbel.
      SELECT SINGLE auart FROM vbak INTO @DATA(lv_auart)
        WHERE vbeln = @wa_lips-vgbel
          AND vkorg = '2600'.
      IF sy-subrc IS INITIAL.
      IF lv_auart EQ 'ZBMO'  or lv_auart eq 'ZBSH' or lv_auart eq 'ZBDO'
        or lv_auart eq 'ZBFG' or lv_auart eq 'ZBSM' .
        CALL FUNCTION 'READ_TEXT'
          EXPORTING
            client   = sy-mandt
            id       = '0001'
            language = sy-langu
            name     = lv_tdname
            object   = 'VBBK'
*           ARCHIVE_HANDLE                = 0
*           LOCAL_CAT                     = ' '
*       IMPORTING
*           HEADER   =
*           OLD_LINE_COUNTER              =
          TABLES
            lines    = lt_tline
*       EXCEPTIONS
*           ID       = 1
*           LANGUAGE = 2
*           NAME     = 3
*           NOT_FOUND                     = 4
*           OBJECT   = 5
*           REFERENCE_CHECK               = 6
*           WRONG_ACCESS_TO_ARCHIVE       = 7
*           OTHERS   = 8
          .
        IF sy-subrc <> 0.
* Implement suitable error handling here
        ELSE.
          READ TABLE lt_tline INTO DATA(wa_line) INDEX 1.
          IF sy-subrc EQ 0.
            CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
              EXPORTING
                date_external            = wa_line-tdline
*               ACCEPT_INITIAL_DATE      =
              IMPORTING
                date_internal            = lv_date
              EXCEPTIONS
                date_external_is_invalid = 1
                OTHERS                   = 2.
            IF sy-subrc <> 0.
* Implement suitable error handling here
            ENDIF.

            cs_likp-wadat_ist =     lv_date.
            cs_likp-wadat     =     lv_date.

          ENDIF.

        ENDIF.
       ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FCODE_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHANGE_FIELD_ATTRIBUTES.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~CHECK_ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DELIVERY_FINAL_CHECK.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~DOCUMENT_NUMBER_PUBLISH.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_HEADER.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~FILL_DELIVERY_ITEM.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~INITIALIZE_DELIVERY.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~ITEM_DELETION.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~PUBLISH_DELIVERY_ITEM.
  endmethod.


  METHOD if_ex_le_shp_delivery_proc~read_delivery.
  ENDMETHOD.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_BEFORE_OUTPUT.
  endmethod.


  method IF_EX_LE_SHP_DELIVERY_PROC~SAVE_AND_PUBLISH_DOCUMENT.
  endmethod.


  METHOD if_ex_le_shp_delivery_proc~save_document_prepare.
  ENDMETHOD.
ENDCLASS.
