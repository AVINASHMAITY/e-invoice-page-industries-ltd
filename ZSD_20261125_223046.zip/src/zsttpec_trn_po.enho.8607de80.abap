"Name: \FU:/STTPEC/INT_TRN_PROCESS_QRFC\SE:BEGIN\EI
ENHANCEMENT 0 ZSTTPEC_TRN_PO.
 "" Commented on 21/02/2025
*If sy-ucomm = 'WABU_T'.
*DATA:lt_vbeln TYPE RANGE OF vbeln_vl.
*
*LOOP AT it_trn_header INTO DATA(ls_trn_header).
*  APPEND VALUE #( sign = 'I' option = 'EQ' low = ls_trn_header-docnum ) TO lt_vbeln.
*ENDLOOP.
*
*SORT lt_vbeln BY low ASCENDING.
*DELETE ADJACENT DUPLICATES FROM lt_vbeln COMPARING ALL FIELDS.
*
*IF lt_vbeln IS NOT INITIAL.
*  SELECT  vbeln, wadat_ist FROM likp INTO TABLE @DATA(lt_likp) ",zord_category
*    WHERE vbeln IN @lt_vbeln.
*  IF sy-subrc = 0.
*    SORT lt_likp  BY vbeln ASCENDING.
*  ENDIF.
*
*  SELECT  vbeln, vgbel FROM lips INTO TABLE @DATA(lt_lips)
*    WHERE vbeln IN @lt_vbeln.
*  IF sy-subrc = 0.
*    SORT lt_lips BY vgbel ASCENDING.
*  ENDIF.
*
*  SELECT  vbeln, bstkd FROM vbkd INTO TABLE  @DATA(lt_vbkd)
*    FOR ALL ENTRIES IN @lt_lips
*    WHERE vbeln = @lt_lips-vgbel.
*  IF sy-subrc = 0.
*    SORT lt_vbkd BY vbeln ASCENDING.
*  ENDIF.
*  SORT lt_lips BY vbeln ASCENDING.
*ENDIF.
*
*LOOP AT it_trn_header ASSIGNING FIELD-SYMBOL(<fs_trn_header>).
*  READ TABLE lt_likp INTO DATA(ls_likp) WITH KEY vbeln = <fs_trn_header>-docnum.
*  IF sy-subrc = 0.
*    READ TABLE lt_lips INTO DATA(ls_lips) WITH KEY vbeln = <fs_trn_header>-docnum.
*    IF sy-subrc = 0.
*      READ TABLE lt_vbkd INTO DATA(ls_vbkd) WITH KEY vbeln = ls_lips-vgbel.
*      IF sy-subrc = 0.
*        <fs_trn_header>-zzdocnum_po = ls_vbkd-bstkd.
*      ENDIF.
*    ENDIF.
*  ENDIF.
*ENDLOOP.
**ENDIF.
ENDENHANCEMENT.
