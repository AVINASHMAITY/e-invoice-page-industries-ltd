FUNCTION-POOL ZEI_STATE_CODE             MESSAGE-ID SV.

* INCLUDE LZEI_STATE_CODED...                " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZEI_STATE_CODET00                      . "view rel. data dcl.
