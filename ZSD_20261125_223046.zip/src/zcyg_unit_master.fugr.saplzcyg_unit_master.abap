*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZCYG_UNIT_MASTERTOP.              " Global Data
  INCLUDE LZCYG_UNIT_MASTERUXX.              " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZCYG_UNIT_MASTERF...              " Subroutines
* INCLUDE LZCYG_UNIT_MASTERO...              " PBO-Modules
* INCLUDE LZCYG_UNIT_MASTERI...              " PAI-Modules
* INCLUDE LZCYG_UNIT_MASTERE...              " Events
* INCLUDE LZCYG_UNIT_MASTERP...              " Local class implement.
* INCLUDE LZCYG_UNIT_MASTERT99.              " ABAP Unit tests
  INCLUDE LZCYG_UNIT_MASTERF00                    . " subprograms
  INCLUDE LZCYG_UNIT_MASTERI00                    . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules
