FUNCTION-POOL ZFGSD_DISTRICT_T           MESSAGE-ID SV.

* INCLUDE LZFGSD_DISTRICT_TD...              " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFGSD_DISTRICT_TT00                    . "view rel. data dcl.
