class ZCL_CM_DM_ORDER definition
  public
  final
  create public .

public section.

  class-methods GET_FILE_PATH
    importing
      !IV_PATH1 type EPSF-EPSDIRNAM
      !IV_PATH2 type EPSF-EPSDIRNAM
    returning
      value(RV_FILEPATH) type EPSF-EPSDIRNAM .
  class-methods POST_TXT_TO_APP_SERVER
    importing
      !I_READY_PATH type ESEFTAPPL
      !I_FILEDATA type STANDARD TABLE
      !I_HEADER type ANY optional
      !I_DELIMITER type CHAR01 optional
    exporting
      !E_RETURN type BAPIRET2 .
protected section.
private section.
ENDCLASS.



CLASS ZCL_CM_DM_ORDER IMPLEMENTATION.


  method GET_FILE_PATH.
      DATA lv_sysid  TYPE  rfctrust-rfctrustid.
    CALL FUNCTION 'RFC_GET_TRUSTED_SYSTEM_ID'
      IMPORTING
        systemid = lv_sysid.

    CHECK sy-subrc = 0.
    rv_filepath = |{ iv_path1 }{ lv_sysid }{ iv_path2 }|.
  endmethod.


  method POST_TXT_TO_APP_SERVER.
    DATA :
      LT_TABLE     TYPE TRUXS_T_TEXT_DATA.
     " I_READY_PATH TYPE ESEFTAPPL.

    CHECK I_FILEDATA[] IS NOT INITIAL.
    CLEAR : E_RETURN.
    "Convert internal with several fields to internal table of type string
    CALL FUNCTION 'SAP_CONVERT_TO_TEX_FORMAT'
      EXPORTING
        I_FIELD_SEPERATOR    = I_DELIMITER
      TABLES
        I_TAB_SAP_DATA       = I_FILEDATA
      CHANGING
        I_TAB_CONVERTED_DATA = LT_TABLE
      EXCEPTIONS
        CONVERSION_FAILED    = 1
        OTHERS               = 2.
    IF SY-SUBRC IS NOT INITIAL.
      E_RETURN = VALUE #( TYPE = 'E'
                 MESSAGE = 'DATA CONVERSION_FAILED' ).
    ELSE.

*      I_READY_PATH = I_READY_PATH.
*      REPLACE SUBSTRING 'READY' IN I_READY_PATH WITH 'WORK'.

      TRY .
          OPEN DATASET I_READY_PATH FOR OUTPUT IN TEXT MODE ENCODING DEFAULT.
          IF SY-SUBRC IS NOT INITIAL.
            E_RETURN = VALUE #( TYPE = 'E'
                       MESSAGE = |Path does not exist:{ I_READY_PATH }| ).
          ELSE.

            IF I_HEADER IS NOT INITIAL.
              TRANSFER I_HEADER TO I_READY_PATH.
            ENDIF.
            LOOP AT LT_TABLE ASSIGNING FIELD-SYMBOL(<FS_TABLE>).
              TRANSFER <FS_TABLE> TO I_READY_PATH.
            ENDLOOP.
            CLOSE DATASET I_READY_PATH.
            E_RETURN = VALUE #( TYPE = 'S'
                       MESSAGE = |Documents moved to folder:{ I_READY_PATH }| ).

          ENDIF.
        CATCH CX_ROOT INTO DATA(LO_ERR).
          E_RETURN = VALUE #( TYPE = 'E'
                     MESSAGE = LO_ERR->GET_TEXT( ) ).
      ENDTRY.
    ENDIF.
  endmethod.
ENDCLASS.
