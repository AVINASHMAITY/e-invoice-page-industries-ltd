*---------------------------------------------------------------------*
*    view related data declarations
*---------------------------------------------------------------------*
*...processing: ZTSD_FNOTE_TEXT.................................*
DATA:  BEGIN OF STATUS_ZTSD_FNOTE_TEXT               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZTSD_FNOTE_TEXT               .
CONTROLS: TCTRL_ZTSD_FNOTE_TEXT
            TYPE TABLEVIEW USING SCREEN '0002'.
*.........table declarations:.................................*
TABLES: *ZTSD_FNOTE_TEXT               .
TABLES: ZTSD_FNOTE_TEXT                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .
