*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_IBP
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_IBP             .

  PERFORM TABLEPROC.

ENDFUNCTION.
