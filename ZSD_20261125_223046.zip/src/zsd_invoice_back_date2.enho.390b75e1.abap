"Name: \PR:SAPMJ1IIN\FO:USER_COMMAND_150\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_INVOICE_BACK_DATE2.

If Wa_vbrk-vkorg = '1101'.

FIELD-SYMBOLS : <lx_BUDAT> type any.
  ASSIGN ('(SAPMJ1IIN)BKPF-BUDAT') TO <lx_BUDAT>.
*  ASSIGN ('(SAPMV45A)VBAK-VKORG') TO <lx_VKORG>.
if <lx_BUDAT> is ASSIGNED.
  if <lx_BUDAT> is not INITIAL.
    if <lx_BUDAT> ne sy-datum.
     wait UP TO 2 SECONDS.
      MESSAGE 'Invoice is back dated Posting not allowed' type 'I' DISPLAY LIKE 'E'.
      LEAVE to TRANSACTION 'J1IIN'.
    endif.
  endif.
endif.
endif.

ENDENHANCEMENT.
