*---------------------------------------------------------------------*
*    program for:   TABLEPROC_ZFG_SDT006
*---------------------------------------------------------------------*
FUNCTION TABLEPROC_ZFG_SDT006          .

  PERFORM TABLEPROC.

ENDFUNCTION.
