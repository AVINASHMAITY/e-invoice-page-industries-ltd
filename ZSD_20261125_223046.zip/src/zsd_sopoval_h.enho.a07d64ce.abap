"Name: \PR:SAPMV45A\FO:USEREXIT_CHECK_VBAP\SE:BEGIN\EI
ENHANCEMENT 0 ZSD_SOPOVAL_H.

*  DATA: lw_zparam TYPE zparam.
*  DATA: lw_zparam_kunnr TYPE zparam.
*  DATA: lw_vbak   TYPE vbak.
*  DATA: lv_kunnr TYPE zparameter.

*  IF sy-tcode EQ 'VA01' OR sy-tcode EQ 'VA02'.
*    IF vbap IS NOT INITIAL.
*      IF sy-ucomm NE 'HEAD'.
*        CLEAR: lw_zparam.
*        SELECT SINGLE * FROM zparam
*                        INTO lw_zparam
*                        WHERE parameter1 LIKE 'ZSOPOVAL%'
*                        AND   parameter2 EQ   'AUART'
*                        AND   parameter3 EQ vbak-auart.
*        IF sy-subrc = 0.
*          CALL FUNCTION 'CONVERSION_EXIT_ALPHA_OUTPUT'
*            EXPORTING
*              input         =  vbak-kunnr
*            IMPORTING
*              output        = lv_kunnr.
*          SELECT SINGLE * FROM zparam
*                          INTO lw_zparam
*                          WHERE parameter1 EQ lw_zparam-parameter1
*                          AND   parameter2 EQ 'KUNNR'
*                          AND   parameter3 EQ lv_kunnr.
*          IF sy-subrc = 0.
*            IF vbak-zzebeln IS INITIAL.
*              sy-ucomm = 'HEAD'.
*              MESSAGE: 'PO Number in Header Addnl Data B is mandatory' TYPE 'E'.
*            ENDIF.
*          ENDIF.
*        ENDIF.
*      ENDIF.
*    ENDIF.
*  ENDIF.
ENDENHANCEMENT.
